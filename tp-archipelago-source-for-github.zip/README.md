# Twilight Princess Archipelago for Dusklight

Plays [Archipelago](https://archipelago.gg) multiworlds generated with the **Twilight Princess**
apworld (the GameCube/Dolphin world on multiworld.gg, game name `Twilight Princess`) inside
[Dusklight](https://github.com/TwilitRealm/dusklight), the PC port. You do not need Dolphin, the
GameCube patch, or the Python client.

You do not configure anything in game. Your YAML is the configuration: the mod reads your
options from the server, builds the matching seed with the randomizer's own generator, and
starts you in the post-prologue state.

> **Status.** Builds with CMake into `tp_archipelago.dusk` against Dusklight v2.0.3 and has been
> played in the installed game, by a person and by a scripted virtual gamepad, against a real room and
> a local fake one: connect window, seed build, name entry, Ordon in Hero's Clothes, chests reported
> the moment they open, own items with their fanfare, another player's item as the Sol with its owner's
> name, items from the room arriving mid-play, reconnecting, saving and reloading a file, death link,
> the overlay, Transform Anywhere on and off, every region and dungeon loading under the seed, and the
> goal followed by `!collect` and `!release`. See [`docs/TESTING.md`](docs/TESTING.md) for what each
> test shows. **Not played:** Ganondorf's last blow (the goal also has a button and a second trigger,
> see the testing notes), Poe, golden wolf, Sky Character and Agitha checks made by hand (every
> location's check is replayed through the real game and reports correctly), other players in a room. One report is
> open: a Slingshot sent from the room's console once did not reach Link in a real session and could
> not be reproduced; the mod now logs why an item waits.

## Playing

1. Build or obtain `tp_archipelago.dusk` and copy it into Dusklight's mods folder
   (Windows `%APPDATA%\TwilitRealm\Dusklight\mods`, Linux `~/.local/share/TwilitRealm/Dusklight/mods`,
   macOS `~/Library/Application Support/TwilitRealm/Dusklight/mods`). It carries its own copy of
   the randomizer, so Dusklight's built-in Randomizer needs no changes.
2. In Dusklight pick **Archipelago** with the arrows next to Play, then create a **new file**.
3. A connection window opens: **Host** (`archipelago.gg`, `localhost`, ...), **Port**, **Slot name**
   (from your YAML) and **Password** (leave empty if the room has none; it is shown as you type).
   A pasted `host:port` splits itself. Press **Connect and start**.
4. The window shows live status: connecting, asking the server what is at each of your locations,
   building your seed (a few seconds), then you continue to name entry as usual.
5. Play. Checks are reported the moment you collect them. Items other players find for you arrive
   on their own, one at a time, when it is safe (see below). The **Archipelago** tab in the menu bar
   shows the connection, items received, checks sent, recent messages, a box for chat and server
   commands (`!hint`, `!remaining`, ...), reconnect/disconnect, and the death link toggle.

Loading an existing Archipelago file reconnects by itself and, if the room moved to a new port,
the Archipelago tab lets you change the address and press Reconnect. Checks made while
disconnected are sent when you reconnect. A file keeps working offline: its seed and what is at
each location are saved next to it.

Both `wss://` (hosted rooms) and `ws://` (a server you run) work; with no scheme, the mod tries
the likelier one first and falls back.

### What other players' items look like

With a free SteamGridDB API key (Status tab, "Other players' items"), another player's item shows as the box of
the game it is for, with that game's cover, in the world and in Link's hands and the text box. Without a key,
or for a game SteamGridDB has no art for, it is a Sol as described next. You can pick the box cover or the
game's square icon for the item itself and, separately, for the picture in the text box (for example the icon
in Link's hands and the cover in the text box). Covers download once per game, from
SteamGridDB only, and are cached; the key is stored in the mod's config and sent only to SteamGridDB.

An item that belongs to someone else appears as a small Sol (the Palace of Twilight orb) with a
text box saying whose it is: *"You found Alice's Hookshot!"*. It plays a jingle matching its
Archipelago classification (progression, useful, filler, trap). Your own items come out of chests,
shops and NPCs exactly as in the randomizer, with their normal fanfare.

### Items arriving from other players

Received items go through the game's own give queue, one at a time, and only when Link can take
them: not during a scene change, pause, cutscene or conversation; not while dying, being hit,
falling, warping or transforming. Progression items from other players play the full get-item
scene; everything else is silent with a toast.

### The Archipelago window

The **Archipelago** tab of the menu bar opens a window with six tabs: **Status** (connection, address,
reconnect countdown, death link, "Send goal complete"), **Tracker** (your checks by region and which are
in logic now, by the apworld's own rules, plain and glitched: yellow rows are only in glitched logic), **Hints** (your hints, hint points
and cost, asking for hints, setting a priority), **Messages** (the room's log in colour, and chat or
commands such as `!remaining`), **Items** (everything the room sent you, who found it and whether it has reached Link;
once your goal is done, buttons for `!collect` and `!release` as far as the room allows them), and **Overlay**. A trap another player sends you plays the Foolish Item's
scene, like the randomizer's own.

### The overlay

Hold **L and R and press D-Pad Left** to hide or show it without opening the menu (Overlay tab: Shortcut).

A small panel in the corner of the screen while you play, drawn by the game's own HUD pass so it
hides when the HUD does: connection status, checks done (with a bar), the last items you received
or found, open hints that concern you, the last chat lines, and a death link reminder. It is on by
default; the **Overlay** tab of the Archipelago window (menu bar) turns each part on or off and sets
its corner, offsets, size, background and how long items and chat stay. The drawing code and the
settings are the community Archipelago mod's overlay, minus its logic tracker (this mod has none).

### Settings from your YAML

Every option in the apworld's slot data is translated automatically; see
[`docs/GC_MAPPING_REPORT.md`](docs/GC_MAPPING_REPORT.md) for the full table. In short:
shuffle toggles, key/map/compass settings, Hyrule Castle and Palace requirements, Faron Woods,
Open Door of Time, entrance requirements, damage multiplier, traps and starting time map onto the
randomizer's settings of the same meaning. The apworld always sends Skip Prologue, all three
twilights cleared and Skip Midna's Desperate Hour as "Yes", so every file starts in the same
post-prologue state. A few GameCube-patch-only options (Fast Iron Boots, Quick Transform, Instant
Message Text, Increase Spinner Speed, Modify Shop Models) have no Dusklight equivalent and are
ignored, as is Early Shadow Crystal (the crystal simply arrives as an item). Death link and
Transform Anywhere are honoured.

The mod is built for apworld version **v0.3.0** and refuses a room generated with another
version, because its tables are keyed by that version's numbering. Set the config variable
`allowUnknownWorldVersion` to override at your own risk.

## What it does about the problems this was written to fix

The causes below are read from the code, not reproduced in game (nothing here has been run); the
Jaggle's-house crash and the Green Rupee in particular are inferences from that code.

| Problem | Likely cause | Fix |
|---|---|---|
| Chests missing; Day-1 morning layer | A new file started with **no** start flags: the official branch's new-save path never activated a seed, so `setupRandomizerFile()` ran on an empty context | The seed is built before the file exists and activated, then start flags are applied, in the same order as the official randomizer's own new-file path. `tools/check_start_state.py` checks the result |
| Crash entering Jaggle & Pergie's house | Same cause: that room's layer needs `FINISHED_SEWERS` or Faron twilight cleared, neither of which was set | Both are start flags now |
| A check giving a Green Rupee | A check whose resolver answered "not mine" falls back to the game's default item | For every location the server owns, the resolver always answers with an explicit item: your item, or the Sol. It never answers "not mine" |
| Checks never reaching the server | Dusklight's WebSocket service delivers only the first message of a connection (as found by the existing Dusklight Archipelago mod, 2.0.1) | The mod uses its own WebSocket/TLS client over raw TCP |
| Crash on connect | The official branch reads a `SeedID` the apworld does not send and misspells a setting name | Slot data is parsed defensively; the seed identity is the room's own seed name |

## Verification

One command runs the live suite against a room (read-only, nothing is sent that changes it):

```sh
python3 -I tools/run_live_tests.py HOST PORT "SLOT NAME" [PASSWORD]
```

It checks, on the room's real data: the apworld version and every setting translation; that all 475
location ids and every placed item match the **server's own data package** and Dusklight's data;
that every location can be noticed in game; that **the real randomizer generator, in Archipelago
mode, builds a seed** from the room's real placements and 60 variants of it, leaving nothing empty
and honouring every placement, with the layer-critical start flags set; and that **the mod's real
network client** connects over `wss://` with compression, reads slot data and scouts, reconnects,
is refused cleanly for a wrong slot name and reports an unreachable server. The first run against
the development room found and fixed a bug that would have stopped every seed from generating (the
Archipelago placeholder item had no text in the language files).

The method and its stand-ins (OpenSSL for mbedTLS, a small JSON/YAML, zlib for miniz) are described
in [`docs/TESTING.md`](docs/TESTING.md).

The game itself is tested too, in the installed Dusklight: `tools/game_test/run_all.py` starts it on
a clean scratch profile (nothing of your own is touched), points it at a local fake room built from a
capture of the real one, and plays it with a virtual gamepad: new file, an item sent mid-play, the
status window, a dropped connection, a death link, saving and reloading, every Ordon map, a chest
opened and reported, another player's item. `tools/game_test/smoke.py` is the no-input check that the
mod loads and activates. [`docs/TESTING.md`](docs/TESTING.md) lists each scenario and what it asserts.

Separately, repeatable from this directory: `tools/gen_gc_tables.py` (fails unless every location,
item and setting resolves against the apworld and Dusklight), `tools/test_gc_settings.cpp`,
`tools/check_start_state.py` (with a negative control), `tools/make_grounding_ledger.py`
([`docs/GROUNDING.md`](docs/GROUNDING.md)) and `tools/syntax_check/check.sh` (type-checks the
game-facing sources against the real game and SDK headers).

## Building

```sh
cd output
cmake -B build
cmake --build build --parallel         # build/mods/tp_archipelago.dusk
```

CMake fetches Dusklight (`v2.0.3` by default, the version this was built and loaded against; pass `-DDUSKLIGHT_DIR=<checkout>` to use an existing
tree instead), yaml-cpp, nlohmann/json, base64pp, battery-embed, mbedTLS and miniz into the build
directory. Nothing is installed globally. Host-side tests of the adapter:
`cmake --build build --target tp_ap_gc_tests && ctest --test-dir build`.

## Continuous integration

`.github/workflows/build.yml` builds the bundle on Linux (x86-64, arm64), macOS (arm64, x86-64) and Windows
(amd64, arm64), runs the host tests that need neither the game nor a network (the settings adapter and the
box-art image code) and a check that the module has no undefined symbols of its own, then merges the six
per-platform bundles into one multi-platform `tp_archipelago.dusk` (with `tools/merge_mod.py`, the
Dusklight randomizer's own tool, and `symgen`); a tag makes a release from it. **Only the Linux build has been
run by me**; the workflow was checked as YAML, the symbol check, the host tests and the bundle merge (with a
stand-in `symgen`) were run locally, but the Windows and macOS builds, and the workflow itself, have not been
run. The in-game tests (`tools/game_test`) need the game and a disc image and are not part of it.

## Layout

| Path | What |
|---|---|
| `src/ap/` | The Archipelago mode. `ap_client.*` the protocol client, `ws_tcp`/`tls`/`ws_deflate` the transport, `gc_tables.*`/`gc_settings.*` the GameCube-apworld adapter, `mode/` the mode itself |
| `src/`, `generator/`, `res/` | The official randomizer, vendored with the small documented patches in [`docs/PATCHES.md`](docs/PATCHES.md) |
| `tools/` | Table generator, live tests, host builds of the generator and client, checks (above); `tools/game_test/` runs the real game (fake room, virtual gamepad, scenarios) |
| `docs/` | [`ARCHITECTURE.md`](docs/ARCHITECTURE.md), [`PATCHES.md`](docs/PATCHES.md), [`TESTING.md`](docs/TESTING.md), generated `GC_MAPPING_REPORT.md` and `GROUNDING.md` |
| `_old_attempt/` | The previous attempt, moved aside, unmodified. Safe to delete |

## Limitations

- Dusklight options the apworld has no equivalent for stay at Dusklight's defaults. Where the
  apworld's logic was checked they agree (for example Skip Bridge Donation stays off, and the
  apworld requires reaching Kakariko Malo Mart for the Castle Town bridge).
- Entrance randomization and in-game hints are off (the local seed cannot see other worlds); use
  Archipelago's hints.
- Your own items are given by the check that holds them (the server does not echo them back),
  so a lost save loses them.
- If Archipelago's logic and the in-game game differ for a location, the server's answer wins at
  that location; such locations are listed in `ap_debug.log` when `debugLog` is on.
- The password is stored in the save file in plain text so a file can reconnect by itself.
- The text box of another player's item shows the Foolish Item's icon.
- Items from the server are handed over only while Link stands or walks (the game's give queue); the
  Status tab and the trail say when one is waiting and why.
- Credits: the network stack, death link, goal detection and the Sol placeholder come from
  noahsmaximum's Dusklight Archipelago mod; the randomizer is Twilit Realm's.
