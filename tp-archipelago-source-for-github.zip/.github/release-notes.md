## Twilight Princess Archipelago for Dusklight

Plays Archipelago multiworlds generated with the **Twilight Princess** (GameCube) apworld inside
[Dusklight](https://github.com/TwilitRealm/dusklight), the PC port. No Dolphin, no patch, no client program.

### Install

1. Download `tp_archipelago.dusk` below and put it in Dusklight's mods folder
   (Windows `%APPDATA%\TwilitRealm\Dusklight\mods`, Linux `~/.local/share/TwilitRealm/Dusklight/mods`,
   macOS `~/Library/Application Support/TwilitRealm/Dusklight/mods`).
2. In Dusklight pick **Archipelago** with the arrows next to Play, press Play, choose an empty file and
   enter your room's host, port, slot name and password. Your YAML is the configuration.

Optional: a free [SteamGridDB](https://www.steamgriddb.com) API key (Archipelago window, Status tab) shows
other players' items as the box or icon of their game.

### What's new

First release. See the README for what is tested and what is not.
