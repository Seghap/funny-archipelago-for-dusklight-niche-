#!/usr/bin/env python3
"""Fuzzes the real generator, in Archipelago mode, with realistic variations of a room.

Each variant picks random options the way a player's YAML would (keeping the apworld's own
constraints from generate_early), builds the placements the way the apworld would (vanilla items in
categories that are switched off, the room's real item multiset elsewhere), hands a random share of
the locations to "another world", and runs the generator exactly as the mod does. Every variant must
generate, leave no item location empty, honour every plando entry and keep everything else vanilla.

    python3 -I output/tools/host_gen/fuzz.py [N variants, default 16] [first seed, default 1]
"""
import importlib.util
import json
import random
import re
import sys
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
OUT = HERE.parents[1]
ROOT = OUT.parent


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


run = load("hostrun", HERE / "run.py")
gen = load("gen", OUT / "tools" / "gen_gc_tables.py")

cap = json.loads((OUT / "tools" / "live" / "capture.json").read_text())
dl_names = {n.lower(): n for n in gen.read_dl_locations()}
gc_locs = {code: dl_names[name.lower()] for name, code in gen.read_gc_locations() if code is not None}
items_by_plando = {}
for it in gen.map_items(gen.read_gc_items(), gen.read_dl_items()):
    if it["code"] is not None and it["dl_name"]:
        items_by_plando.setdefault(it["dl_name"], []).append(it["code"])

# GC location flags (TPFlag) and Dusklight original items
src = (ROOT / "ref_tp_apworld" / "Locations.py").read_text()
gc_flags = {}
for m in re.finditer(r'^    "([^"]+)": TPLocationData\(\s*code=(\w+),\s*flags=([^,\n]+),', src, re.M):
    gc_flags[m.group(1).lower()] = set(re.findall(r"TPFlag\.(\w+)", m.group(3)))
originals = {}
cur = None
for ln in (ROOT / "ref_official_rando_ap" / "generator" / "data" / "locations.yaml").read_text().splitlines():
    m = re.match(r"^- Name:\s*(.+?)\s*$", ln)
    if m:
        cur = m.group(1).strip("\"'")
    m = re.match(r"^  Original Item:\s*(.+?)\s*$", ln)
    if m and cur:
        originals[cur] = m.group(1)

live_items = [(s["item"]) for s in cap["scouted"]]
live_ids = sorted(set(cap["connected"]["checked_locations"]) | set(cap["connected"]["missing_locations"]))

TOGGLES = ["Golden Bugs Shuffled", "Sky Chracters Shuffled", "NPC Items Shuffled", "Shop Items Shuffled",
           "Hidden Skills Shuffled", "Poes Shuffled", "Heart Pieces Shuffled", "Overworld Shuffled",
           "Dungeons Shuffled", "Dungeon Rewards Progression", "Skip Minor Cutscenes", "Skip Major Cutscenes",
           "Open Map", "Open Door of Time", "Increase Wallet", "Transform Anywhere", "Bonks do Damage",
           "Lakebed Entrance Requirements", "Arbiters Grounds Entrance Requirements",
           "Snowpeak Entrance Requirements", "City in the Sky Entrance Requirements"]
CHOICES = {
    "Small Key Settings": ["Vanilla", "Own Dungeon", "Any Dungeon", "Anywhere", "Startwith"],
    "Big Key Settings": ["Vanilla", "Own Dungeon", "Any Dungeon", "Anywhere", "Startwith"],
    "Map and Compass Settings": ["Vanilla", "Own Dungeon", "Any Dungeon", "Anywhere", "Startwith"],
    "Castle Requirements": ["Open", "Fused Shadows", "Mirror Shards", "All Dungeons", "Vanilla"],
    "Palace of Twilight Requirements": ["Open", "Fused Shadows", "Mirror Shards", "Vanilla"],
    "Faron Woods Logic": ["Open", "Closed"],
    "Temple of Time Entrance Requirements": ["Closed", "Open Grove", "Open"],
    "Goron Mines Entrance Requirements": ["Closed", "No Wrestling", "Open"],
    "Trap Frequency": ["No Traps", "Few", "Many", "Mayhem", "Nightmare"],
    "Damage Magnification": ["Vanilla", "Double", "Triple", "Quadruple", "Ohko"],
    "Starting ToD": ["Morning", "Noon", "Evening", "Night"],
}
FIXED_YES = ["Skip Prologue", "Faron Twilight Cleared", "Eldin Twilight Cleared", "Lanayru Twilight Cleared", "Skip MDH"]
IGNORED = {"Fast Iron Boots": "Yes", "Quick Transform": "Yes", "Instant Message Text": "Yes",
           "Increase Spinner Speed": "Yes", "Modify Shop Models": "No", "Early Shadow Crystal": "No",
           "Logic Settings": "Glitchless"}


def variant(seed):
    rnd = random.Random(seed)
    s = {k: rnd.choice(["Yes", "No"]) for k in TOGGLES}
    for k, opts in CHOICES.items():
        s[k] = rnd.choice(opts)
    for k in FIXED_YES:
        s[k] = "Yes"
    s.update(IGNORED)
    if seed == 1:  # the live room's own settings
        s = dict(cap["connected"]["slot_data"]["Settings"])
    # the apworld's generate_early constraints
    if s["Overworld Shuffled"] == "No" and s["Dungeons Shuffled"] == "No":
        s["Overworld Shuffled"] = "Yes"
    if s["Dungeons Shuffled"] == "No":
        for k in ("Small Key Settings", "Big Key Settings", "Map and Compass Settings"):
            if s[k] != "Startwith":
                s[k] = "Vanilla"
    if s["Overworld Shuffled"] == "No":
        for k in ("Golden Bugs Shuffled", "Shop Items Shuffled", "Heart Pieces Shuffled", "Hidden Skills Shuffled",
                  "Sky Chracters Shuffled", "Poes Shuffled"):
            s[k] = "No"

    on = lambda k: s[k] == "Yes"
    enabled = {"Always", "Boss", "MiniBoss"}
    for key, flag in (("Golden Bugs Shuffled", "Bug"), ("Shop Items Shuffled", "Shop"), ("Sky Chracters Shuffled", "Sky_Book"),
                      ("Poes Shuffled", "Poe"), ("NPC Items Shuffled", "Npc"), ("Hidden Skills Shuffled", "Skill"),
                      ("Heart Pieces Shuffled", "Heart"), ("Overworld Shuffled", "Overworld"), ("Dungeons Shuffled", "Dungeon")):
        enabled.add(flag if on(key) else "Always")

    pool = list(live_items)
    rnd.shuffle(pool)
    foreign = {0: 0.0, 1: 0.0}.get(seed, rnd.choice([0.0, 0.25, 0.6, 0.9]))
    lines = [f"SEED\tFUZZ{seed}", f"SLOT\tFuzz Player {seed}", "MYSLOT\t1"]
    for k, v in s.items():
        lines.append(f"SETTING\t{k}\t{v}")
    vanilla_n = foreign_n = 0
    for i, loc_id in enumerate(live_ids):
        name = gc_locs[loc_id - gen.ID_BASE]
        orig = originals.get(name, "")
        flags = gc_flags[name.lower()]
        vanilla = not flags <= enabled
        if re.search(r"Small Key$|Ordon Pumpkin|Ordon Cheese", orig) and s["Small Key Settings"] == "Vanilla":
            vanilla = True
        if orig.endswith("Big Key") and orig != "Hyrule Castle Big Key" and s["Big Key Settings"] == "Vanilla":
            vanilla = True
        if re.search(r"Dungeon Map$|Compass$", orig) and s["Map and Compass Settings"] == "Vanilla":
            vanilla = True
        item = None
        if vanilla and orig in items_by_plando:
            item = gen.ID_BASE + items_by_plando[orig][0]
            vanilla_n += 1
        if item is None:
            item = pool[i]
        player = 2 if rnd.random() < foreign else 1
        foreign_n += player == 2
        lines.append(f"PLACE\t{loc_id}\t{item}\t{player}")
    return s, lines, vanilla_n, foreign_n


def main():
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 16
    first = int(sys.argv[2]) if len(sys.argv) > 2 else 1
    exe = run.build()
    failed = 0
    print(f"{'seed':>4}  {'result':8} {'plando':>6} {'kept':>5} {'other':>5} {'empty':>5}  {'foreign':>7} {'vanilla-fill':>12}  notes")
    for seed in range(first, first + n):
        s, lines, vanilla_n, foreign_n = variant(seed)
        code, rec, err = run.run_case(exe, lines, HERE / "seedwork")
        result = [r for r in rec if r[0] == "R"]
        if not result or result[0][1] != "generated":
            failed += 1
            msg = (" | ".join(result[0][1:]) if result else (err.strip().splitlines() or ["no output"])[-1])[:200]
            print(f"{seed:>4}  FAILED   {msg}")
            print("        settings:", {k: v for k, v in s.items() if k in CHOICES or k in ("Dungeons Shuffled", "Overworld Shuffled")})
            continue
        c, bad, differ, skipped, locs = run.check_world(rec)
        status = "ok" if not bad else "PROBLEM"
        failed += 1 if bad else 0
        note = f"{len(differ)} kept-vanilla differ" if differ else ""
        print(f"{seed:>4}  {status:8} {c['plando']:>6} {c['kept']:>5} {c['vanilla']:>5} {c['empty']:>5}  {foreign_n:>7} {vanilla_n:>12}  {note}")
        for b in bad[:4]:
            print("        PROBLEM:", b)
    print(f"\n{n - failed}/{n} variants generated and verified")
    sys.exit(1 if failed else 0)


if __name__ == "__main__":
    main()
