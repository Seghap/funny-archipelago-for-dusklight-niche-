// Checks src/ap/gc_logic.* (the C++ port of the apworld's logic) against the apworld itself:
// tools/ap_truth/truth.py runs the real apworld's Python rules in Archipelago's real core and writes, per
// option variant, item sets with the locations reachable Glitchless and Glitched. This reads those files and
// requires the same answers from the C++ (location by location).
//
//   logic_test <truth file>...      exit 0 only if every case in every file matches

#include "ap/gc_logic.hpp"

#include <cstdio>
#include <fstream>
#include <iostream>
#include <set>
#include <sstream>
#include <string>
#include <vector>

static std::vector<std::string> split(const std::string& line) {
    std::vector<std::string> out;
    std::string cur;
    for (const char c : line) {
        if (c == '\t') out.push_back(std::move(cur)), cur.clear();
        else cur += c;
    }
    out.push_back(cur);
    return out;
}

int main(int argc, char** argv) {
    int bad = 0, cases = 0;
    for (int a = 1; a < argc; ++a) {
        std::ifstream in(argv[a]);
        std::vector<std::pair<std::string, std::string>> settings;
        std::vector<std::string> items;
        std::set<std::string> plain, glitched;
        int file_cases = 0, file_bad = 0;
        std::string line;
        ap::gc_logic::Options options;
        bool have_options = false;
        while (std::getline(in, line)) {
            const auto f = split(line);
            if (f[0] == "SETTING") {
                settings.emplace_back(f[1], f[2]);
            } else if (f[0] == "CASE") {
                if (!have_options) {
                    options = ap::gc_logic::options_from_settings(settings);
                    have_options = true;
                }
                items.clear(), plain.clear(), glitched.clear();
            } else if (f[0] == "ITEM") {
                items.push_back(f[1]);
            } else if (f[0] == "PLAIN") {
                plain.insert(f[1]);
            } else if (f[0] == "GLITCHED") {
                glitched.insert(f[1]);
            } else if (f[0] == "END") {
                ++file_cases;
                for (const bool g : {false, true}) {
                    const auto got = ap::gc_logic::reachable_names(items, options, g);
                    const auto& want = g ? glitched : plain;
                    std::set<std::string> gotSet(got.begin(), got.end());
                    if (gotSet != want) {
                        ++file_bad;
                        std::printf("MISMATCH %s case %d %s (%zu items): C++ %zu locations, apworld %zu\n", argv[a],
                            file_cases, g ? "glitched" : "glitchless", items.size(), gotSet.size(), want.size());
                        int shown = 0;
                        for (const auto& n : gotSet) if (!want.contains(n) && shown++ < 6) std::printf("    only C++:     %s\n", n.c_str());
                        shown = 0;
                        for (const auto& n : want) if (!gotSet.contains(n) && shown++ < 6) std::printf("    only apworld: %s\n", n.c_str());
                    }
                }
            }
        }
        std::printf("%s: %d cases, %d mismatches\n", argv[a], file_cases, file_bad);
        cases += file_cases;
        bad += file_bad;
    }
    std::printf("%s (%d cases)\n", bad ? "LOGIC TEST FAILED" : "LOGIC TEST PASSED", cases);
    return bad ? 1 : 0;
}
