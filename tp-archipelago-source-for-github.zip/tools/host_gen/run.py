#!/usr/bin/env python3
"""Builds the randomizer generator for the host (with small stand-ins for yaml-cpp, the embedder
and base64pp, see shims/) and runs it, in Archipelago mode, on the placements and settings a live
room sent (tools/live/capture.json, from tools/live_probe.py).

    python3 -I output/tools/host_gen/run.py [--rebuild]

Checks, on the finished world:
  * generation succeeds with the mod's settings and a plando for every server location
  * no item location is left empty
  * every plandoed location holds exactly the item it was given, except locations the generator
    already considered vanilla under these settings (those are reported and must hold their
    vanilla item)
  * every other item location holds its original (vanilla) item
Objects are cached in tools/host_gen/build (delete it to start clean).
"""
import concurrent.futures
import json
import os
import subprocess
import sys
import time
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
OUT = HERE.parents[1]
ROOT = OUT.parent
BUILD = HERE / "build"
SDK = ROOT / "dusklight" / "sdk" / "include"

# the generator's sources, exactly as CMakeLists.txt lists them
cmake = (OUT / "CMakeLists.txt").read_text()
start = cmake.index("set(RANDOMIZER_GENERATOR_SOURCES")
block = cmake[start:cmake.index(")", start)]
gen_sources = [l.strip() for l in block.splitlines()[1:] if l.strip().endswith(".cpp")]

FLAGS = ["-std=c++23", "-O1", "-w", "-DRANDOMIZER_ONLY", f'-DRANDO_DATA_PATH="generator/data/"', "-DSOURCE_PATH_SIZE=0",
         '-DFULL_RANDOMIZER_VERSION="host"', f'-DRANDO_SAVE_PATH="{BUILD}/"', "-DDUSK_MOD_FEATURE_FMT=1",
         f"-I{HERE / 'shims'}", f"-I{SDK}", f"-I{OUT}", f"-I{OUT / 'src'}"]

jobs = [(OUT / s, BUILD / (s.replace("/", "_") + ".o")) for s in gen_sources]
jobs.append((HERE / "shims" / "yaml_shim.cpp", BUILD / "yaml_shim.o"))
jobs.append((OUT / "src" / "ap" / "seed_inputs.cpp", BUILD / "seed_inputs.o"))
jobs.append((OUT / "src" / "ap" / "gc_settings.cpp", BUILD / "gc_settings.o"))
jobs.append((OUT / "src" / "ap" / "gc_tables.cpp", BUILD / "gc_tables.o"))
jobs.append((HERE / "gen_host_test.cpp", BUILD / "gen_host_test.o"))


def compile_one(job):
    src, obj = job
    if obj.exists() and obj.stat().st_mtime > max(src.stat().st_mtime, (OUT / "generator" / "randomizer.hpp").stat().st_mtime) \
            and "--rebuild" not in sys.argv:
        return None
    r = subprocess.run(["g++", "-c", *FLAGS, str(src), "-o", str(obj)], capture_output=True, text=True)
    return (src, r.stderr) if r.returncode else None


def build():
    BUILD.mkdir(exist_ok=True)
    t = time.time()
    with concurrent.futures.ThreadPoolExecutor(max_workers=os.cpu_count() or 4) as ex:
        failures = [f for f in ex.map(compile_one, jobs) if f]
    if failures:
        for src, err in failures[:3]:
            print(f"COMPILE FAILED {src.relative_to(OUT)}:\n" + "\n".join(err.splitlines()[:25]))
        sys.exit(2)
    exe = BUILD / "gen_host_test"
    r = subprocess.run(["g++", *[str(o) for _, o in jobs], "-lyaml", "-lfmt", "-lpthread", "-o", str(exe)],
                       capture_output=True, text=True)
    if r.returncode:
        print("LINK FAILED\n" + "\n".join(r.stderr.splitlines()[:30]))
        sys.exit(2)
    print(f"built the generator for the host in {time.time() - t:.0f}s")
    return exe


def run_case(exe, lines, workdir=None):
    """Runs the generator on one input; returns (exit code, parsed records, stderr)."""
    env = dict(os.environ, RANDO_EMBED_ROOT=str(OUT))
    run = subprocess.run([str(exe), str(workdir or HERE / "seedwork")], input="\n".join(lines) + "\n",
                         capture_output=True, text=True, env=env, cwd=OUT)
    return run.returncode, [l.split("\t") for l in run.stdout.splitlines()], run.stderr


def check_world(rec):
    """Invariants of a generated world. Returns (counts, problems, kept-vanilla-differing)."""
    locs = [r[1:] for r in rec if r[0] == "L"]   # name, current, original, plando
    skipped = {r[1] for r in rec if r[0] == "SK"}
    bad = []
    c = dict(plando=0, kept=0, vanilla=0, empty=0, total=len(locs), skipped=len(skipped))
    differ = []
    for name, cur, orig, plando in locs:
        if cur == "<EMPTY>":
            c["empty"] += 1
            bad.append(("empty", name))
        elif plando:
            if name in skipped:
                c["kept"] += 1
                if cur != orig:
                    bad.append(("skipped-but-not-vanilla", name, cur, orig))
                if plando != orig:
                    differ.append((name, orig, plando))
            else:
                c["plando"] += 1
                if cur != plando:
                    bad.append(("plando-mismatch", name, cur, plando))
        else:
            c["vanilla"] += 1
            if cur != orig:
                bad.append(("not-vanilla", name, cur, orig))
    stray = skipped - {n for n, _, _, p_ in locs if p_}
    for n in stray:
        bad.append(("skipped-but-not-in-plando", n))
    return c, bad, differ, skipped, locs


def live_lines():
    cap = json.loads((OUT / "tools" / "live" / "capture.json").read_text())
    slot_name = next(p["name"] for p in cap["connected"]["players"] if p["slot"] == cap["connected"]["slot"])
    lines = [f"SEED\t{cap['room_info']['seed_name']}", f"SLOT\t{slot_name}", f"MYSLOT\t{cap['connected']['slot']}"]
    for k, v in cap["connected"]["slot_data"]["Settings"].items():
        lines.append(f"SETTING\t{k}\t{v}")
    for s in cap["scouted"]:
        lines.append(f"PLACE\t{s['location']}\t{s['item']}\t{s['player']}")
    return lines


def main():
    exe = build()
    t = time.time()
    code, rec, err = run_case(exe, live_lines())
    print(f"generator ran in {time.time() - t:.1f}s (exit {code})")
    if err.strip():
        print("stderr (last lines):\n" + "\n".join(err.strip().splitlines()[-8:]))
    result = [r for r in rec if r[0] == "R"]
    for r in result:
        print("result:", " | ".join(r[1:])[:600])
    if not result or result[0][1] != "generated":
        sys.exit(1)
    c, bad, differ, skipped, locs = check_world(rec)
    print(f"\n{c['total']} item locations in the generated world")
    print(f"  {c['plando']:4d} hold exactly the item the server put there")
    print(f"  {c['kept']:4d} server locations the generator keeps vanilla under these settings "
          f"(plando skipped; resolver patches them if they differ)")
    print(f"  {c['vanilla']:4d} locations the server does not own: vanilla")
    print(f"  {c['empty']:4d} empty")
    print(f"  of the {c['skipped']} kept vanilla, {len(differ)} are where the server's item differs from the vanilla one")
    for n, o, p_ in differ[:20]:
        print(f"      {n}: vanilla {o!r}, server {p_!r}")
    for b in bad[:15]:
        print("  PROBLEM:", b)

    # start state, from the real generator's own evaluation of startflags.yaml
    flag_set = {}
    for r in rec:
        if r[0] == "F":
            f = int(r[1])
            flag_set[f >> 8] = flag_set.get(f >> 8, 0) | (f & 0xFF)
    consts = {}
    import re
    for line in (OUT / "src" / "flags.h").read_text(encoding="utf-8").splitlines():
        m = re.match(r"^\s+([A-Z0-9_]+)\s*=\s*(0x[0-9A-Fa-f]+),?", line)
        if m:
            consts[m.group(1)] = int(m.group(2), 16)
    print("\nfinished world's settings the start state depends on:",
          ", ".join(f"{r[1]}={r[2]}" for r in rec if r[0] == "W"))
    state_bad = []
    for name in ("ORDON_DAY_1_FINISHED", "ORDON_DAY_2_OVER", "FINISHED_SEWERS", "CLEARED_FARON_TWILIGHT",
                 "CLEARED_ELDIN_TWILIGHT", "CLEARED_LANAYRU_TWILIGHT", "MIDNAS_DESPERATE_HOUR_COMPLETED"):
        f = consts[name]
        ok = (flag_set.get(f >> 8, 0) & (f & 0xFF)) == (f & 0xFF)
        print(f"  {'ok  ' if ok else 'FAIL'}  start flag {name} (0x{f:04X})")
        if not ok:
            state_bad.append(name)
    bad += [("start-flag", n) for n in state_bad]
    print("\nGENERATOR TEST " + ("PASSED" if not bad else f"FAILED ({len(bad)} problems)"))
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
