// Runs the REAL randomizer generator, in Archipelago mode, on a live room's real settings and
// placements, and reports what the finished world looks like.
//
// It uses the same code the mod does for everything before the engine is involved:
//   gc::translate_settings   slot_data["Settings"] -> Dusklight settings
//   ap::write_seed_inputs    settings.yaml / plando.yaml / preferences.yaml
//   randomizer::Randomizer   the generator, with g_archipelagoMode set
// (the step after, WriteSeedData, needs the game's headers and is not run here).
//
// Input (stdin, TAB separated), as written by tools/host_gen/run.py:
//   SEED <room seed name>   SLOT <slot name>   MYSLOT <slot number>
//   SETTING <key> <value>   PLACE <location id> <item id> <receiving player>
//
// Output records: R (result), L (location: name, current item, original item, plandoed item),
// SK (skipped plando location), SUMMARY.

#include "ap/gc_settings.hpp"
#include "ap/gc_tables.hpp"
#include "ap/seed_inputs.hpp"

#include "generator/logic/item.hpp"
#include "generator/logic/location.hpp"
#include "generator/logic/world.hpp"
#include "generator/randomizer.hpp"
#include "generator/utility/yaml.hpp"

#include <cstdio>
#include <cstdlib>
#include <filesystem>
#include <iostream>
#include <map>
#include <string>
#include <vector>

static std::vector<std::string> split(const std::string& line) {
    std::vector<std::string> out;
    std::string cur;
    for (const char c : line) {
        if (c == '\t') out.push_back(std::move(cur)), cur.clear();
        else cur += c;
    }
    out.push_back(cur);
    return out;
}

int main(int argc, char** argv) {
    const std::filesystem::path base = argc > 1 ? argv[1] : "seedwork";

    ap::SeedInput in;
    ap::gc::StringPairs raw;
    long mySlot = -1;
    struct Place { long long loc, item; int player; };
    std::vector<Place> places;
    std::string line;
    while (std::getline(std::cin, line)) {
        const auto f = split(line);
        if (f[0] == "SEED" && f.size() > 1) in.seedName = f[1];
        else if (f[0] == "SLOT" && f.size() > 1) in.slot = f[1];
        else if (f[0] == "MYSLOT" && f.size() > 1) mySlot = std::atol(f[1].c_str());
        else if (f[0] == "SETTING" && f.size() > 2) raw.emplace_back(f[1], f[2]);
        else if (f[0] == "PLACE" && f.size() > 3)
            places.push_back({std::atoll(f[1].c_str()), std::atoll(f[2].c_str()), std::atoi(f[3].c_str())});
    }

    const auto translated = ap::gc::translate_settings(raw);
    if (!translated.errors.empty()) {
        std::printf("R\tsettings-error\t%s\n", translated.errors.front().c_str());
        return 2;
    }
    in.settings = translated.settings;
    std::map<std::string, std::string> plandoItem;
    for (const auto& p : places) {
        const auto* loc = ap::gc::find_location(p.loc);
        const auto* item = ap::gc::find_item(p.item);
        if (loc == nullptr || item == nullptr) {
            std::printf("R\tunknown-id\t%lld/%lld\n", p.loc, p.item);
            return 2;
        }
        const std::string name = p.player == mySlot ? item->plandoName : "Archipelago Item";
        in.plando.emplace_back(loc->dusklightName, name);
        plandoItem[loc->dusklightName] = name;
    }

    std::filesystem::remove_all(base);
    ap::write_seed_inputs(in, base);

    randomizer::g_archipelagoMode = true;
    randomizer::g_archipelagoSkippedPlando.clear();
    randomizer::Randomizer rando{base};
    std::optional<std::string> err;
    try {
        err = rando.Generate();
    } catch (const std::exception& e) {
        err = std::string("uncaught exception: ") + e.what();
    }
    randomizer::g_archipelagoMode = false;
    if (err.has_value()) {
        std::printf("R\tgenerate-failed\t%s\n", err->c_str());
        return 1;
    }
    std::printf("R\tgenerated\thash=%s\n", rando.GetConfig().GetHash().c_str());

    auto* world = rando.GetWorld();
    int empty = 0, total = 0;
    for (auto* location : world->GetAllLocations()) {
        ++total;
        const auto* cur = location->GetCurrentItem();
        if (location->IsEmpty() || cur == nullptr) {
            ++empty;
            std::printf("L\t%s\t<EMPTY>\t%s\t\n", location->GetName().c_str(), location->GetOriginalItem()->GetName().c_str());
            continue;
        }
        const auto it = plandoItem.find(location->GetName());
        std::printf("L\t%s\t%s\t%s\t%s\n", location->GetName().c_str(), cur->GetName().c_str(),
            location->GetOriginalItem()->GetName().c_str(), it != plandoItem.end() ? it->second.c_str() : "");
    }
    for (const auto& s : randomizer::g_archipelagoSkippedPlando) std::printf("SK\t%s\n", s.c_str());

    // The start event flags, evaluated against the finished world exactly as WriteSeedData does
    // (src/randomizer_context.cpp "Set starting flags"), and the settings the game would see.
    {
        auto startFlags = LOAD_EMBED_YAML(RANDO_DATA_PATH "startflags.yaml");
        for (const auto& flagNode : startFlags["EventFlags"]) {
            if (flagNode.IsScalar()) {
                std::printf("F\t%u\n", static_cast<unsigned>(flagNode.as<uint16_t>()));
            } else if (flagNode.IsMap()) {
                const auto& condition = flagNode.begin()->first.as<std::string>();
                if (world->EvaluateSettingCondition(condition)) {
                    for (const auto& conditionalFlag : flagNode.begin()->second)
                        std::printf("F\t%u\n", static_cast<unsigned>(conditionalFlag.as<uint16_t>()));
                }
            }
        }
        for (const char* name : {"Skip Prologue", "Faron Twilight Cleared", "Eldin Twilight Cleared",
                 "Lanayru Twilight Cleared", "Skip Midna's Desperate Hour", "Randomize Starting Spawn",
                 "Starting Time of Day", "Unlock Map Regions"})
            std::printf("W\t%s\t%s\n", name, world->Setting(name).GetCurrentOption().c_str());
    }
    std::printf("SUMMARY\t%d item locations\t%d empty\t%zu skipped plando\n", total, empty,
        randomizer::g_archipelagoSkippedPlando.size());
    return empty ? 1 : 0;
}
