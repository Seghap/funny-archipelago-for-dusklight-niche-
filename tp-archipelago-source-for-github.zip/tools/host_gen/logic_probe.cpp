// What the tracker's logic says for a list of items, with the settings a room sent:
//   logic_probe <settings file: SETTING<TAB>key<TAB>value lines> [item name]...
// Prints the locations reachable Glitchless ("P") and those only the Glitched rules reach ("G").
#include "ap/gc_logic.hpp"

#include <cstdio>
#include <fstream>
#include <set>
#include <string>
#include <vector>

int main(int argc, char** argv) {
    std::vector<std::pair<std::string, std::string>> settings;
    std::ifstream in(argv[1]);
    std::string line;
    while (std::getline(in, line)) {
        const auto a = line.find('\t'), b = line.find('\t', a + 1);
        if (a != std::string::npos && b != std::string::npos && line.substr(0, a) == "SETTING")
            settings.emplace_back(line.substr(a + 1, b - a - 1), line.substr(b + 1));
    }
    std::vector<std::string> items(argv + 2, argv + argc);
    const auto options = ap::gc_logic::options_from_settings(settings);
    const auto plain = ap::gc_logic::reachable_names(items, options, false);
    const auto glitched = ap::gc_logic::reachable_names(items, options, true);
    std::set<std::string> p(plain.begin(), plain.end()), g(glitched.begin(), glitched.end());
    for (const auto& n : p) std::printf("P\t%s\n", n.c_str());
    for (const auto& n : g) if (!p.contains(n)) std::printf("G\t%s\n", n.c_str());
    return 0;
}
