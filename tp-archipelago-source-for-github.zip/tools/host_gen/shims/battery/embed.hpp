// HOST TEST SHIM, not battery-embed: b::embed<"path">().str() reads the file at run time,
// relative to the directory in $RANDO_EMBED_ROOT (default: the current directory), instead of
// from the binary. The mod itself embeds the same files at build time.
#pragma once
#include <cstddef>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <stdexcept>
#include <string>
namespace b {
template <size_t N> struct fixed_string {
    char v[N];
    constexpr fixed_string(const char (&s)[N]) { for (size_t i = 0; i < N; ++i) v[i] = s[i]; }
};
template <fixed_string P> struct embedded {
    std::string str() const {
        const char* root = std::getenv("RANDO_EMBED_ROOT");
        std::ifstream f(std::string(root ? root : ".") + "/" + P.v, std::ios::binary);
        if (!f) throw std::runtime_error(std::string("embedded file not found: ") + P.v);
        std::ostringstream o;
        o << f.rdbuf();
        return o.str();
    }
};
template <fixed_string P> embedded<P> embed() { return {}; }
}  // namespace b
