// HOST TEST SHIM: YAML::Load on top of the system libyaml. See shims/yaml-cpp/yaml.h.
#include <yaml-cpp/yaml.h>

#include <yaml.h>  // libyaml

#include <map>

namespace YAML {
namespace {

using detail::DataPtr;
using detail::make;

struct Builder {
    yaml_parser_t parser;
    std::map<std::string, DataPtr> anchors;

    DataPtr build(yaml_event_t& ev) {
        DataPtr node;
        std::string anchor;
        switch (ev.type) {
        case YAML_SCALAR_EVENT: {
            const std::string value(reinterpret_cast<const char*>(ev.data.scalar.value), ev.data.scalar.length);
            const bool plain = ev.data.scalar.style == YAML_PLAIN_SCALAR_STYLE && ev.data.scalar.tag == nullptr;
            const bool isNull = plain && (value.empty() || value == "~" || value == "null" || value == "Null" || value == "NULL");
            node = make(isNull ? NodeType::Null : NodeType::Scalar);
            if (!isNull) node->scalar = value;
            if (ev.data.scalar.anchor) anchor = reinterpret_cast<const char*>(ev.data.scalar.anchor);
            break;
        }
        case YAML_ALIAS_EVENT: {
            const auto it = anchors.find(reinterpret_cast<const char*>(ev.data.alias.anchor));
            if (it == anchors.end()) throw ParserException("unknown anchor");
            return it->second;
        }
        case YAML_SEQUENCE_START_EVENT: {
            node = make(NodeType::Sequence);
            if (ev.data.sequence_start.anchor) anchor = reinterpret_cast<const char*>(ev.data.sequence_start.anchor);
            if (!anchor.empty()) anchors[anchor] = node;
            for (;;) {
                yaml_event_t child;
                next(child);
                if (child.type == YAML_SEQUENCE_END_EVENT) {
                    yaml_event_delete(&child);
                    break;
                }
                node->seq.push_back(build(child));
                yaml_event_delete(&child);
            }
            return node;
        }
        case YAML_MAPPING_START_EVENT: {
            node = make(NodeType::Map);
            if (ev.data.mapping_start.anchor) anchor = reinterpret_cast<const char*>(ev.data.mapping_start.anchor);
            if (!anchor.empty()) anchors[anchor] = node;
            for (;;) {
                yaml_event_t key;
                next(key);
                if (key.type == YAML_MAPPING_END_EVENT) {
                    yaml_event_delete(&key);
                    break;
                }
                DataPtr k = build(key);
                yaml_event_delete(&key);
                yaml_event_t val;
                next(val);
                DataPtr v = build(val);
                yaml_event_delete(&val);
                // yaml-cpp lets a later duplicate key win
                bool replaced = false;
                for (auto& kv : node->map)
                    if (kv.first->scalar == k->scalar) {
                        kv.second = v;
                        replaced = true;
                    }
                if (!replaced) node->map.emplace_back(k, v);
            }
            return node;
        }
        default:
            throw ParserException("unexpected YAML event");
        }
        if (!anchor.empty()) anchors[anchor] = node;
        return node;
    }

    void next(yaml_event_t& ev) {
        if (!yaml_parser_parse(&parser, &ev)) {
            std::string msg = parser.problem ? parser.problem : "parse error";
            msg += " (line " + std::to_string(parser.problem_mark.line + 1) + ")";
            throw ParserException(msg);
        }
    }
};

}  // namespace

Node Load(const std::string& input) {
    Builder b;
    yaml_parser_initialize(&b.parser);
    yaml_parser_set_input_string(&b.parser, reinterpret_cast<const unsigned char*>(input.data()), input.size());
    struct Guard {
        yaml_parser_t* p;
        ~Guard() { yaml_parser_delete(p); }
    } guard{&b.parser};

    DataPtr root = make(NodeType::Null);
    yaml_event_t ev;
    for (;;) {
        b.next(ev);
        const auto type = ev.type;
        if (type == YAML_DOCUMENT_START_EVENT) {
            yaml_event_delete(&ev);
            yaml_event_t content;
            b.next(content);
            if (content.type != YAML_DOCUMENT_END_EVENT) {
                root = b.build(content);
                yaml_event_delete(&content);
                yaml_event_t end;
                b.next(end);
                yaml_event_delete(&end);
            } else {
                yaml_event_delete(&content);
            }
            break;
        }
        yaml_event_delete(&ev);
        if (type == YAML_STREAM_END_EVENT) break;
    }
    return Node(root);
}

}  // namespace YAML
