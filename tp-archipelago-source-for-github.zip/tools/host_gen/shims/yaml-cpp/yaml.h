// HOST TEST SHIM, not yaml-cpp. A small YAML tree with the subset of yaml-cpp's Node API the
// randomizer generator and the Archipelago seed-input writer use, parsed with the system libyaml
// (see yaml_shim.cpp). It follows yaml-cpp's behaviour where the generator depends on it:
//   * Nodes are references: copies share their data; operator[] on a map creates the child
//   * a child that was only looked up (never assigned) stays Undefined and is invisible to
//     iteration, size() and Dump()
//   * `if (node["x"])` is IsDefined(); as<T>() on an undefined node throws InvalidNode
//   * integers parse decimal, 0x hex and 0o octal; bools accept y/yes/true/on and n/no/false/off
// It exists so the real generator can be run on a machine without yaml-cpp. The mod links the
// real yaml-cpp (see CMakeLists.txt).
#pragma once

#include <algorithm>
#include <array>
#include <deque>
#include <functional>
#include <iostream>
#include <list>
#include <map>
#include <set>
#include <span>
#include <string_view>
#include <unordered_map>
#include <unordered_set>
#include <cctype>
#include <limits>
#include <charconv>
#include <cstdint>
#include <cstdlib>
#include <memory>
#include <optional>
#include <sstream>
#include <stdexcept>
#include <string>
#include <type_traits>
#include <utility>
#include <vector>

namespace YAML {

enum struct NodeType { Undefined, Null, Scalar, Sequence, Map };

class Exception : public std::runtime_error {
public:
    using std::runtime_error::runtime_error;
};
class BadFile : public Exception {
public:
    explicit BadFile(const std::string& f) : Exception("bad file: " + f) {}
};
class ParserException : public Exception {
public:
    using Exception::Exception;
};
class BadConversion : public Exception {
public:
    BadConversion() : Exception("bad conversion") {}
};
class InvalidNode : public Exception {
public:
    InvalidNode() : Exception("invalid node; this may result from using a map iterator as a sequence iterator, or vice-versa") {}
};

namespace detail {
struct Data;
using DataPtr = std::shared_ptr<Data>;
struct Data {
    NodeType type = NodeType::Undefined;
    std::string scalar;
    std::vector<DataPtr> seq;
    std::vector<std::pair<DataPtr, DataPtr>> map;
};
inline DataPtr make(NodeType t) {
    auto d = std::make_shared<Data>();
    d->type = t;
    return d;
}

// ---- conversions (yaml-cpp's convert<T>)
inline std::string lower(std::string s) {
    for (auto& c : s) c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
    return s;
}
template <class T>
bool parse_integer(const std::string& s, T& out) {
    if (s.empty()) return false;
    size_t i = 0;
    bool neg = false;
    if (s[i] == '+' || s[i] == '-') {
        neg = s[i] == '-';
        ++i;
    }
    int base = 10;
    if (s.size() > i + 1 && s[i] == '0' && (s[i + 1] == 'x' || s[i + 1] == 'X')) {
        base = 16;
        i += 2;
    } else if (s.size() > i + 1 && s[i] == '0' && (s[i + 1] == 'o' || s[i + 1] == 'O')) {
        base = 8;
        i += 2;
    }
    if (i >= s.size()) return false;
    unsigned long long mag = 0;
    const auto r = std::from_chars(s.data() + i, s.data() + s.size(), mag, base);
    if (r.ec != std::errc() || r.ptr != s.data() + s.size()) return false;
    if (neg) {
        if constexpr (std::is_unsigned_v<T>) return false;
        const long long v = -static_cast<long long>(mag);
        if (v < static_cast<long long>(std::numeric_limits<T>::min())) return false;
        out = static_cast<T>(v);
    } else {
        if (mag > static_cast<unsigned long long>(std::numeric_limits<T>::max())) return false;
        out = static_cast<T>(mag);
    }
    return true;
}

inline bool decode(const Data& d, std::string& out) {
    if (d.type == NodeType::Null) {
        out = "null";
        return true;
    }
    if (d.type != NodeType::Scalar) return false;
    out = d.scalar;
    return true;
}
inline bool decode(const Data& d, bool& out) {
    if (d.type != NodeType::Scalar) return false;
    const std::string s = lower(d.scalar);
    if (s == "y" || s == "yes" || s == "true" || s == "on") return out = true, true;
    if (s == "n" || s == "no" || s == "false" || s == "off") return out = false, true;
    return false;
}
template <class T, std::enable_if_t<std::is_integral_v<T> && !std::is_same_v<T, bool>, int> = 0>
bool decode(const Data& d, T& out) {
    return d.type == NodeType::Scalar && parse_integer<T>(d.scalar, out);
}
template <class T, std::enable_if_t<std::is_floating_point_v<T>, int> = 0>
bool decode(const Data& d, T& out) {
    if (d.type != NodeType::Scalar || d.scalar.empty()) return false;
    char* end = nullptr;
    const double v = std::strtod(d.scalar.c_str(), &end);
    if (end != d.scalar.c_str() + d.scalar.size()) return false;
    out = static_cast<T>(v);
    return true;
}

// sequences convert to standard containers, element by element (yaml-cpp's convert<std::list<T>> ...)
template <class C, class T>
bool decode_sequence(const Data& d, C& out) {
    if (d.type != NodeType::Sequence) return false;
    for (const auto& e : d.seq) {
        T t{};
        if (!decode(*e, t)) return false;
        out.insert(out.end(), std::move(t));
    }
    return true;
}
template <class T> bool decode(const Data& d, std::list<T>& out) { return decode_sequence<std::list<T>, T>(d, out); }
template <class T> bool decode(const Data& d, std::vector<T>& out) { return decode_sequence<std::vector<T>, T>(d, out); }
template <class T> bool decode(const Data& d, std::set<T>& out) { return decode_sequence<std::set<T>, T>(d, out); }

template <class T>
std::string to_scalar(const T& v) {
    if constexpr (std::is_same_v<T, bool>) return v ? "true" : "false";
    else if constexpr (std::is_integral_v<T>) return std::to_string(v);
    else if constexpr (std::is_floating_point_v<T>) {
        std::ostringstream o;
        o << v;
        return o.str();
    } else return std::string(v);
}

template <class T>
inline constexpr bool is_map_like = requires { typename T::mapped_type; };
template <class T>
inline constexpr bool is_seq_like = requires { typename T::value_type; } && !is_map_like<T> &&
                                    !std::is_same_v<T, std::string> && !std::is_same_v<T, std::string_view>;

// Any value a Node can be assigned from: scalars, and standard maps / sequences of them.
template <class T>
DataPtr to_data(const T& v) {
    if constexpr (is_map_like<T>) {
        auto d = make(NodeType::Map);
        for (const auto& kv : v) {
            auto k = make(NodeType::Scalar);
            k->scalar = to_scalar(kv.first);
            d->map.emplace_back(k, to_data(kv.second));
        }
        return d;
    } else if constexpr (is_seq_like<T>) {
        auto d = make(NodeType::Sequence);
        for (const auto& e : v) d->seq.push_back(to_data(e));
        return d;
    } else {
        auto d = make(NodeType::Scalar);
        d->scalar = to_scalar(v);
        return d;
    }
}
}  // namespace detail

class Node {
public:
    struct iterator_value;
    class const_iterator;
    using iterator = const_iterator;

    Node() : d_(detail::make(NodeType::Null)) {}
    explicit Node(NodeType t) : d_(detail::make(t)) {}
    template <class T, std::enable_if_t<!std::is_same_v<std::decay_t<T>, Node> && !std::is_same_v<std::decay_t<T>, NodeType> &&
                                            !std::is_base_of_v<Node, std::decay_t<T>>, int> = 0>
    explicit Node(const T& v) : d_(detail::to_data(v)) {}
    Node(const Node&) = default;
    explicit Node(detail::DataPtr d) : d_(std::move(d)) {}

    // Assignment replaces the node's content for everyone who shares it.
    Node& operator=(const Node& rhs) {
        if (d_ != rhs.d_) *d_ = *rhs.d_;
        return *this;
    }
    template <class T, std::enable_if_t<!std::is_base_of_v<Node, std::decay_t<T>>, int> = 0>
    Node& operator=(const T& v) {
        *d_ = *detail::to_data(v);
        return *this;
    }

    NodeType Type() const { return d_->type; }
    bool IsDefined() const { return d_->type != NodeType::Undefined; }
    bool IsNull() const { return d_->type == NodeType::Null; }
    bool IsScalar() const { return d_->type == NodeType::Scalar; }
    bool IsSequence() const { return d_->type == NodeType::Sequence; }
    bool IsMap() const { return d_->type == NodeType::Map; }
    explicit operator bool() const { return IsDefined(); }
    bool operator!() const { return !IsDefined(); }
    const std::string& Scalar() const { return d_->scalar; }

    template <class T>
    T as() const {
        if (!IsDefined()) throw InvalidNode();
        T t{};
        if (!detail::decode(*d_, t)) throw BadConversion();
        return t;
    }
    template <class T, class S>
    T as(const S& fallback) const {
        if (!IsDefined()) return static_cast<T>(fallback);
        T t{};
        return detail::decode(*d_, t) ? t : static_cast<T>(fallback);
    }

    size_t size() const {
        if (d_->type == NodeType::Sequence) return d_->seq.size();
        if (d_->type == NodeType::Map) {
            size_t n = 0;
            for (const auto& kv : d_->map) n += kv.second->type != NodeType::Undefined ? 1 : 0;
            return n;
        }
        return 0;
    }

    template <class K>
    const Node operator[](const K& key) const {
        return lookup(key, false);
    }
    template <class K>
    Node operator[](const K& key) {
        return lookup(key, true);
    }

    void push_back(const Node& v) {
        if (d_->type == NodeType::Null || d_->type == NodeType::Undefined) d_->type = NodeType::Sequence;
        d_->seq.push_back(v.d_);
    }
    template <class T, std::enable_if_t<!std::is_base_of_v<Node, std::decay_t<T>>, int> = 0>
    void push_back(const T& v) {
        push_back(Node(v));
    }

    iterator_value make_value(size_t i) const;
    const_iterator begin() const;
    const_iterator end() const;

    friend std::string Dump(const Node&);

protected:
    detail::DataPtr d_;

private:
    template <class K>
    Node lookup(const K& key, bool create) const {
        if constexpr (std::is_integral_v<K> && !std::is_same_v<K, bool>) {
            if (d_->type == NodeType::Sequence) {
                if (static_cast<size_t>(key) < d_->seq.size()) return Node(d_->seq[static_cast<size_t>(key)]);
                return Node(NodeType::Undefined);
            }
        }
        const std::string k = detail::to_scalar(key);
        if (d_->type != NodeType::Map) {
            if (!create || (d_->type != NodeType::Null && d_->type != NodeType::Undefined)) return Node(NodeType::Undefined);
            d_->type = NodeType::Map;
        }
        for (const auto& kv : d_->map)
            if (kv.first->scalar == k) return Node(kv.second);
        if (!create) return Node(NodeType::Undefined);
        auto key_d = detail::make(NodeType::Scalar);
        key_d->scalar = k;
        auto val_d = detail::make(NodeType::Undefined);  // invisible until it is assigned
        d_->map.emplace_back(key_d, val_d);
        return Node(val_d);
    }
};

struct Node::iterator_value : public Node, public std::pair<Node, Node> {
    iterator_value() : Node(NodeType::Undefined), std::pair<Node, Node>(Node(NodeType::Undefined), Node(NodeType::Undefined)) {}
};

class Node::const_iterator {
public:
    const_iterator() = default;
    const_iterator(std::shared_ptr<std::vector<iterator_value>> items, size_t i) : items_(std::move(items)), i_(i) {}
    const iterator_value& operator*() const { return (*items_)[i_]; }
    const iterator_value* operator->() const { return &(*items_)[i_]; }
    const_iterator& operator++() {
        ++i_;
        return *this;
    }
    const_iterator operator++(int) {
        auto c = *this;
        ++i_;
        return c;
    }
    bool operator==(const const_iterator& o) const { return i_ == o.i_; }
    bool operator!=(const const_iterator& o) const { return i_ != o.i_; }

private:
    std::shared_ptr<std::vector<iterator_value>> items_;
    size_t i_ = 0;
};

inline Node::const_iterator Node::begin() const {
    auto items = std::make_shared<std::vector<iterator_value>>();
    if (d_->type == NodeType::Sequence) {
        for (const auto& e : d_->seq) {
            iterator_value v;
            static_cast<Node&>(v) = Node(e);
            items->push_back(v);
        }
    } else if (d_->type == NodeType::Map) {
        for (const auto& kv : d_->map) {
            if (kv.second->type == NodeType::Undefined) continue;
            iterator_value v;
            v.first = Node(kv.first);
            v.second = Node(kv.second);
            items->push_back(v);
        }
    }
    return const_iterator(items, 0);
}
inline Node::const_iterator Node::end() const {
    auto items = std::make_shared<std::vector<iterator_value>>();
    const_iterator b = begin();
    size_t n = 0;
    if (d_->type == NodeType::Sequence) n = d_->seq.size();
    else if (d_->type == NodeType::Map) n = size();
    return const_iterator(items, n);
}

Node Load(const std::string& input);  // yaml_shim.cpp (libyaml)
inline std::string Dump(const Node& n);
inline std::ostream& operator<<(std::ostream& o, const Node& n) { return o << Dump(n); }

namespace detail {
inline std::string quote_if_needed(const std::string& s) {
    bool plain = !s.empty();
    if (plain) {
        const char f = s.front(), l = s.back();
        if (std::isspace(static_cast<unsigned char>(f)) || std::isspace(static_cast<unsigned char>(l))) plain = false;
        if (std::string("-?:,[]{}#&*!|>'\"%@`").find(f) != std::string::npos) plain = false;
        for (const char c : s)
            if (c == '\n' || c == '\t' || c == '\r' || c == '#' || c == '"' || c == '\\') plain = false;
        if (s.find(": ") != std::string::npos || (!s.empty() && s.back() == ':')) plain = false;
        const std::string lc = lower(s);
        if (lc == "~" || lc == "null") plain = false;
    }
    if (plain) return s;
    std::string out = "\"";
    for (const char c : s) {
        if (c == '"' || c == '\\') out += '\\', out += c;
        else if (c == '\n') out += "\\n";
        else if (c == '\t') out += "\\t";
        else if (c == '\r') out += "\\r";
        else out += c;
    }
    return out + "\"";
}
inline void emit(const Data& n, int indent, std::string& out) {
    const std::string pad(static_cast<size_t>(indent), ' ');
    auto scalar_like = [](const Data& c) { return c.type == NodeType::Scalar || c.type == NodeType::Null; };
    auto empty_coll = [](const Data& c) {
        if (c.type == NodeType::Sequence) return c.seq.empty();
        size_t k = 0;
        for (const auto& kv : c.map) k += kv.second->type != NodeType::Undefined;
        return c.type == NodeType::Map && k == 0;
    };
    auto inline_value = [&](const Data& c) {
        if (c.type == NodeType::Null) return std::string("~");
        if (c.type == NodeType::Scalar) return quote_if_needed(c.scalar);
        return std::string(c.type == NodeType::Sequence ? "[]" : "{}");
    };
    if (n.type == NodeType::Map) {
        for (const auto& kv : n.map) {
            if (kv.second->type == NodeType::Undefined) continue;
            out += pad + quote_if_needed(kv.first->scalar) + ":";
            if (scalar_like(*kv.second) || empty_coll(*kv.second)) out += " " + inline_value(*kv.second) + "\n";
            else {
                out += "\n";
                emit(*kv.second, indent + 2, out);
            }
        }
    } else if (n.type == NodeType::Sequence) {
        for (const auto& e : n.seq) {
            if (e->type == NodeType::Undefined) continue;
            out += pad + "-";
            if (scalar_like(*e) || empty_coll(*e)) out += " " + inline_value(*e) + "\n";
            else {
                out += "\n";
                emit(*e, indent + 2, out);
            }
        }
    }
}
}  // namespace detail

inline std::string Dump(const Node& n) {
    const detail::Data& d = *n.d_;
    std::string out;
    if (d.type == NodeType::Scalar) return detail::quote_if_needed(d.scalar);
    if (d.type == NodeType::Null || d.type == NodeType::Undefined) return "~";
    if ((d.type == NodeType::Map && n.size() == 0)) return "{}";
    if (d.type == NodeType::Sequence && d.seq.empty()) return "[]";
    detail::emit(d, 0, out);
    if (!out.empty() && out.back() == '\n') out.pop_back();
    return out;
}

}  // namespace YAML
