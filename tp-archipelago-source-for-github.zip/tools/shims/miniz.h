// HOST TEST SHIM, not miniz: maps the few miniz calls src/ap/ws_deflate.cpp makes onto the system
// zlib, so the mod's real inflate code can be run on a development machine that has no miniz.
// The mod itself links the real miniz (see CMakeLists.txt).
#pragma once
#define ZLIB_CONST
#include <zlib.h>
typedef z_stream mz_stream;
#define MZ_OK Z_OK
#define MZ_STREAM_END Z_STREAM_END
#define MZ_BUF_ERROR Z_BUF_ERROR
#define MZ_SYNC_FLUSH Z_SYNC_FLUSH
#define MZ_DEFAULT_WINDOW_BITS 15
static inline int mz_inflateInit2(mz_stream* s, int bits) { return inflateInit2(s, bits); }
static inline int mz_inflate(mz_stream* s, int flush) { return inflate(s, flush); }
static inline int mz_inflateEnd(mz_stream* s) { return inflateEnd(s); }
