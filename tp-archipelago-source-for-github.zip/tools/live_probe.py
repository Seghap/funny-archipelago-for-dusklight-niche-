#!/usr/bin/env python3
"""Read-only probe of a live Archipelago room, mirroring what the mod does when it connects.

It performs exactly the mod's handshake (RoomInfo, then Connect with game "Twilight Princess",
items_handling 0b101 and a GetDataPackage in the same frame, offering permessage-deflate),
reads the Connected packet and the data package, then asks LocationScouts (create_as_hint 0)
for every location of the slot. It sends nothing that changes the multiworld: no
LocationChecks, no StatusUpdate, no Say.

    python3 -I output/tools/live_probe.py HOST PORT "SLOT NAME" [PASSWORD]

Writes output/tools/live/capture.json for tools/live_check.py and tools/gc_adapter_cli.
Standard library only.
"""
import base64
import hashlib
import json
import os
import socket
import ssl
import struct
import sys
import time
import zlib
from pathlib import Path

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parents[1]
LIVE = OUT / "tools" / "live"


class WS:
    def __init__(self, host, port, secure, offer_deflate=True, timeout=15):
        raw = socket.create_connection((host, port), timeout)
        self.sock = ctx_wrap(raw, host) if secure else raw
        self.sock.settimeout(timeout)
        self.buf = b""
        self.inflater = None
        self.log = []  # every message as received: compressed flag, raw payload, plaintext
        key = base64.b64encode(os.urandom(16)).decode()
        # exactly what the mod offers (src/ap/ws_tcp.cpp send_upgrade): the bare extension
        ext = "Sec-WebSocket-Extensions: permessage-deflate\r\n" if offer_deflate else ""
        req = (f"GET / HTTP/1.1\r\nHost: {host}:{port}\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n"
               f"Sec-WebSocket-Key: {key}\r\nSec-WebSocket-Version: 13\r\n{ext}\r\n")
        self.sock.sendall(req.encode())
        head = self._read_until(b"\r\n\r\n").decode("latin1")
        lines = head.split("\r\n")
        if " 101 " not in lines[0]:
            raise RuntimeError("upgrade refused: " + lines[0])
        hdr = {l.split(":", 1)[0].strip().lower(): l.split(":", 1)[1].strip() for l in lines[1:] if ":" in l}
        want = base64.b64encode(hashlib.sha1((key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").encode()).digest()).decode()
        if hdr.get("sec-websocket-accept") != want:
            raise RuntimeError("bad Sec-WebSocket-Accept")
        self.extensions = hdr.get("sec-websocket-extensions", "")
        if "permessage-deflate" in self.extensions:
            self.inflater = zlib.decompressobj(-15)  # persistent: the server keeps context between messages

    def _read_until(self, marker):
        while marker not in self.buf:
            chunk = self.sock.recv(65536)
            if not chunk:
                raise RuntimeError("connection closed during handshake")
            self.buf += chunk
        i = self.buf.index(marker) + len(marker)
        out, self.buf = self.buf[:i], self.buf[i:]
        return out

    def _need(self, n):
        while len(self.buf) < n:
            chunk = self.sock.recv(65536)
            if not chunk:
                raise EOFError("closed")
            self.buf += chunk

    def _take(self, n):
        self._need(n)
        out, self.buf = self.buf[:n], self.buf[n:]
        return out

    def send_text(self, text):
        payload = text.encode()
        mask = os.urandom(4)
        n = len(payload)
        head = bytes([0x81])
        if n < 126:
            head += bytes([0x80 | n])
        elif n <= 0xFFFF:
            head += bytes([0x80 | 126]) + struct.pack(">H", n)
        else:
            head += bytes([0x80 | 127]) + struct.pack(">Q", n)
        self.sock.sendall(head + mask + bytes(b ^ mask[i % 4] for i, b in enumerate(payload)))

    def recv_message(self):
        """Next complete text message (control frames are handled), or None on close."""
        fragments, compressed, started = b"", False, False
        while True:
            b0, b1 = self._take(2)
            fin, rsv1, opcode = b0 & 0x80, b0 & 0x40, b0 & 0x0F
            n = b1 & 0x7F
            if n == 126:
                n = struct.unpack(">H", self._take(2))[0]
            elif n == 127:
                n = struct.unpack(">Q", self._take(8))[0]
            payload = self._take(n)
            if opcode == 0x9:  # ping
                self._send_control(0xA, payload)
                continue
            if opcode == 0xA:
                continue
            if opcode == 0x8:
                return None
            if opcode in (0x1, 0x2):
                started, compressed = True, bool(rsv1)
                fragments = payload
            elif opcode == 0x0 and started:
                fragments += payload
            if fin:
                data = fragments
                raw = fragments
                if compressed:
                    data = self.inflater.decompress(data + b"\x00\x00\xff\xff")
                self.log.append({"compressed": compressed, "payload": raw, "plain": data})
                return data.decode("utf-8")

    def _send_control(self, opcode, payload=b""):
        mask = os.urandom(4)
        self.sock.sendall(bytes([0x80 | opcode, 0x80 | len(payload)]) + mask +
                          bytes(b ^ mask[i % 4] for i, b in enumerate(payload)))

    def close(self):
        try:
            self._send_control(0x8, struct.pack(">H", 1000))
            self.sock.close()
        except OSError:
            pass


def fnv1a64(data):
    h = 0xcbf29ce484222325
    for b in data:
        h = ((h ^ b) * 0x100000001b3) & 0xFFFFFFFFFFFFFFFF
    return f"{h:016x}"


def ctx_wrap(raw, host):
    return ssl.create_default_context().wrap_socket(raw, server_hostname=host)


def main():
    if len(sys.argv) < 4:
        sys.exit(__doc__)
    host, port, slot = sys.argv[1], int(sys.argv[2]), sys.argv[3]
    password = sys.argv[4] if len(sys.argv) > 4 else ""

    ws, how = None, None
    for secure in (True, False):  # the mod's order for a remote host: wss first, then ws
        try:
            ws = WS(host, port, secure)
            how = "wss" if secure else "ws"
            break
        except Exception as e:
            print(f"{'wss' if secure else 'ws'}://{host}:{port} failed: {type(e).__name__}: {e}")
    if ws is None:
        sys.exit("could not connect")
    print(f"connected over {how}; extensions negotiated: {ws.extensions or 'none'}")

    cap = {"transport": how, "extensions": ws.extensions, "packets": {}, "data_package_games": {}}
    t0 = time.time()

    def next_packets(timeout=12):
        ws.sock.settimeout(timeout)
        msg = ws.recv_message()
        if msg is None:
            raise EOFError("server closed the connection")
        return json.loads(msg)

    room = next_packets()[0]
    assert room["cmd"] == "RoomInfo", room["cmd"]
    cap["room_info"] = {k: room.get(k) for k in ("seed_name", "version", "generator_version", "games", "password",
                                                  "permissions", "hint_cost", "location_check_points", "tags")}
    print("RoomInfo: seed", room["seed_name"], "| games:", room["games"], "| password:", room["password"])

    ws.send_text(json.dumps([
        {"cmd": "Connect", "password": password, "game": "Twilight Princess", "name": slot,
         "uuid": "livetest" + os.urandom(8).hex(), "version": {"major": 0, "minor": 6, "build": 2, "class": "Version"},
         "items_handling": 0b101, "tags": [], "slot_data": True},
        {"cmd": "GetDataPackage", "games": room["games"]}]))

    connected, received, got_dp = None, [], False
    deadline = time.time() + 30
    while time.time() < deadline and not (connected and got_dp):
        for p in next_packets():
            cmd = p["cmd"]
            if cmd == "ConnectionRefused":
                print("REFUSED:", p.get("errors"))
                cap["refused"] = p.get("errors")
                ws.close()
                LIVE.mkdir(parents=True, exist_ok=True)
                (LIVE / "capture.json").write_text(json.dumps(cap, indent=1))
                sys.exit(1)
            elif cmd == "Connected":
                connected = p
            elif cmd == "DataPackage":
                got_dp = True
                for g, gd in p["data"]["games"].items():
                    cap["data_package_games"][g] = {"items": len(gd["item_name_to_id"]),
                                                    "locations": len(gd["location_name_to_id"])}
                    if g == "Twilight Princess":
                        cap["tp_item_name_to_id"] = gd["item_name_to_id"]
                        cap["tp_location_name_to_id"] = gd["location_name_to_id"]
            elif cmd == "ReceivedItems":
                received.append(p)
            elif cmd == "RoomUpdate":
                pass
    if not connected:
        sys.exit("no Connected packet")
    cap["connected"] = {k: connected.get(k) for k in ("slot", "team", "players", "slot_info", "slot_data",
                                                       "checked_locations", "missing_locations", "hint_points")}
    print(f"Connected as slot {connected['slot']} (team {connected['team']}): "
          f"{len(connected['checked_locations'])} checked, {len(connected['missing_locations'])} missing")
    print("slot_data keys:", sorted(connected["slot_data"]))
    print("data package:", cap["data_package_games"])

    ids = sorted(set(connected["checked_locations"]) | set(connected["missing_locations"]))
    infos = []
    for i in range(0, len(ids), 500):
        ws.send_text(json.dumps([{"cmd": "LocationScouts", "locations": ids[i:i + 500], "create_as_hint": 0}]))
    want = len(ids)
    got = 0
    deadline = time.time() + 30
    while got < want and time.time() < deadline:
        for p in next_packets():
            if p["cmd"] == "LocationInfo":
                infos.extend(p["locations"])
                got += len(p["locations"])
            elif p["cmd"] == "ReceivedItems":
                received.append(p)
    # a moment for the start inventory
    try:
        for p in next_packets(timeout=2):
            if p["cmd"] == "ReceivedItems":
                received.append(p)
    except Exception:
        pass
    cap["scouted"] = infos
    cap["wire"] = [{"compressed": m["compressed"], "payload_hex": m["payload"].hex(), "plain_size": len(m["plain"]),
                    "plain_fnv1a64": fnv1a64(m["plain"])} for m in ws.log]
    cap["received_items"] = [{"index": r.get("index"), "items": r["items"]} for r in received]
    print(f"scouted {len(infos)}/{want} locations; ReceivedItems packets: {len(received)} "
          f"({sum(len(r['items']) for r in received)} items)")
    ws.close()
    LIVE.mkdir(parents=True, exist_ok=True)
    (LIVE / "capture.json").write_text(json.dumps(cap, indent=1))
    print(f"wrote tools/live/capture.json in {time.time() - t0:.1f}s")


if __name__ == "__main__":
    main()
