#include "cover_art.hpp"
#include <cstdio>
#include <fstream>
#include <iterator>
#include <vector>
using namespace ap::cover_art;
static std::vector<uint8_t> load(const char* p) { std::ifstream f(p, std::ios::binary); return {std::istreambuf_iterator<char>(f), {}}; }
static int bad = 0;
#define CHECK(c, m) do { std::printf("%s  %s\n", (c) ? "ok" : "FAIL", m); if (!(c)) ++bad; } while (0)
int main(int, char** argv) {
    const std::string dir = argv[1];
    auto ic = load((dir + "/icon.png").c_str());
    auto co = load((dir + "/cover.png").c_str());
    auto a = process(ic.data(), ic.size(), Style::Icon);
    CHECK(a && a->width == 256 && a->height == 256 && a->aspect > 0.99f && a->aspect < 1.01f, "a square icon becomes a 256x256 texture");
    if (a) {
        const size_t corner = 0;  // top-left pixel: transparent in the art
        CHECK(a->texels[corner * 4 + 3] == 255, "the world texture is opaque");
        CHECK(a->texels[0] == 34 && a->texels[1] == 34 && a->texels[2] == 40, "its transparent corner shows the dark backdrop");
        const size_t centre = (128 * 256 + 128) * 4;
        CHECK(a->texels[centre] > 150 && a->texels[centre + 1] < 80, "the art itself is kept (red disc)");
        CHECK(a->iconSize == 192 && a->icon[3] == 0, "the text box icon keeps its transparent corner");
        const size_t ic_centre = (96 * 192 + 96) * 4;
        CHECK(a->icon[ic_centre + 3] == 255 && a->icon[ic_centre] > 150, "and fills the square with the art");
    }
    auto b = process(co.data(), co.size(), Style::Cover);
    CHECK(b && b->width == 256 && b->height == 384, "a portrait cover is still 256x384");
    nlohmann::json r = nlohmann::json::parse(std::string(R"({"success":true,"data":[
      {"width":0,"height":0,"mime":"image/vnd.microsoft.icon","thumb":"https://cdn2.x/icon/aa/32/64x64.png","url":"https://cdn2.x/icon/aa.ico"},
      {"width":0,"height":0,"mime":"image/vnd.microsoft.icon","thumb":"https://cdn2.x/icon/bb/32/256x256.png","url":"https://cdn2.x/icon/bb.ico"},
      {"width":512,"height":512,"mime":"image/png","thumb":"https://cdn2.x/icon_thumb/cc.png","url":"https://cdn2.x/icon/cc.png"}]})"));
    CHECK(pick_icon(r) == "https://cdn2.x/icon/cc.png", "a square PNG icon is preferred");
    nlohmann::json r2 = nlohmann::json::parse(std::string(R"({"success":true,"data":[
      {"width":0,"height":0,"mime":"image/vnd.microsoft.icon","thumb":"https://cdn2.x/icon/aa/32/64x64.png","url":"https://cdn2.x/icon/aa.ico"},
      {"width":0,"height":0,"mime":"image/vnd.microsoft.icon","thumb":"https://cdn2.x/icon/bb/32/256x256.png","url":"https://cdn2.x/icon/bb.ico"}]})"));
    CHECK(pick_icon(r2) == "https://cdn2.x/icon/bb/32/256x256.png", "otherwise the largest .ico preview");
    CHECK(pick_icon(nlohmann::json::parse(std::string(R"({"success":true,"data":[]})"))).empty(), "no icons: nothing picked");
    return bad;
}
