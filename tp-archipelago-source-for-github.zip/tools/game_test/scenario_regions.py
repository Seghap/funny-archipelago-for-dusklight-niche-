#!/usr/bin/env python3
"""Regions beyond Ordon: the game loads each under the Archipelago seed.

    python3 -I tools/game_test/scenario_regions.py          # a curated set, about 25 minutes
    python3 -I tools/game_test/scenario_regions.py --all    # every map of the Warp window, over an hour
    python3 -I tools/game_test/scenario_regions.py --from "Gerudo Desert"   # start at a region

New file against the fake room, then the game's own Warp window takes Link to each map (default room,
point and layer: the mod's start flags and layer logic decide what the map looks like). After each:
the game is still running and the screen is not black. At the end the game's log has no error. The
screenshots (.gametest/shots/region_*.png) show what the start flags do: the three twilights of this
room's settings are cleared, so Faron, Kakariko and Zora's Domain should look like daylight.
"""
import re
import subprocess
import sys
import time
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import env  # noqa: E402
from flows import Rig  # noqa: E402

results = []

CURATED = [
    ("Hyrule Field", "Hyrule Field"),
    ("Faron", "South Faron Woods"), ("Faron", "North Faron Woods"), ("Faron", "Sacred Grove"),
    ("Faron", "Faron Woods Cave"), ("Faron", "Coro's House"),
    ("Eldin", "Kakariko Village"), ("Eldin", "Death Mountain Trail"), ("Eldin", "Kakariko Graveyard"),
    ("Eldin", "Renado's Sanctuary"), ("Eldin", "Malo Mart"),
    ("Lanayru", "Castle Town"), ("Lanayru", "Zora's Domain"), ("Lanayru", "Lake Hylia"),
    ("Lanayru", "Zora's River"), ("Lanayru", "Telma's Bar / Secret Passage"),
    ("Gerudo Desert", "Gerudo Desert"),
    ("Snowpeak", "Snowpeak Mountain"),
    ("Forest Temple", "Forest Temple"), ("Goron Mines", "Goron Mines"), ("Lakebed Temple", "Lakebed Temple"),
    ("Arbiter's Grounds", "Arbiter's Grounds"), ("Snowpeak Ruins", "Snowpeak Ruins"),
    ("Temple of Time", "Temple of Time"), ("City in the Sky", "City in the Sky"),
    ("Palace of Twilight", "Palace of Twilight"), ("Hyrule Castle", "Hyrule Castle"),
    ("Mini-Dungeons and Grottos", "Cave Of Ordeals"),
]


def check(name, ok, detail=""):
    results.append(ok)
    print(("PASS  " if ok else "FAIL  ") + name + (f"  [{detail}]" if detail and not ok else ""), flush=True)


def slug(*names):
    return re.sub(r"[^a-z0-9]+", "_", "_".join(names).lower()).strip("_")


def brightness(path):
    """Mean grey level of an image, 0 (black) to 1 (white)."""
    for tool in (["magick"], ["convert"]):
        r = subprocess.run([*tool, str(path), "-colorspace", "Gray", "-format", "%[fx:mean]", "info:"],
                           capture_output=True, text=True)
        if r.returncode == 0 and r.stdout.strip():
            return float(r.stdout.strip())
    return 1.0


def main():
    if "--all" in sys.argv:
        # Not Ordon (scenario_ordon), not the cutscene maps, and not Bulblin Camp's first room, which
        # the game's own warp table says "can't load far enough": it leaves a black screen.
        targets = [(r, m) for r, maps in Rig.warp_table() for m in maps
                   if r not in ("Ordon", "Misc") and m != "Bulblin Camp"]
    else:
        targets = CURATED
    table = Rig.warp_table()
    order = {r: i for i, (r, _) in enumerate(table)}
    if "--from" in sys.argv:       # resume a long sweep at a region: the Warp window still starts from the top
        first = sys.argv[sys.argv.index("--from") + 1]
        targets = [t for t in targets if [r for r, _ in table].index(t[0]) >= [r for r, _ in table].index(first)]
    targets = sorted(targets, key=lambda t: (order[t[0]], dict(table)[t[0]].index(t[1])))
    with Rig() as rig:
        # The game's own cheats keep Link alive: a Game Over screen would block the Warp window.
        rig.start_game(fresh=True, extra=("--config", "backend.enableAdvancedSettings=true",
                                          "--config", "game.infiniteHearts=true", "--config", "game.infiniteOxygen=true"))
        rig.new_file()
        for region, name in targets:
            rig.warp_to(region, name)
            shot = f"region_{slug(region, name)}"
            rig.shot(shot)
            alive = rig.ctl("alive") == "alive"
            lum = brightness(env.WORK / "shots" / f"{shot}.png")
            ok = alive and lum > 0.02
            check(f"{region} / {name}: running, not black", ok, f"alive={alive} brightness={lum:.3f}")
            if not ok:
                break          # a black screen blocks the menu: the rest would only fail for that reason
    log = env.read_log(dict(logs=env.WORK / "ctl" / "logs"))
    errors = [l for l in log.splitlines() if ("[ERROR" in l or "[FATAL" in l) and "Failed to open file" not in l]
    check("the game's log has no errors", not errors, "; ".join(e[:120] for e in errors[:3]))
    print(f"\nscreenshots: {env.WORK / 'shots'}/region_*.png")
    return 0 if all(results) else 1


if __name__ == "__main__":
    sys.exit(main())
