#!/usr/bin/env python3
"""A location check in the real game: open the Wooden Sword Chest in Link's House.

    python3 -I tools/game_test/scenario_checks.py

New file against the fake room, warp into Link's House (the game's own Warp window), walk to the
chest and open it with A. Asserted:

  * the room receives LocationChecks with the Wooden Sword Chest's id (from the data package), once,
    before the text box is dismissed: the check is reported when the chest opens, not later
  * the item the game hands over is the one the room says is there (Piece of Heart, 0x21) and never
    the engine's default Green Rupee (0x01)
  * the overlay's check counter shows it (screenshot s_checks_*.png)
"""
import json
import sys
import time
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from flows import Rig  # noqa: E402

results = []


def check(name, ok, detail=""):
    results.append(ok)
    print(("PASS  " if ok else "FAIL  ") + name + (f"  [{detail}]" if detail and not ok else ""), flush=True)


def main():
    cap = json.loads((HERE.parents[1] / "tools/live/capture.json").read_text())
    chest_id = cap["tp_location_name_to_id"]["Wooden Sword Chest"]
    placed = next(s for s in cap["scouted"] if s["location"] == chest_id)
    expected_item = cap["tp_item_name_to_id"]
    expected_name = next(n for n, i in expected_item.items() if i == placed["item"])

    with Rig() as rig:
        rig.start_game(fresh=True, extra=("--config", "backend.enableAdvancedSettings=true"))
        rig.new_file()
        rig.warp_to_ordon("Link's House")
        before = [e for e in rig.fake_log() if e["dir"] == "in" and e["packet"].get("cmd") == "LocationChecks"]
        check("no location check has been sent before the chest is opened", not before)
        rig.pad("stick", 0, -1, 0.7, settle=1.2)       # from the door to the chest
        rig.pad("stick", -0.4, -1, 0.35, settle=1.2)
        rig.pad("stick", 0, -1, 0.3, settle=1.2)
        rig.shot("s_checks_before")
        rig.tap("a", settle=2.5)                        # open: the text box is up, nothing dismissed yet
        sent = [e["packet"] for e in rig.fake_log() if e["dir"] == "in" and e["packet"].get("cmd") == "LocationChecks"]
        rig.shot("s_checks_open")
        ids = [i for p in sent for i in p["locations"]]
        check("the Wooden Sword Chest is reported while its text box is still up", ids == [chest_id], f"{ids} vs {chest_id}")
        rig.tap("a", settle=3.5)
        rig.shot("s_checks_text")
        rig.tap("a", settle=3)                          # dismiss "You got ..."
        trail = rig.trail()
        gives = [l for l in trail if "give item=" in l and "chest:R_SP01:4" in l]
        check("the chest gave the item the room placed there", any(f"({expected_name})" in l for l in gives),
              f"{gives} vs {expected_name}")
        check("the engine's default Green Rupee was not given", not any("give item=0x01 " in l for l in gives))
        rig.shot("s_checks_after")
    print(f"\nscreenshots: {HERE.parents[1] / '.gametest/shots'}/s_checks_*.png")
    return 0 if all(results) else 1


if __name__ == "__main__":
    sys.exit(main())
