#!/usr/bin/env python3
"""A virtual Xbox-style gamepad on /dev/uinput (Linux), standard library only.

Used to press buttons in the real game without typing into the player's desktop: a gamepad is only
read by programs that open game controllers, never by the compositor's focused text field.

    with VirtualPad() as pad:
        pad.tap("a")             # confirm
        pad.tap("dpad_down", n=3)
        pad.press("lt")         # the left analog trigger: L
        pad.stick(-1.0, 0.0, hold=0.3)

Needs write access to /dev/uinput (here: group ACL for the logged-in user). The device identifies as
a wired Xbox 360 controller (045e:028e), which SDL maps without any configuration.
"""
import fcntl
import os
import struct
import time

EV_SYN, EV_KEY, EV_ABS = 0, 1, 3
SYN_REPORT = 0

BTN = {  # name -> evdev code, in the layout SDL's Xbox 360 mapping expects
    "a": 0x130, "b": 0x131, "x": 0x133, "y": 0x134,
    "lb": 0x136, "rb": 0x137, "back": 0x13A, "start": 0x13B, "guide": 0x13C,
    "ls": 0x13D, "rs": 0x13E,
}
ABS_X, ABS_Y, ABS_Z, ABS_RX, ABS_RY, ABS_RZ, ABS_HAT0X, ABS_HAT0Y = 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x10, 0x11

# ioctl numbers (linux/uinput.h)
UI_SET_EVBIT = 0x40045564
UI_SET_KEYBIT = 0x40045565
UI_SET_ABSBIT = 0x40045567
UI_DEV_SETUP = 0x405C5503
UI_ABS_SETUP = 0x401C5504
UI_DEV_CREATE = 0x5501
UI_DEV_DESTROY = 0x5502


class VirtualPad:
    def __init__(self, name="Dusklight AP test pad"):
        self.fd = os.open("/dev/uinput", os.O_WRONLY | os.O_NONBLOCK)
        fcntl.ioctl(self.fd, UI_SET_EVBIT, EV_KEY)
        fcntl.ioctl(self.fd, UI_SET_EVBIT, EV_ABS)
        fcntl.ioctl(self.fd, UI_SET_EVBIT, EV_SYN)
        for code in BTN.values():
            fcntl.ioctl(self.fd, UI_SET_KEYBIT, code)
        axes = {ABS_X: (-32768, 32767, 16, 128), ABS_Y: (-32768, 32767, 16, 128), ABS_RX: (-32768, 32767, 16, 128),
                ABS_RY: (-32768, 32767, 16, 128), ABS_Z: (0, 255, 0, 0), ABS_RZ: (0, 255, 0, 0),
                ABS_HAT0X: (-1, 1, 0, 0), ABS_HAT0Y: (-1, 1, 0, 0)}
        for code, (lo, hi, fuzz, flat) in axes.items():
            fcntl.ioctl(self.fd, UI_SET_ABSBIT, code)
            # struct uinput_abs_setup { u16 code; (pad) struct input_absinfo { s32 value, min, max, fuzz, flat, res; } }
            fcntl.ioctl(self.fd, UI_ABS_SETUP, struct.pack("Hxx6i", code, 0, lo, hi, fuzz, flat, 0))
        # struct uinput_setup { struct input_id { u16 bustype, vendor, product, version; } id; char name[80]; u32 ff_effects_max; }
        setup = struct.pack("HHHH80sI", 0x03, 0x045E, 0x028E, 0x0110, name.encode(), 0)
        fcntl.ioctl(self.fd, UI_DEV_SETUP, setup)
        fcntl.ioctl(self.fd, UI_DEV_CREATE)
        time.sleep(0.5)  # let udev and SDL notice the new device

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()

    def close(self):
        if self.fd is not None:
            try:
                fcntl.ioctl(self.fd, UI_DEV_DESTROY)
            finally:
                os.close(self.fd)
                self.fd = None

    def _emit(self, etype, code, value):
        os.write(self.fd, struct.pack("llHHi", 0, 0, etype, code, value))

    def _sync(self):
        self._emit(EV_SYN, SYN_REPORT, 0)

    def press(self, button):
        if button in ("lt", "rt"):  # the analog triggers: the game's L and R on an Xbox-style pad
            self._emit(EV_ABS, ABS_Z if button == "lt" else ABS_RZ, 255)
        elif button.startswith("dpad_"):
            axis, value = {"dpad_left": (ABS_HAT0X, -1), "dpad_right": (ABS_HAT0X, 1),
                           "dpad_up": (ABS_HAT0Y, -1), "dpad_down": (ABS_HAT0Y, 1)}[button]
            self._emit(EV_ABS, axis, value)
        else:
            self._emit(EV_KEY, BTN[button], 1)
        self._sync()

    def release(self, button):
        if button in ("lt", "rt"):
            self._emit(EV_ABS, ABS_Z if button == "lt" else ABS_RZ, 0)
        elif button.startswith("dpad_"):
            axis = ABS_HAT0X if button in ("dpad_left", "dpad_right") else ABS_HAT0Y
            self._emit(EV_ABS, axis, 0)
        else:
            self._emit(EV_KEY, BTN[button], 0)
        self._sync()

    def tap(self, button, n=1, hold=0.12, gap=0.18):
        for _ in range(n):
            self.press(button)
            time.sleep(hold)
            self.release(button)
            time.sleep(gap)

    def stick(self, x, y, hold=0.2, right=False):
        ax, ay = (ABS_RX, ABS_RY) if right else (ABS_X, ABS_Y)
        self._emit(EV_ABS, ax, int(max(-1, min(1, x)) * 32767))
        self._emit(EV_ABS, ay, int(max(-1, min(1, y)) * 32767))
        self._sync()
        time.sleep(hold)
        self._emit(EV_ABS, ax, 0)
        self._emit(EV_ABS, ay, 0)
        self._sync()
