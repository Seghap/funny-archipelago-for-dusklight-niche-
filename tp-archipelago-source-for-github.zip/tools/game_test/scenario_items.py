#!/usr/bin/env python3
"""The real game, a local fake room, a virtual gamepad: a new file and then the room's side of play.

Runs unattended (needs write access to /dev/uinput and a capture from tools/live_probe.py):

    python3 -I tools/game_test/scenario_items.py [--keep-open]

  1. new file: title -> empty quest log -> connect window -> seed built -> name entry -> first scene,
     asserting what the mod and the room each saw (Connect, LocationScouts, the hint request, ...)
  2. an item sent by the room while Link stands idle reaches him
  3. an item sent while the status window is open reaches him too (and the window's text shows);
     the window's "Send goal complete" reaches the room
  4. chat, a hint and a drop of the connection: the overlay shows them, the mod reconnects by itself,
     and the items already delivered are not delivered twice
  5. a death link from another player

Screenshots of the game window go to .gametest/shots/ and are summarised at the end.
"""
import sys
import time
from pathlib import Path

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
from flows import Rig  # noqa: E402

results = []


def check(name, ok, detail=""):
    results.append(ok)
    print(("PASS  " if ok else "FAIL  ") + name + (f"  [{detail}]" if detail and not ok else ""), flush=True)


def main():
    keep_open = "--keep-open" in sys.argv
    with Rig() as rig:
        rig.start_game(fresh=True)
        rig.new_file()
        rig.shot("s1_first_scene")

        # ---- 1. what each side saw
        sent = [e["packet"].get("cmd") for e in rig.fake_log() if e["dir"] == "in"]
        for cmd in ("Connect", "GetDataPackage", "LocationScouts", "Get", "SetNotify", "ConnectUpdate"):
            check(f"the mod sent {cmd}", cmd in sent)
        trail = rig.trail()
        check("the seed was built from the room's placements", any("seed built:" in l for l in trail))
        check("the file was created", any("new save created" in l for l in trail))
        check("the connection stayed up through name entry (one Connect, no abandon)",
              sent.count("Connect") == 1 and not any("abandoned" in l for l in trail),
              f"Connect x{sent.count('Connect')}")

        # ---- 2. an item while idle
        mark = rig.mark()
        rig.fake("send", "Slingshot")
        line = rig.wait_trail("delivered item 0x4B", timeout=25, after=mark)
        check("an item sent while Link is idle is delivered", line is not None)

        # ---- 3. an item while the status window is open
        rig.tap("back", settle=1.5)           # the menu bar
        rig.tap("dpad_right", 2)
        rig.tap("a", settle=2)                # Archipelago -> the status window
        rig.shot("s3_window")
        mark = rig.mark()
        rig.fake("send", "Gale Boomerang")
        line = rig.wait_trail("delivered item 0x40", timeout=25, after=mark)
        check("an item sent while the status window is open is delivered", line is not None)
        time.sleep(1.5)
        rig.shot("s3_window_after")
        rig.tap("dpad_down", 5)               # host, port, Reconnect, Disconnect, Send goal complete
        rig.tap("a", settle=2)
        goal = [e["packet"] for e in rig.fake_log() if e["dir"] == "in" and e["packet"].get("cmd") == "StatusUpdate"]
        check("'Send goal complete' sends the goal to the room (StatusUpdate 30)",
              any(g.get("status") == 30 for g in goal), f"{goal}")
        rig.shot("s3_goal")
        rig.tap("back", settle=1.5)           # Back toggles Dusklight's menu: closes the window
        rig.shot("s3_closed")

        # ---- 4. overlay content, a dropped connection
        rig.fake("chat", "hello from Alice")
        rig.fake("hint", '"Sera Shop Slingshot"', "Slingshot", "30")
        time.sleep(3)
        rig.shot("s4_overlay")
        mark = rig.mark()
        deliveries_before = sum("delivering #" in l for l in rig.trail())
        rig.fake("drop")
        line = rig.wait_trail("connected in phase", timeout=40, after=mark)
        check("after the connection drops the mod reconnects by itself", line is not None)
        time.sleep(4)
        deliveries_after = sum("delivering #" in l for l in rig.trail())
        check("items already delivered are not delivered again after a reconnect",
              deliveries_after == deliveries_before, f"{deliveries_before} -> {deliveries_after}")
        rig.shot("s4_after_reconnect")

        # ---- 5. death link
        mark = rig.mark()
        rig.fake("death", "Alice")
        line = rig.wait_trail("death link: received from", timeout=25, after=mark)
        check("a death link from another player is received", line is not None)
        time.sleep(6)
        rig.shot("s5_death")
        if keep_open:
            input("game left open; press Enter to stop")
    print(f"\nscreenshots: {Path(__file__).resolve().parents[2] / '.gametest/shots'}")
    return 0 if all(results) else 1


if __name__ == "__main__":
    sys.exit(main())
