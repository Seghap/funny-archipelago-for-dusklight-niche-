#!/usr/bin/env python3
"""Checks played by hand in the real game (the shop, with the room's own item and with another player's;
see scenario_every_check.py for all of them replayed).

    python3 -I tools/game_test/scenario_checktypes.py [type ...]      # types: shop

Each type starts a fresh file, goes to a place where the check can be made (the game's own Warp window,
then the virtual gamepad), makes it, and asserts what the room received: LocationChecks with exactly
that location's id (looked up by name in the data package), and, where the game shows it, the item
the room put there. Screenshots: .gametest/shots/type_<name>_*.png.
"""
import json
import sys
import time
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import env  # noqa: E402
from flows import Rig  # noqa: E402

results = []
CAP = json.loads((HERE.parents[1] / "tools/live/capture.json").read_text())
CHEATS = ("--config", "backend.enableAdvancedSettings=true", "--config", "game.infiniteHearts=true")


def check(name, ok, detail=""):
    results.append(ok)
    print(("PASS  " if ok else "FAIL  ") + name + (f"  [{detail}]" if detail and not ok else ""), flush=True)


def loc_id(name):
    return CAP["tp_location_name_to_id"][name]


def item_name_at(location):
    inv = {v: k for k, v in CAP["tp_item_name_to_id"].items()}
    return inv[next(s["item"] for s in CAP["scouted"] if s["location"] == loc_id(location))]


def sent_ids(rig):
    return [i for e in rig.fake_log() if e["dir"] == "in" and e["packet"].get("cmd") == "LocationChecks"
            for i in e["packet"]["locations"]]


def give_rupees(rig, n=2):
    for _ in range(n):
        rig.fake("send", "Purple Rupee")
    rig.wait_trail("delivered item", timeout=30)
    time.sleep(8)


# ---------------------------------------------------------------------------------------------

def shop():
    """Sera's Sundries: buy the third item (where the Slingshot would be)."""
    name = "Sera Shop Slingshot"
    with Rig() as rig:
        rig.start_game(fresh=True, extra=CHEATS)
        rig.new_file()
        give_rupees(rig)
        rig.warp_to_ordon("Sera's Sundries")
        rig.pad("stick", 0, -1, 0.8, settle=1.5)           # up to the counter
        for _ in range(5):
            rig.tap("a", settle=2.5)                        # Sera's talk, down to "check out my wares"
        rig.tap("b", settle=2.5)                            # quit the talk: the shop view
        rig.pad("stick", 1, 0, 0.3, settle=1.5)             # Milk, Bee Larva, then the third item
        rig.pad("stick", 1, 0, 0.3, settle=1.5)
        rig.pad("stick", 1, 0, 0.3, settle=1.5)
        rig.shot("type_shop_selected")
        check("nothing is reported while only looking at the wares", not sent_ids(rig))
        rig.tap("a", settle=2.5)                            # "A ... is N Rupees. Do you want to buy it?"
        rig.tap("a", settle=3.0)                            # "I'll buy it": Sera's remark about the Slingshot
        rig.tap("a", settle=3.0)                            # the rupees are paid and the check is made
        rig.shot("type_shop_bought")
        ids = sent_ids(rig)
        check(f"buying it reports {name}", ids == [loc_id(name)], f"{ids} vs {loc_id(name)}")
        rig.tap("a", settle=3.0); rig.tap("a", settle=4.0)
        rig.shot("type_shop_after")
        gives = [l for l in rig.trail() if "give item=" in l]
        check(f"the game handed over what the room placed there ({item_name_at(name)}), under its shop check name",
              any(f"({item_name_at(name)})" in l and "check='shop:R_SP01:1:" in l for l in gives), str(gives))


def shop_foreign():
    """The same shelf when the room says the item there is another player's: the shelf, the prompt and
    the purchase talk name it ("Alice's Hookshot"), and the placeholder is what the game hands over."""
    name = "Sera Shop Slingshot"
    with Rig(foreign=[f"{name}=Alice:Ocarina of Time:Hookshot@1"]) as rig:
        rig.start_game(fresh=True, extra=CHEATS)
        rig.new_file()
        # (the seed's texts are compressed, so the shelf and prompt wording is read from the screenshots
        # type_shopf_*.png: "Alice's Hookshot: 30 Rupees", "Alice's Hookshot is 30 Rupees. Do you want to buy it?")
        give_rupees(rig)
        rig.warp_to_ordon("Sera's Sundries")
        rig.pad("stick", 0, -1, 0.8, settle=1.5)
        for _ in range(5):
            rig.tap("a", settle=2.5)
        rig.tap("b", settle=2.5)
        for _ in range(3):
            rig.pad("stick", 1, 0, 0.3, settle=1.5)
        rig.shot("type_shopf_selected")
        rig.tap("a", settle=2.5)
        rig.shot("type_shopf_prompt")
        rig.tap("a", settle=3.0)
        rig.tap("a", settle=3.0)
        ids = sent_ids(rig)
        check(f"buying it reports {name}", ids == [loc_id(name)], f"{ids} vs {loc_id(name)}")
        rig.tap("a", settle=3.0); rig.tap("a", settle=4.0)
        gives = [l for l in rig.trail() if "give item=" in l and "check='shop:" in l]
        check("the placeholder (0xDC) was handed over", any("give item=0xDC" in l for l in gives), str(gives))
        rig.shot("type_shopf_after")


TYPES = {"shop": shop, "shop_foreign": shop_foreign}


def main():
    wanted = [a for a in sys.argv[1:] if not a.startswith("-")] or list(TYPES)
    for t in wanted:
        print(f"== {t}", flush=True)
        TYPES[t]()
    print(f"\nscreenshots: {HERE.parents[1] / '.gametest/shots'}/type_*.png")
    return 0 if all(results) else 1


if __name__ == "__main__":
    sys.exit(main())
