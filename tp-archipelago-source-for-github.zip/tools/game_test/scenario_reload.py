#!/usr/bin/env python3
"""A file made in one run of the game, loaded in the next (real game, fake room, virtual gamepad).

    python3 -I tools/game_test/scenario_reload.py

  1. new file against the fake room; the room sends two items, both reach Link; the game is saved
     from the Collection screen (items and the delivered count are both part of the save)
  2. the game is closed and started again; the file is loaded from the quest log list
  3. the mod finds the file's seed and connection info, reconnects by itself, is told about the
     two items again by the room and does NOT hand them over a second time
  4. an item sent after the reload (index 2 in the room's list) is delivered, and the Slingshot from
     before the restart is still in the item wheel
"""
import sys
import time
from pathlib import Path

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
from flows import Rig  # noqa: E402

results = []


def check(name, ok, detail=""):
    results.append(ok)
    print(("PASS  " if ok else "FAIL  ") + name + (f"  [{detail}]" if detail and not ok else ""), flush=True)


def main():
    with Rig() as rig:
        rig.start_game(fresh=True)
        rig.new_file()
        for item, code in (("Slingshot", "0x4B"), ("Gale Boomerang", "0x40")):
            mark = rig.mark()
            rig.fake("send", item)
            check(f"{item} is delivered in the first run",
                  rig.wait_trail(f"delivered item {code}", timeout=25, after=mark) is not None)
        time.sleep(2)
        rig.save_game()   # the delivered-item count lives in the save, like the inventory: save first
        rig.shot("r0_after_save")

        # ---- the restart
        rig.ctl("stop")
        time.sleep(4)
        mark = rig.mark()
        rig.start_game(fresh=False)
        rig.load_file()
        rig.shot("r1_loaded")
        trail = rig.trail()[mark:]
        text = "\n".join(trail)
        check("the file's seed and connection info are found", "save loaded:" in text and "connection info present" in text)
        check("it records the two items as already delivered", "2 server item(s) already delivered" in text)
        check("it reconnects by itself", "connected in phase 5" in text)
        check("the room's list (2 items) is read back", "server sent 2 item(s) from index 0; 2 in total, 2 already delivered" in text)
        check("nothing is delivered a second time", "delivering #" not in text)

        # ---- play on
        mark = rig.mark()
        rig.fake("send", "Iron Boots")
        check("an item sent after the reload is delivered",
              rig.wait_trail("delivered item", timeout=25, after=mark) is not None)
        rig.tap("dpad_up", settle=3)          # the item wheel
        rig.shot("r2_items")
        rig.tap("b", settle=1)
    print(f"\nscreenshots: {Path(__file__).resolve().parents[2] / '.gametest/shots'}")
    return 0 if all(results) else 1


if __name__ == "__main__":
    sys.exit(main())
