#!/usr/bin/env python3
"""Assisted in-game session against a real Archipelago room (a person plays the menus).

Starts the installed Dusklight with only this mod, in a scratch profile (nothing of the player's own
saves or config is read or written), with the connect window's host/port/slot pre-filled. A person
then does the part that needs a controller or keyboard:

    1. Pick "Archipelago" with the arrows next to Play, press Play.
    2. Choose an empty file, "New file".
    3. In the connect window press "Connect and start" (enter the password first if the room has one).
    4. Play: open the first chest, talk to someone. To test an incoming item, type
       /send "SLOT" Slingshot in the room page's server-command box and keep Link idle.
    5. Quit, then run again with --resume and load the file: it must reconnect by itself.

Meanwhile this script follows the mod's flushed debug trail (ap_debug.log) and prints each line as it
appears, takes a window-only screenshot at every milestone, and ends with a verdict. Stop with Ctrl+C,
by closing the game, or after --minutes.

    python3 -I tools/game_test/session.py --host multiworld.gg --port 49607 --slot "HELP ME"
"""
import argparse
import sys
import time
from pathlib import Path

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
import env  # noqa: E402

# (trail substring, verdict label). Order is the order a healthy run reaches them.
MILESTONES = [
    ("connected in phase", "connected to the room and received the slot data"),
    ("new save created", "seed built from the room's placements and the new file created"),
    ("give item=", "an item was awarded through the game's item path"),
    ("sending ", "location checks were sent to the room"),
    ("delivered item", "an item sent by the room was delivered to Link (type /send in the room's console)"),
]
RESUME_MILESTONES = [
    ("save loaded", "the saved file loaded and found its seed and connection info"),
    ("connected in phase", "it reconnected to the room by itself"),
    ("delivered item", "an item sent by the room was delivered to Link"),
]
# Logged by the game itself the first time a mode's save file or a fresh profile's card file is
# opened; nothing is wrong when they appear.
BENIGN = ("Failed to open file: gczelda2", "Failed to open file: tp-archipelago")
PROBLEMS = ("failed", "refus", "not a location of this slot", "not known to this mod", "skipping server item")


def trail_files(user_dir):
    return list(Path(user_dir).rglob("ap_debug.log"))


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--host", required=True)
    ap.add_argument("--port", type=int, required=True)
    ap.add_argument("--slot", required=True)
    ap.add_argument("--minutes", type=float, default=20)
    ap.add_argument("--resume", action="store_true",
                    help="reuse the previous session's profile, so its file can be loaded; the default "
                         "starts clean and moves the previous session to .gametest/archive/")
    ap.add_argument("--dusk", default=str(env.OUT / ".build/mods/tp_archipelago.dusk"))
    a = ap.parse_args()

    prefix = env.cvar_prefix()
    e = env.prepare(a.dusk, "session", {prefix + "lastHost": a.host, prefix + "lastPort": a.port,
                                        prefix + "lastSlot": a.slot, prefix + "debugLog": True},
                    keep=a.resume, archive=True)
    milestones = RESUME_MILESTONES if a.resume else MILESTONES
    shots = e["root"] / "shots"
    shots.mkdir()
    proc = env.launch(e)
    if a.resume:
        print("Game started on the previous session's profile. Steps: Archipelago -> Play -> pick the file made last time.")
    else:
        print("Game started. Steps: Archipelago -> Play -> New file -> Connect and start -> play.")
    print(f"Scratch profile: {e['root']}\n")

    seen = {p: p.stat().st_size for p in trail_files(e["user"])}  # path -> bytes consumed; a resumed
    # profile already holds the earlier session's lines
    reached = {}       # milestone index -> trail line
    problems = []
    deadline = time.time() + a.minutes * 60
    try:
        while proc.poll() is None and time.time() < deadline:
            for path in trail_files(e["user"]):
                with open(path, "r", errors="replace") as f:
                    f.seek(seen.get(path, 0))
                    chunk = f.read()
                    seen[path] = f.tell()
                for line in chunk.splitlines():
                    print("  mod> " + line)
                    for i, (needle, _) in enumerate(milestones):
                        if needle in line and i not in reached:
                            reached[i] = line
                            env.screenshot(shots / f"milestone{i + 1}.png")
                    if any(p in line for p in PROBLEMS):
                        problems.append(line)
            time.sleep(1.0)
    except KeyboardInterrupt:
        print("\nstopping")
    finally:
        env.stop(proc)

    time.sleep(0.5)
    log = env.read_log(e).splitlines()
    errors = [l for l in log if ("[ERROR" in l or "[FATAL" in l or ("[WARNING" in l and env.MOD_ID in l))
              and not any(b in l for b in BENIGN)]
    print("\n==== verdict ====")
    for i, (_, label) in enumerate(milestones):
        print(("PASS  " if i in reached else "----  ") + label)
    print(("PASS  " if not problems else "FAIL  ") + "no failure lines in the trail" + "".join("\n        " + p for p in problems[:5]))
    print(("PASS  " if not errors else "FAIL  ") + "no ERROR/WARNING from the loader or the mod in the game log"
          + "".join("\n        " + x[:160] for x in errors[:5]))
    print(f"\ngame log: {env.newest_log(e)}\nscreenshots: {shots}")
    return 0 if len(reached) == len(milestones) and not problems and not errors else 1


if __name__ == "__main__":
    sys.exit(main())
