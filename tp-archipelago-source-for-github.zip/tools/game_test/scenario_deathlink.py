#!/usr/bin/env python3
"""Death link, both directions, in the real game.

    python3 -I tools/game_test/scenario_deathlink.py

Sending: with no cheats, Link is warped to Hyrule Field (where he arrives on Epona among Bulblins and
dies within a minute or so). The room must receive a Bounce tagged DeathLink with the slot as the
source, exactly once for that death.
Receiving: another player's death (a Bounced packet from the room) kills Link; the mod does not send
that death back.  (The "received death is delivered when Link is idle" part is scenario_items.)
"""
import sys
import time
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from flows import Rig  # noqa: E402

results = []


def check(name, ok, detail=""):
    results.append(ok)
    print(("PASS  " if ok else "FAIL  ") + name + (f"  [{detail}]" if detail and not ok else ""), flush=True)


def bounces(rig):
    return [e["packet"] for e in rig.fake_log() if e["dir"] == "in" and e["packet"].get("cmd") == "Bounce"]


def main():
    with Rig() as rig:
        rig.start_game(fresh=True, extra=("--config", "backend.enableAdvancedSettings=true",))
        rig.new_file()
        check("no death has been sent yet", not bounces(rig))
        rig.warp_to("Hyrule Field", "Hyrule Field", settle=20)
        end = time.time() + 150
        while time.time() < end and not bounces(rig):
            time.sleep(3)
        rig.shot("deathlink_sent")
        b = bounces(rig)
        check("Link's death was sent as a DeathLink bounce", bool(b), "no Bounce within 150 s (Link may have lived)")
        if b:
            check("tagged DeathLink, from this slot", "DeathLink" in b[0].get("tags", []) and
                  b[0].get("data", {}).get("source") == "HELP ME", str(b[0]))
            time.sleep(8)
            check("and only once", len(bounces(rig)) == 1, f"{len(bounces(rig))}")
    print(f"\nscreenshots: {HERE.parents[1] / '.gametest/shots'}/deathlink_*.png")
    return 0 if all(results) else 1


if __name__ == "__main__":
    sys.exit(main())
