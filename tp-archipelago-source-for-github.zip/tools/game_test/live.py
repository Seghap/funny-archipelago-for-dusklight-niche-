#!/usr/bin/env python3
"""Keep the game, the virtual pad and the fake room running between commands, to explore by hand.

    live.py up [--setting "Name=Value"]... [--foreign "Loc=Player:Game:Item"]...   # start all three, new file, in the first scene
    live.py tap BUTTON [N]            live.py stick X Y SECONDS         live.py shot NAME
    live.py warp REGION MAP [POINT]   live.py send ITEM|chat|...        (any fake-room command, see fake_ap_server.py)
    live.py trail [N]                 live.py checks                    (the location ids the room has received)
    live.py down                      (stop everything)

Used to find the way to a check before it is written into a scenario. Screenshots: .gametest/shots/NAME.png.
"""
import json
import sys
import time
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import env  # noqa: E402
from flows import Rig, send_line, PAD, FAKE  # noqa: E402

STATE = env.WORK / "live.json"
CHEATS = ("--config", "backend.enableAdvancedSettings=true", "--config", "game.infiniteHearts=true",
          "--config", "game.infiniteOxygen=true")


def load(rig):
    if STATE.exists():
        st = json.loads(STATE.read_text())
        for k in ("_warp_region", "_warp_map", "_warp_point", "_warp_map_for_point", "_warp_region_for_point"):
            if k in st:
                setattr(rig, k, st[k])


def save(rig):
    st = {k: getattr(rig, k) for k in ("_warp_region", "_warp_map", "_warp_point", "_warp_map_for_point", "_warp_region_for_point") if hasattr(rig, k)}
    STATE.write_text(json.dumps(st))


def main():
    cmd, args = sys.argv[1], sys.argv[2:]
    rig = Rig()
    load(rig)
    if cmd == "up":
        settings, foreign, i = [], [], 0
        while i < len(args):
            if args[i] == "--setting":
                settings.append(args[i + 1])
            elif args[i] == "--foreign":
                foreign.append(args[i + 1])
            i += 2
        rig.settings, rig.foreign = tuple(settings), tuple(foreign)
        rig.__enter__()
        STATE.write_text("{}")
        rig.start_game(fresh=True, extra=CHEATS)
        rig.new_file()
        print("ready")
    elif cmd == "down":
        rig.__exit__()
        STATE.unlink(missing_ok=True)
        print("stopped")
    elif cmd == "tap":
        rig.tap(args[0], int(args[1]) if len(args) > 1 else 1)
    elif cmd == "stick":
        rig.pad("stick", args[0], args[1], args[2], settle=1.0)
    elif cmd == "shot":
        print(rig.shot(args[0]))
    elif cmd == "warp":
        rig.warp_to(args[0], args[1], point=int(args[2]) if len(args) > 2 else 0)
        save(rig)
    elif cmd == "trail":
        print("\n".join(l for l in rig.trail()[-int(args[0] if args else 12):] if "vanilla" not in l))
    elif cmd == "checks":
        print([i for e in rig.fake_log() if e["dir"] == "in" and e["packet"].get("cmd") == "LocationChecks"
               for i in e["packet"]["locations"]])
    else:
        send_line(FAKE, " ".join([cmd, *args]))


if __name__ == "__main__":
    main()
