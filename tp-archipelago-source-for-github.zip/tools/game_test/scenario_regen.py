#!/usr/bin/env python3
"""A saved file whose seed has to be rebuilt from the server.

    python3 -I tools/game_test/scenario_regen.py

What a player's existing file meets when the mod's seed format changes (the cache of what the server
said is at each location carries a version; an older one is rebuilt) or when the file is carried to
another computer. A file is made and saved, the game closed, its placement cache marked as an older
version, and the file loaded again. Asserted: the mod notices, asks the server again, builds the seed
again with the same hash (the save still matches it), the game plays on, and an item sent afterwards
is delivered.
"""
import json
import sys
import time
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import env  # noqa: E402
from flows import Rig  # noqa: E402

results = []


def check(name, ok, detail=""):
    results.append(ok)
    print(("PASS  " if ok else "FAIL  ") + name + (f"  [{detail}]" if detail and not ok else ""), flush=True)


def main():
    with Rig() as rig:
        rig.start_game(fresh=True)
        rig.new_file()
        first_hash = next((l.split("seed built: ")[1].split(" ")[0:3] for l in rig.trail() if "seed built:" in l), None)
        rig.save_game()
        rig.ctl("stop")
        time.sleep(4)
        caches = list((env.WORK / "ctl/user/mod_data/local.dusklight_tp_archipelago/archipelago").rglob("ap_placements.json"))
        check("the file's placement cache exists", len(caches) == 1, str(caches))
        data = json.loads(caches[0].read_text())
        data["version"] = 1
        caches[0].write_text(json.dumps(data))
        mark = rig.mark()
        rig.start_game(fresh=False)
        rig.load_file()
        trail = rig.trail()[mark:]
        text = "\n".join(trail)
        check("the mod notices the old cache and rebuilds the seed", "seed built:" in text or "Rebuilding" in text, text[-300:])
        check("the rebuilt seed matches the save (no \"doesn't match\" in the trail)", "doesn't match this save" not in text)
        rig.shot("regen_loaded")
        mark = rig.mark()
        rig.fake("send", "Slingshot")
        check("play goes on: an item sent afterwards is delivered",
              rig.wait_trail("delivered item 0x4B", timeout=40, after=mark) is not None)
        check("the game is running", rig.ctl("alive") == "alive")
    print(f"\nscreenshots: {HERE.parents[1] / '.gametest/shots'}/regen_*.png")
    return 0 if all(results) else 1


if __name__ == "__main__":
    sys.exit(main())
