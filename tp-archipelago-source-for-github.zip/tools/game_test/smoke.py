#!/usr/bin/env python3
"""Smoke test against the installed Dusklight: needs no input, runs unattended.

Starts the real game with only this mod (isolated user/mods/log directories, see env.py), lets it
reach the prelaunch menu with the Archipelago game mode selected, and checks the game's own log:

  * the .dusk bundle is found and every mod activates (4/4 with the stock mods),
  * the game mode registers under the id the host derives for it and activates,
  * nothing is logged at ERROR/FATAL by the mod loader or the mod while running and shutting down,
  * shutdown deactivates the mode and unloads the mod exactly once,
  * a screenshot of the game window (and nothing else on the desktop) shows the mode's name.

    python3 -I tools/game_test/smoke.py [path/to/tp_archipelago.dusk]
"""
import sys
import time
from pathlib import Path

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
import env  # noqa: E402

DUSK = Path(sys.argv[1]) if len(sys.argv) > 1 else env.OUT / ".build/mods/tp_archipelago.dusk"

results = []


def check(name, ok, detail=""):
    results.append(ok)
    print(("PASS  " if ok else "FAIL  ") + name + (f"  [{detail}]" if detail and not ok else ""))


def main():
    if not DUSK.exists():
        print(f"no bundle at {DUSK}; build first (see docs/TESTING.md)")
        return 2
    prefix = env.cvar_prefix()
    e = env.prepare(DUSK, "smoke", {prefix + "lastHost": "localhost", prefix + "lastPort": 38281,
                                    prefix + "lastSlot": "Player", prefix + "debugLog": True})
    proc = env.launch(e)
    try:
        # The game buffers its log until exit, so wait for the window instead and read the log after.
        end = time.time() + 90
        while env.window_id() is None and proc.poll() is None and time.time() < end:
            time.sleep(0.5)
        check("game window appears", env.window_id() is not None)
        time.sleep(8)  # prelaunch menu built, mode activated, a few mod ticks
        shot = e["root"] / "menu.png"
        check("game window captured", env.screenshot(shot) and shot.stat().st_size > 20000)
        alive = proc.poll() is None
        check("game still running after the menu appeared", alive)
    finally:
        env.stop(proc)
    time.sleep(0.5)
    log = env.read_log(e).splitlines()
    mine = [l for l in log if env.MOD_ID in l]
    check("game mode activates in the prelaunch menu",
          sum("randomizer game mode activated" in l for l in mine) == 1,
          "id the host expects: " + env.GAME_MODE_ID)
    check("bundle found", any("found 'Twilight Princess Archipelago'" in l for l in mine))
    check("all mods active", any("4/4 mod(s) active" in l for l in log), "stock cosmetics, luau, randomizer + this mod")
    check("mode deactivated once at shutdown", sum("randomizer game mode deactivated" in l for l in mine) == 1)
    check("mod unloaded once", sum("randomizer unloaded" in l for l in mine) == 1)
    errors = [l for l in log if ("[ERROR" in l or "[FATAL" in l) and (env.MOD_ID in l or "dusk::mods" in l)]
    check("no loader/mod errors", not errors, "; ".join(x[:140] for x in errors[:3]))
    print(f"\nlog: {env.newest_log(e)}\nscreenshot: {e['root'] / 'menu.png'}")
    return 0 if all(results) else 1


if __name__ == "__main__":
    sys.exit(main())
