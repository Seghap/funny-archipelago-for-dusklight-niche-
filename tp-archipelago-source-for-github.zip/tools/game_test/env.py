"""Helpers for running the installed Dusklight against the mod in an isolated environment.

Nothing here touches the player's own Dusklight data: the game is started with --user-dir (config,
saves, caches), --mods (only the .dusk under test) and --log-dir pointing at a scratch directory.
The player's config.json is copied for its graphics/ISO settings, with every mod setting removed.
"""
import json
import os
import shutil
import signal
import subprocess
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
OUT = HERE.parents[1]
GAME = Path(os.environ.get("DUSKLIGHT_BIN", Path.home() / ".local/bin/dusklight"))
REAL_USER_DIR = Path.home() / ".local/share/TwilitRealm/Dusklight"
WORK = OUT / ".gametest"
FIXTURES = HERE / "fixtures"

MOD_ID = "local.dusklight_tp_archipelago"
# The host registers a mod's game mode as "<game_mode_id>_<mod id>", lower-cased (svc/game_mode.cpp).
GAME_MODE_ID = ("tp_archipelago_" + MOD_ID).lower()


def cvar_prefix(mod_id=MOD_ID):
    """Config key prefix for a mod's variables: '.' becomes '_' and '_' becomes '__'."""
    return "mod." + mod_id.replace("_", "__").replace(".", "_") + "."


def prepare(mod_file, name="run", extra_config=None, keep=False, archive=False, extra_mods=()):
    """Creates a scratch environment and returns its paths.

    By default the directory is rebuilt from scratch. `archive` moves the previous run aside (to
    .gametest/archive/, newest five kept) instead of deleting it, so its saves, trail and game log
    survive the next run. `keep` reuses the previous run as it is (saves included) and only replaces
    the mod bundle and the given config values: for loading a file made by an earlier run.
    """
    root = WORK / name
    if root.exists() and not keep:
        if archive:
            arch = WORK / "archive"
            arch.mkdir(exist_ok=True)
            stamp = time.strftime("%Y%m%d-%H%M%S", time.localtime(root.stat().st_mtime))
            shutil.move(str(root), str(arch / f"{name}-{stamp}"))
            for old in sorted(arch.iterdir(), key=lambda p: p.stat().st_mtime)[:-5]:
                shutil.rmtree(old, ignore_errors=True)
        else:
            shutil.rmtree(root)
    user, mods, logs = root / "user", root / "mods", root / "logs"
    for d in (user, mods, logs):
        d.mkdir(parents=True, exist_ok=True)
    for stale in mods.glob("*.dusk"):
        stale.unlink()
    shutil.copy2(mod_file, mods / Path(mod_file).name)
    for extra in extra_mods:
        shutil.copy2(extra, mods / Path(extra).name)
    cfg = {}
    mine = user / "config.json"
    real = REAL_USER_DIR / "config.json"
    if keep and mine.exists():
        cfg = json.loads(mine.read_text())
    elif real.exists():
        cfg = {k: v for k, v in json.loads(real.read_text()).items() if not k.startswith("mod.")}
    if not (user / "controller_ports.dat").exists():
        # Port 1 -> the virtual gamepad (padd.py). Dusklight only reads a port's controller when it
        # has been assigned in Settings -> Input -> Configure Inputs; these files are what that screen
        # writes (made once with the pad, by pressing the buttons in the game's own settings).
        for f in FIXTURES.glob("*"):
            shutil.copy2(f, user / f.name)
    cfg["game.lastSelectedGameModeId"] = GAME_MODE_ID
    cfg["video.enableFullscreen"] = False
    cfg.update(extra_config or {})
    mine.write_text(json.dumps(cfg, indent=2))
    return dict(root=root, user=user, mods=mods, logs=logs, iso=cfg.get("backend.isoPath"))


def launch(env, args=(), extra_env=None, log_level="info", pass_disc=False):
    """Starts the game and returns the Popen. stdout/stderr go to <root>/stdout.log.

    The disc comes from the config (backend.isoPath). It is NOT passed on the command line unless
    asked: a disc on the command line skips the prelaunch menu, and with it the game-mode carousel
    that activates the mod's mode.
    """
    iso = env["iso"]
    if not iso or not Path(iso).exists():
        raise RuntimeError("no game disc image configured (backend.isoPath in the player's config.json)")
    cmd = [str(GAME), "--user-dir", str(env["user"]), "--mods", str(env["mods"]), "--log-dir", str(env["logs"]),
           "-L", log_level, *args] + ([iso] if pass_disc else [])
    e = dict(os.environ)
    e["SDL_VIDEODRIVER"] = "x11"  # an XWayland window can be captured on its own (see window_id)
    e.update(extra_env or {})
    out = open(env["root"] / "stdout.log", "w")
    return subprocess.Popen(cmd, stdout=out, stderr=subprocess.STDOUT, env=e, start_new_session=True)


def stop(proc, grace=5.0):
    if proc.poll() is not None:
        return proc.returncode
    try:
        os.killpg(proc.pid, signal.SIGTERM)
    except ProcessLookupError:
        return proc.poll()
    t = time.time()
    while proc.poll() is None and time.time() - t < grace:
        time.sleep(0.1)
    if proc.poll() is None:
        os.killpg(proc.pid, signal.SIGKILL)
    return proc.wait()


def newest_log(env):
    logs = sorted(Path(env["logs"]).glob("dusklight-*.log"), key=lambda p: p.stat().st_mtime)
    return logs[-1] if logs else None


def read_log(env):
    p = newest_log(env)
    return p.read_text(errors="replace") if p else ""


def wait_for(env, needle, timeout=60.0, proc=None):
    """Waits until `needle` appears in the newest game log; returns the matching line or None."""
    end = time.time() + timeout
    while time.time() < end:
        for line in read_log(env).splitlines():
            if needle in line:
                return line
        if proc is not None and proc.poll() is not None:
            return None
        time.sleep(0.25)
    return None


def window_id(wm_class="dev.twilitrealm.dusk"):
    """The X11 id of the game's window, found by its class only (no other window is looked at)."""
    out = subprocess.run(["xprop", "-root", "_NET_CLIENT_LIST"], capture_output=True, text=True).stdout
    for wid in out.split("#", 1)[-1].replace(",", " ").split():
        cls = subprocess.run(["xprop", "-id", wid, "WM_CLASS"], capture_output=True, text=True).stdout
        if wm_class in cls:
            return wid
    return None


def screenshot(path):
    """Captures the game's window (only) to `path`; returns True on success."""
    wid = window_id()
    if wid is None:
        return False
    r = subprocess.run(["import", "-window", wid, str(path)], capture_output=True, text=True, timeout=30)
    return r.returncode == 0 and Path(path).exists()
