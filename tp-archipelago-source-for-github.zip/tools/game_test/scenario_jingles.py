#!/usr/bin/env python3
"""Another player's item gets the jingle of its classification.

    python3 -I tools/game_test/scenario_jingles.py

The Wooden Sword Chest holds Alice's item, once as progression, once as useful, once as filler and
once as a trap (four runs). Opening it, the mod chooses the jingle from the classification and says
so in the trail ("jingle for <location>: <kind>"): the item fanfare for progression, the small
item jingle for useful, the rupee jingle for filler, the "Continue? No" sound for a trap. What is
asserted is the choice (the trail) and that the check was reported; the sound itself can only be heard.
"""
import sys
import time
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from flows import Rig  # noqa: E402

results = []
CASES = [(1, "progression"), (2, "useful"), (0, "filler"), (4, "trap")]


def check(name, ok, detail=""):
    results.append(ok)
    print(("PASS  " if ok else "FAIL  ") + name + (f"  [{detail}]" if detail and not ok else ""), flush=True)


def main():
    for flags, kind in CASES:
        with Rig(foreign=[f"Wooden Sword Chest=Alice:Ocarina of Time:Hookshot@{flags}"]) as rig:
            rig.start_game(fresh=True, extra=("--config", "backend.enableAdvancedSettings=true",
                                              "--config", "game.infiniteHearts=true"))
            rig.new_file()
            rig.warp_to_ordon("Link's House")
            rig.pad("stick", 0, -1, 0.7, settle=1.2)
            rig.pad("stick", -0.4, -1, 0.35, settle=1.2)
            rig.pad("stick", 0, -1, 0.3, settle=1.2)
            rig.tap("a", settle=3.0)
            line = rig.wait_trail("jingle for Wooden Sword Chest", timeout=10)
            rig.shot(f"jingle_{kind}")
            check(f"{kind} (flags {flags}): the jingle chosen is {kind}", line is not None and f": {kind} " in line, str(line))
            time.sleep(1)
    print(f"\nscreenshots: {HERE.parents[1] / '.gametest/shots'}/jingle_*.png")
    return 0 if all(results) else 1


if __name__ == "__main__":
    sys.exit(main())
