#!/usr/bin/env python3
"""The overlay's controller shortcut: hold L and R (the pad's two triggers), press D-Pad Left.

    python3 -I tools/game_test/scenario_shortcut.py

The overlay starts on. L + R + D-Pad Left hides it, again shows it. D-Pad Left alone, L + D-Pad Left and
L + R alone do nothing, nor does L + R + D-Pad Right. (Not Down: it opens the item ring.) Asserted from
the mod's trail; the overlay on and off is in the screenshots (shortcut_*.png).
"""
import sys
import time
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from flows import Rig  # noqa: E402

results = []


def check(name, ok, detail=""):
    results.append(ok)
    print(("PASS  " if ok else "FAIL  ") + name + (f"  [{detail}]" if detail and not ok else ""), flush=True)


def toggles(rig):
    return [l.split("overlay shortcut: ")[1] for l in rig.trail() if "overlay shortcut:" in l]


def toggle_with(rig, third, count):
    """Presses L + R + `third` until the trail has `count` toggles (up to three tries).

    The virtual pad's release of a chord is sometimes noticed by the game only seconds late (it showed
    as the same buttons held through the next press); a chord pressed again meanwhile is not a new
    press. So a chord that toggled nothing is simply sent again after the previous one has gone.
    """
    for _ in range(3):
        rig.chord("lt", "rt", third, settle=4)
        if len(toggles(rig)) >= count:
            break


def main():
    with Rig() as rig:
        rig.start_game(fresh=True, extra=("--config", "game.infiniteHearts=true"))
        rig.new_file()
        time.sleep(3)
        rig.shot("shortcut_1_on")
        rig.tap("dpad_left", settle=1.0)
        rig.chord("lt", "dpad_left", settle=2)
        rig.chord("lt", "rt", hold=0.4, settle=2)
        check("D-Pad Left alone, L + D-Pad Left and L + R alone do nothing", toggles(rig) == [], str(toggles(rig)))
        toggle_with(rig, "dpad_left", 1)
        rig.shot("shortcut_2_off")
        check("L + R + D-Pad Left hides the overlay", toggles(rig) == ["off"], str(toggles(rig)))
        toggle_with(rig, "dpad_left", 2)
        rig.shot("shortcut_3_on")
        check("and shows it again", toggles(rig) == ["off", "on"], str(toggles(rig)))
        rig.chord("lt", "rt", "dpad_right", settle=4)
        check("L + R + D-Pad Right does nothing", toggles(rig) == ["off", "on"], str(toggles(rig)))
    print(f"\nscreenshots: {HERE.parents[1] / '.gametest/shots'}/shortcut_*.png")
    return 0 if all(results) else 1


if __name__ == "__main__":
    sys.exit(main())
