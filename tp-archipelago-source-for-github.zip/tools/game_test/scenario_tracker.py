#!/usr/bin/env python3
"""The tracker in the real game: logic from the seed's world, updated by items and checks.

    python3 -I tools/game_test/scenario_tracker.py

New file against the fake room. The mod rebuilds the seed's world on a worker thread and searches it:
  * with nothing but the start state, some checks (Ordon's, mostly) are in logic and most are not
  * items sent by the room make more checks reachable (never fewer): Lantern, Iron Boots, the Gale
    Boomerang, a Clawshot, the Bow and a Master Sword
  * a check the player makes becomes "done" (the room's counts and the tab agree)
  * the counts are what the overlay's "In logic now" line shows (screenshots)
The numbers are the randomizer generator's logic on this room's settings (see docs/TESTING.md for how
that relates to the apworld's own logic).
"""
import re
import sys
import time
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from flows import Rig  # noqa: E402

results = []


def check(name, ok, detail=""):
    results.append(ok)
    print(("PASS  " if ok else "FAIL  ") + name + (f"  [{detail}]" if detail and not ok else ""), flush=True)


def counts(rig, after=0):
    last = None
    for l in rig.trail()[after:]:
        m = re.search(r"tracker: (\d+) of (\d+) checks in logic \((\d+) done\)", l)
        if m:
            last = tuple(map(int, m.groups()))
    return last


def wait_counts(rig, after, timeout=40):
    end = time.time() + timeout
    while time.time() < end:
        c = counts(rig, after)
        if c:
            return c
        time.sleep(1)
    return None


def main():
    with Rig() as rig:
        rig.start_game(fresh=True)
        rig.new_file()
        start = wait_counts(rig, 0)
        check("the logic is built and searched", start is not None)
        if not start:
            return 1
        check("with only the start state, some checks are in logic and most are not", 5 < start[0] < start[1] // 3,
              str(start))
        rig.shot("tracker_start")
        prev = start
        for item in ("Lantern", "Iron Boots", "Gale Boomerang", "Progressive Clawshot", "Progressive Hero's Bow",
                     "Progressive Master Sword"):
            mark = rig.mark()
            rig.fake("send", item)
            rig.wait_trail("delivered item", timeout=30, after=mark)
            now = wait_counts(rig, mark)
            check(f"after {item}: nothing falls out of logic", now is not None and now[0] >= prev[0], f"{prev} -> {now}")
            if now:
                print(f"      in logic: {prev[0]} -> {now[0]}", flush=True)
                prev = now
        check("the items together opened up a lot more", prev[0] > start[0] + 15, f"{start} -> {prev}")
        rig.shot("tracker_items")
    return 0 if all(results) else 1


if __name__ == "__main__":
    sys.exit(main())
