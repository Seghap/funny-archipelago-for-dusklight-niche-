// Test tool for tools/game_test/scenario_every_check.py. Not shipped with the mod.
//
// Reads <data dir>/replay.txt, one check per line:   <check name> <vanilla item number>
// and asks the item service for each as a resolved, silent give (ITEM_GIVE_RESOLVE | ITEM_GIVE_SILENT).
// That is what the game itself does when a check is made, minus walking there: the check resolvers
// run (the randomizer's, then the Archipelago mode's), the item is applied, and every give observer
// is told which check it was. The file is renamed to replay.done once queued.

#include "mods/service.hpp"
#include "mods/svc/host.h"
#include "mods/svc/item.h"
#include "mods/svc/log.h"

#include <cstdio>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <sstream>
#include <string>

DEFINE_MOD();
IMPORT_SERVICE(HostService, svc_host);
IMPORT_SERVICE(LogService, svc_log);
IMPORT_SERVICE(ItemService, svc_item);

namespace {
int s_frames = 0;
}

extern "C" {

MOD_EXPORT ModResult mod_initialize(ModError*) {
    svc_log->info(mod_ctx, "check replay tool loaded");
    return MOD_OK;
}

MOD_EXPORT ModResult mod_update(ModError*) {
    if (++s_frames % 30 != 0) {
        return MOD_OK;
    }
    const char* dir = nullptr;
    if (svc_host->data_dir(mod_ctx, &dir) != MOD_OK || dir == nullptr) {
        return MOD_OK;
    }
    const std::filesystem::path file = std::filesystem::path(dir) / "replay.txt";
    std::ifstream in(file);
    if (!in) {
        return MOD_OK;
    }
    std::string line;
    int queued = 0, failed = 0;
    while (std::getline(in, line)) {
        std::istringstream words(line);
        std::string name;
        int item = 0;
        if (!(words >> name >> item)) {
            continue;
        }
        if (svc_item->give_item(mod_ctx, name.c_str(), static_cast<uint8_t>(item),
                ITEM_GIVE_RESOLVE | ITEM_GIVE_SILENT) == MOD_OK) {
            ++queued;
        } else {
            ++failed;
        }
    }
    in.close();
    std::filesystem::rename(file, std::filesystem::path(dir) / "replay.done");
    char msg[96];
    std::snprintf(msg, sizeof msg, "replay: %d check(s) queued, %d refused", queued, failed);
    svc_log->info(mod_ctx, msg);
    return MOD_OK;
}

MOD_EXPORT ModResult mod_shutdown(ModError*) {
    return MOD_OK;
}
}
