#!/usr/bin/env python3
"""Runs every real-game test in turn and prints one table (about 2.5 hours).

    python3 -I tools/game_test/run_all.py [name ...]      # e.g.: smoke items reload

smoke needs nothing; the others need write access to /dev/uinput (the virtual gamepad), the installed
Dusklight with a disc image configured, and tools/live/capture.json from tools/live_probe.py. Each
one starts the game on its own clean profile in .gametest/ and stops it again.
"""
import subprocess
import sys
import time
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ALL = {
    "smoke": "smoke.py",
    "items": "scenario_items.py",
    "reload": "scenario_reload.py",
    "ordon": "scenario_ordon.py",
    "checks": "scenario_checks.py",
    "foreign": "scenario_foreign.py",
    "transform": "scenario_transform.py",
    "goal": "scenario_goal.py",
    "regions": "scenario_regions.py",
    "checktypes": "scenario_checktypes.py",
    "everycheck": "scenario_every_check.py",
    "tracker": "scenario_tracker.py",
    "glitched": "scenario_glitched.py",
    "tabs": "scenario_tabs.py",
    "jingles": "scenario_jingles.py",
    "variants": "scenario_variants.py",
    "deathlink": "scenario_deathlink.py",
    "boxes": "scenario_boxes.py",
    "itemstab": "scenario_items_tab.py",
    "shortcut": "scenario_shortcut.py",
    "regen": "scenario_regen.py",
}


def main():
    wanted = sys.argv[1:] or list(ALL)
    rows = []
    for name in wanted:
        t = time.time()
        proc = subprocess.run([sys.executable, "-I", str(HERE / ALL[name])], capture_output=True, text=True)
        lines = proc.stdout.splitlines()
        passed = sum(l.startswith("PASS") for l in lines)
        failed = [l for l in lines if l.startswith("FAIL")]
        rows.append((name, passed, failed, proc.returncode, time.time() - t, proc.stderr.strip().splitlines()[-1:] if proc.returncode and not failed else []))
        print(f"{name:8} {passed:3} passed, {len(failed)} failed  ({rows[-1][4]:.0f} s)", flush=True)
        for l in failed:
            print("         " + l)
        for l in rows[-1][5]:
            print("         " + l)
    ok = all(r[3] == 0 for r in rows)
    print("\nALL GAME TESTS PASSED" if ok else "\nGAME TESTS FAILED")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
