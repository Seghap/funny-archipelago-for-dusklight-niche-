#!/usr/bin/env python3
"""Other YAML options: the mod builds and plays seeds for settings the first room did not have.

    python3 -I tools/game_test/scenario_variants.py [variant ...]

The fake room gives the slot different Settings (the apworld's own option names and values, in the form
the server sends them); everything else, including where the room placed items, stays the real room's.
For each variant: a new file is made (seed translated and built, file created), the tracker's logic is
built and searched, the game warps to Ordon and runs a minute with no error, and the trail has no
settings errors. Locations the variant turns into vanilla ones (Poes, shop items, ...) take the
mod's "patched at runtime" path, which is the point of the 'categories' variant.
"""
import re
import sys
import time
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import env  # noqa: E402
from flows import Rig  # noqa: E402

results = []

VARIANTS = {
    "dungeon_items": ["Dungeons Shuffled=No", "Small Key Settings=Own Dungeon", "Big Key Settings=Any Dungeon",
                      "Map and Compass Settings=Start With"],
    "categories": ["Poes Shuffled=No", "Golden Bugs Shuffled=No", "Shop Items Shuffled=No",
                   "Heart Pieces Shuffled=No", "Overworld Shuffled=No", "NPC Items Shuffled=No"],
    "requirements": ["Castle Requirements=Fused Shadows", "Palace of Twilight Requirements=Mirror Shards",
                     "Temple of Time Entrance Requirements=Closed", "Faron Woods Logic=Closed",
                     "Goron Mines Entrance Requirements=Closed"],
    "play_style": ["Starting ToD=Night", "Damage Magnification=Ohko", "Logic Settings=Glitched",
                   "Transform Anywhere=No", "Increase Wallet=No", "Skip Minor Cutscenes=No"],
    "keys_anywhere": ["Small Key Settings=Anywhere", "Big Key Settings=Anywhere",
                      "Map and Compass Settings=Anywhere", "Small Keys on Bosses=Yes"],
}


def check(name, ok, detail=""):
    results.append(ok)
    print(("PASS  " if ok else "FAIL  ") + name + (f"  [{detail}]" if detail and not ok else ""), flush=True)


def run(name):
    with Rig(settings=VARIANTS[name]) as rig:
        rig.start_game(fresh=True, extra=("--config", "backend.enableAdvancedSettings=true",
                                          "--config", "game.infiniteHearts=true"))
        try:
            rig.new_file()
        except RuntimeError as e:
            check(f"[{name}] a new file is made", False, str(e) + " | " + " / ".join(l for l in rig.trail()[-4:] if "vanilla" not in l))
            return
        trail = rig.trail()
        check(f"[{name}] the seed was built and the file created", any("new save created" in l for l in trail))
        bad = [l for l in trail if "settings:" in l and ("error" in l.lower() or "cannot" in l.lower())]
        check(f"[{name}] no settings error in the trail", not bad, "; ".join(bad[:2]))
        skipped = sum("vanilla in the local seed" in l for l in trail)  # one trail line per such location
        print(f"      {skipped} locations are vanilla in this variant's local seed (patched at runtime)", flush=True)
        end = time.time() + 40
        counts = None
        while time.time() < end and not counts:
            for l in rig.trail():
                m = re.search(r"tracker: (\d+) of (\d+) checks in logic", l)
                if m:
                    counts = tuple(map(int, m.groups()))
            time.sleep(2)
        check(f"[{name}] the tracker's logic is built and searched", counts is not None and counts[0] > 0, str(counts))
        if counts:
            print(f"      in logic at the start: {counts[0]} of {counts[1]}", flush=True)
        rig.warp_to_ordon("Ordon Village")
        rig.shot(f"variant_{name}")
        time.sleep(20)
        check(f"[{name}] the game runs on", rig.ctl("alive") == "alive")


def main():
    wanted = [a for a in sys.argv[1:] if not a.startswith("-")] or list(VARIANTS)
    for v in wanted:
        print(f"== {v}: {', '.join(VARIANTS[v])}", flush=True)
        run(v)
    log = env.read_log(dict(logs=env.WORK / "ctl" / "logs"))
    errors = [l for l in log.splitlines() if ("[ERROR" in l or "[FATAL" in l) and "Failed to open file" not in l]
    check("the game's log (last variant) has no errors", not errors, "; ".join(e[:120] for e in errors[:3]))
    print(f"\nscreenshots: {env.WORK / 'shots'}/variant_*.png")
    return 0 if all(results) else 1


if __name__ == "__main__":
    sys.exit(main())
