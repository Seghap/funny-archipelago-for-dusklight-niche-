#!/usr/bin/env python3
"""The Archipelago window's tabs in the real game: Hints, Messages and Tracker.

    python3 -I tools/game_test/scenario_tabs.py

Against the fake room: chat arrives and is shown in the Messages tab in colour; `!hint Slingshot` sent
from the Messages tab costs hint points and the hint appears in the Hints tab (and in the overlay);
setting its priority from the Hints tab reaches the room (UpdateHint); the Tracker tab lists the
checks by region. Screenshots of each tab: .gametest/shots/tab_*.png (looked at by a person; the
asserts are on what the room receives and the mod's trail).
"""
import sys
import time
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from flows import Rig  # noqa: E402

results = []


def check(name, ok, detail=""):
    results.append(ok)
    print(("PASS  " if ok else "FAIL  ") + name + (f"  [{detail}]" if detail and not ok else ""), flush=True)


def incoming(rig, cmd):
    return [e["packet"] for e in rig.fake_log() if e["dir"] == "in" and e["packet"].get("cmd") == cmd]


def open_tab(rig, n):
    """The Archipelago window (menu bar: Settings, Warp, Editor, Mods, Archipelago) and its n-th tab."""
    rig.tap("back", settle=1.5)
    rig.tap("dpad_right", 4)
    rig.tap("a", settle=2)
    rig.tap("lb", 5, settle=0.8)         # the window reopens on the tab it was closed on: go to the first
    rig.tap("rb", n, settle=1.5)


def main():
    with Rig() as rig:
        rig.start_game(fresh=True, extra=("--config", "backend.enableAdvancedSettings=true",
                                          "--config", "game.infiniteHearts=true"))
        rig.new_file()
        rig.fake("chat", "hello from Alice")
        rig.fake("send", "Gale Boomerang")
        time.sleep(4)

        # Messages tab (the fourth): the room's chat and the item announcement, in colour
        open_tab(rig, 3)
        rig.shot("tab_messages")
        rig.tap("back", settle=1.5)

        # Hints tab (the third): a hint from the room shows, and its priority can be set from here
        rig.fake("hint", '"Sera Shop Slingshot"', "Silver Rupee", "0")
        time.sleep(3)
        open_tab(rig, 2)
        rig.shot("tab_hints_listed")
        rig.tap("dpad_down", 6, settle=0.8)      # past the two ask fields and their buttons, to the list
        rig.tap("a", settle=1.5)                 # select the hint
        rig.shot("tab_hints_selected")
        rig.tap("dpad_right", settle=1.0)        # to the details pane: Priority, No priority, Avoid
        rig.tap("a", settle=2.0)                 # Priority
        rig.shot("tab_hints_set")
        upd = incoming(rig, "UpdateHint")
        check("setting a hint's priority from the Hints tab reaches the room (UpdateHint)",
              any(u.get("status") == 30 for u in upd), str(upd))
        rig.tap("back", settle=1.5)

        # Tracker tab (the second)
        open_tab(rig, 1)
        rig.shot("tab_tracker")
        rig.tap("back", settle=1.5)
        rig.shot("tab_overlay_with_hint")
        trail = rig.trail()
        check("the overlay is still drawn with the hint open (screenshot)", rig.ctl("alive") == "alive")
    print(f"\nscreenshots: {HERE.parents[1] / '.gametest/shots'}/tab_*.png")
    return 0 if all(results) else 1


if __name__ == "__main__":
    sys.exit(main())
