#!/usr/bin/env python3
"""Keeps one virtual gamepad alive and presses buttons on request.

    padd.py serve FIFO                 # run once (in the background); creates the pad and the FIFO
    padd.py send FIFO tap a [n]        # then, from anywhere:
    padd.py send FIFO hold a 1.5
    padd.py send FIFO chord lt rt dpad_down 0.3   # several buttons at once (lt, rt: the analog triggers)
    padd.py send FIFO stick 0 -1 0.8   # x y [seconds]; -1 on y is up
    padd.py send FIFO wait 2
    padd.py send FIFO quit

Commands are executed in order, one per line. The pad exists before the game starts, so the game
sees a controller from its first frame.
"""
import os
import sys
import time
from pathlib import Path

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
from vpad import VirtualPad  # noqa: E402


def serve(fifo):
    if os.path.exists(fifo):
        os.unlink(fifo)
    os.mkfifo(fifo)
    with VirtualPad() as pad:
        print("pad ready", flush=True)
        done = False
        while not done:
            with open(fifo, "r") as f:  # blocks until a writer connects; EOF when it closes
                for line in f:
                    parts = line.split()
                    if not parts:
                        continue
                    cmd, args = parts[0], parts[1:]
                    if cmd == "tap":
                        pad.tap(args[0], n=int(args[1]) if len(args) > 1 else 1)
                    elif cmd == "hold":
                        pad.press(args[0])
                        time.sleep(float(args[1]))
                        pad.release(args[0])
                    elif cmd == "chord":      # chord BUTTON BUTTON ... SECONDS: pressed together, then released
                        buttons, secs = args[:-1], float(args[-1])
                        for b in buttons:
                            pad.press(b)
                        time.sleep(secs)
                        for b in reversed(buttons):
                            pad.release(b)
                    elif cmd == "stick":
                        pad.stick(float(args[0]), float(args[1]), hold=float(args[2]) if len(args) > 2 else 0.2)
                    elif cmd == "wait":
                        time.sleep(float(args[0]))
                    elif cmd == "quit":
                        done = True
                        break
                    else:
                        print("unknown command:", line.strip(), flush=True)
    os.unlink(fifo)


def send(fifo, words):
    with open(fifo, "w") as f:
        f.write(" ".join(words) + "\n")


if __name__ == "__main__":
    if len(sys.argv) >= 3 and sys.argv[1] == "serve":
        serve(sys.argv[2])
    elif len(sys.argv) >= 4 and sys.argv[1] == "send":
        send(sys.argv[2], sys.argv[3:])
    else:
        print(__doc__)
        sys.exit(2)
