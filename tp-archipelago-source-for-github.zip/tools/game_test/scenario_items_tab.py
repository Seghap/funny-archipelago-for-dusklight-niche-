#!/usr/bin/env python3
"""The Items tab: what the room sent, and release / collect once the goal is reached.

    python3 -I tools/game_test/scenario_items_tab.py

A room that allows !release and !collect only once the goal is reached, and that holds two items for the
slot. Items from another player arrive and show in the tab (with who sent them and whether they reached
Link). Before the goal both buttons do nothing (the room is not sent the commands); after the goal,
Collect delivers the held items and Release, after a confirmation, releases the rest.
"""
import sys
import time
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from flows import Rig  # noqa: E402

results = []


def check(name, ok, detail=""):
    results.append(ok)
    print(("PASS  " if ok else "FAIL  ") + name + (f"  [{detail}]" if detail and not ok else ""), flush=True)


def said(rig, text):
    return [e for e in rig.fake_log() if e["dir"] == "in" and e["packet"].get("cmd") == "Say" and e["packet"].get("text") == text]


def open_tab(rig, n):
    rig.tap("back", settle=1.5)
    rig.tap("dpad_right", 4)
    rig.tap("a", settle=2)
    rig.tap("lb", 6, settle=0.8)
    rig.tap("rb", n, settle=1.5)


def main():
    with Rig(permissions=["release=goal", "collect=goal"], held=["Slingshot", "Gale Boomerang"],
             foreign=["Wooden Sword Chest=Alice:Ocarina of Time:Hookshot@1"]) as rig:
        rig.start_game(fresh=True, extra=("--config", "backend.enableAdvancedSettings=true",
                                          "--config", "game.infiniteHearts=true"))
        rig.new_file()
        rig.fake("send", "Bombs (10)@0 from 2")
        rig.fake("send", "Purple Rupee@1 from 2")
        rig.wait_trail("delivering #1", timeout=40)
        time.sleep(4)
        rig.tap("a", 3, settle=1.5)               # the progression item plays the whole get-item scene: A dismisses it
        time.sleep(2)

        open_tab(rig, 4)
        rig.shot("items_before_goal")
        rig.tap("dpad_down", settle=0.6)
        rig.tap("a", settle=1.5)                  # Collect, before the goal
        rig.tap("dpad_down", settle=0.6)
        rig.tap("a", settle=1.5)                  # Release, before the goal
        rig.shot("items_before_goal_pressed")
        check("before the goal, Collect and Release send nothing", not said(rig, "!collect") and not said(rig, "!release"))

        # the goal, from the Status tab
        rig.tap("lb", 4, settle=0.8)
        rig.tap("dpad_down", 5, settle=0.6)
        rig.tap("a", settle=2)
        rig.tap("rb", 4, settle=1.5)
        rig.shot("items_after_goal")

        mark = rig.mark()
        rig.tap("dpad_down", settle=0.6)
        rig.tap("a", settle=1.5)                  # Collect
        check("after the goal, Collect asks the room (!collect)", bool(said(rig, "!collect")))
        check("and the held items arrive in the game",
              rig.wait_trail("delivered item 0x4B", timeout=40, after=mark) is not None)
        rig.tap("dpad_down", settle=0.6)
        rig.tap("a", settle=2)                    # Release: a confirmation first
        rig.shot("items_release_dialog")
        check("Release asks first (nothing sent yet)", not said(rig, "!release"))
        rig.tap("a", settle=2)                    # the dialog's first action: Release
        check("confirming sends !release", bool(said(rig, "!release")))
        line = rig.wait_trail("more location(s) as checked", timeout=20, after=mark)
        check("the room counts the rest of the locations as checked", line is not None, str(line))
        time.sleep(2)
        rig.shot("items_after_release")
    print(f"\nscreenshots: {HERE.parents[1] / '.gametest/shots'}/items_*.png")
    return 0 if all(results) else 1


if __name__ == "__main__":
    sys.exit(main())
