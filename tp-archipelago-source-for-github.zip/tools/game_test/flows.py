"""Building blocks for scripted play of the real game: the virtual gamepad, the fake room, the trail.

    from flows import *
    with Rig() as rig:                      # starts the pad daemon and the fake room
        rig.start_game(fresh=True)          # the game on a clean profile pointing at the fake room
        rig.new_file()                      # title -> new file -> connect -> name entry -> in the game
        rig.fake("send", "Slingshot")       # the room sends an item
        rig.wait_trail("delivered item 0x4B")

Button presses go through padd.py (see its docstring), screenshots show the game's window only.
"""
import errno
import json
import os
import subprocess
import sys
import time
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import env  # noqa: E402

PAD = str(env.WORK / "pad.fifo")
FAKE = str(env.WORK / "fake.fifo")
FAKE_LOG = env.WORK / "fake_server.log"
PORT = 38999
PY = [sys.executable, "-I"]


def send_line(fifo, text, timeout=5.0):
    """Writes one line to a FIFO without blocking forever if nobody is reading it."""
    end = time.time() + timeout
    while True:
        try:
            fd = os.open(fifo, os.O_WRONLY | os.O_NONBLOCK)
            break
        except OSError as e:
            if e.errno not in (errno.ENXIO, errno.ENOENT) or time.time() > end:
                raise
            time.sleep(0.1)
    try:
        os.write(fd, (text + "\n").encode())
    finally:
        os.close(fd)


class Rig:
    def __init__(self, deflate=True, items="", checked="", foreign=(), settings=(), permissions=(), held=()):
        self.deflate, self.items, self.checked, self.foreign = deflate, items, checked, tuple(foreign)
        self.settings = tuple(settings)
        self.permissions, self.held = tuple(permissions), tuple(held)
        self.procs = []

    # ---- lifecycle
    def __enter__(self):
        env.WORK.mkdir(exist_ok=True)
        self.procs.append(subprocess.Popen([*PY, str(HERE / "padd.py"), "serve", PAD],
                                           stdout=open(env.WORK / "padd.log", "w"), stderr=subprocess.STDOUT,
                                           start_new_session=True))
        cmd = [*PY, str(HERE / "fake_ap_server.py"), "serve", "--port", str(PORT), "--fifo", FAKE,
               "--log", str(FAKE_LOG), "--items", self.items, "--checked", self.checked]
        if not self.deflate:
            cmd.append("--no-deflate")
        for spec in self.foreign:
            cmd += ["--foreign", spec]
        for spec in self.settings:
            cmd += ["--setting", spec]
        for spec in self.permissions:
            cmd += ["--permission", spec]
        for name in self.held:
            cmd += ["--held", name]
        self.procs.append(subprocess.Popen(cmd, stdout=open(env.WORK / "fake_server.out", "w"), stderr=subprocess.STDOUT,
                                           start_new_session=True))
        deadline = time.time() + 10
        while time.time() < deadline and not (Path(PAD).exists() and Path(FAKE).exists()):
            time.sleep(0.2)
        time.sleep(1.0)  # the pad has to exist before the game starts
        return self

    def __exit__(self, *exc):
        self.ctl("stop")
        for fifo in (PAD, FAKE):
            try:
                send_line(fifo, "quit", timeout=1.0)
            except OSError:
                pass
        time.sleep(1.0)
        for p in self.procs:
            if p.poll() is None:
                p.terminate()

    # ---- the pad
    def pad(self, *words, settle=0.5):
        send_line(PAD, " ".join(str(w) for w in words))
        time.sleep(settle)

    def chord(self, *buttons, hold=0.3, settle=1.0):
        self.pad("chord", *buttons, hold, settle=settle)

    def tap(self, button, n=1, settle=0.6):
        self.pad("tap", button, n, settle=0.32 * n + settle)

    # ---- the game
    def ctl(self, *args):
        return subprocess.run([*PY, str(HERE / "ctl.py"), *map(str, args)], capture_output=True, text=True).stdout.strip()

    def start_game(self, fresh=True, host="localhost", port=PORT, slot="HELP ME", extra=()):
        import os
        key = os.environ.get("TP_AP_SGDB_KEY")      # a SteamGridDB API key, from the environment only
        extra = (*extra, *(["--cvar", f"steamGridDbKey={key}"] if key else []))
        out = self.ctl("start", *(["--fresh"] if fresh else []), "--host", host, "--port", port, "--slot", slot, *extra)
        end = time.time() + 90
        while env.window_id() is None and time.time() < end:
            time.sleep(0.5)
        return out

    def shot(self, name):
        return self.ctl("shot", name)

    def trail(self):
        text = self.ctl("trail", 100000)
        return text.splitlines()

    def wait_trail(self, needle, timeout=30.0, after=0):
        """The first trail line at index >= `after` containing `needle`, waiting up to `timeout`."""
        end = time.time() + timeout
        while time.time() < end:
            lines = self.trail()
            for line in lines[after:]:
                if needle in line:
                    return line
            time.sleep(0.5)
        return None

    def mark(self):
        return len(self.trail())

    # ---- the room
    def fake(self, *words):
        send_line(FAKE, " ".join(str(w) for w in words))

    def fake_log(self):
        out = []
        for line in FAKE_LOG.read_text().splitlines():
            try:
                out.append(json.loads(line))
            except ValueError:
                pass
        return out

    # ---- flows
    def to_file_select(self):
        time.sleep(12)          # the prelaunch menu is up and the mode is the one next to Play
        self.tap("a", settle=8)       # Play: the opening movie starts
        self.tap("start", settle=4)   # skip it
        self.tap("start", settle=5)   # title -> quest log selection

    def new_file(self):
        """Title -> an empty quest log -> connect window -> name entry -> in the game (fake room)."""
        self.to_file_select()
        self.tap("a", settle=3)       # an empty quest log opens the connect window
        self.tap("dpad_down", 5)      # host, port, slot, password, Connect and start
        self.tap("a", settle=1)
        if not self.wait_trail("seed built:", timeout=90):
            raise RuntimeError("the seed was not built")
        time.sleep(4)
        self.tap("start", settle=1.5)  # in name entry: the cursor jumps to END
        self.tap("a", settle=3)        # name done -> horse name (cursor already on END)
        self.tap("a", settle=3)        # horse done
        if not self.wait_trail("new save created", timeout=40):
            raise RuntimeError("the file was not created")
        time.sleep(14)                 # the first scene

    def load_file(self, slot_row=0):
        """Title -> the first quest log -> Start (a file made by an earlier run)."""
        self.to_file_select()
        self.tap("a", settle=3)        # select the file
        self.tap("a", settle=14)       # Start

    def save_game(self):
        """Start menu -> Collection -> Save -> log 1 -> overwrite: Yes (the game's own save)."""
        self.tap("start", settle=3)
        self.tap("dpad_down", 3, settle=1.5)   # items grid -> the Save button
        self.tap("a", settle=2.5)              # Save to which log? (log 1 is the one in use)
        self.tap("a", settle=2.5)              # Overwrite this log? (the cursor is on No)
        self.tap("dpad_left", settle=1)
        self.tap("a", settle=5)                # Yes
        self.shot("saved")
        self.tap("a", settle=2)                # dismiss "saved"
        self.tap("b", settle=2)                # back out of the menu

    # ---- the game's own Warp window (menu bar; needs backend.enableAdvancedSettings in the profile)
    @staticmethod
    def warp_table():
        """[(region, [map names])] as the Warp window lists them, read from the game's own header."""
        import re
        path = env.OUT / ".build" / "dusklight" / "src" / "dusk" / "map_loader_definitions.h"
        regions = []
        for m in re.finditer(r'RegionEntry\("([^"]+)"|MapEntry\("([^"]+)",\s*"[^"]+"', path.read_text()):
            if m.group(1):
                regions.append((m.group(1), []))
            else:
                regions[-1][1].append(m.group(2))
        return regions

    def warp_to(self, region, map_name, settle=18, point=0):
        """Warps to a map with the default room, point and layer, and closes the menu.

        The Warp window opens fresh on Hyrule Field the first time, then keeps its selection and its
        focus (on the Warp button) while the game runs; the stage changes as soon as Warp is pressed,
        behind the open window. Choosing another region resets the map to that region's first.
        Rows differ per map, so the Warp button is reached by pressing Down until the focus stops.
        """
        table = self.warp_table()
        ri = [r for r, _ in table].index(region)
        mi = table[ri][1].index(map_name)
        first = not hasattr(self, "_warp_region")
        self.tap("back", settle=1.5)
        if first:
            self.tap("dpad_right", settle=0.8)     # Settings -> Warp
            self.tap("a", settle=2.5)
            self.tap("dpad_down", settle=0.8)      # focus Region
            self._warp_region = self._warp_map = 0
        else:
            self.tap("dpad_up", 8, settle=0.5)     # up to the top row of the window
            self.tap("dpad_down", settle=0.8)      # Region
        if ri != self._warp_region:
            self.tap("a", settle=1.5)              # region list; the focus is on the selected region
            delta = ri - self._warp_region
            self.tap("dpad_down" if delta > 0 else "dpad_up", abs(delta), settle=0.8)
            self.tap("a", settle=1.5)
            self.tap("dpad_left", settle=0.8)
            self._warp_region, self._warp_map = ri, 0
        self.tap("dpad_down", settle=0.8)          # Map
        self.tap("a", settle=1.5)                  # map list; the focus is on the selected map
        delta = mi - self._warp_map
        if delta:
            self.tap("dpad_down" if delta > 0 else "dpad_up", abs(delta), settle=0.8)
        self.tap("a", settle=1.5)
        self._warp_map = mi
        self.tap("dpad_left", settle=0.8)
        # a new map resets the point to 0; the window remembers the point otherwise
        if mi != getattr(self, "_warp_map_for_point", None) or ri != getattr(self, "_warp_region_for_point", None):
            self._warp_point = 0
        self._warp_map_for_point, self._warp_region_for_point = mi, ri
        if point != getattr(self, "_warp_point", 0):
            self.tap("dpad_down", settle=0.8)      # Room is greyed for one-room maps: down lands on Point
            self.tap("a", settle=1.5)              # the points list; the focus is on the selected point
            delta = point - self._warp_point
            self.tap("dpad_down" if delta > 0 else "dpad_up", abs(delta), settle=0.8)
            self.tap("a", settle=1.5)
            self.tap("dpad_left", settle=0.8)
            self._warp_point = point
        self.tap("dpad_down", 8, settle=0.8)       # the Warp button
        self.tap("a", settle=2)
        self.tap("back", settle=1.5)               # close the menu
        time.sleep(settle)                         # the scene loads; do not open the menu meanwhile

    def warp_to_ordon(self, name, settle=16):
        self.warp_to("Ordon", name, settle=settle)
