#!/usr/bin/env python3
"""Another player's item at one of our locations, in the real game.

    python3 -I tools/game_test/scenario_foreign.py

The fake room says the Wooden Sword Chest holds Alice's Hookshot (a game this mod has no items for).
New file, warp into Link's House, open the chest. Asserted: the check is reported; the game hands over
the "Archipelago Item" placeholder (0xDC), never Piece of Heart (the vanilla item), never the engine's
default Green Rupee. Screenshots show the Sol in Link's hand and the text box that names the owner.
"""
import json
import sys
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from flows import Rig  # noqa: E402

results = []


def check(name, ok, detail=""):
    results.append(ok)
    print(("PASS  " if ok else "FAIL  ") + name + (f"  [{detail}]" if detail and not ok else ""), flush=True)


def main():
    cap = json.loads((HERE.parents[1] / "tools/live/capture.json").read_text())
    chest_id = cap["tp_location_name_to_id"]["Wooden Sword Chest"]
    with Rig(foreign=["Wooden Sword Chest=Alice:Ocarina of Time:Hookshot"]) as rig:
        rig.start_game(fresh=True, extra=("--config", "backend.enableAdvancedSettings=true"))
        rig.new_file()
        trail = rig.trail()
        check("the seed was built with another player's item in it", any("seed built:" in l for l in trail))
        rig.warp_to_ordon("Link's House")
        rig.pad("stick", 0, -1, 0.7, settle=1.2)
        rig.pad("stick", -0.4, -1, 0.35, settle=1.2)
        rig.pad("stick", 0, -1, 0.3, settle=1.2)
        rig.tap("a", settle=2.5)
        rig.shot("s_foreign_open")
        sent = [i for e in rig.fake_log() if e["dir"] == "in" and e["packet"].get("cmd") == "LocationChecks"
                for i in e["packet"]["locations"]]
        check("the chest is reported when it opens", sent == [chest_id], f"{sent} vs {chest_id}")
        rig.tap("a", settle=3.5)
        rig.shot("s_foreign_text")
        rig.tap("a", settle=3)
        gives = [l for l in rig.trail() if "give item=" in l and "chest:R_SP01:4" in l]
        check("the game handed over the Archipelago Item placeholder (0xDC)", any("give item=0xDC" in l for l in gives), str(gives))
        check("not the vanilla Piece of Heart (0x21) and not the default Green Rupee (0x01)",
              not any("give item=0x21" in l or "give item=0x01 " in l for l in gives))
        rig.shot("s_foreign_after")
    print(f"\nscreenshots: {HERE.parents[1] / '.gametest/shots'}/s_foreign_*.png")
    return 0 if all(results) else 1


if __name__ == "__main__":
    sys.exit(main())
