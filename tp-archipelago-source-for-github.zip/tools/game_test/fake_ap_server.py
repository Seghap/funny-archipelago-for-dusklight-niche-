#!/usr/bin/env python3
"""A small local Archipelago server for testing the mod in the real game, standard library only.

It replays a read-only capture of a real room (tools/live/capture.json, made by tools/live_probe.py):
the room's RoomInfo, slot data, data package, player list and the placement of every location, so
the mod's whole new-file flow (connect, scout, build the seed, play) runs against it exactly as it
does against the real room. What the real server does *during* play, a test can trigger on demand:

    fake_ap_server.py serve [--port 38999] [--fifo FIFO] [--log FILE] [--checked ID,ID] [--items ID,ID]
                            [--foreign "Location Name=Player:Game:Item"]... [--setting "Name=Value"]...
                            [--permission release=goal|enabled|auto|disabled]... [--held "Item Name"]...

Goal, release and collect behave as the real server does: a StatusUpdate 30 marks the slot's goal as
reached; "!release" and "!collect" (sent in chat) and "!remaining" are allowed according to the room's
permissions (disabled, enabled = any time, goal = once the goal is reached, auto = done by the server
the moment the goal is reached) and answer in chat. --held lists items that other worlds hold for this
slot: "!collect" delivers them.
    fake_ap_server.py send FIFO send Slingshot      # an item arrives from the server console
    fake_ap_server.py send FIFO chat hello there    # a chat line
    fake_ap_server.py send FIFO say Some server announcement
    fake_ap_server.py send FIFO hint "Sera Shop Slingshot" Slingshot 30   # an open hint for the slot
    fake_ap_server.py send FIFO death Alice         # a death link bounce from another player
    fake_ap_server.py send FIFO release             # the server releases the slot's remaining items (as /release HELP ME)
    fake_ap_server.py send FIFO collect             # ... and collects the items other worlds hold for it
    fake_ap_server.py send FIFO pause               # refuse new connections until `resume`
    fake_ap_server.py send FIFO drop                # close every client connection
    fake_ap_server.py send FIFO quit

Everything it receives is appended to the log, one JSON packet per line, so a test can assert on it
(for example that LocationChecks carried the right ids, or that a StatusUpdate for the goal came).
It speaks plain `ws://`, with permessage-deflate (window 2**11, context takeover, like the real room)
unless --no-deflate.
"""
import argparse
import asyncio
import base64
import hashlib
import json
import struct
import sys
import time
import zlib
from pathlib import Path

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parents[2]
CAPTURE = OUT / "tools" / "live" / "capture.json"
MAGIC = b"258EAFA5-E914-47DA-95CA-C5AB0DC85B11"
SLOT, TEAM, GAME, NAME = 1, 0, "Twilight Princess", "HELP ME"


class Room:
    def __init__(self, capture, log_path, checked, items, deflate=True, foreign=(), settings=(), permissions=(), held=()):
        self.deflate = deflate
        self.hint_points = 100        # what the slot can spend; a hint costs hint_cost percent of the locations
        self.goal = False
        self.paused = False
        self.permissions = dict(capture["room_info"]["permissions"])
        names = {"disabled": 0, "enabled": 1, "goal": 2, "auto": 6, "auto_enabled": 7}
        for spec in permissions:
            key, value = spec.split("=", 1)
            self.permissions[key] = names[value]
        self.held = [capture["tp_item_name_to_id"][n] for n in held]
        self.cap = capture
        # Slot-data overrides, "Setting Name=Value": the YAML choices the mod reads on connect.
        self.slot_data = json.loads(json.dumps(capture["connected"]["slot_data"]))
        for spec in settings:
            key, value = spec.split("=", 1)
            self.slot_data["Settings"][key] = value
        self.players = [dict(p) for p in capture["connected"]["players"]]
        self.slot_info = {k: dict(v) for k, v in capture["connected"]["slot_info"].items()}
        self.other_games = {}   # game -> {item name: id}
        self.games = list(capture["room_info"]["games"])
        self.log_path = log_path
        self.clients = set()
        self.all_locations = sorted(capture["tp_location_name_to_id"].values())
        self.checked = set(checked) if checked else set()
        self.items = [self.network_item(i, -1, 0) for i in items]
        self.item_names = {v: k for k, v in capture["tp_item_name_to_id"].items()}
        self.location_names = {v: k for k, v in capture["tp_location_name_to_id"].items()}
        self.hints = []
        self.scouted = {s["location"]: dict(s) for s in capture["scouted"]}
        # Another player's item at one of our locations: "Location=Player:Game:Item".
        for spec in foreign:
            location, rest = spec.split("=", 1)
            player, game, item = rest.split(":", 2)
            flags = 1                       # "Item@N": the item's classification flags (1 progression, 2 useful, 4 trap)
            if "@" in item:
                item, flags = item.rsplit("@", 1)
                flags = int(flags)
            slot = 2 + len({p["slot"] for p in self.players if p["slot"] >= 2})
            self.players.append({"team": TEAM, "slot": slot, "alias": player, "name": player, "class": "NetworkPlayer"})
            self.slot_info[str(slot)] = {"name": player, "game": game, "type": 1, "group_members": [], "class": "NetworkSlot"}
            item_id = 66000 + len(self.other_games.setdefault(game, {})) + 1
            self.other_games[game][item] = item_id
            if game not in self.games:
                self.games.append(game)
            self.scouted[self.cap["tp_location_name_to_id"][location]].update(
                {"item": item_id, "player": slot, "flags": flags})

    @staticmethod
    def network_item(item, location, player, flags=0):
        return {"item": item, "location": location, "player": player, "flags": flags, "class": "NetworkItem"}

    @property
    def hints_key(self):
        return f"_read_hints_{TEAM}_{SLOT}"

    def log(self, direction, packet):
        with open(self.log_path, "a") as f:
            f.write(json.dumps({"t": round(time.time(), 3), "dir": direction, "packet": packet}) + "\n")

    async def send(self, client, packets):
        for p in packets:
            self.log("out", p)
        await client.send_text(json.dumps(packets))

    async def broadcast(self, packets):
        for c in list(self.clients):
            if c.connected:
                try:
                    await self.send(c, packets)
                except Exception:
                    pass


class Client:
    def __init__(self, reader, writer):
        self.reader, self.writer = reader, writer
        self.connected = False  # past Connect
        self.tags = []
        # permessage-deflate as the real room does it: one window per direction, kept between
        # messages (context takeover), the server's window 2**11 bytes
        self.compress = None
        self.inflate = None

    async def send_frame(self, opcode, payload, compressed=False):
        header = bytes([0x80 | (0x40 if compressed else 0) | opcode])
        n = len(payload)
        if n < 126:
            header += bytes([n])
        elif n < 65536:
            header += bytes([126]) + struct.pack(">H", n)
        else:
            header += bytes([127]) + struct.pack(">Q", n)
        self.writer.write(header + payload)
        await self.writer.drain()

    async def send_text(self, text):
        payload = text.encode()
        if self.compress is not None:
            payload = (self.compress.compress(payload) + self.compress.flush(zlib.Z_SYNC_FLUSH))[:-4]
            await self.send_frame(0x1, payload, compressed=True)
        else:
            await self.send_frame(0x1, payload)

    async def read_message(self):
        """The next text message (fragments joined), answering pings; None when the peer closes."""
        data, op, packed = b"", None, False
        while True:
            head = await self.reader.readexactly(2)
            fin, opcode, rsv1 = head[0] & 0x80, head[0] & 0x0F, head[0] & 0x40
            masked, n = head[1] & 0x80, head[1] & 0x7F
            if n == 126:
                n = struct.unpack(">H", await self.reader.readexactly(2))[0]
            elif n == 127:
                n = struct.unpack(">Q", await self.reader.readexactly(8))[0]
            mask = await self.reader.readexactly(4) if masked else b""
            payload = await self.reader.readexactly(n)
            if masked:
                payload = bytes(b ^ mask[i % 4] for i, b in enumerate(payload))
            if opcode == 0x8:
                return None
            if opcode == 0x9:
                await self.send_frame(0xA, payload)
                continue
            if opcode == 0xA:
                continue
            if opcode in (0x1, 0x2):
                op = opcode
                data = payload
                packed = bool(rsv1)
            else:  # continuation
                data += payload
            if fin:
                if packed:
                    data = self.inflate.decompress(data + b"\x00\x00\xff\xff")
                return data.decode() if op == 0x1 else None


def room_info(room):
    ri = dict(room.cap["room_info"])
    ri["permissions"] = room.permissions
    ri["games"] = room.games
    ri["cmd"] = "RoomInfo"
    ri["tags"] = ["AP", "FakeServer"]
    ri["datapackage_checksums"] = {}
    ri["time"] = time.time()
    return ri


def connected_packet(room):
    c = room.cap["connected"]
    return {
        "cmd": "Connected", "team": TEAM, "slot": SLOT, "players": room.players, "slot_info": room.slot_info,
        "slot_data": room.slot_data, "checked_locations": sorted(room.checked),
        "missing_locations": [i for i in room.all_locations if i not in room.checked], "hint_points": room.hint_points,
    }


def data_package(room, games):
    out = {}
    for g in games:
        if g == GAME:
            out[g] = {"item_name_to_id": room.cap["tp_item_name_to_id"],
                      "location_name_to_id": room.cap["tp_location_name_to_id"]}
        else:
            out[g] = {"item_name_to_id": room.other_games.get(g, {}), "location_name_to_id": {}}
    return {"cmd": "DataPackage", "data": {"games": out}}


def allowed(room, what):
    """The real server's rule: bit 1 = any time, bit 2 = once the goal is reached."""
    perm = room.permissions.get(what, 0)
    return bool(perm & 1) or (bool(perm & 2) and room.goal)


async def do_release(room):
    missing = [i for i in room.all_locations if i not in room.checked]
    room.checked.update(missing)
    await room.broadcast([print_json(f"{NAME} has released all remaining items from their world.", "Release"),
                          {"cmd": "RoomUpdate", "checked_locations": sorted(room.checked)}])


async def do_collect(room):
    index = len(room.items)
    new = [room.network_item(i, -1, 0) for i in room.held]
    room.held = []
    room.items.extend(new)
    packets = [print_json(f"{NAME} has collected their items from other worlds.", "Collect")]
    if new:
        packets.insert(0, {"cmd": "ReceivedItems", "index": index, "items": new})
    await room.broadcast(packets)


async def chat_command(room, client, text):
    word = text.split()[0].lower()
    if word == "!release":
        if allowed(room, "release"):
            await do_release(room)
        else:
            await room.broadcast([print_json("Release is not permitted until the goal is reached." if room.permissions.get("release") == 2
                                             else "Forfeiting is disabled on this server.", "CommandResult")])
    elif word == "!collect":
        if allowed(room, "collect"):
            await do_collect(room)
        else:
            await room.broadcast([print_json("Collect is not permitted until the goal is reached." if room.permissions.get("collect") == 2
                                             else "Collect is disabled on this server.", "CommandResult")])
    elif word == "!hint":
        want = text.split(None, 1)[1].strip().lower() if len(text.split(None, 1)) > 1 else ""
        cost = max(1, int(room.permissions.get("_cost_percent", room.cap["room_info"].get("hint_cost", 5)) * 0.01 * len(room.all_locations)))
        match = [(loc, sc) for loc, sc in room.scouted.items() if room.item_names.get(sc["item"], "").lower() == want
                 and sc["player"] == SLOT and loc not in room.checked and not any(h["location"] == loc for h in room.hints)]
        if not match:
            await room.broadcast([print_json(f'Could not find a hint for "{want}".', "CommandResult")])
        elif room.hint_points < cost:
            await room.broadcast([print_json(f"You can't afford this hint: {room.hint_points} points, it costs {cost}.", "CommandResult")])
        else:
            room.hint_points -= cost
            loc, sc = match[0]
            room.hints.append({"receiving_player": SLOT, "finding_player": SLOT, "location": loc, "item": sc["item"],
                               "found": False, "entrance": "", "item_flags": sc["flags"], "status": 0})
            await room.broadcast([print_json(f"Hint: {room.item_names[sc['item']]} is at {room.location_names[loc]} in your world.", "Hint"),
                                  {"cmd": "SetReply", "key": room.hints_key, "value": room.hints, "original_value": room.hints[:-1], "slot": SLOT},
                                  {"cmd": "RoomUpdate", "hint_points": room.hint_points}])
    elif word == "!remaining":
        if allowed(room, "remaining"):
            n = len([i for i in room.all_locations if i not in room.checked])
            await room.broadcast([print_json(f"Remaining items: {n}", "CommandResult")])
        else:
            await room.broadcast([print_json("Remaining is not permitted until the goal is reached.", "CommandResult")])
    else:
        await room.broadcast([print_json(f"Unknown command {word}.", "CommandResult")])


def print_json(text, kind=None, **extra):
    p = {"cmd": "PrintJSON", "data": [{"text": text}]}
    if kind:
        p["type"] = kind
    p.update(extra)
    return p


async def handle_packet(room, client, p):
    cmd = p.get("cmd")
    if cmd == "Connect":
        if p.get("name") != NAME or p.get("game") != GAME:
            await room.send(client, [{"cmd": "ConnectionRefused", "errors": ["InvalidSlot"]}])
            return
        client.connected = True
        client.tags = p.get("tags", [])
        await room.send(client, [connected_packet(room)])
        if room.items:
            await room.send(client, [{"cmd": "ReceivedItems", "index": 0, "items": room.items}])
    elif cmd == "GetDataPackage":
        await room.send(client, [data_package(room, p.get("games") or [GAME])])
    elif cmd == "LocationScouts":
        ids = p.get("locations", [])
        await room.send(client, [{"cmd": "LocationInfo",
                                  "locations": [room.scouted[i] for i in ids if i in room.scouted]}])
    elif cmd == "LocationChecks":
        new = [i for i in p.get("locations", []) if i not in room.checked]
        room.checked.update(new)
        for i in new:
            sc = room.scouted.get(i)
            what = room.item_names.get(sc["item"], "an item") if sc else "an item"
            await room.broadcast([print_json(
                f"{NAME} found their {what} ({room.location_names.get(i, i)})", "ItemSend")])
        await room.broadcast([{"cmd": "RoomUpdate", "checked_locations": sorted(room.checked)}])
    elif cmd == "Get":
        keys = {k: (room.hints if k == room.hints_key else None) for k in p.get("keys", [])}
        await room.send(client, [{"cmd": "Retrieved", "keys": keys}])
    elif cmd == "Sync":
        if room.items:
            await room.send(client, [{"cmd": "ReceivedItems", "index": 0, "items": room.items}])
    elif cmd == "Say":
        text = p.get("text", "")
        await room.broadcast([print_json(f"{NAME}: {text}", "Chat", message=text)])
        if text.startswith("!"):
            await chat_command(room, client, text)
    elif cmd == "StatusUpdate":
        if p.get("status") == 30 and not room.goal:
            room.goal = True
            await room.broadcast([print_json(f"{NAME} (Team #1) has completed their goal.", "Goal")])
            if room.permissions.get("release", 0) & 4:
                await do_release(room)
            if room.permissions.get("collect", 0) & 4:
                await do_collect(room)
    elif cmd == "UpdateHint":
        for h in room.hints:
            if h["location"] == p.get("location") and h["finding_player"] == p.get("player"):
                h["status"] = p.get("status", h["status"])
        await room.broadcast([{"cmd": "SetReply", "key": room.hints_key, "value": room.hints, "original_value": room.hints, "slot": SLOT}])
    elif cmd == "ConnectUpdate":
        client.tags = p.get("tags", client.tags)
    elif cmd == "Bounce":
        tags = set(p.get("tags", []))
        for c in list(room.clients):
            if c is not client and c.connected and tags & set(c.tags):
                await room.send(c, [{"cmd": "Bounced", "tags": p.get("tags", []), "data": p.get("data", {})}])
    # StatusUpdate, SetNotify and anything else: logged by the caller, nothing to answer


async def serve_client(room, reader, writer):
    client = Client(reader, writer)
    if room.paused:
        writer.close()
        return
    try:
        request = b""
        while b"\r\n\r\n" not in request:
            chunk = await reader.read(4096)
            if not chunk:
                return
            request += chunk
        key = next(line.split(b":", 1)[1].strip() for line in request.split(b"\r\n") if line.lower().startswith(b"sec-websocket-key"))
        accept = base64.b64encode(hashlib.sha1(key + MAGIC).digest())
        offered = b"permessage-deflate" in request.lower()
        extension = b""
        if offered and room.deflate:
            extension = b"Sec-WebSocket-Extensions: permessage-deflate; server_max_window_bits=11\r\n"
            client.compress = zlib.compressobj(6, zlib.DEFLATED, -11)
            client.inflate = zlib.decompressobj(-15)
        writer.write(b"HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n"
                     + extension + b"Sec-WebSocket-Accept: " + accept + b"\r\n\r\n")
        await writer.drain()
        room.clients.add(client)
        await room.send(client, [room_info(room)])
        while True:
            text = await client.read_message()
            if text is None:
                break
            for p in json.loads(text):
                room.log("in", p)
                await handle_packet(room, client, p)
    except (asyncio.IncompleteReadError, ConnectionError):
        pass
    finally:
        room.clients.discard(client)
        writer.close()


async def run_command(room, line):
    words = line.split()
    if not words:
        return True
    cmd, rest = words[0], line.split(None, 1)[1] if len(words) > 1 else ""
    if cmd == "send":
        # send <item>[@flags] [from <slot>]: from another player's world (slot 2 is Alice, made by
        # --foreign), as a real find: it then has a location and a sender
        name, _, sender = rest.partition(" from ")
        flags = 0
        if "@" in name:
            name, flags = name.rsplit("@", 1)
            flags = int(flags)
        name = name.strip()
        item_id = room.cap["tp_item_name_to_id"].get(name) or (int(name) if name.isdigit() else None)
        if item_id is None:
            room.log("note", f"unknown item {name!r}")
            return True
        player = int(sender) if sender.strip() else 0
        item = room.network_item(item_id, 4242 if player else -1, player, flags)
        index = len(room.items)
        room.items.append(item)
        await room.broadcast([{"cmd": "ReceivedItems", "index": index, "items": [item]},
                              print_json(f'Cheat console: sending "{room.item_names.get(item_id, item_id)}" to {NAME}')])
    elif cmd == "chat":
        await room.broadcast([print_json(f"Alice: {rest}", "Chat", message=rest)])
    elif cmd == "say":
        await room.broadcast([print_json(rest, "ServerChat", message=rest)])
    elif cmd == "hint":
        # hint "<location name>" <item name> [status]
        parts = rest.split('"')
        loc = parts[1]
        item_name, _, status = parts[2].strip().rpartition(" ")
        if not status.isdigit():
            item_name, status = parts[2].strip(), "30"
        room.hints.append({"receiving_player": SLOT, "finding_player": SLOT,
                           "location": room.cap["tp_location_name_to_id"][loc],
                           "item": room.cap["tp_item_name_to_id"][item_name], "found": False, "entrance": "",
                           "item_flags": 1, "status": int(status)})
        await room.broadcast([{"cmd": "SetReply", "key": room.hints_key, "value": room.hints,
                               "original_value": room.hints[:-1], "slot": SLOT}])
    elif cmd == "death":
        await room.broadcast([{"cmd": "Bounced", "tags": ["DeathLink"],
                               "data": {"time": time.time(), "source": rest or "Alice", "cause": f"{rest or 'Alice'} died."}}])
    elif cmd == "release":
        await do_release(room)
    elif cmd == "collect":
        await do_collect(room)
    elif cmd == "pause":
        room.paused = True
    elif cmd == "resume":
        room.paused = False
    elif cmd == "drop":
        for c in list(room.clients):
            c.writer.close()
    elif cmd == "quit":
        return False
    return True


async def fifo_loop(room, fifo, stop):
    import os
    if os.path.exists(fifo):
        os.unlink(fifo)
    os.mkfifo(fifo)
    loop = asyncio.get_running_loop()
    while not stop.is_set():
        # open blocks until a writer appears; do it off the event loop
        data = await loop.run_in_executor(None, lambda: open(fifo).read())
        for line in data.splitlines():
            room.log("admin", line)
            if not await run_command(room, line):
                stop.set()
                return


async def serve(args):
    cap = json.loads(Path(args.capture).read_text())
    log = Path(args.log)
    log.write_text("")
    parse = lambda s: [int(x) for x in s.split(",") if x] if s else []
    room = Room(cap, log, parse(args.checked), parse(args.items), not args.no_deflate, args.foreign, args.setting, args.permission, args.held)
    stop = asyncio.Event()
    server = await asyncio.start_server(lambda r, w: serve_client(room, r, w), ["127.0.0.1", "::1"], args.port)
    print(f"fake room on ws://127.0.0.1:{args.port} (slot {NAME!r}); log {log}", flush=True)
    if args.fifo:
        asyncio.create_task(fifo_loop(room, args.fifo, stop))
    async with server:
        await stop.wait()


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("serve")
    s.add_argument("--port", type=int, default=38999)
    s.add_argument("--fifo", default="")
    s.add_argument("--log", default=str(OUT / ".gametest" / "fake_server.log"))
    s.add_argument("--foreign", action="append", default=[], help='"Location Name=Player:Game:Item": another player\'s item at one of our locations')
    s.add_argument("--setting", action="append", default=[], help='"Setting Name=Value": override one of the slot data\'s Settings')
    s.add_argument("--permission", action="append", default=[], help="release|collect|remaining=disabled|enabled|goal|auto|auto_enabled")
    s.add_argument("--held", action="append", default=[], help="an item other worlds hold for this slot (delivered by !collect)")
    s.add_argument("--no-deflate", action="store_true", help="do not accept permessage-deflate")
    s.add_argument("--capture", default=str(CAPTURE))
    s.add_argument("--checked", default="", help="location ids the room already counts as checked")
    s.add_argument("--items", default="", help="item ids already in the room's list for the slot")
    t = sub.add_parser("send")
    t.add_argument("fifo")
    t.add_argument("words", nargs="+")
    a = ap.parse_args()
    if a.cmd == "serve":
        asyncio.run(serve(a))
    else:
        with open(a.fifo, "w") as f:
            f.write(" ".join(a.words) + "\n")


if __name__ == "__main__":
    main()
