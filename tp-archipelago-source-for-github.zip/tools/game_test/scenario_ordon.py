#!/usr/bin/env python3
"""Every Ordon map under the Archipelago seed: the houses (stage R_SP01), the village, the ranch, the spring.

    python3 -I tools/game_test/scenario_ordon.py

The first official-branch attempt crashed in Jaggle & Pergie's house (stage R_SP01) and started the
village on the wrong day-layer with chests missing. This starts a new file against the fake room (the
seed and the start flags come from the mod), then uses the game's own Warp window (menu bar, turned on
with backend.enableAdvancedSettings in the scratch profile) to enter each Ordon map with the default
layer (-1: the mod's layer logic decides), and checks after each that the game is still running and
the game's log has no errors. Screenshots of each map stay in .gametest/shots/ordon_*.png.
"""
import re
import sys
import time
from pathlib import Path

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
import env  # noqa: E402
from flows import Rig  # noqa: E402

results = []

ORDER = ["Link's House", "Jaggle's House", "Bo's House", "Rusl's House", "Sera's Sundries",
         "Outside Link's House", "Ordon Ranch", "Ordon Spring", "Ordon Village"]


def check(name, ok, detail=""):
    results.append(ok)
    print(("PASS  " if ok else "FAIL  ") + name + (f"  [{detail}]" if detail and not ok else ""), flush=True)


def slug(name):
    return re.sub(r"[^a-z0-9]+", "_", name.lower()).strip("_")


def main():
    with Rig() as rig:
        rig.start_game(fresh=True, extra=("--config", "backend.enableAdvancedSettings=true"))
        rig.new_file()
        for name in ORDER:
            rig.warp_to_ordon(name)
            rig.shot(f"ordon_{slug(name)}")
            alive = rig.ctl("alive") == "alive"
            check(f"{name}: the game is running after the warp", alive)
            if not alive:
                break
    log = env.read_log(dict(logs=env.WORK / "ctl" / "logs"))
    errors = [l for l in log.splitlines() if ("[ERROR" in l or "[FATAL" in l)
              and "Failed to open file" not in l]
    check("the game's log has no errors", not errors, "; ".join(e[:120] for e in errors[:3]))
    print(f"\nscreenshots: {Path(__file__).resolve().parents[2] / '.gametest/shots'}/ordon_*.png")
    return 0 if all(results) else 1


if __name__ == "__main__":
    sys.exit(main())
