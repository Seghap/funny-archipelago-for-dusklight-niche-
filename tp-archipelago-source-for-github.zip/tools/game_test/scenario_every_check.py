#!/usr/bin/env python3
"""Every location, through the real game's item service: one replayed check each.

    python3 -I tools/game_test/scenario_every_check.py [--limit N]

What it does and what it does not do. A test tool (replay_mod, a separate .dusk, never shipped) tells
the game's item service to give the item of a named check as if the game had just made that check
(the same call a chest, a Poe, a shop or an owl statue makes). The game then does what it always
does: the randomizer's resolver and the Archipelago mode's resolver pick the item, the item is applied,
and the mode's give observer reports the location to the room. So this tests, in the real engine and
for every location, the part this mod owns: **check name -> location -> item -> report**. It does not
test that the game itself raises that check name when a player does the thing; that is the game's own
code (the names are those of the SDK's mods/items.h, listed by tools/check_detection.py), and a
handful of types are played by hand in scenario_checktypes.py.

For each of the room's 474 locations that has an engine check name:
  * the room receives LocationChecks with exactly that location's id
  * the game hands over the item the room placed there (its own item, possibly turned into a Blue
    Rupee by the randomizer's ammo-before-weapon rule or to the progressive item the inventory
    needs), or the "Archipelago Item" placeholder (0xDC) where the room placed another player's item
  * and no other location is reported (the set of ids received equals the set replayed)
Every sixth location holds another player's item in the fake room.
"""
import json
import re
import subprocess
import sys
import time
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
OUT = HERE.parents[1]
sys.path.insert(0, str(HERE))
import env  # noqa: E402
from flows import Rig  # noqa: E402

results = []


def check(name, ok, detail=""):
    results.append(ok)
    print(("PASS  " if ok else "FAIL  ") + name + (f"  [{detail}]" if detail and not ok else ""), flush=True)


def main():
    limit = int(sys.argv[sys.argv.index("--limit") + 1]) if "--limit" in sys.argv else None
    cap = json.loads((OUT / "tools/live/capture.json").read_text())
    ids = cap["tp_location_name_to_id"]
    dump = env.WORK / "check_names.json"
    dump.parent.mkdir(exist_ok=True)
    subprocess.run([sys.executable, "-I", str(OUT / "tools/check_detection.py"), "--dump", str(dump)],
                   capture_output=True, check=True)
    names = json.loads(dump.read_text())            # location -> {checks, original}
    low = {n.lower(): n for n in ids}                # apworld spelling -> data package spelling
    locs = sorted((low[n.lower()] for n in names if names[n]["checks"]), key=lambda n: ids[n])
    if limit:
        locs = locs[:limit]
    placed = {s["location"]: s for s in cap["scouted"]}
    inv = {v: k for k, v in cap["tp_item_name_to_id"].items()}
    give_byte = {}
    for m in re.finditer(r'\{(\d+),\s*(\d+),\s*"([^"]*)",\s*"([^"]*)"\}', (OUT / "src/ap/gc_data.inc").read_text()):
        give_byte[2320000 + int(m.group(1))] = int(m.group(2))

    by_lower = {n.lower(): n for n in names}
    foreign = [loc for k, loc in enumerate(locs) if k % 6 == 5]
    foreign_args = [f"{loc}=Alice:Ocarina of Time:Hookshot {k}" for k, loc in enumerate(foreign)]
    expected = {}
    for loc in locs:
        item = placed[ids[loc]]["item"]
        expected[loc] = 0xDC if loc in foreign else give_byte[item]

    lines = []
    for loc in locs:
        info = names[by_lower[loc.lower()]]
        for chk in info["checks"]:
            lines.append(f"{chk} {info['original']}")
    print(f"{len(locs)} locations, {len(lines)} check names, {len(foreign)} held by another player", flush=True)

    replay_mod = OUT / ".build/mods/tp_ap_replay.dusk"
    if not replay_mod.exists():
        sys.exit("build the test tool first:  cmake --build .build --target tp_ap_replay_package")
    with Rig(foreign=foreign_args) as rig:
        rig.start_game(fresh=True, extra=("--extra-mod", str(replay_mod)))
        rig.new_file()
        data = env.WORK / "ctl/user/mod_data/local.tp_ap_replay"
        data.mkdir(parents=True, exist_ok=True)
        mark = rig.mark()
        (data / "replay.txt").write_text("\n".join(lines) + "\n")
        end = time.time() + 600
        while time.time() < end:
            got = sum("give item=" in l for l in rig.trail()[mark:])
            if got >= len(lines):
                break
            time.sleep(3)
            if rig.ctl("alive") != "alive":
                break
        time.sleep(4)
        rig.shot("every_check_after")
        trail = rig.trail()[mark:]
        alive = rig.ctl("alive") == "alive"
        check("the game survived the whole replay", alive)
        sent = [i for e in rig.fake_log() if e["dir"] == "in" and e["packet"].get("cmd") == "LocationChecks"
                for i in e["packet"]["locations"]]

    gives = {}
    canon = {n.lower(): n for n in ids}
    for k, l in enumerate(trail):
        m = re.search(r"give item=0x([0-9A-F]{2}) \(.*?\) origin=\d+ check='([^']*)' -> (.*)$", l)
        if m:
            subst = k + 1 < len(trail) and "the server's item there is" in trail[k + 1] or "the server's item there is" in l
            gives.setdefault(canon.get(m.group(3).strip().lower(), m.group(3).strip()), []).append((int(m.group(1), 16), m.group(2), l))
    check("every replayed check name produced a give", len(gives) >= len(locs) - 1 if limit is None else len(gives) == len(locs),
          f"{len(gives)} locations gave of {len(locs)}")
    missing = [loc for loc in locs if loc not in gives]
    wrong_item, ok_items = [], 0
    for loc in locs:
        g = gives.get(loc)
        if not g:
            continue
        observed = {b for b, _, _ in g}
        if expected[loc] in observed:
            ok_items += 1
        else:
            # explained substitutions: the trail's next line says what the room's item was
            idx = [k for k, l in enumerate(trail) if g[0][2] in l][0]
            note = trail[idx + 1] if idx + 1 < len(trail) else ""
            explained = "the server's item there is" in note and f"(0x{expected[loc]:02X})" in note
            if explained:
                ok_items += 1
            else:
                wrong_item.append((loc, f"expected 0x{expected[loc]:02X}", [f"0x{b:02X}" for b in observed]))
    loc_of = {v: k for k, v in ids.items()}
    sent_set = set(sent)
    want_set = {ids[loc] for loc in locs if loc in gives}
    extra = sorted(sent_set - want_set)
    unsent = sorted(want_set - sent_set)
    check(f"the room received exactly the replayed locations ({len(sent_set)})", not extra and not unsent,
          f"extra {[loc_of.get(i, i) for i in extra][:6]} unsent {[i for i in unsent][:3]} ({len(unsent)} unsent)")
    check(f"the game handed over the placed item at each of the {ok_items} locations it was checked",
          not wrong_item, "; ".join(map(str, wrong_item[:4])) + f" ({len(wrong_item)} wrong)")
    check("the placeholder was given exactly where another player's item sits",
          all(0xDC in {b for b, _, _ in gives[loc]} for loc in foreign if loc in gives) and
          all(0xDC not in {b for b, _, _ in gives[loc]} for loc in locs if loc in gives and loc not in foreign))
    if missing:
        print("no give for:", missing[:10])
    print(f"\nscreenshot: {env.WORK / 'shots/every_check_after.png'}")
    return 0 if all(results) else 1


if __name__ == "__main__":
    sys.exit(main())
