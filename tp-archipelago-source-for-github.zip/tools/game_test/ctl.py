#!/usr/bin/env python3
"""Start, look at and stop the real game across separate commands (for stepwise, scripted play).

    ctl.py start [--fresh] [--host H --port P --slot S] [--dusk PATH]   # --fresh: clean profile
    ctl.py shot NAME                  # window-only screenshot -> .gametest/shots/NAME.png
    ctl.py trail [N]                  # last N lines of the mod's flushed debug trail (default 25)
    ctl.py alive
    ctl.py stop                       # also leaves the game log (written at exit) in .gametest/ctl/logs

The profile lives in .gametest/ctl and is reused between starts, so a file made in one start can be
loaded in the next. Buttons are pressed with padd.py (see its docstring).
"""
import argparse
import json
import os
import sys
import time
from pathlib import Path

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
import env  # noqa: E402

STATE = env.WORK / "ctl.json"
NAME = "ctl"


def profile():
    root = env.WORK / NAME
    return dict(root=root, user=root / "user", mods=root / "mods", logs=root / "logs", iso=None)


def trail_path():
    for p in (env.WORK / NAME / "user").rglob("ap_debug.log"):
        return p
    return None


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    st = sub.add_parser("start")
    st.add_argument("--fresh", action="store_true")
    st.add_argument("--host", default="multiworld.gg")
    st.add_argument("--port", type=int, default=49607)
    st.add_argument("--slot", default="HELP ME")
    st.add_argument("--dusk", default=str(env.OUT / ".build/mods/tp_archipelago.dusk"))
    st.add_argument("--extra-mod", action="append", default=[], help="another .dusk to run alongside (a test tool)")
    st.add_argument("--load-save", type=int, default=0, help="the game's own --load-save N: skip the opening and load file N after Play")
    st.add_argument("--config", action="append", default=[], help="game config KEY=VALUE (JSON value), e.g. backend.enableAdvancedSettings=true")
    st.add_argument("--cvar", action="append", default=[], help="extra mod config NAME=VALUE (int/bool/text)")
    sh = sub.add_parser("shot")
    sh.add_argument("name")
    tr = sub.add_parser("trail")
    tr.add_argument("n", nargs="?", type=int, default=25)
    sub.add_parser("alive")
    sub.add_parser("stop")
    a = ap.parse_args()

    if a.cmd == "start":
        prefix = env.cvar_prefix()
        extra = {prefix + "lastHost": a.host, prefix + "lastPort": a.port, prefix + "lastSlot": a.slot,
                 prefix + "debugLog": True}
        for kv in a.config:
            k, v = kv.split("=", 1)
            extra[k] = json.loads(v)
        for kv in a.cvar:
            k, v = kv.split("=", 1)
            extra[prefix + k] = True if v == "true" else False if v == "false" else int(v) if v.lstrip("-").isdigit() else v
        e = env.prepare(a.dusk, NAME, extra, keep=not a.fresh and (env.WORK / NAME).exists(), extra_mods=a.extra_mod)
        proc = env.launch(e, args=("--load-save", str(a.load_save)) if a.load_save else ())
        STATE.write_text(json.dumps({"pid": proc.pid}))
        print("started pid", proc.pid)
    elif a.cmd == "shot":
        out = env.WORK / "shots" / f"{a.name}.png"      # outside the profile: a clean start does not wipe them
        out.parent.mkdir(parents=True, exist_ok=True)
        print(str(out) if env.screenshot(out) else "no game window")
    elif a.cmd == "trail":
        p = trail_path()
        print("\n".join(p.read_text(errors="replace").splitlines()[-a.n:]) if p else "(no trail yet)")
    elif a.cmd == "alive":
        pid = json.loads(STATE.read_text())["pid"] if STATE.exists() else 0
        try:
            os.kill(pid, 0)
            print("alive")
        except (ProcessLookupError, PermissionError, OSError):
            print("not running")
    elif a.cmd == "stop":
        pid = json.loads(STATE.read_text())["pid"] if STATE.exists() else 0
        import signal
        try:
            os.killpg(pid, signal.SIGTERM)
        except (ProcessLookupError, OSError):
            pass
        for _ in range(60):
            try:
                os.kill(pid, 0)
            except OSError:
                break
            time.sleep(0.1)
        else:
            try:
                os.killpg(pid, signal.SIGKILL)
            except OSError:
                pass
        print("stopped")


if __name__ == "__main__":
    main()
