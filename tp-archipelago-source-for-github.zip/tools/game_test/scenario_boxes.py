#!/usr/bin/env python3
"""Game boxes: another player's item shown as the box of their game, with SteamGridDB art.

    TP_AP_SGDB_KEY=<your SteamGridDB API key> python3 -I tools/game_test/scenario_boxes.py

The key is read from the environment and put only in the scratch profile; nothing writes it to the tree.
Three combinations of the two art settings (item: cover or icon; text box: cover or icon) are played.
The fake room says the Wooden Sword Chest holds Alice's item from "The Legend of Zelda: Ocarina of Time".
With the key the mod downloads that game's cover (once, cached), and opening the chest shows the
box where the Sol was, with the cover as the get-item text box's icon. Without the key the item stays
a Sol and the status says so. Screenshots: .gametest/shots/box_*.png (looked at by a person).
"""
import os
import sys
import time
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import env  # noqa: E402
from flows import Rig  # noqa: E402

results = []
GAME = "Ocarina of Time"


def check(name, ok, detail=""):
    results.append(ok)
    print(("PASS  " if ok else "FAIL  ") + name + (f"  [{detail}]" if detail and not ok else ""), flush=True)


COMBOS = [("cover", "cover", 0, 0), ("icon_icon", "icon", 1, 1), ("icon_in_hand_cover_in_text", "icon+cover", 1, 0)]


def run(tag, label, world, text, have_key):
    with Rig(foreign=[f"Wooden Sword Chest=Alice:{GAME}:Hookshot@1"]) as rig:
        rig.start_game(fresh=True, extra=("--config", "backend.enableAdvancedSettings=true",
                                          "--config", "game.infiniteHearts=true",
                                          "--cvar", f"boxArtWorld={world}", "--cvar", f"boxArtText={text}"))
        rig.new_file()
        if have_key:
            time.sleep(50)       # the downloads and decodes finish on worker threads
        covers = [c.name for c in (env.WORK / "ctl/user/mod_data/local.dusklight_tp_archipelago").rglob("covers/*.*")
                  if c.name != "index.json"]
        want = set()
        if have_key:
            want = {"cover" if k == 0 else "icon" for k in {world, text}}
        got = {"icon" if "-icon" in n else "cover" for n in covers}
        check(f"[{tag}] downloaded exactly the art asked for ({', '.join(sorted(want)) or 'none'})", got == want, str(covers))
        rig.warp_to_ordon("Link's House")
        rig.pad("stick", 0, -1, 0.7, settle=1.2)
        rig.pad("stick", -0.4, -1, 0.35, settle=1.2)
        rig.pad("stick", 0, -1, 0.3, settle=1.2)
        rig.tap("a", settle=3.5)
        rig.shot(f"box_{tag}_held")
        rig.tap("a", settle=6)
        rig.shot(f"box_{tag}_text")
        check(f"[{tag}] the game is running with the box drawn", rig.ctl("alive") == "alive")


def main():
    have_key = bool(os.environ.get("TP_AP_SGDB_KEY"))
    for combo in (COMBOS if have_key else COMBOS[:1]):
        run(*combo, have_key)
    print(f"\nscreenshots: {HERE.parents[1] / '.gametest/shots'}/box_*.png")
    return 0 if all(results) else 1


if __name__ == "__main__":
    sys.exit(main())
