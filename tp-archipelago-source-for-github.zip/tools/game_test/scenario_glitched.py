#!/usr/bin/env python3
"""The tracker's glitched tier in the real game: the apworld's own glitched logic, shown in yellow.

    python3 -I tools/game_test/scenario_glitched.py

New file against the fake room (the live room's real settings: Logic Settings Glitchless). The tracker
runs the apworld's rules (src/ap/gc_logic.*, generated from the apworld's Python) twice, Glitchless and
Glitched. Asserted, with the numbers the C++ gives on these settings (tools/host_gen/logic_probe.cpp, itself
checked against the real apworld by tools/ap_truth):
  * at the start 21 checks are in logic and 13 more (Flight By Fowl, the Castle Town ladybugs, ...) are in
    glitched logic only; the trail lists them, and the Tracker tab shows them in yellow (screenshot)
  * receiving the Shadow Crystal moves all 13 into plain logic (and none of the 21 out)
"""
import re
import sys
import time
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from flows import Rig  # noqa: E402

results = []
SAMPLE = {"Flight By Fowl Top Platform Reward", "Outside South Castle Town Male Ladybug", "Charlo Donation Blessing"}


def check(name, ok, detail=""):
    results.append(ok)
    print(("PASS  " if ok else "FAIL  ") + name + (f"  [{detail}]" if detail and not ok else ""), flush=True)


def names(rig, key, after=0):
    last = None
    for l in rig.trail()[after:]:
        if key in l:
            last = set(n.strip(" ;") for n in l.split(key, 1)[1].split("; ") if n.strip(" ;"))
    return last


def wait_names(rig, after, timeout=60):
    end = time.time() + timeout
    while time.time() < end:
        if names(rig, "tracker: glitched only:", after) is not None and names(rig, "tracker: in logic:", after) is not None:
            return True
        time.sleep(1)
    return False


def open_tab(rig, n):
    rig.tap("back", settle=1.5)
    rig.tap("dpad_right", 4)
    rig.tap("a", settle=2)
    rig.tap("lb", 5, settle=0.8)
    rig.tap("rb", n, settle=1.5)


def main():
    with Rig() as rig:
        rig.start_game(fresh=True, extra=("--config", "backend.enableAdvancedSettings=true",
                                          "--config", "game.infiniteHearts=true"))
        rig.new_file()
        check("the tracker answered", wait_names(rig, 0))
        logic = names(rig, "tracker: in logic:") or set()
        glitched = names(rig, "tracker: glitched only:") or set()
        check("21 checks are in logic at the start", len(logic) == 21, str(len(logic)))
        check("13 more are in glitched logic only", len(glitched) == 13 and SAMPLE <= glitched, f"{len(glitched)}")
        check("none is in both", not (logic & glitched))
        counts = [re.search(r"tracker: (\d+) of (\d+) checks in logic \((\d+) done\), (\d+) more", l) for l in rig.trail()]
        counts = [m for m in counts if m]
        check("the trail counts say the same", bool(counts) and counts[-1].group(1) == "21" and counts[-1].group(4) == "13")
        open_tab(rig, 1)
        rig.shot("glitched_tab")
        rig.tap("dpad_down", 5, settle=0.8)       # In logic now, Ordon, Faron, Eldin, Lanayru: its list has the 13
        rig.tap("a", settle=1.5)
        rig.shot("glitched_tab_lanayru")
        rig.tap("back", settle=1.5)

        mark = rig.mark()
        rig.fake("send", "Shadow Crystal")
        rig.wait_trail("delivered item", timeout=30, after=mark)
        end = time.time() + 60
        while time.time() < end:
            now_logic = names(rig, "tracker: in logic:", mark)
            if now_logic and SAMPLE <= now_logic:
                break
            time.sleep(1)
        now_logic = names(rig, "tracker: in logic:", mark) or set()
        now_glitched = names(rig, "tracker: glitched only:", mark) or set()
        check("the Shadow Crystal moves the 13 into plain logic", glitched <= now_logic, f"{len(glitched - now_logic)} left")
        check("and nothing fell out of logic", logic <= now_logic)
        check("they are no longer listed as glitched-only", not (glitched & now_glitched))
    print(f"\nscreenshots: {HERE.parents[1] / '.gametest/shots'}/glitched_tab*.png")
    return 0 if all(results) else 1


if __name__ == "__main__":
    sys.exit(main())
