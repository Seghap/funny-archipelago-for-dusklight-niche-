#!/usr/bin/env python3
"""Transform Anywhere in the real game, with the slot's setting off and on.

    python3 -I tools/game_test/scenario_transform.py

The player's own Dusklight setting "Can Transform Anywhere" is turned off in the scratch profile, so
only the mod's own handling of the slot's YAML option is under test. For each value the fake room
gives the slot, a new file is made, the Shadow Crystal arrives from the room, Link is warped to Ordon
Ranch where Fado stands next to him, and Midna's button (Z) opens her menu with "Transform into wolf".

  * Off: Midna refuses ("If you transform here, it would scare someone!"); the mod overrides nothing
  * On:  Link becomes the wolf with Fado watching; the trail says the mod let it through

Screenshots (.gametest/shots/ta_*): the refusal and the wolf.
"""
import sys
from pathlib import Path

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
from flows import Rig  # noqa: E402

results = []


def check(name, ok, detail=""):
    results.append(ok)
    print(("PASS  " if ok else "FAIL  ") + name + (f"  [{detail}]" if detail and not ok else ""), flush=True)


HOST_OFF = ("--config", "backend.enableAdvancedSettings=true", "--config", "game.canTransformAnywhere=false",
            "--config", "game.enableQuickTransform=false")


def run(value):
    with Rig(settings=[f"Transform Anywhere={value}"]) as rig:
        rig.start_game(fresh=True, extra=HOST_OFF)
        rig.new_file()
        rig.fake("send", "Shadow Crystal")
        check(f"[{value}] the Shadow Crystal arrives from the room",
              rig.wait_trail("delivered item 0x32", timeout=30) is not None)
        status = [l for l in rig.trail() if "save loaded" in l]
        rig.warp_to_ordon("Ordon Ranch")
        mark = rig.mark()
        rig.tap("rb", settle=2.5)               # Z: Midna's menu
        rig.shot(f"ta_{value.lower()}_menu")
        rig.tap("a", settle=3.0)                # "Transform into wolf"
        rig.shot(f"ta_{value.lower()}_after")
        rig.tap("a", settle=3.0)
        rig.shot(f"ta_{value.lower()}_after2")
        overrides = [l for l in rig.trail()[mark:] if "transform anywhere:" in l]
        if value == "Yes":
            check("[Yes] the mod let Link transform with Fado watching", bool(overrides), "no override line in the trail")
        else:
            check("[No] the mod overrode nothing", not overrides, str(overrides))


def main():
    run("No")
    run("Yes")
    print(f"\nscreenshots: {Path(__file__).resolve().parents[2] / '.gametest/shots'}/ta_*.png (the refusal and the wolf are to be looked at)")
    return 0 if all(results) else 1


if __name__ == "__main__":
    sys.exit(main())
