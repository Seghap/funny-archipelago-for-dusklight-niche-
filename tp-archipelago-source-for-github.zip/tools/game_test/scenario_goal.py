#!/usr/bin/env python3
"""Finishing the game: the goal reaches the room, and !collect / !release work afterwards.

    python3 -I tools/game_test/scenario_goal.py

The fake room is set up like a room whose release, collect and remaining permissions are "goal" (the
server only allows them once the slot's goal is reached) and in which other worlds hold two items
for this slot. In the real game:

  1. new file; the status window's "Send goal complete" button (what the mod does when it sees
     Ganondorf fall) sends StatusUpdate 30; the room marks the goal reached
  2. the room then lets "!collect" through: the two held items arrive and are delivered to Link
  3. and "!release": the room counts every remaining location as checked, the mod notices
     (overlay: Checks 475 / 475)
  4. the connection drops and comes back: the mod says again that the goal is done
  5. the game is saved, closed and started again: the file remembers the goal and says so to the room
     on connecting (a game finished while offline is reported when the player is back online)

The ending of the game itself (Ganondorf's last blow) cannot be played by a script; its hook is read
against the game's source (docs/TESTING.md).
"""
import sys
import time
from pathlib import Path

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
from flows import Rig  # noqa: E402

results = []


def check(name, ok, detail=""):
    results.append(ok)
    print(("PASS  " if ok else "FAIL  ") + name + (f"  [{detail}]" if detail and not ok else ""), flush=True)


def goal_updates(rig):
    return [e for e in rig.fake_log() if e["dir"] == "in" and e["packet"].get("cmd") == "StatusUpdate"
            and e["packet"].get("status") == 30]


def main():
    with Rig(permissions=["release=goal", "collect=goal", "remaining=goal"],
             held=["Slingshot", "Gale Boomerang"]) as rig:
        rig.start_game(fresh=True)
        rig.new_file()
        check("no goal has been reported yet", not goal_updates(rig))

        # ---- 1. the goal
        rig.tap("back", settle=1.5)
        rig.tap("dpad_right", 2)
        rig.tap("a", settle=2)                       # the status window
        rig.tap("dpad_down", 5)                      # host, port, Reconnect, Disconnect, Send goal complete
        rig.tap("a", settle=2.5)
        rig.shot("goal_status")
        check("the goal reaches the room (StatusUpdate 30)", len(goal_updates(rig)) == 1)
        check("the trail records it", any("goal complete (manual)" in l for l in rig.trail()))
        rig.tap("back", settle=1.5)                  # close the menu

        # ---- 2. !collect, allowed now that the goal is reached
        mark = rig.mark()
        rig.fake("collect")
        check("!collect: the first held item reaches Link",
              rig.wait_trail("delivered item 0x4B", timeout=30, after=mark) is not None)
        check("!collect: and the second",
              rig.wait_trail("delivered item 0x40", timeout=30, after=mark) is not None)

        # ---- 3. !release
        mark = rig.mark()
        rig.fake("release")
        line = rig.wait_trail("more location(s) as checked", timeout=20, after=mark)
        check("!release: the mod sees every remaining location counted as checked",
              line is not None and "475 of 475" in line, str(line))
        time.sleep(2)
        rig.shot("goal_released")

        # ---- 4. a dropped connection
        before = len(goal_updates(rig))
        mark = rig.mark()
        rig.fake("drop")
        check("it reconnects", rig.wait_trail("connected in phase", timeout=40, after=mark) is not None)
        time.sleep(3)
        check("and says again that the goal is done", len(goal_updates(rig)) == before + 1)

        # ---- 5. saved, closed, loaded: the file remembers
        rig.save_game()
        rig.ctl("stop")
        time.sleep(4)
        before = len(goal_updates(rig))
        mark = rig.mark()
        rig.start_game(fresh=False)
        rig.load_file()
        check("a reloaded file reports its goal on connecting",
              rig.wait_trail("connected in phase", timeout=40, after=mark) is not None and
              len(goal_updates(rig)) == before + 1, f"{before} -> {len(goal_updates(rig))}")
        rig.shot("goal_reloaded")
    print(f"\nscreenshots: {Path(__file__).resolve().parents[2] / '.gametest/shots'}/goal_*.png")
    return 0 if all(results) else 1


if __name__ == "__main__":
    sys.exit(main())
