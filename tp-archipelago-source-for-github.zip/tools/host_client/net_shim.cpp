// HOST TEST SHIM: Dusklight's NetService (and LogService) on top of plain POSIX sockets, so the mod's
// real WebSocket and protocol code can run outside the game. Only what src/ap/ws_tcp.cpp uses is
// implemented: asynchronous TCP connect, send, poll_event, close. In the game the host provides this.
#include <mods/svc/log.h>
#include <mods/svc/net.h>

#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <netdb.h>
#include <netinet/tcp.h>
#include <poll.h>
#include <sys/socket.h>
#include <unistd.h>

#include <chrono>
#include <cstdio>
#include <cstring>
#include <map>
#include <string>
#include <vector>

namespace {

struct Conn {
    int fd = -1;
    bool connecting = true;
    void* user = nullptr;
    std::chrono::steady_clock::time_point started = std::chrono::steady_clock::now();
    std::string peer;
};
std::map<NetHandle, Conn> g_conns;
NetHandle g_next = 1;
std::vector<unsigned char> g_buf(65536);
std::string g_err;

ModResult net_connect(ModContext*, const NetConnectDesc* d, NetHandle* out) {
    std::string ep = d->endpoint ? d->endpoint : "";
    if (ep.rfind("tcp://", 0) != 0) return MOD_INVALID_ARGUMENT;
    ep = ep.substr(6);
    const auto colon = ep.rfind(':');
    if (colon == std::string::npos) return MOD_INVALID_ARGUMENT;
    const std::string host = ep.substr(0, colon), port = ep.substr(colon + 1);
    addrinfo hints{}, *res = nullptr;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_family = AF_UNSPEC;
    if (getaddrinfo(host.c_str(), port.c_str(), &hints, &res) != 0 || !res) return MOD_ERROR;
    int fd = -1;
    for (addrinfo* a = res; a; a = a->ai_next) {
        fd = ::socket(a->ai_family, a->ai_socktype, a->ai_protocol);
        if (fd < 0) continue;
        fcntl(fd, F_SETFL, fcntl(fd, F_GETFL, 0) | O_NONBLOCK);
        int one = 1;
        setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &one, sizeof(one));
        if (::connect(fd, a->ai_addr, a->ai_addrlen) == 0 || errno == EINPROGRESS) break;
        ::close(fd);
        fd = -1;
    }
    freeaddrinfo(res);
    if (fd < 0) return MOD_ERROR;
    Conn c;
    c.fd = fd;
    c.user = d->user_data;
    c.peer = ep;
    *out = g_next++;
    g_conns[*out] = c;
    return MOD_OK;
}

ModResult net_send(ModContext*, NetHandle h, const void* data, size_t size) {
    auto it = g_conns.find(h);
    if (it == g_conns.end() || it->second.connecting) return MOD_INVALID_ARGUMENT;
    const char* p = static_cast<const char*>(data);
    while (size > 0) {
        const ssize_t n = ::send(it->second.fd, p, size, MSG_NOSIGNAL);
        if (n < 0) {
            if (errno == EAGAIN || errno == EWOULDBLOCK) {
                pollfd pf{it->second.fd, POLLOUT, 0};
                ::poll(&pf, 1, 1000);
                continue;
            }
            return MOD_ERROR;
        }
        p += n;
        size -= static_cast<size_t>(n);
    }
    return MOD_OK;
}

ModResult net_close(ModContext*, NetHandle h) {
    auto it = g_conns.find(h);
    if (it == g_conns.end()) return MOD_INVALID_ARGUMENT;
    ::close(it->second.fd);
    g_conns.erase(it);
    return MOD_OK;
}

ModResult net_poll(ModContext*, NetEvent* ev) {
    *ev = NET_EVENT_INIT;
    for (auto it = g_conns.begin(); it != g_conns.end(); ++it) {
        Conn& c = it->second;
        pollfd pf{c.fd, static_cast<short>(c.connecting ? POLLOUT : POLLIN), 0};
        if (::poll(&pf, 1, 0) <= 0) {
            if (c.connecting && std::chrono::steady_clock::now() - c.started > std::chrono::seconds(10)) {
                ev->type = NET_EVENT_CLOSED;
                ev->handle = it->first;
                ev->user_data = c.user;
                ev->error = NET_ERROR_TIMEOUT;
                g_err = "connection timed out";
                ev->error_message = g_err.c_str();
                ::close(c.fd);
                g_conns.erase(it);
                return MOD_OK;
            }
            continue;
        }
        ev->handle = it->first;
        ev->user_data = c.user;
        if (c.connecting) {
            int err = 0;
            socklen_t len = sizeof(err);
            getsockopt(c.fd, SOL_SOCKET, SO_ERROR, &err, &len);
            if (err != 0) {
                ev->type = NET_EVENT_CLOSED;
                ev->error = err == ECONNREFUSED ? NET_ERROR_REFUSED : NET_ERROR_NETWORK;
                g_err = std::strerror(err);
                ev->error_message = g_err.c_str();
                ::close(c.fd);
                g_conns.erase(it);
                return MOD_OK;
            }
            c.connecting = false;
            ev->type = NET_EVENT_CONNECTED;
            std::snprintf(ev->endpoint.text, NET_ENDPOINT_MAX, "%s", c.peer.c_str());
            return MOD_OK;
        }
        const ssize_t n = ::recv(c.fd, g_buf.data(), g_buf.size(), 0);
        if (n > 0) {
            ev->type = NET_EVENT_STREAM_DATA;
            ev->data = g_buf.data();
            ev->size = static_cast<size_t>(n);
            return MOD_OK;
        }
        if (n < 0 && (errno == EAGAIN || errno == EWOULDBLOCK)) continue;
        ev->type = NET_EVENT_CLOSED;
        ev->error = n == 0 ? NET_ERROR_NONE : NET_ERROR_RESET;
        g_err = n == 0 ? "closed by the peer" : std::strerror(errno);
        ev->error_message = g_err.c_str();
        ::close(c.fd);
        g_conns.erase(it);
        return MOD_OK;
    }
    return MOD_OK;
}

ModResult net_unsupported(...) { return MOD_UNSUPPORTED; }

NetService g_net = {
    {sizeof(NetService), NET_SERVICE_MAJOR, NET_SERVICE_MINOR},
    net_connect,
    reinterpret_cast<decltype(NetService::listen)>(net_unsupported),
    reinterpret_cast<decltype(NetService::open_datagram)>(net_unsupported),
    reinterpret_cast<decltype(NetService::resolve)>(net_unsupported),
    net_poll,
    net_send,
    reinterpret_cast<decltype(NetService::send_to)>(net_unsupported),
    reinterpret_cast<decltype(NetService::set_user_data)>(net_unsupported),
    reinterpret_cast<decltype(NetService::stats)>(net_unsupported),
    net_close,
};

bool g_verbose = std::getenv("AP_HOST_VERBOSE") != nullptr;
void log_write(ModContext*, LogLevel level, const char* msg) {
    static const char* names[] = {"trace", "debug", "info", "warn", "error"};
    if (level >= LOG_LEVEL_INFO || g_verbose) std::printf("    [mod %s] %s\n", names[level], msg);
}
void log_trace(ModContext* c, const char* m) { log_write(c, LOG_LEVEL_TRACE, m); }
void log_debug(ModContext* c, const char* m) { log_write(c, LOG_LEVEL_DEBUG, m); }
void log_info(ModContext* c, const char* m) { log_write(c, LOG_LEVEL_INFO, m); }
void log_warn(ModContext* c, const char* m) { log_write(c, LOG_LEVEL_WARN, m); }
void log_error(ModContext* c, const char* m) { log_write(c, LOG_LEVEL_ERROR, m); }
LogService g_log = {{sizeof(LogService), LOG_SERVICE_MAJOR, LOG_SERVICE_MINOR}, log_write, log_trace, log_debug,
    log_info, log_warn, log_error};

}  // namespace

extern "C" {
ModContext* mod_ctx = nullptr;
const NetService* svc_net = &g_net;
const LogService* svc_log = &g_log;
}
