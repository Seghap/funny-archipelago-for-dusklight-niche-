// HOST TEST SHIM: ap::TlsStream (src/ap/tls.hpp) on OpenSSL memory BIOs instead of mbedTLS, so the
// mod's real WebSocket client can speak wss:// on a machine without mbedTLS. Same contract as
// src/ap/tls.cpp: ciphertext in through feed(), out through the write callback, certificate and host
// name always verified. The mod itself uses src/ap/tls.cpp.
#include "tls.hpp"

#include <openssl/err.h>
#include <openssl/rand.h>
#include <openssl/ssl.h>

namespace ap {

bool secure_random(void* out, size_t size) {
    return RAND_bytes(static_cast<unsigned char*>(out), static_cast<int>(size)) == 1;
}

struct TlsStream::Impl {
    SSL_CTX* ctx = nullptr;
    SSL* ssl = nullptr;
    BIO* in = nullptr;
    BIO* out = nullptr;
    void free() {
        if (ssl) SSL_free(ssl);  // also frees the BIOs it owns
        if (ctx) SSL_CTX_free(ctx);
        ssl = nullptr; ctx = nullptr; in = out = nullptr;
    }
    ~Impl() { free(); }
};

TlsStream::TlsStream() : mImpl{std::make_unique<Impl>()} {}
TlsStream::~TlsStream() = default;
int TlsStream::bio_send(const unsigned char*, size_t) { return 0; }
int TlsStream::bio_recv(unsigned char*, size_t) { return 0; }

void TlsStream::fail(const std::string& what, int code) {
    mFailed = true;
    char buf[200] = {};
    ERR_error_string_n(static_cast<unsigned long>(code), buf, sizeof(buf));
    mError = what + ": " + buf;
}

static bool flush(SSL* ssl, BIO* out, const TlsStream::WriteFn& write) {
    (void)ssl;
    char buf[16384];
    while (BIO_ctrl_pending(out) > 0) {
        const int n = BIO_read(out, buf, sizeof(buf));
        if (n <= 0) break;
        if (!write || !write(buf, static_cast<size_t>(n))) return false;
    }
    return true;
}

bool TlsStream::start(const std::string& host, WriteFn write) {
    reset();
    mWrite = std::move(write);
    auto& m = *mImpl;
    m.ctx = SSL_CTX_new(TLS_client_method());
    SSL_CTX_set_min_proto_version(m.ctx, TLS1_2_VERSION);
    SSL_CTX_set_verify(m.ctx, SSL_VERIFY_PEER, nullptr);  // verification is not optional
    SSL_CTX_set_default_verify_paths(m.ctx);
    m.ssl = SSL_new(m.ctx);
    m.in = BIO_new(BIO_s_mem());
    m.out = BIO_new(BIO_s_mem());
    SSL_set_bio(m.ssl, m.in, m.out);
    SSL_set_tlsext_host_name(m.ssl, host.c_str());
    SSL_set1_host(m.ssl, host.c_str());  // the name the certificate has to match
    SSL_set_connect_state(m.ssl);
    mStarted = true;
    return pump();
}

void TlsStream::reset() {
    mImpl->free();
    mWrite = nullptr;
    mInbox.clear(); mPlaintext.clear(); mError.clear();
    mStarted = mHandshakeDone = mPeerClosed = mFailed = false;
}

void TlsStream::feed(const char* data, size_t size) { mInbox.append(data, size); }

bool TlsStream::pump() {
    if (mFailed) return false;
    if (!mStarted) { mError = "TLS was not started"; return false; }
    auto& m = *mImpl;
    if (!mInbox.empty()) {
        BIO_write(m.in, mInbox.data(), static_cast<int>(mInbox.size()));
        mInbox.clear();
    }
    if (!mHandshakeDone) {
        const int r = SSL_do_handshake(m.ssl);
        if (!flush(m.ssl, m.out, mWrite)) { fail("TLS write failed", 0); return false; }
        if (r != 1) {
            const int e = SSL_get_error(m.ssl, r);
            if (e == SSL_ERROR_WANT_READ || e == SSL_ERROR_WANT_WRITE) return true;
            const long v = SSL_get_verify_result(m.ssl);
            fail("TLS handshake failed" + std::string(v != X509_V_OK ? std::string(" (certificate: ") + X509_verify_cert_error_string(v) + ")" : ""),
                static_cast<int>(ERR_get_error()));
            return false;
        }
        mHandshakeDone = true;
    }
    char buffer[16 * 1024];
    for (;;) {
        const int r = SSL_read(m.ssl, buffer, sizeof(buffer));
        if (r > 0) { mPlaintext.append(buffer, static_cast<size_t>(r)); continue; }
        const int e = SSL_get_error(m.ssl, r);
        flush(m.ssl, m.out, mWrite);
        if (e == SSL_ERROR_WANT_READ || e == SSL_ERROR_WANT_WRITE) break;
        if (e == SSL_ERROR_ZERO_RETURN) { mPeerClosed = true; break; }
        fail("TLS read failed", static_cast<int>(ERR_get_error()));
        return false;
    }
    return true;
}

bool TlsStream::handshake_done() const { return mHandshakeDone; }
bool TlsStream::closed_by_peer() const { return mPeerClosed; }

bool TlsStream::write(const char* data, size_t size) {
    if (mFailed || !mHandshakeDone) return false;
    auto& m = *mImpl;
    size_t sent = 0;
    while (sent < size) {
        const int r = SSL_write(m.ssl, data + sent, static_cast<int>(size - sent));
        if (r > 0) { sent += static_cast<size_t>(r); continue; }
        fail("TLS write failed", static_cast<int>(ERR_get_error()));
        return false;
    }
    return flush(m.ssl, m.out, mWrite);
}

std::string TlsStream::take_plaintext() {
    std::string out;
    out.swap(mPlaintext);
    return out;
}

}  // namespace ap
