#!/usr/bin/env python3
"""Builds the mod's real Archipelago client for the host and runs it against a live room.

    python3 -I output/tools/host_client/run.py HOST PORT "SLOT NAME"

Compiles src/ap/ap_client.cpp, ws_tcp.cpp, ws_deflate.cpp, gc_tables.cpp and gc_settings.cpp as they
are, with host stand-ins for what the game and the build normally provide (shims here and in
tools/shims): the net service over POSIX sockets, TLS over OpenSSL, JSON, and zlib in place of miniz.
Needs g++, OpenSSL and zlib development files.
"""
import json
import subprocess
import sys
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
OUT = HERE.parents[1]
ROOT = OUT.parent

if len(sys.argv) < 4:
    sys.exit(__doc__)
host, port, slot = sys.argv[1:4]
cap = OUT / "tools" / "live" / "capture.json"
seed = json.loads(cap.read_text())["room_info"]["seed_name"] if cap.exists() else ""

exe = HERE / "client_test"
cmd = ["g++", "-std=c++23", "-O1", "-w", "-DDUSK_MOD_FEATURE_FMT=1",
       f"-I{HERE / 'shims'}", f"-I{OUT / 'tools' / 'shims'}", f"-I{ROOT / 'dusklight' / 'sdk' / 'include'}", f"-I{OUT / 'src' / 'ap'}",
       str(HERE / "client_test.cpp"), str(HERE / "net_shim.cpp"), str(HERE / "tls_openssl_shim.cpp"),
       str(OUT / "src" / "ap" / "ap_client.cpp"), str(OUT / "src" / "ap" / "ws_tcp.cpp"),
       str(OUT / "src" / "ap" / "ws_deflate.cpp"), str(OUT / "src" / "ap" / "gc_tables.cpp"),
       str(OUT / "src" / "ap" / "gc_settings.cpp"), "-lssl", "-lcrypto", "-lz", "-lfmt", "-lpthread", "-o", str(exe)]
r = subprocess.run(cmd, capture_output=True, text=True)
if r.returncode:
    print("BUILD FAILED\n" + "\n".join(r.stderr.splitlines()[:40]))
    sys.exit(2)
try:
    sys.exit(subprocess.run([str(exe), host, port, slot, seed]).returncode)
finally:
    exe.unlink(missing_ok=True)
