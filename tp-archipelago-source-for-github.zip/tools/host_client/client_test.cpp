// Drives the mod's REAL network client (src/ap/ap_client.cpp over src/ap/ws_tcp.cpp, ws_deflate.cpp
// and the gc_* tables) against a live Archipelago room, through the same calls the mod makes.
//
//   client_test HOST PORT "SLOT" EXPECTED_SEED_NAME
//
// Sessions: connect and read slot data, scout every location, toggle the DeathLink tag, sync;
// disconnect and reconnect on the same Client; a wrong slot name (must be refused cleanly);
// an unreachable address (must report failure, not hang). It sends nothing that changes the
// multiworld: no location checks, no status update, no chat.
//
// Built with host stand-ins for the game's net service, TLS (OpenSSL) and JSON; see run.py.

#include "ap_client.hpp"
#include "gc_settings.hpp"
#include "gc_tables.hpp"

#include <chrono>
#include <cstdio>
#include <string>
#include <thread>
#include <variant>

using Clock = std::chrono::steady_clock;
static int g_failures = 0;
#define CHECK(cond, what)                                                                       \
    do {                                                                                        \
        const bool ok_ = (cond);                                                                \
        std::printf("%s  %s\n", ok_ ? "ok  " : "FAIL", what);                                   \
        if (!ok_) ++g_failures;                                                                 \
    } while (0)

// Pumps the client the way the mod's per-frame update does, handing each event to `on`.
// Returns when `on` returns true or the time runs out.
template <class F>
static bool pump(ap::Client& c, double seconds, F&& on) {
    const auto end = Clock::now() + std::chrono::milliseconds(static_cast<int>(seconds * 1000));
    while (Clock::now() < end) {
        c.poll();
        ap::Event ev;
        while (c.next_event(ev)) {
            if (on(ev)) return true;
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(5));
    }
    return false;
}

int main(int argc, char** argv) {
    if (argc < 5) {
        std::fprintf(stderr, "usage: client_test HOST PORT SLOT SEED_NAME\n");
        return 2;
    }
    const std::string server = std::string(argv[1]) + ":" + argv[2], slot = argv[3], expectSeed = argv[4];
    ap::Client c;

    // ---- session 1: the connect window's path
    std::printf("\n== session 1: connect, slot data, scout\n");
    c.connect({server, slot, ""});
    ap::json connected;
    bool gotConnected = false;
    const auto t0 = Clock::now();
    pump(c, 20, [&](ap::Event& ev) {
        if (auto* e = std::get_if<ap::ConnectedEvent>(&ev)) {
            connected = e->packet;
            gotConnected = true;
            return true;
        }
        if (auto* d = std::get_if<ap::DisconnectedEvent>(&ev)) {
            std::printf("    disconnected while connecting: %s\n", d->reason.c_str());
            return true;
        }
        return false;
    });
    CHECK(gotConnected, "Connected event arrives");
    if (!gotConnected) return 1;
    std::printf("    connected in %.2fs, state=%d\n", std::chrono::duration<double>(Clock::now() - t0).count(),
        static_cast<int>(c.state()));
    CHECK(c.state() == ap::State::Connected, "client state is Connected");
    CHECK(c.slot() == 1 && c.team() == 0, "slot and team numbers read");
    // The expected name comes from a previous capture of the room; without one, a seed name that was
    // read at all is what can be checked.
    CHECK(expectSeed.empty() ? !c.seedName().empty() : c.seedName() == expectSeed,
        "room seed name read from RoomInfo");
    CHECK(c.playerName(c.slot()) == slot, "player name resolved from the players list");
    // The client asks for the hint list right after Connected (data storage + SetNotify); the
    // room answers with the whole list, empty if nobody has made a hint.
    bool gotHints = false;
    pump(c, 5, [&](ap::Event& ev) {
        if (auto* h = std::get_if<ap::HintsEvent>(&ev)) {
            std::printf("    hint list from data storage: %zu hint(s)\n", h->hints.size());
            gotHints = true;
            return true;
        }
        return false;
    });
    CHECK(gotHints, "the hint list arrives after Connected");
    {
        // The server's own shape (NetUtils.Hint as JSON), including a bad entry that must be skipped.
        const auto parsed = ap::parse_hints(ap::json::parse(std::string(
            R"([{"receiving_player":1,"finding_player":2,"location":2320005,"item":2320010,"found":false,)"
            R"("entrance":"","item_flags":1,"status":30},"junk",{"receiving_player":3,"finding_player":1,)"
            R"("location":2320007,"item":99,"found":true}])")));
        CHECK(parsed.size() == 2 && parsed[0].receivingPlayer == 1 && parsed[0].findingPlayer == 2 &&
                  parsed[0].location == 2320005 && parsed[0].item == 2320010 && !parsed[0].found &&
                  parsed[0].status == 30 && parsed[0].itemFlags == 1,
            "a hint parses from the server's JSON");
        CHECK(parsed.size() == 2 && parsed[1].found && parsed[1].status == 40,
            "a found hint without a status reads as found (40)");
        CHECK(ap::parse_hints(ap::json::parse(std::string("{}"))).empty(), "a hint list that is not a list is empty");
    }
    CHECK(c.gameOfSlot(c.slot()) == "Twilight Princess", "game of our slot read from slot_info");

    const auto& slotData = connected["slot_data"];
    CHECK(slotData.contains("World Version") && slotData["World Version"].get<std::string>() == ap::gc::supported_world_version(),
        "slot_data World Version is the supported one");
    ap::gc::StringPairs raw;
    for (const auto& [k, v] : slotData["Settings"].items()) raw.emplace_back(k, v.get<std::string>());
    const auto translated = ap::gc::translate_settings(raw);
    CHECK(translated.errors.empty() && raw.size() > 30, "slot_data Settings parse and translate");
    CHECK(slotData["DeathLink"].is_number_integer(), "slot_data DeathLink read");

    std::vector<int64_t> ids;
    for (const char* key : {"checked_locations", "missing_locations"})
        for (const auto& id : connected[key]) ids.push_back(id.get<int64_t>());
    int unknown = 0;
    for (const auto id : ids) unknown += ap::gc::find_location(id) == nullptr ? 1 : 0;
    CHECK(ids.size() == 475 && unknown == 0, "475 server locations, all known to the mod");

    // the mod scouts in chunks of 500
    std::vector<ap::NetworkItem> placed;
    c.sendScouts(ids);
    pump(c, 20, [&](ap::Event& ev) {
        if (auto* e = std::get_if<ap::LocationInfoEvent>(&ev)) {
            placed.insert(placed.end(), e->items.begin(), e->items.end());
            return placed.size() >= ids.size();
        }
        return false;
    });
    CHECK(placed.size() == 475, "LocationScouts answered for every location");
    int own = 0, nameBad = 0, locBad = 0, unknownItem = 0;
    for (const auto& p : placed) {
        own += p.player == c.slot() ? 1 : 0;
        const auto* item = ap::gc::find_item(p.item);
        const auto* loc = ap::gc::find_location(p.location);
        if (!item) { ++unknownItem; continue; }
        // names the real client parsed from the data package, against the mod's own tables
        if (c.itemName(p.item, p.player) != item->gcName) ++nameBad;
        if (!loc) continue;
        std::string a = c.locationName(p.location, c.slot()), b = loc->dusklightName;
        for (auto& ch : a) ch = static_cast<char>(std::tolower(static_cast<unsigned char>(ch)));
        for (auto& ch : b) ch = static_cast<char>(std::tolower(static_cast<unsigned char>(ch)));
        if (a != b) ++locBad;
    }
    CHECK(own == 475, "all 475 placements are this slot's own items");
    CHECK(unknownItem == 0, "every placed item is known to the mod's item table");
    CHECK(nameBad == 0, "data-package item names (parsed by the real client) match the mod's table");
    CHECK(locBad == 0, "data-package location names match the mod's table");

    // what the mod does once connected: the DeathLink tag (from slot_data) and a Sync
    c.setTags({"DeathLink"});
    c.sendSync();
    bool dropped = false;
    int extra = 0;
    pump(c, 2.0, [&](ap::Event& ev) {
        if (std::holds_alternative<ap::DisconnectedEvent>(ev)) dropped = true;
        else ++extra;
        return false;
    });
    CHECK(!dropped && c.state() == ap::State::Connected, "ConnectUpdate (DeathLink tag) and Sync leave the connection up");
    std::printf("    %d further event(s) after Sync\n", extra);
    c.setTags({});
    c.disconnect();
    CHECK(c.state() == ap::State::Disconnected, "disconnect() leaves the client Disconnected");

    // ---- goal and server commands. These change a room (a goal, a release), so only against the
    // local fake room (tools/game_test/fake_ap_server.py), never against a real one.
    if (argv[1] == std::string("localhost") || argv[1] == std::string("127.0.0.1")) {
        std::printf("\n== goal and commands (fake room, permissions: release/collect once the goal is reached)\n");
        c.connect({server, slot, ""});
        pump(c, 20, [&](ap::Event& ev) { return std::holds_alternative<ap::ConnectedEvent>(ev); });
        auto answers = [&](const char* type) {
            std::vector<std::string> out;
            pump(c, 2.0, [&](ap::Event& ev) {
                if (auto* e = std::get_if<ap::PrintEvent>(&ev)) {
                    if (e->message.value("type", "") == type) out.push_back(e->text);
                }
                return false;
            });
            return out;
        };
        c.say("!release");   // before the goal: refused
        const auto early = answers("CommandResult");
        CHECK(!early.empty() && early[0].find("not permitted") != std::string::npos,
            "!release before the goal is refused by the room, and the answer reaches the client");
        c.sendGoal();
        const auto goal = answers("Goal");
        CHECK(!goal.empty() && goal[0].find("completed their goal") != std::string::npos, "the goal is announced");
        c.say("!release");
        const auto released = answers("Release");
        CHECK(!released.empty(), "!release after the goal is announced as a release");
        c.disconnect();
    }

    // ---- session 2: reconnect on the same Client (what Reconnect and the automatic retry do)
    std::printf("\n== session 2: reconnect on the same client\n");
    c.connect({server, slot, ""});
    bool again = pump(c, 20, [&](ap::Event& ev) { return std::holds_alternative<ap::ConnectedEvent>(ev); });
    CHECK(again && c.state() == ap::State::Connected, "reconnect reaches Connected again");
    c.disconnect();

    // ---- session 3: a slot that does not exist
    std::printf("\n== session 3: wrong slot name\n");
    c.connect({server, "NO SUCH SLOT", ""});
    ap::DisconnectedEvent refused;
    bool gotRefused = pump(c, 20, [&](ap::Event& ev) {
        if (auto* d = std::get_if<ap::DisconnectedEvent>(&ev)) { refused = *d; return true; }
        return std::holds_alternative<ap::ConnectedEvent>(ev);
    });
    std::printf("    reason: %s\n", refused.reason.c_str());
    CHECK(gotRefused && refused.refused, "a wrong slot name is refused (and flagged so the mod does not retry)");
    CHECK(refused.reason.find("InvalidSlot") != std::string::npos, "the server's refusal reason is reported");

    // ---- session 4: nothing listening
    std::printf("\n== session 4: unreachable address\n");
    c.connect({"localhost:1", slot, ""});
    ap::DisconnectedEvent down;
    const auto t1 = Clock::now();
    bool gotDown = pump(c, 30, [&](ap::Event& ev) {
        if (auto* d = std::get_if<ap::DisconnectedEvent>(&ev)) { down = *d; return true; }
        return false;
    });
    std::printf("    reported after %.1fs: %s\n", std::chrono::duration<double>(Clock::now() - t1).count(), down.reason.c_str());
    CHECK(gotDown && !down.refused, "an unreachable server is reported as a failure, not a hang");

    std::printf("\n%s\n", g_failures == 0 ? "CLIENT TEST PASSED" : "CLIENT TEST FAILED");
    return g_failures ? 1 : 0;
}
