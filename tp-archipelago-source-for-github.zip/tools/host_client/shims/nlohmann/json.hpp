// HOST TEST SHIM, not nlohmann/json: a small but working JSON value (parser and writer) with the API
// surface the Archipelago client uses, so src/ap/ap_client.cpp can run on a machine without it.
// The mod links the real library (see CMakeLists.txt).
#pragma once
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <initializer_list>
#include <iterator>
#include <map>
#include <stdexcept>
#include <string>
#include <string_view>
#include <type_traits>
#include <utility>
#include <vector>

namespace nlohmann {
class json {
public:
    enum class value_t { null, object, array, string, boolean, integer, floating, discarded };
    struct error_handler_t { enum type { strict, replace, ignore }; };
    using object_t = std::map<std::string, json>;
    using array_t = std::vector<json>;

    json() {}
    json(std::nullptr_t) {}
    json(bool b) : t_(value_t::boolean), i_(b) {}
    json(int v) : t_(value_t::integer), i_(v) {}
    json(long v) : t_(value_t::integer), i_(v) {}
    json(long long v) : t_(value_t::integer), i_(v) {}
    json(unsigned v) : t_(value_t::integer), i_(v) {}
    json(unsigned long v) : t_(value_t::integer), i_(static_cast<long long>(v)) {}
    json(double v) : t_(value_t::floating), d_(v) {}
    json(const char* v) : t_(value_t::string), s_(v) {}
    json(const std::string& v) : t_(value_t::string), s_(v) {}
    template <class T, class = std::enable_if_t<!std::is_same_v<T, json> && !std::is_same_v<T, char>>>
    json(const std::vector<T>& v) : t_(value_t::array) { for (const auto& e : v) a_.push_back(json(e)); }
    json(std::initializer_list<json> l) {
        bool isObj = l.size() > 0;
        for (const auto& e : l) if (!(e.t_ == value_t::array && e.a_.size() == 2 && e.a_[0].t_ == value_t::string)) { isObj = false; break; }
        if (isObj) { t_ = value_t::object; for (const auto& e : l) o_[e.a_[0].s_] = e.a_[1]; }
        else { t_ = value_t::array; a_.assign(l.begin(), l.end()); }
    }
    static json object() { json j; j.t_ = value_t::object; return j; }
    static json array(std::initializer_list<json> l = {}) { json j; j.t_ = value_t::array; j.a_.assign(l.begin(), l.end()); return j; }

    // ---- parsing
    static json parse(std::string_view text, std::nullptr_t = nullptr, bool allow_exceptions = true) {
        try {
            size_t p = 0;
            json v = parse_value(text, p);
            skip_ws(text, p);
            if (p != text.size()) throw std::runtime_error("trailing characters");
            return v;
        } catch (const std::exception&) {
            if (allow_exceptions) throw;
            json d; d.t_ = value_t::discarded; return d;
        }
    }
    static json parse(const std::string& text, std::nullptr_t = nullptr, bool allow_exceptions = true) {
        return parse(std::string_view(text), nullptr, allow_exceptions);
    }

    bool is_discarded() const { return t_ == value_t::discarded; }
    bool is_null() const { return t_ == value_t::null; }
    bool is_array() const { return t_ == value_t::array; }
    bool is_object() const { return t_ == value_t::object; }
    bool is_string() const { return t_ == value_t::string; }
    bool is_boolean() const { return t_ == value_t::boolean; }
    bool is_number() const { return t_ == value_t::integer || t_ == value_t::floating; }
    bool is_number_integer() const { return t_ == value_t::integer; }
    bool empty() const { return size() == 0; }
    size_t size() const { return t_ == value_t::array ? a_.size() : t_ == value_t::object ? o_.size() : t_ == value_t::null ? 0 : 1; }
    bool contains(const std::string& k) const { return t_ == value_t::object && o_.count(k) > 0; }

    json& operator[](const std::string& k) { if (t_ == value_t::null) t_ = value_t::object; return o_[k]; }
    json& operator[](const char* k) { return (*this)[std::string(k)]; }
    const json& operator[](const std::string& k) const {
        if (t_ != value_t::object) throw std::runtime_error("cannot use operator[] with a string argument on a non-object");
        auto it = o_.find(k);
        if (it == o_.end()) throw std::runtime_error("key not found: " + k);
        return it->second;
    }
    const json& operator[](const char* k) const { return (*this)[std::string(k)]; }

    template <class T> T value(const std::string& k, const T& def) const {
        if (t_ != value_t::object) throw std::runtime_error("cannot use value() with a non-object");
        auto it = o_.find(k);
        return it == o_.end() ? def : it->second.template get<T>();
    }
    std::string value(const std::string& k, const char* def) const { return value(k, std::string(def)); }

    template <class T> T get() const {
        if constexpr (std::is_same_v<T, json>) return *this;
        else if constexpr (std::is_same_v<T, std::string>) { if (t_ != value_t::string) throw std::runtime_error("type must be string"); return s_; }
        else if constexpr (std::is_same_v<T, bool>) { if (t_ != value_t::boolean) throw std::runtime_error("type must be boolean"); return i_ != 0; }
        else if constexpr (std::is_floating_point_v<T>) { if (!is_number()) throw std::runtime_error("type must be number"); return static_cast<T>(t_ == value_t::floating ? d_ : static_cast<double>(i_)); }
        else { if (!is_number()) throw std::runtime_error("type must be number"); return static_cast<T>(t_ == value_t::floating ? static_cast<long long>(d_) : i_); }
    }
    void push_back(const json& v) { if (t_ == value_t::null) t_ = value_t::array; a_.push_back(v); }

    // ---- iteration: arrays and objects both yield values
    class const_iterator {
    public:
        using value_type = json;
        using difference_type = std::ptrdiff_t;
        using pointer = const json*;
        using reference = const json&;
        using iterator_category = std::forward_iterator_tag;
        const_iterator() = default;
        const json& operator*() const { return isObj ? oi->second : *ai; }
        const json* operator->() const { return &**this; }
        const_iterator& operator++() { if (isObj) ++oi; else ++ai; return *this; }
        const_iterator operator++(int) { auto c = *this; ++*this; return c; }
        bool operator==(const const_iterator& o) const { return isObj ? oi == o.oi : ai == o.ai; }
        bool operator!=(const const_iterator& o) const { return !(*this == o); }
        const std::string& key() const { return oi->first; }
        bool isObj = false;
        array_t::const_iterator ai{};
        object_t::const_iterator oi{};
    };
    using iterator = const_iterator;
    const_iterator begin() const { const_iterator it; it.isObj = t_ == value_t::object; if (it.isObj) it.oi = o_.begin(); else it.ai = a_.begin(); return it; }
    const_iterator end() const { const_iterator it; it.isObj = t_ == value_t::object; if (it.isObj) it.oi = o_.end(); else it.ai = a_.end(); return it; }
    const_iterator find(const std::string& k) const { const_iterator it = end(); if (t_ == value_t::object) it.oi = o_.find(k); return it; }
    std::vector<std::pair<std::string, json>> items() const { return {o_.begin(), o_.end()}; }

    // ---- writing
    std::string dump(int = -1, char = ' ', bool = false, error_handler_t::type = error_handler_t::strict) const {
        std::string out;
        write(out);
        return out;
    }

private:
    value_t t_ = value_t::null;
    long long i_ = 0;
    double d_ = 0;
    std::string s_;
    array_t a_;
    object_t o_;

    void write(std::string& out) const {
        switch (t_) {
        case value_t::null: case value_t::discarded: out += "null"; break;
        case value_t::boolean: out += i_ ? "true" : "false"; break;
        case value_t::integer: out += std::to_string(i_); break;
        case value_t::floating: { char b[40]; std::snprintf(b, sizeof(b), "%.17g", d_); out += b; break; }
        case value_t::string: write_string(out, s_); break;
        case value_t::array: { out += '['; bool f = true; for (const auto& e : a_) { if (!f) out += ','; f = false; e.write(out); } out += ']'; break; }
        case value_t::object: { out += '{'; bool f = true; for (const auto& kv : o_) { if (!f) out += ','; f = false; write_string(out, kv.first); out += ':'; kv.second.write(out); } out += '}'; break; }
        }
    }
    static void write_string(std::string& out, const std::string& s) {
        out += '"';
        for (const unsigned char c : s) {
            switch (c) {
            case '"': out += "\\\""; break;
            case '\\': out += "\\\\"; break;
            case '\n': out += "\\n"; break;
            case '\r': out += "\\r"; break;
            case '\t': out += "\\t"; break;
            default:
                if (c < 0x20) { char b[8]; std::snprintf(b, sizeof(b), "\\u%04x", c); out += b; }
                else out += static_cast<char>(c);
            }
        }
        out += '"';
    }
    static void skip_ws(std::string_view s, size_t& p) { while (p < s.size() && (s[p] == ' ' || s[p] == '\t' || s[p] == '\n' || s[p] == '\r')) ++p; }
    static void append_utf8(std::string& out, uint32_t cp) {
        if (cp < 0x80) out += static_cast<char>(cp);
        else if (cp < 0x800) { out += static_cast<char>(0xC0 | (cp >> 6)); out += static_cast<char>(0x80 | (cp & 0x3F)); }
        else if (cp < 0x10000) { out += static_cast<char>(0xE0 | (cp >> 12)); out += static_cast<char>(0x80 | ((cp >> 6) & 0x3F)); out += static_cast<char>(0x80 | (cp & 0x3F)); }
        else { out += static_cast<char>(0xF0 | (cp >> 18)); out += static_cast<char>(0x80 | ((cp >> 12) & 0x3F)); out += static_cast<char>(0x80 | ((cp >> 6) & 0x3F)); out += static_cast<char>(0x80 | (cp & 0x3F)); }
    }
    static uint32_t hex4(std::string_view s, size_t p) {
        if (p + 4 > s.size()) throw std::runtime_error("bad \\u escape");
        uint32_t v = 0;
        for (size_t k = 0; k < 4; ++k) {
            const char c = s[p + k];
            v <<= 4;
            if (c >= '0' && c <= '9') v |= c - '0'; else if (c >= 'a' && c <= 'f') v |= c - 'a' + 10; else if (c >= 'A' && c <= 'F') v |= c - 'A' + 10; else throw std::runtime_error("bad \\u escape");
        }
        return v;
    }
    static std::string parse_string(std::string_view s, size_t& p) {
        std::string out;
        ++p;  // opening quote
        for (;;) {
            if (p >= s.size()) throw std::runtime_error("unterminated string");
            const char c = s[p++];
            if (c == '"') return out;
            if (c != '\\') { out += c; continue; }
            if (p >= s.size()) throw std::runtime_error("bad escape");
            const char e = s[p++];
            switch (e) {
            case '"': out += '"'; break; case '\\': out += '\\'; break; case '/': out += '/'; break;
            case 'b': out += '\b'; break; case 'f': out += '\f'; break; case 'n': out += '\n'; break;
            case 'r': out += '\r'; break; case 't': out += '\t'; break;
            case 'u': {
                uint32_t cp = hex4(s, p); p += 4;
                if (cp >= 0xD800 && cp < 0xDC00 && p + 6 <= s.size() && s[p] == '\\' && s[p + 1] == 'u') {
                    const uint32_t lo = hex4(s, p + 2);
                    if (lo >= 0xDC00 && lo < 0xE000) { cp = 0x10000 + ((cp - 0xD800) << 10) + (lo - 0xDC00); p += 6; }
                }
                append_utf8(out, cp);
                break;
            }
            default: throw std::runtime_error("bad escape");
            }
        }
    }
    static json parse_value(std::string_view s, size_t& p) {
        skip_ws(s, p);
        if (p >= s.size()) throw std::runtime_error("unexpected end");
        const char c = s[p];
        if (c == '{') {
            json j = object();
            ++p; skip_ws(s, p);
            if (p < s.size() && s[p] == '}') { ++p; return j; }
            for (;;) {
                skip_ws(s, p);
                if (p >= s.size() || s[p] != '"') throw std::runtime_error("expected key");
                std::string k = parse_string(s, p);
                skip_ws(s, p);
                if (p >= s.size() || s[p++] != ':') throw std::runtime_error("expected ':'");
                j.o_[k] = parse_value(s, p);
                skip_ws(s, p);
                if (p >= s.size()) throw std::runtime_error("unterminated object");
                if (s[p] == ',') { ++p; continue; }
                if (s[p] == '}') { ++p; return j; }
                throw std::runtime_error("expected ',' or '}'");
            }
        }
        if (c == '[') {
            json j = array();
            ++p; skip_ws(s, p);
            if (p < s.size() && s[p] == ']') { ++p; return j; }
            for (;;) {
                j.a_.push_back(parse_value(s, p));
                skip_ws(s, p);
                if (p >= s.size()) throw std::runtime_error("unterminated array");
                if (s[p] == ',') { ++p; continue; }
                if (s[p] == ']') { ++p; return j; }
                throw std::runtime_error("expected ',' or ']'");
            }
        }
        if (c == '"') return json(parse_string(s, p));
        if (s.substr(p, 4) == "true") { p += 4; return json(true); }
        if (s.substr(p, 5) == "false") { p += 5; return json(false); }
        if (s.substr(p, 4) == "null") { p += 4; return json(); }
        size_t q = p;
        bool fl = false;
        if (q < s.size() && s[q] == '-') ++q;
        while (q < s.size() && ((s[q] >= '0' && s[q] <= '9') || s[q] == '.' || s[q] == 'e' || s[q] == 'E' || s[q] == '+' || s[q] == '-')) { if (!(s[q] >= '0' && s[q] <= '9')) fl = true; ++q; }
        if (q == p) throw std::runtime_error("unexpected character");
        const std::string num(s.substr(p, q - p));
        p = q;
        if (fl) return json(std::strtod(num.c_str(), nullptr));
        return json(static_cast<long long>(std::strtoll(num.c_str(), nullptr, 10)));
    }
};
}  // namespace nlohmann
