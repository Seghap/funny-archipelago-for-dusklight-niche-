#!/usr/bin/env python3
"""For every location the server owns: can the mod notice it was collected?

Emulates, over Dusklight's real locations.yaml, the two detection paths of the mod:

  A. the engine's check names. `build_check_map` (src/ap/mode/slot.cpp) turns each location's
     metadata into the strings the item service reports (chest:<stage>:<box>, poe:..., shop:...,
     sky:..., bug:..., golden_wolf:..., freestanding:..., and named gifts through
     nameLookupOverride in src/tools.cpp, whose targets are ITEM_CHECK_* names from the SDK's
     mods/items.h). observe_give sees those.
  B. the save's own flags. `scan_locations` -> isLocationMetadataObtained (src/tools.cpp) reads
     chest, poe, freestanding, event, golden wolf, switch, item and twilit-insect flags.

A location with neither path would never be reported. Uses the location set the live server
reports (tools/live/capture.json) when present, otherwise every apworld location.

    python3 -I output/tools/check_detection.py
"""
import json
import re
import sys
from pathlib import Path

import yaml

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parents[1]
ROOT = OUT.parent
DL = ROOT / "ref_official_rando_ap" / "generator" / "data"

# ---- the locations to check
spec_locs = None
cap_path = OUT / "tools" / "live" / "capture.json"
sys.path.insert(0, str(OUT / "tools"))
import importlib.util
spec = importlib.util.spec_from_file_location("gen", OUT / "tools" / "gen_gc_tables.py")
gen = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gen)
dl_names = {n.lower(): n for n in gen.read_dl_locations()}
by_code = {code: dl_names[name.lower()] for name, code in gen.read_gc_locations() if code is not None}
if cap_path.exists():
    cap = json.loads(cap_path.read_text())
    ids = set(cap["connected"]["checked_locations"]) | set(cap["connected"]["missing_locations"])
    names = {by_code[i - gen.ID_BASE] for i in ids}
    source = f"the {len(names)} locations the live server reports"
else:
    names = set(by_code.values())
    source = f"all {len(names)} apworld locations"

# ---- stage names by index (src/stages.cpp)
stages = {}
for m in re.finditer(r'^\s*"([A-Za-z0-9_]+)",\s*//\s*(\d+)', (OUT / "src" / "stages.cpp").read_text(), re.M):
    stages[int(m.group(2))] = m.group(1)

# ---- nameLookupOverride (src/tools.cpp) with ITEM_CHECK_* values from the SDK
sdk = (ROOT / "dusklight" / "sdk" / "include" / "mods" / "items.h").read_text()
item_check = dict(re.findall(r'#define\s+(ITEM_CHECK_\w+)\s+"([^"]*)"', sdk))
tools_cpp = (OUT / "src" / "tools.cpp").read_text()
body = tools_cpp[tools_cpp.index("std::string nameLookupOverride"):]
body = body[:body.index("return locationName;")]
override = {}
for loc, const in re.findall(r'\{"([^"]+)",\s*(ITEM_CHECK_\w+)\}', body):
    if const not in item_check:
        sys.exit(f"tools.cpp names {const}, which the SDK does not define")
    override[loc] = item_check[const]


def name_lookup(n):
    return override.get(n, n)


locs = yaml.safe_load((DL / "locations.yaml").read_text(encoding="utf-8"))
by_name = {l["Name"]: l for l in locs}

SCAN_KEYS = ("Chest", "Poe", "Freestanding Item", "Event Flag", "Golden Wolf", "Switch Flag", "Item Flag",
             "Twilit Insect")
report = {"names": 0, "scan": 0, "both": 0, "neither": []}
check_names = {}
for n in sorted(names):
    meta = by_name[n].get("Metadata") or {}
    keys = []

    def stage(c):
        return stages[c["Stage"]]

    for c in meta.get("Chest") or []:
        keys.append(f"chest:{stage(c)}:{c['Tbox Id']}")
    for c in meta.get("Poe") or []:
        keys.append(f"poe:{stage(c)}:{c['Flag']}")
    for c in meta.get("Freestanding Item") or []:
        keys.append(f"freestanding:{stage(c)}:{c['Flag']}")
        if c["Flag"] == 0x9F:
            keys.append(f"boss:{stage(c)}")
    for c in meta.get("Sky Character") or []:
        keys.append(f"sky:{stage(c)}:{c['Room']}")
    for c in meta.get("Golden Wolf") or []:
        keys.append(f"golden_wolf:{c['Flag']}")
    for c in meta.get("Bug Reward") or []:
        keys.append(f"bug:{c['Item Id']}")
    for c in meta.get("Shop") or []:
        keys.append(f"shop:{stage(c)}:{c['Room']}:{c['Item']}")
    named = []
    for c in meta.get("Name Lookup") or []:
        k = name_lookup(c)
        # a name the engine never emits (not an ITEM_CHECK_* string) cannot be observed
        if k in item_check.values():
            keys.append(k)
        named.append(k)
    scan = any(k in meta for k in SCAN_KEYS)
    check_names[n] = keys
    a, b = bool(keys), scan
    if a and b:
        report["both"] += 1
    elif a:
        report["names"] += 1
    elif b:
        report["scan"] += 1
        report.setdefault("scan_only", []).append(n)
    else:
        report["neither"].append((n, sorted(meta)))

print(f"checking {source}")
print(f"  detectable through engine check names AND the save-flag scan: {report['both']}")
print(f"  engine check names only:                                      {report['names']}")
print(f"  save-flag scan only:                                          {report['scan']}")
print(f"  NEITHER (would never be reported):                            {len(report['neither'])}")
for n in report.get("scan_only", []):
    print(f"      scan only: {n}   ({', '.join(sorted(by_name[n].get('Metadata') or {}))})")
for n, keys in report["neither"]:
    print(f"      {n}   metadata: {keys}")

# check names must not be shared in ways that make one pickup report a different location
inverse = {}
for n, keys in check_names.items():
    for k in keys:
        inverse.setdefault(k, []).append(n)
shared = {k: v for k, v in inverse.items() if len(v) > 1}
print(f"  check names shared by several locations (all reported together): {len(shared)}")
for k, v in list(shared.items())[:6]:
    print(f"      {k}: {v}")
# `--dump FILE`: every location's engine check names and original item, for the in-game replay
# (tools/game_test/scenario_every_check.py)
if "--dump" in sys.argv:
    items = {i["Name"]: i["Id"] for i in yaml.safe_load((DL / "items.yaml").read_text(encoding="utf-8"))}
    out = {n: {"checks": check_names[n], "original": items.get(by_name[n].get("Original Item"), 0)} for n in sorted(names)}
    Path(sys.argv[sys.argv.index("--dump") + 1]).write_text(json.dumps(out, indent=1))
    print(f"wrote {len(out)} locations")
sys.exit(1 if report["neither"] else 0)
