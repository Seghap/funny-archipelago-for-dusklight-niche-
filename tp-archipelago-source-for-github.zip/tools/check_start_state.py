#!/usr/bin/env python3
"""Checks that a new Archipelago file starts in the post-prologue state.

Evaluates the generator's real startflags.yaml under the settings this mod derives from the
GameCube apworld (its hard-coded Skip Prologue / twilights cleared / Skip MDH, plus the
defaults in gen_gc_tables.py) and verifies that every event flag the scene-layer code and the
save setup test is among the start flags. This is the same data setupRandomizerFile() applies.

Why these flags (src/hooks.cpp hookPreGetLayerNo, src/session.cpp setupRandomizerFile):
  ORDON_DAY_1_FINISHED   Ordon Village layer: unset means the Day-1 morning layer (no chests)
  ORDON_DAY_2_OVER       Ordon Village / Spring / Ranch layers, Faron Woods layers
  FINISHED_SEWERS        Jaggle & Pergie's house (R_SP01 room 2) layer, with isDarkClearLV(0)
  CLEARED_*_TWILIGHT     twilight state of every province, and Hero's Clothes in setupRandomizerFile
  MIDNAS_DESPERATE_HOUR_COMPLETED  Castle Town / Hyrule Field layers

Run:  python3 -I output/tools/check_start_state.py
"""
import importlib.util
import sys
sys.dont_write_bytecode = True  # do not leave __pycache__ next to the tools
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "output"
DL = ROOT / "ref_official_rando_ap" / "generator" / "data"

spec = importlib.util.spec_from_file_location("gen_gc_tables", OUT / "tools" / "gen_gc_tables.py")
gen = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gen)

# Settings as the mod writes them: fixed, then defaults (what the apworld hard-codes).
settings = dict(gen.FIXED)
settings.update(gen.DEFAULTS)

# Dusklight defaults for anything the apworld does not mention matter only for conditions in
# startflags.yaml; those use these names:
default_off = ["Skip Minor Cutscenes", "Skip Major Cutscenes"]
for name in default_off:
    settings.setdefault(name, "Off")


DL_OPTIONS = gen.read_dl_settings()


def atom_true(atom):
    m = re.fullmatch(r"([A-Za-z_']+)\s*(==|!=|>=|<=|>|<)\s*(\w+)", atom.strip())
    if not m:
        sys.exit(f"cannot evaluate start-flag condition {atom!r}")
    name = m.group(1).replace("_", " ")
    value, canonical = None, name
    # settings_list names contain apostrophes, the condition syntax drops them
    for key in DL_OPTIONS:
        if key.replace("'", "").lower() == name.lower():
            canonical = key
    for key, val in settings.items():
        if key == canonical:
            value = val
    if value is None:
        # untouched by the apworld: the Dusklight default (the first-listed option is not the
        # default in general, so only toggles and the two ordered options used here are handled)
        value = "Vanilla" if canonical == "Ilia Memory Quest" else "Off"
    op, want = m.group(2), m.group(3)
    if op in ("==", "!="):
        return (value == want) == (op == "==")
    order = DL_OPTIONS.get(canonical, [])
    if value not in order or want not in order:
        sys.exit(f"cannot order {value!r} and {want!r} for {canonical!r}")
    a, b = order.index(value), order.index(want)
    return {">=": a >= b, "<=": a <= b, ">": a > b, "<": a < b}[op]


def cond_true(cond):
    # "a or b and c": and binds tighter than or
    return any(all(atom_true(a) for a in term.split(" and ")) for term in cond.split(" or "))


# --- parse startflags.yaml EventFlags section (flat list with conditional sub-lists)
flags = []
text = (DL / "startflags.yaml").read_text(encoding="utf-8")
section = text.split("EventFlags:")[1].split("RegionFlags:")[0]
current_cond = None
for raw in section.splitlines():
    line = raw.split("#", 1)[0].rstrip()
    if not line.strip():
        continue
    m = re.match(r"^  - (0x[0-9A-Fa-f]+)\s*$", line)
    if m:
        flags.append(int(m.group(1), 16))
        current_cond = None
        continue
    m = re.match(r"^  - (.+):\s*$", line)
    if m:
        current_cond = cond_true(m.group(1))
        continue
    m = re.match(r"^    - (0x[0-9A-Fa-f]+)\s*$", line)
    if m and current_cond is not None:
        if current_cond:
            flags.append(int(m.group(1), 16))
        continue

bytes_set = {}
for f in flags:
    bytes_set[f >> 8] = bytes_set.get(f >> 8, 0) | (f & 0xFF)


def is_set(flag):
    return (bytes_set.get(flag >> 8, 0) & (flag & 0xFF)) == (flag & 0xFF)


# --- constants from the engine-side header
consts = {}
for line in (OUT / "src" / "flags.h").read_text(encoding="utf-8").splitlines():
    m = re.match(r"^\s+([A-Z0-9_]+)\s*=\s*(0x[0-9A-Fa-f]+),?", line)
    if m:
        consts[m.group(1)] = int(m.group(2), 16)

required = ["ORDON_DAY_1_FINISHED", "ORDON_DAY_2_OVER", "FINISHED_SEWERS", "CLEARED_FARON_TWILIGHT",
            "CLEARED_ELDIN_TWILIGHT", "CLEARED_LANAYRU_TWILIGHT", "MIDNAS_DESPERATE_HOUR_COMPLETED"]
failed = 0
for name in required:
    if name not in consts:
        print(f"FAIL  {name}: not in flags.h")
        failed += 1
        continue
    ok = is_set(consts[name])
    print(f"{'ok  ' if ok else 'FAIL'}  {name} = 0x{consts[name]:04X}")
    failed += 0 if ok else 1

print(f"\n{len(flags)} start event flags under the apworld's settings")
sys.exit(1 if failed else 0)
