#!/usr/bin/env python3
"""Host test of the box-art image code (src/ap/cover_art.cpp): picking an icon from a SteamGridDB
/icons answer, and turning a square icon or a portrait cover into the textures the game draws.

    python3 -I tools/test_cover_art.py

Makes two small PNGs (stdlib only), builds tools/test_cover_art.cpp against cover_art.cpp with the host
JSON shim, and runs it. No game, no network.
"""
import os
import pathlib
import struct
import subprocess
import sys
import tempfile
import zlib

sys.dont_write_bytecode = True
OUT = pathlib.Path(__file__).resolve().parents[1]


def png(w, h, px):
    raw = b"".join(b"\x00" + b"".join(bytes(px(x, y)) for x in range(w)) for y in range(h))

    def chunk(t, d):
        c = struct.pack(">I", len(d)) + t + d
        return c + struct.pack(">I", zlib.crc32(t + d) & 0xFFFFFFFF)
    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0)) +
            chunk(b"IDAT", zlib.compress(raw)) + chunk(b"IEND", b""))


with tempfile.TemporaryDirectory() as tmp:
    d = pathlib.Path(tmp)
    (d / "icon.png").write_bytes(png(128, 128, lambda x, y: (200, 30, 30, 255) if (x - 64) ** 2 + (y - 64) ** 2 < 50 ** 2 else (0, 0, 0, 0)))
    (d / "cover.png").write_bytes(png(100, 150, lambda x, y: (30 + x, 60, 200, 255)))
    exe = d / "t"
    r = subprocess.run(["g++", "-std=c++23", "-O1", "-w", f"-I{OUT / 'tools/host_client/shims'}", f"-I{OUT / 'src/ap'}",
                        str(OUT / "tools/test_cover_art.cpp"), str(OUT / "src/ap/cover_art.cpp"), "-o", str(exe)],
                       capture_output=True, text=True)
    if r.returncode:
        sys.exit(r.stderr[-2000:])
    sys.exit(subprocess.run([str(exe), str(d)]).returncode)
