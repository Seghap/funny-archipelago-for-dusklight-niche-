#!/usr/bin/env python3
"""Checks the mod's adapter against what a live room really sent (tools/live_probe.py's capture).

Runs the real C++ adapter (tools/gc_adapter_cli.cpp over src/ap/gc_*.cpp) on the captured slot
data and placements, then verifies every result against the server's own data package and the
Dusklight generator data:

  * the apworld version is the one the mod supports
  * no setting errors; every warning is a documented ignored key
  * every location id the server lists is known to the mod, and the mod's name for it matches the
    server's data package (so the id table is right, not just self-consistent)
  * every item the server placed at the slot's locations is known, has a name matching the data
    package, can be given in game, and has a generator item to plando
  * the settings.yaml and plando.yaml the mod would write only name settings, options, locations
    and items that exist in Dusklight's own data
  * which locations the generator would keep vanilla (skipped plando) under these settings

    python3 -I output/tools/live_check.py
"""
import json
import re
import subprocess
import sys
from pathlib import Path

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parents[1]
ROOT = OUT.parent
LIVE = OUT / "tools" / "live"
DL = ROOT / "ref_official_rando_ap" / "generator" / "data"

cap = json.loads((LIVE / "capture.json").read_text())
slot = cap["connected"]["slot"]
slot_data = cap["connected"]["slot_data"]

# ---- build the adapter and feed it the capture
exe = LIVE / "gc_adapter_cli"
subprocess.run(["g++", "-std=c++23", "-Wall", "-Wextra", "-I", str(OUT / "src" / "ap"),
                str(OUT / "tools" / "gc_adapter_cli.cpp"), str(OUT / "src" / "ap" / "gc_settings.cpp"),
                str(OUT / "src" / "ap" / "gc_tables.cpp"), "-o", str(exe)], check=True)
lines = [f"WORLD\t{slot_data.get('World Version', '')}", f"SLOT\t{slot}"]
for k, v in slot_data["Settings"].items():
    lines.append(f"SETTING\t{k}\t{v}")
ids = sorted(set(cap["connected"]["checked_locations"]) | set(cap["connected"]["missing_locations"]))
for i in ids:
    lines.append(f"LOC\t{i}")
for s in cap["scouted"]:
    lines.append(f"PLACE\t{s['location']}\t{s['item']}\t{s['player']}")
(LIVE / "adapter_input.txt").write_text("\n".join(lines) + "\n")
res = subprocess.run([str(exe)], input="\n".join(lines) + "\n", capture_output=True, text=True, check=True)
exe.unlink()

rec = [l.split("\t") for l in res.stdout.splitlines()]
translated = [(r[1], r[2]) for r in rec if r[0] == "T"]
warnings = [r[1] for r in rec if r[0] == "W"]
errors = [r[1] for r in rec if r[0] == "E"]
loc_names = {int(r[1]): r[2] for r in rec if r[0] == "L"}
unknown = [r for r in rec if r[0] == "U"]
places = [r[1:] for r in rec if r[0] == "P"]
version = next(r for r in rec if r[0] == "V")

failures = []


def check(ok, what, detail=""):
    print(f"{'ok  ' if ok else 'FAIL'}  {what}{('  ' + detail) if detail else ''}")
    if not ok:
        failures.append(what)


# ---- 1 version
check(version[3] == "match", "apworld version supported", f"server {version[1]!r}, mod {version[2]!r}")

# ---- 2 settings
check(not errors, "slot settings translate without errors", "; ".join(errors))
ignored_ok = all("no Dusklight equivalent; ignored" in w for w in warnings)
check(ignored_ok, "every warning is a documented ignored key",
      f"{len(warnings)} ignored: " + ", ".join(re.findall(r"'([^']+)'", " ".join(warnings))))

dl_settings = {}
txt = (DL / "settings_list.yaml").read_text(encoding="utf-8")
for block in re.split(r"\n(?=- Name:)", txt):
    block = block.strip()
    if not block.startswith("- Name:"):
        continue
    name = block.split("\n")[0].split(":", 1)[1].strip()
    opts, in_o = [], False
    for ln in block.split("\n")[1:]:
        if re.match(r"^\s{2}Options:\s*$", ln):
            in_o = True
        elif in_o:
            m = re.match(r'^\s{4}- ("?)(.+?)\1:\s', ln)
            if m:
                opts.append(m.group(2))
            elif re.match(r"^\s{2}\S", ln):
                in_o = False
    dl_settings[name] = opts


def legal(name, val):
    for o in dl_settings.get(name, []):
        if o == val:
            return True
        m = re.fullmatch(r"(\d+)-(\d+)", o)
        if m and val.isdigit() and int(m.group(1)) <= int(val) <= int(m.group(2)):
            return True
    return False


bad = [(n, v) for n, v in translated if not legal(n, v)]
check(not bad, f"all {len(translated)} translated settings name a real Dusklight setting and a legal option", str(bad))

# ---- 3 locations vs the server's data package
dp_loc = {v: k for k, v in cap["tp_location_name_to_id"].items()}  # id -> apworld name
check(not [r for r in unknown if r[1] == "location"], f"all {len(ids)} server locations are known to the mod")
mismatch = [(i, loc_names[i], dp_loc.get(i)) for i in ids if i in loc_names and loc_names[i].lower() != dp_loc.get(i, "").lower()]
check(not mismatch, "the mod's name for every location id matches the server's data package", str(mismatch[:3]))
check(len(loc_names) == len(set(loc_names.values())), "no two location ids share a Dusklight name")

dl_locations = {}
cur = None
for ln in (DL / "locations.yaml").read_text(encoding="utf-8").splitlines():
    m = re.match(r"^- Name:\s*(.+?)\s*$", ln)
    if m:
        cur = m.group(1).strip("\"'")
        dl_locations[cur] = {"cats": [], "orig": None}
    elif cur:
        m = re.match(r"^  Original Item:\s*(.+?)\s*$", ln)
        if m:
            dl_locations[cur]["orig"] = m.group(1)
        m = re.match(r"^    - (.+?)\s*$", ln)
        if m and dl_locations[cur]["orig"] is not None and "Metadata" not in ln:
            dl_locations[cur]["cats"].append(m.group(1))
check(all(n in dl_locations for n in loc_names.values()), "every location exists in Dusklight's locations.yaml")

# ---- 4 items
dp_item = {v: k for k, v in cap["tp_item_name_to_id"].items()}
items_yaml = set()
for ln in (DL / "items.yaml").read_text(encoding="utf-8").splitlines():
    m = re.match(r"^- Name:\s*(.+?)\s*(#.*)?$", ln)
    if m:
        items_yaml.add(m.group(1).strip("\"'"))
check(not [r for r in unknown if r[1] == "item"], f"all {len(places)} placed items are known to the mod")
own = [p for p in places if p[4] == "1"]
check(len(own) == len(places), f"all {len(places)} placements are the slot's own items (single-slot room)")
item_name_bad = []
for s in cap["scouted"]:
    gc_name = next((p[1] for p in places if p[0] == loc_names.get(s["location"])), None)
    if dp_item.get(s["item"], "").lower() != (gc_name or "").lower():
        item_name_bad.append((s["item"], dp_item.get(s["item"]), gc_name))
check(not item_name_bad, "the mod's name for every placed item matches the server's data package", str(item_name_bad[:3]))
check(all(p[3] != "255" for p in places), "every placed item can be given in game")
check(all(p[2] in items_yaml for p in own), "every placed item has a generator item to plando",
      str(sorted({p[2] for p in own if p[2] not in items_yaml})))

# ---- 5 the files the mod would write
plando = {}
for s in cap["scouted"]:
    name = loc_names[s["location"]]
    plando[name] = next(p[2] for p in places if p[0] == name)
check(len(plando) == len(ids), f"plando covers every location once ({len(plando)})")
settings_yaml = dict(translated)
print(f"      settings.yaml would carry {len(settings_yaml)} settings, plando.yaml {len(plando)} locations")

# ---- 5b the compressed frames the server really sent, through the mod's own negotiation and inflater
dexe = LIVE / "deflate_cli"
subprocess.run(["g++", "-std=c++23", "-Wall", "-Wextra", "-I", str(OUT / "tools" / "shims"), "-I", str(OUT / "src" / "ap"),
                str(OUT / "tools" / "deflate_cli.cpp"), str(OUT / "src" / "ap" / "ws_deflate.cpp"), "-lz", "-o", str(dexe)],
               check=True)
dlines = ["EXT " + cap["extensions"]] + [f"MSG {1 if w['compressed'] else 0} {w['payload_hex']} {w['plain_size']} {w['plain_fnv1a64']}"
                                         for w in cap["wire"]]
dres = subprocess.run([str(dexe)], input="\n".join(dlines) + "\n", capture_output=True, text=True)
dexe.unlink()
drec = [l.split("\t") for l in dres.stdout.splitlines()]
check(drec and drec[0][1] == "ok", "the server's permessage-deflate answer is accepted", cap["extensions"])
check(all(r[2] == "ok" for r in drec if r[0] == "MSG") and dres.returncode == 0,
      f"all {sum(1 for r in drec if r[0] == 'MSG')} messages inflate byte-for-byte (persistent context)")

# ---- 6 report: placement summary and what the generator keeps vanilla
from collections import Counter
print()
print("what the server put at your locations (items by name):")
for name, n in Counter(p[1] for p in places).most_common(8):
    print(f"   {n:3d}  {name}")
print(f"   ... {len(set(p[1] for p in places))} distinct items")
approx = [p for p in places if p[1].endswith("(3)")]
print(f"items placed by approximation (plando name differs from the item given): {len(approx)}")

# vanilla-by-setting emulation of World::PlaceVanillaItems for the categories that the settings control
def cats(n):
    return dl_locations[n]["cats"]

s = settings_yaml
vanilla = []
for n in plando:
    orig = dl_locations[n]["orig"] or ""
    c = cats(n)
    keep = False
    if s.get("Small Keys") == "Vanilla" and re.search(r"Small Key$|Ordon Pumpkin|Ordon Cheese", orig):
        keep = True
    if s.get("Big Keys") == "Vanilla" and orig.endswith("Big Key") and orig != "Hyrule Castle Big Key":
        keep = True
    if s.get("Maps and Compasses") == "Vanilla" and re.search(r"Dungeon Map$|Compass$", orig):
        keep = True
    if s.get("Poe Souls") == "Vanilla" and orig == "Poe Soul":
        keep = True
    for setting, cat in (("Golden Bugs", "Golden Bug"), ("Sky Characters", "Sky Character"),
                         ("Gifts From NPCs", "Npc"), ("Shop Items", "Shop"), ("Hidden Skills", "Golden Wolf"),
                         ("Hidden Rupees", "Rupee - Hidden"), ("Freestanding Rupees", "Rupee - Freestanding")):
        if s.get(setting) == "Off" and cat in c:
            keep = True
    if keep:
        vanilla.append((n, orig, plando[n]))
print(f"\nlocations the generator would keep vanilla under these settings (plando skipped, patched at runtime): {len(vanilla)}")
differ = [v for v in vanilla if v[1] != v[2]]
print(f"   of those, where the server's item differs from the vanilla one (the runtime resolver matters there): {len(differ)}")
for n, orig, got in differ[:12]:
    print(f"   {n}: vanilla {orig!r}, server {got!r}")

print()
print("ALL CHECKS PASSED" if not failures else f"{len(failures)} CHECK(S) FAILED: {failures}")
sys.exit(1 if failures else 0)
