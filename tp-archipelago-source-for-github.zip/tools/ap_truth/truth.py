#!/usr/bin/env python3
"""Ground truth for the tracker's C++ port of the apworld's logic (src/ap/gc_logic.*).

    .toolchain/ap_venv/bin/python -I tools/ap_truth/truth.py [--cases N] [--only NAME]

For each option variant, generates the REAL apworld in Archipelago's real core (twice: Glitchless and
Glitched), asks the apworld's own Python rules which locations are reachable for N random item sets,
and writes .gametest/ap_truth/<variant>.txt:

  SETTING <key> <value>   what the world's slot_data["Settings"] says (tab separated)
  CASE / ITEM <name>... / PLAIN <location>... / GLITCHED <location>... / END

tools/host_gen/logic_test.cpp then checks the C++ evaluator gives exactly the same lists.
Reachable means what the tracker means: the received items, plus the event locations (bosses, quest
chain) once they are reachable; every other location's own item is NOT assumed.
"""
import json
import random
import sys
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import gen_world  # noqa: E402

OUT = HERE.parents[1] / ".gametest" / "ap_truth"

# Each variant overrides apworld options (the yaml names; the Python world reads them).
VARIANTS = {
    "default": {},
    "keys_anywhere": {"small_key_settings": "anywhere", "big_key_settings": "anywhere"},
    "closed": {"castle_requirements": "all_dungeons", "palace_requirements": "mirror_shards",
               "goron_mines_entrance": "closed", "tot_entrance": "closed", "faron_woods_logic": "closed"},
    "no_skips": {"skip_arbiters_grounds_entrance": False, "skip_lakebed_entrance": False,
                 "skip_city_in_the_sky_entrance": False, "skip_snowpeak_entrance": False,
                 "transform_anywhere": False, "increase_wallet": False},
    "hard": {"damage_magnification": "ohko", "bonks_do_damage": True, "shop_items_shuffled": False,
             "castle_requirements": "fused_shadows", "palace_requirements": "fused_shadows",
             "goron_mines_entrance": "no_wrestling", "tot_entrance": "open_grove"},
    "map_closed": {"open_map": False},
}


def yaml_for(over, glitched):
    lines = ["name: Link", "game: Twilight Princess", "Twilight Princess:"]
    over = dict(over)
    over["logic_rules"] = "glitched" if glitched else "glitchless"
    for k, v in over.items():
        if isinstance(v, bool):
            v = "true" if v else "false"
        lines.append(f"  {k}: {v}")
    return "\n".join(lines) + "\n"


def reach(mw, world, names):
    from BaseClasses import CollectionState
    state = CollectionState(mw)
    for n in names:
        state.collect(world.create_item(n), prevent_sweep=True)
    events = [l for l in mw.get_locations() if l.address is None and l.item is not None]
    done = set()
    while True:
        new = [l for l in events if l.name not in done and l.can_reach(state)]
        if not new:
            break
        for l in new:
            done.add(l.name)
            state.collect(l.item, prevent_sweep=True)
    return sorted(l.name for l in mw.get_locations() if l.can_reach(state))


def item_pool(world):
    from worlds.twilight_princess.Items import ITEM_TABLE
    pool = []
    for name, data in ITEM_TABLE.items():
        if data.code is not None:
            pool.append((name, max(1, data.quantity)))
    return pool


def main():
    n_cases = int(sys.argv[sys.argv.index("--cases") + 1]) if "--cases" in sys.argv else 60
    only = sys.argv[sys.argv.index("--only") + 1] if "--only" in sys.argv else None
    OUT.mkdir(parents=True, exist_ok=True)
    for vname, over in VARIANTS.items():
        if only and vname != only:
            continue
        worlds = {}
        for glitched in (False, True):
            try:
                mw = gen_world.generate(yaml_for(over, glitched), seed=7)
            except Exception as e:  # a combination the apworld itself refuses
                print(f"{vname}: generation failed ({glitched=}): {type(e).__name__}: {e}")
                break
            worlds[glitched] = mw
        if len(worlds) != 2:
            continue
        w0 = worlds[False].worlds[1]
        settings = [[k, str(v)] for k, v in w0.get_settings_map().items()]
        pool = item_pool(w0)
        rng = random.Random(f"truth-{vname}")
        cases = []
        for c in range(n_cases):
            p = rng.choice([0.03, 0.1, 0.25, 0.5, 0.8, 1.0])
            names = []
            for name, qty in pool:
                if rng.random() < p:
                    names += [name] * rng.randint(1, qty)
            row = {"items": names}
            for glitched, key in ((False, "glitchless"), (True, "glitched")):
                mw = worlds[glitched]
                row[key] = reach(mw, mw.worlds[1], names)
            cases.append(row)
        lines = [f"SETTING\t{k}\t{v}" for k, v in settings]
        for row in cases:
            lines.append("CASE")
            lines += [f"ITEM\t{n}" for n in row["items"]]
            lines += [f"PLAIN\t{n}" for n in row["glitchless"]]
            lines += [f"GLITCHED\t{n}" for n in row["glitched"]]
            lines.append("END")
        (OUT / f"{vname}.txt").write_text("\n".join(lines) + "\n")
        sizes = [(len(r["glitchless"]), len(r["glitched"])) for r in cases]
        print(f"{vname}: {len(cases)} cases, reachable glitchless {min(s[0] for s in sizes)}-{max(s[0] for s in sizes)}, "
              f"glitched {min(s[1] for s in sizes)}-{max(s[1] for s in sizes)}", flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
