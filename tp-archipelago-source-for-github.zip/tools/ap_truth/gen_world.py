#!/usr/bin/env python3
"""Generates a Twilight Princess world with the REAL Archipelago core and the REAL apworld
(ref_tp_apworld, copied into the core's worlds/ folder) and hands back the MultiWorld, so the
apworld's own Python rules can be asked what is reachable. Used as ground truth for the C++ port of the
logic (src/ap/gc_logic.*). Needs output/.toolchain/ap_core/Archipelago-0.6.7 (see docs/TESTING.md).

Python 3.14 is newer than core 0.6.7 officially supports (3.11-3.13); its version guard is stubbed
out here and nothing in the core is modified.
"""
import sys
import types
from pathlib import Path

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parents[2]
CORE = OUT / ".toolchain" / "ap_core" / "Archipelago-0.6.7"


def load_core():
    stub = types.ModuleType("ModuleUpdate")
    stub.update = lambda *a, **k: None
    stub.update_ran = True
    stub.requirements_files = set()
    sys.modules["ModuleUpdate"] = stub
    sys.path.insert(0, str(CORE))
    import os
    os.chdir(CORE)


def generate(yaml_text: str, seed: int = 1):
    """Returns the generated MultiWorld (one Twilight Princess player, slot 1)."""
    load_core()
    players = CORE / "Players"
    players.mkdir(exist_ok=True)
    for f in players.glob("*.yaml"):
        f.unlink()
    (players / "link.yaml").write_text(yaml_text)
    import Generate
    import Main
    sys.argv = ["Generate.py", "--skip_output", "--player_files_path", str(players), "--seed", str(seed),
                "--outputpath", str(OUT / ".gametest" / "ap_truth_out")]
    args, seed = Generate.main()
    return Main.main(args, seed)


if __name__ == "__main__":
    mw = generate("name: Link\ngame: Twilight Princess\nTwilight Princess: {}\n")
    print("generated:", len(mw.get_locations()), "locations,", len(mw.regions), "regions")
