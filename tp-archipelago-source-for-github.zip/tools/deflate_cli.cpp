// Runs the mod's real permessage-deflate code (src/ap/ws_deflate.cpp) on frames captured from a
// live server by tools/live_probe.py.
//
//   g++ -std=c++23 -I tools/shims -I src/ap tools/deflate_cli.cpp src/ap/ws_deflate.cpp -lz -o deflate_cli
//
// Input: EXT <Sec-WebSocket-Extensions response header>   then   MSG <rsv1> <hex payload> <size> <fnv1a64>
// Output: one line per record.

#include "ws_deflate.hpp"

#include <cstdint>
#include <cstdio>
#include <iostream>
#include <sstream>
#include <string>

static std::string unhex(const std::string& h) {
    std::string out;
    for (size_t i = 0; i + 1 < h.size(); i += 2) out += static_cast<char>(std::stoi(h.substr(i, 2), nullptr, 16));
    return out;
}

static std::string fnv(const std::string& d) {
    uint64_t h = 0xcbf29ce484222325ull;
    for (const unsigned char c : d) h = (h ^ c) * 0x100000001b3ull;
    char buf[32];
    std::snprintf(buf, sizeof(buf), "%016llx", static_cast<unsigned long long>(h));
    return buf;
}

int main() {
    ap::DeflateParams params;
    ap::Inflater inflater;
    std::string line;
    int n = 0, bad = 0;
    while (std::getline(std::cin, line)) {
        if (line.rfind("EXT ", 0) == 0) {
            std::string error;
            const bool ok = ap::parse_deflate_response(line.substr(4), params, error);
            std::printf("EXT\t%s\taccepted=%d serverNoContextTakeover=%d\t%s\n", ok ? "ok" : "REJECTED",
                params.accepted ? 1 : 0, params.serverNoContextTakeover ? 1 : 0, error.c_str());
            bad += ok ? 0 : 1;
        } else if (line.rfind("MSG ", 0) == 0) {
            std::istringstream in(line.substr(4));
            int rsv1;
            std::string hex, expectFnv;
            size_t expectSize;
            in >> rsv1 >> hex >> expectSize >> expectFnv;
            std::string data = unhex(hex), error;
            bool ok = true;
            if (rsv1) ok = inflater.inflate_message(data, 64ull * 1024 * 1024, params.serverNoContextTakeover, error);
            const bool match = ok && data.size() == expectSize && fnv(data) == expectFnv;
            std::printf("MSG\t%d\t%s\t%zu bytes\t%s\n", ++n, match ? "ok" : "FAIL", data.size(), error.c_str());
            bad += match ? 0 : 1;
        }
    }
    std::printf("DONE\t%d problem(s)\n", bad);
    return bad ? 1 : 0;
}
