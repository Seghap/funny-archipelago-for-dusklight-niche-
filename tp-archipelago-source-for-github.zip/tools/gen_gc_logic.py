#!/usr/bin/env python3
"""Turns the GameCube Twilight Princess apworld's logic (ref_tp_apworld) into C++ for the tracker.

    python3 -I tools/gen_gc_logic.py            # rewrites src/ap/gc_logic.inc
    python3 -I tools/gen_gc_logic.py --check    # exits 1 if the file on disk is out of date

Reads (with Python's `ast`, nothing is executed): Logic/Macros.py, Logic/Rules.py (location rules),
Logic/RegionRules.py (exit rules), Logic/RegionConnection.py + RegionCreation.py (the region graph),
Locations.py (location -> region, ids), options.py (option values and the names slot_data uses),
Randomizer/ItemPool.py (the event items), RoomFunctions.py, and writes C++:

  * one function per macro, one rule per location and exit, glitchless and (where the apworld has
    one) glitched, as the apworld spells them
  * the region graph, the location table and the event items
  * the option tables that turn slot_data["Settings"] strings into the values the rules compare

Anything it does not understand stops the script with the offending source line: the output must
cover the logic completely or not exist. The few macros that are not a single return expression
(loops, an early-exit chain) are written by hand in gc_logic.cpp; the list is HAND_WRITTEN below and
the script checks every other function really is a plain expression.
"""
import ast
import sys
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
OUT = HERE.parent
REF = OUT.parent / "ref_tp_apworld"
TARGET = OUT / "src" / "ap" / "gc_logic.inc"

# Macros written by hand in gc_logic.cpp (statements, loops over room lists, a dead assert).
HAND_WRITTEN = {
    "can_use", "can_change_time", "can_warp", "has_bug", "has_bugs", "has_bottles",
    "can_unlock_ordona_map", "can_unlock_faron_map", "can_unlock_eldin_map",
    "can_unlock_lanayru_map", "can_unlock_snowpeak_map", "can_unlock_gerudo_map",
    "can_complete_faron_twilight",
}

# The state accessors of Rules.py (TPLogic) the rules call, and the options.py attribute each reads.
ACCESSORS = {
    "_tp_glitched": "logic_rules", "_tp_shops_shuffled": "shop_items_shuffled",
    "_tp_small_key_settings": "small_key_settings", "_tp_big_key_settings": "big_key_settings",
    "_tp_skip_arbiters_entrance": "skip_arbiters_grounds_entrance",
    "_tp_skip_lakebed_entrance": "skip_lakebed_entrance",
    "_tp_skip_city_in_the_sky_entrance": "skip_city_in_the_sky_entrance",
    "_tp_skip_snowpeak_entrance": "skip_snowpeak_entrance", "_tp_tot_entrance": "tot_entrance",
    "_tp_palace_requirements": "palace_requirements", "_tp_castle_requirements": "castle_requirements",
    "_tp_goron_mines_enterance": "goron_mines_entrance", "_tp_faron_woods_logic": "faron_woods_logic",
    "_tp_open_map": "open_map", "_tp_increase_wallet": "increase_wallet",
    "_tp_bonks_do_damage": "bonks_do_damage", "_tp_damage_magnification": "damage_magnification",
    "_tp_transform_anywhere": "transform_anywhere",
}
# Accessors that are a comparison, not the raw value
DERIVED = {
    "_tp_is_small_key_anywhere": ("small_key_settings", "SmallKeySettings", "option_anywhere"),
    "_tp_is_big_key_anywhere": ("big_key_settings", "BigKeySettings", "option_anywhere"),
}


class Unsupported(Exception):
    pass


def parse(path):
    src = (REF / path).read_text(encoding="utf-8")
    return ast.parse(src), src


def fail(node, why):
    raise Unsupported(f"{why}: line {getattr(node, 'lineno', '?')}: {ast.unparse(node)[:160]}")


# ----------------------------------------------------------------------------------------- options
class Options:
    def __init__(self):
        tree, _ = parse("options.py")
        self.classes = {}      # class name -> (bases, {option_name: value}, default)
        self.has_default = set()
        self.attr_class = {}   # options attr -> class name
        for node in tree.body:
            if isinstance(node, ast.ClassDef):
                vals, default = {}, 0
                for st in node.body:
                    if isinstance(st, ast.Assign) and len(st.targets) == 1 and isinstance(st.targets[0], ast.Name):
                        name = st.targets[0].id
                        if name.startswith("option_") and isinstance(st.value, ast.Constant):
                            vals[name[len("option_"):]] = st.value.value
                        elif name == "default" and isinstance(st.value, ast.Constant):
                            default = st.value.value
                            self.has_default.add(node.name)
                bases = [ast.unparse(b) for b in node.bases]
                self.classes[node.name] = (bases, vals, default)
                if node.name == "TPOptions" or any("PerGameCommonOptions" in b for b in bases):
                    for st in node.body:
                        if isinstance(st, ast.AnnAssign) and isinstance(st.target, ast.Name):
                            self.attr_class[st.target.id] = ast.unparse(st.annotation)

    def resolve(self, cls):
        """(is_toggle, values, default) with the values and default inherited from options.py bases."""
        bases, vals, default = self.classes[cls]
        toggle = any(b.endswith("Toggle") for b in bases)
        merged, dflt = {}, None
        for b in bases:
            if b == "DefaultOnToggle":      # Archipelago core's own classes
                dflt = 1
            elif b in ("Toggle", "DefaultOffToggle"):
                dflt = 0
            if b in self.classes:
                t, v, d = self.resolve(b)
                toggle = toggle or t
                merged.update(v)
                dflt = d
        merged.update(vals)
        if "default" in self._own_default(cls):
            dflt = default
        return toggle, merged, int(dflt if dflt is not None else default)

    def _own_default(self, cls):
        return {"default"} if cls in self.has_default else set()

    def toggle(self, cls):
        return self.resolve(cls)[0]

    def value(self, cls, option):
        _, vals, _ = self.resolve(cls)
        if option not in vals and self.toggle(cls):
            vals = {"false": 0, "true": 1}
        if option not in vals:
            raise Unsupported(f"{cls}.option_{option} is not in options.py")
        return vals[option]

    def names(self, attr):
        """slot_data's spelling of each value, as Options.get_option_name makes it."""
        cls = self.attr_class[attr]
        toggle, vals, default = self.resolve(cls)
        if toggle:
            return default, {0: "No", 1: "Yes"}
        return default, {v: k.replace("_", " ").title() for k, v in vals.items()}


# --------------------------------------------------------------------------------------------- names
class Tables:
    def __init__(self):
        self.items, self.regions = {}, {}

    def item(self, name):
        return self.items.setdefault(name, len(self.items))

    def region(self, name):
        return self.regions.setdefault(name, len(self.regions))


class Translator:
    """Python rule expression -> C++ expression over `const State& s`."""

    def __init__(self, opts, tabs, macros, lists):
        self.opts, self.tabs, self.macros, self.lists = opts, tabs, macros, lists
        self.used = set()

    def const(self, node):
        if isinstance(node, ast.Constant):
            return node.value
        if isinstance(node, ast.Attribute) and isinstance(node.value, ast.Name) and node.attr.startswith("option_"):
            return self.opts.value(node.value.id, node.attr[len("option_"):])
        fail(node, "not a constant")

    def expr(self, n):
        if isinstance(n, ast.Constant):
            if isinstance(n.value, bool):
                return "true" if n.value else "false"
            if isinstance(n.value, int):
                return str(n.value)
            fail(n, "constant")
        if isinstance(n, ast.BoolOp):
            op = " && " if isinstance(n.op, ast.And) else " || "
            return "(" + op.join(self.expr(v) for v in n.values) + ")"
        if isinstance(n, ast.UnaryOp) and isinstance(n.op, ast.Not):
            return "!" + self.expr(n.operand)
        if isinstance(n, ast.Compare):
            if len(n.ops) != 1:
                fail(n, "chained comparison")
            ops = {ast.Eq: "==", ast.NotEq: "!=", ast.Gt: ">", ast.GtE: ">=", ast.Lt: "<", ast.LtE: "<="}
            if type(n.ops[0]) not in ops:
                fail(n, "comparison")
            return f"({self.expr(n.left)} {ops[type(n.ops[0])]} {self.expr(n.comparators[0])})"
        if isinstance(n, ast.Attribute):
            return str(self.const(n))
        if isinstance(n, ast.Call):
            return self.call(n)
        fail(n, "expression")

    def args_after_player(self, n, skip):
        a = n.args[skip:]
        if n.keywords:
            fail(n, "keyword arguments")
        return [self.expr(x) for x in a]

    def call(self, n):
        f = n.func
        if isinstance(f, ast.Attribute) and isinstance(f.value, ast.Name) and f.value.id == "state":
            if f.attr == "has":
                if not (isinstance(n.args[0], ast.Constant) and isinstance(n.args[0].value, str)):
                    fail(n, "state.has with a computed item")
                item = self.tabs.item(n.args[0].value)
                count = ", ".join(self.args_after_player(n, 2))
                return f"s.has({item}" + (f", {count})" if count else ")")
            if f.attr == "can_reach_region":
                if not (isinstance(n.args[0], ast.Constant) and isinstance(n.args[0].value, str)):
                    fail(n, "can_reach_region with a computed region")
                return f"s.reach({self.tabs.region(n.args[0].value)})"
            if f.attr in ACCESSORS:
                return f"s.opt({OPT_INDEX[ACCESSORS[f.attr]]})"
            if f.attr in DERIVED:
                attr, cls, option = DERIVED[f.attr]
                return f"(s.opt({OPT_INDEX[attr]}) == {self.opts.value(cls, option)})"
            fail(n, f"state method {f.attr}")
        if isinstance(f, ast.Name):
            if f.id not in self.macros and f.id not in HAND_WRITTEN:
                fail(n, f"call to unknown function {f.id}")
            if not (len(n.args) >= 2 and isinstance(n.args[0], ast.Name) and n.args[0].id == "state"):
                fail(n, "macro call without (state, player)")
            self.used.add(f.id)
            extra = self.args_after_player(n, 2)
            return f"m_{f.id}(s" + "".join(", " + e for e in extra) + ")"
        fail(n, "call")

    def rule(self, lam):
        if not isinstance(lam, ast.Lambda) or [a.arg for a in lam.args.args] != ["state"]:
            fail(lam, "rule is not `lambda state: ...`")
        return self.expr(lam.body)


OPT_INDEX = {}


def main():
    opts = Options()
    tabs = Tables()

    # Option table: only options some rule reads; settings key from get_settings_map
    attrs = sorted(set(ACCESSORS.values()) | {a for a, _, _ in DERIVED.values()})
    for i, a in enumerate(attrs):
        OPT_INDEX[a] = i
    init_tree, _ = parse("__init__.py")
    settings_key = {}
    for node in ast.walk(init_tree):
        if isinstance(node, ast.FunctionDef) and node.name == "get_settings_map":
            for d in ast.walk(node):
                if isinstance(d, ast.Dict):
                    for k, v in zip(d.keys, d.values):
                        if isinstance(v, ast.Call) and isinstance(v.func, ast.Attribute) and v.func.attr == "get_option_name":
                            attr = ast.unparse(v.func.value).split(".")[-1]
                            settings_key[attr] = k.value
    for a in attrs:
        if a not in settings_key:
            fail(init_tree, f"option {a} is read by rules but slot_data's Settings has no key for it")

    # macros: name -> FunctionDef; the lists they loop over come from RoomFunctions / Items
    mtree, _ = parse("Logic/Macros.py")
    macros = {}
    for node in mtree.body:
        if isinstance(node, ast.FunctionDef):
            macros[node.name] = node
    plain = {}
    for name, fn in macros.items():
        if name in HAND_WRITTEN:
            continue
        body = [s for s in fn.body if not (isinstance(s, ast.Expr) and isinstance(s.value, ast.Constant))]
        if len(body) != 1 or not isinstance(body[0], ast.Return):
            fail(fn, f"macro {name} is not a single return and is not in HAND_WRITTEN")
        plain[name] = fn

    tr = Translator(opts, tabs, set(plain), None)
    macro_src = {}
    macro_decls = {}

    def emit_macro(name):
        fn = plain[name]
        params = fn.args.args
        if [p.arg for p in params[:2]] != ["state", "player"]:
            fail(fn, "macro signature")
        extra = params[2:]
        defaults = [None] * (len(extra) - len(fn.args.defaults)) + list(fn.args.defaults)
        sig = "".join(
            f", int {p.arg}" + (f" = {tr.const(d)}" if d is not None else "") for p, d in zip(extra, defaults))
        macro_decls[name] = f"static bool m_{name}(const State& s{sig});"
        expr_src = tr_expr_with_params(tr, fn.body[-1].value, {p.arg for p in extra})
        sig_def = "".join(f", int {p.arg}" for p in extra)
        macro_src[name] = f"static bool m_{name}(const State& s{sig_def}) {{ return {expr_src}; }}"

    # hand-written macros' signatures (declared here so rules can call them)
    hand_sigs = {"can_use": None, "has_bugs": ", int count"}
    hand_decls = [f"static bool m_{n}(const State& s{hand_sigs.get(n) or ''});" for n in sorted(HAND_WRITTEN)
                  if n != "can_use"]

    # region graph
    ctree, _ = parse("Logic/RegionCreation.py")
    region_names = []
    for node in ast.walk(ctree):
        if (isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "Region"
                and node.args and isinstance(node.args[0], ast.Constant)):
            region_names.append(node.args[0].value)
    for r in region_names:
        tabs.region(r)

    # connections and their rules
    etree, _ = parse("Logic/RegionConnection.py")
    connections = []  # (name, from, to)
    for node in ast.walk(etree):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr == "connect":
            parent = node.func.value
            if not (isinstance(parent, ast.Call) and parent.args and isinstance(parent.args[0], ast.Constant)):
                fail(node, "connect() parent")
            tgt = node.args[0]
            if not (isinstance(tgt, ast.Call) and tgt.args and isinstance(tgt.args[0], ast.Constant)):
                fail(node, "connect() target")
            name = node.args[1].value if len(node.args) > 1 else None
            connections.append((name, parent.args[0].value, tgt.args[0].value))
    conn_by_name = {}
    for name, a, b in connections:
        if name is None:
            fail(etree, "connection without an explicit name")
        conn_by_name[name] = (a, b)

    def collect_rules(path, fname, helper):
        tree, _ = parse(path)
        found = {}
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef) and node.name == fname:
                for st in node.body:
                    if isinstance(st, ast.Expr) and isinstance(st.value, ast.Call) and isinstance(st.value.func, ast.Name) \
                            and st.value.func.id == helper:
                        c = st.value
                        if c.keywords or not (2 <= len(c.args) <= 3):
                            fail(c, "rule call shape")
                        found[ast.unparse(c.args[0])] = (c.args[0], c.args[1], c.args[2] if len(c.args) == 3 else None)
                    elif isinstance(st, (ast.FunctionDef, ast.Assert, ast.Assign)):
                        pass
                    else:
                        fail(st, "statement in the rule setup the generator does not know")
        return found

    exit_rules = collect_rules("Logic/RegionRules.py", "set_region_access_rules", "set_rule_if_exits")
    loc_rules = collect_rules("Logic/Rules.py", "set_location_access_rules", "set_rule_if_exists")

    exits = []
    for key, (target, std, gl) in exit_rules.items():
        if not (isinstance(target, ast.Call) and target.func.attr == "get_entrance"):
            fail(target, "exit rule target")
        name = target.args[0].value
        if name not in conn_by_name:
            fail(target, f"exit {name} has a rule but no connection")
        a, b = conn_by_name[name]
        exits.append((name, tabs.region(a), tabs.region(b), tr.rule(std), tr.rule(gl) if gl else None))
    ruled = {e[0] for e in exits}
    for name, (a, b) in conn_by_name.items():
        if name not in ruled:
            exits.append((name, tabs.region(a), tabs.region(b), "true", None))

    # locations
    ltree, _ = parse("Locations.py")
    codes, loc_region = {}, {}
    for node in ltree.body:
        t = node.targets[0] if isinstance(node, ast.Assign) else node.target if isinstance(node, ast.AnnAssign) else None
        if isinstance(t, ast.Name) and t.id == "LOCATION_TABLE":
            for k, v in zip(node.value.keys, node.value.values):
                code = None
                for kw in v.keywords:
                    if kw.arg == "code":
                        code = ast.literal_eval(kw.value)
                codes[k.value] = code
        if isinstance(t, ast.Name) and t.id == "LOCATION_TO_REGION":
            for k, v in zip(node.value.keys, node.value.values):
                loc_region[k.value] = v.value
    locs = []
    for name in codes:
        if name not in loc_region:
            fail(ltree, f"location {name} has no region")
        std, gl = "true", None
        key = f'world.get_location("{name}")'
        for k, (target, s_, g_) in loc_rules.items():
            pass
        locs.append(name)
    rules_by_name = {}
    for key, (target, std, gl) in loc_rules.items():
        if not isinstance(target, ast.Constant):
            fail(target, "location rule target")
        rules_by_name[target.value] = (tr.rule(std), tr.rule(gl) if gl else None)
    for name in rules_by_name:
        if name not in codes:
            fail(ltree, f"rule for unknown location {name}")

    # macros: only those the rules (transitively) call; a macro nothing calls may use things the
    # apworld itself never defined (can_complete_eldin_twilight_glitched reads a commented-out accessor)
    done = set()
    while tr.used - done:
        name = sorted(tr.used - done)[0]
        done.add(name)
        if name in plain:
            emit_macro(name)
    skipped = sorted(set(plain) - done)

    # event items: place_deterministic_items
    itree, _ = parse("Randomizer/ItemPool.py")
    boss_names = {}
    for node in ast.walk(itree):
        if isinstance(node, ast.FunctionDef) and node.name == "get_boss_defeat_items":
            for d in ast.walk(node):
                if isinstance(d, ast.Dict):
                    for k, v in zip(d.keys, d.values):
                        if isinstance(v, ast.Call) and isinstance(v.func, ast.Name) and v.func.id == "TPItem":
                            boss_names[k.value] = v.args[0].value
    events = []
    for node in ast.walk(itree):
        if isinstance(node, ast.FunctionDef) and node.name == "place_deterministic_items":
            for c in ast.walk(node):
                if isinstance(c, ast.Call) and isinstance(c.func, ast.Attribute) and c.func.attr == "place_locked_item":
                    loc = c.func.value
                    while isinstance(loc, ast.Call) and not (isinstance(loc.func, ast.Attribute) and loc.func.attr == "get_location"):
                        fail(loc, "event location")
                    lname = loc.args[0].value
                    it = c.args[0]
                    if isinstance(it, ast.Subscript):          # world.boss_defeat_items["Diababa"]
                        iname = boss_names[it.slice.value]
                    elif isinstance(it, ast.Call) and isinstance(it.func, ast.Name) and it.func.id in ("TPItem", "item_factory"):
                        iname = it.args[0].value
                    else:
                        fail(it, "event item")
                    events.append((lname, iname))
    for lname, _ in events:
        if lname not in codes:
            fail(itree, f"event location {lname} is not a location")

    # room lists and bug list used by the hand-written macros
    rtree, _ = parse("RoomFunctions.py")
    rooms = {}
    for node in ast.walk(rtree):
        if isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name) and isinstance(node.value, ast.List):
            rooms[node.targets[0].id] = [e.value for e in node.value.elts]
    for need in ("time_flow_rooms", "warp_rooms", "OrdonaMapRooms", "FaronMapRooms", "EldinMapRooms",
                 "LanayruMapRooms", "SnowpeakMapRooms", "GerudoMapRooms"):
        if need not in rooms:
            fail(rtree, f"RoomFunctions.{need} not found")
        for r in rooms[need]:
            tabs.region(r)
    itm_tree, _ = parse("Items.py")
    bugs = None
    for node in ast.walk(itm_tree):
        if isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name) and node.targets[0].id == "GoldenBugs":
            bugs = [e.value for e in node.value.elts]
    if not bugs:
        fail(itm_tree, "GoldenBugs not found")

    # open_map portal connections and the start region, from TPWorld.create_regions
    portals = None
    for node in ast.walk(init_tree):
        if isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name) and node.targets[0].id == "portal_regions":
            portals = [e.value for e in node.value.elts if isinstance(e, ast.Constant)]
    if not portals:
        fail(init_tree, "portal_regions not found")

    # ------------------------------------------------------------------------------------ output
    # fully intern everything first (rules above already interned items/regions they use)
    for _, iname in events:
        tabs.item(iname)
    for b in bugs:
        tabs.item(b)
    for r in portals + ["Menu", "Outside Links House"]:
        tabs.region(r)
    for n_, i_ in (("Shadow Crystal", None),):
        tabs.item(n_)

    def q(s):
        return '"' + s.replace("\\", "\\\\").replace('"', '\\"') + '"'

    lines = ["// Generated by tools/gen_gc_logic.py from ref_tp_apworld (the GameCube apworld's logic). Do not edit.",
             "// Included by gc_logic.cpp inside namespace ap::gc_logic, after State and the hand-written macros' declarations.", ""]
    lines.append("static const char* const kItemNames[] = {" + ", ".join(q(n) for n in tabs.items) + "};")
    lines.append("static const char* const kRegionNames[] = {" + ", ".join(q(n) for n in tabs.regions) + "};")
    lines.append("")
    lines.append("// slot_data[\"Settings\"] key, default value, value names (value order), for each option a rule reads")
    lines.append("static const OptionDef kOptions[] = {")
    for a in attrs:
        default, names = opts.names(a)
        pairs = ", ".join(f"{{{q(n)}, {v}}}" for v, n in sorted(names.items()))
        lines.append(f"    {{{q(a)}, {q(settings_key[a])}, {default}, {{{pairs}}}}},")
    lines.append("};")
    lines.append(f"static const int kLogicRules = {OPT_INDEX['logic_rules']}, kOpenMap = {OPT_INDEX['open_map']}, "
                 f"kSkipSnowpeak = {OPT_INDEX['skip_snowpeak_entrance']};")
    lines.append("")
    for d in hand_decls:
        lines.append(d)
    for d in macro_decls.values():
        lines.append(d)
    lines.append("")
    for m in macro_src.values():
        lines.append(m)
    lines.append("")
    lines.append("static const Exit kExits[] = {")
    for name, a, b, std, gl in exits:
        lines.append(f"    {{{q(name)}, {a}, {b}, [](const State& s) {{ return {std}; }}, "
                     + (f"[](const State& s) {{ return {gl}; }}" if gl else "nullptr") + "},")
    lines.append("};")
    lines.append("")
    lines.append("static const Location kLocations[] = {")
    for name in codes:
        std, gl = rules_by_name.get(name, ("true", None))
        code = codes[name] if codes[name] is not None else -1
        lines.append(f"    {{{q(name)}, {code}, {tabs.region(loc_region[name])}, [](const State& s) {{ return {std}; }}, "
                     + (f"[](const State& s) {{ return {gl}; }}" if gl else "nullptr") + "},")
    lines.append("};")
    lines.append("")
    lines.append("// location name, item it holds for logic once the location is reached (events)")
    lines.append("static const Event kEvents[] = {" + ", ".join(f"{{{q(l)}, {tabs.item(i)}}}" for l, i in events) + "};")
    for key, lst in (("kTimeFlowRooms", rooms["time_flow_rooms"]), ("kWarpRooms", rooms["warp_rooms"]),
                     ("kOrdonaMapRooms", rooms["OrdonaMapRooms"]), ("kFaronMapRooms", rooms["FaronMapRooms"]),
                     ("kEldinMapRooms", rooms["EldinMapRooms"]), ("kLanayruMapRooms", rooms["LanayruMapRooms"]),
                     ("kSnowpeakMapRooms", rooms["SnowpeakMapRooms"]), ("kGerudoMapRooms", rooms["GerudoMapRooms"])):
        lines.append(f"static const int {key}[] = {{" + ", ".join(str(tabs.region(r)) for r in lst) + "};")
    lines.append("static const int kGoldenBugs[] = {" + ", ".join(str(tabs.item(b)) for b in bugs) + "};")
    lines.append("static const int kPortalRegions[] = {" + ", ".join(str(tabs.region(r)) for r in portals) + "};")
    lines.append(f"static const int kMenuRegion = {tabs.region('Menu')}, kStartRegion = {tabs.region('Outside Links House')};")
    lines.append(f"static const int kShadowCrystal = {tabs.item('Shadow Crystal')};")
    phantom = [r for r in tabs.regions if r not in set(region_names)]
    if phantom:
        print("regions named by rules or room lists but never created by RegionCreation:", phantom)
    text = "\n".join(lines) + "\n"
    print(f"{len(tabs.items)} items, {len(tabs.regions)} regions, {len(exits)} exits, {len(codes)} locations "
          f"({sum(1 for e in exits if e[4])} glitched exit rules, "
          f"{sum(1 for v in rules_by_name.values() if v[1])} glitched location rules), {len(plain)} macros, "
          f"{len(events)} events; {len(skipped)} macros nothing calls left out)")
    if "--check" in sys.argv:
        return 0 if TARGET.exists() and TARGET.read_text() == text else 1
    TARGET.write_text(text)
    return 0


def tr_expr_with_params(tr, node, params):
    """Macro bodies mention their extra parameters (count, ...) by name."""
    orig = tr.expr

    def expr(n):
        if isinstance(n, ast.Name) and n.id in params:
            return n.id
        return orig(n)

    tr.expr = expr
    try:
        return expr(node)
    finally:
        tr.expr = orig


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Unsupported as e:
        print("UNSUPPORTED:", e)
        sys.exit(2)
