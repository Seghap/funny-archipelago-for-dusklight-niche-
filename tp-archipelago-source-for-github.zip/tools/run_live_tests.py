#!/usr/bin/env python3
"""Runs every test that can be run against a live room, in order, and prints one summary.

    python3 -I output/tools/run_live_tests.py HOST PORT "SLOT NAME" [PASSWORD]

  1. live_probe        read-only handshake: slot data, data package, LocationScouts for every location
  2. live_check        the mod's C++ adapter on that data, checked against the server's own data package
                       and Dusklight's data; the server's compressed frames through the mod's inflater
  3. check_detection   every location the server owns can be noticed in game (check names / save flags)
  4. host_gen/run      the REAL randomizer generator, in Archipelago mode, on the room's real placements
  5. host_gen/fuzz     the same generator on many realistic variants (options, other worlds' items)
  6. host_client/run   the mod's REAL network client against the live server (connect, scout, reconnect,
                       refusal, unreachable)

Nothing here sends a location check, a status update or chat. Needs g++, OpenSSL and zlib development
files and PyYAML. See docs/TESTING.md for what each step does and does not prove.
"""
import subprocess
import sys
import time
from pathlib import Path

sys.dont_write_bytecode = True
T = Path(__file__).resolve().parent
if len(sys.argv) < 4:
    sys.exit(__doc__)
host, port, slot = sys.argv[1:4]
password = sys.argv[4:5]

steps = [
    ("live_probe", [str(T / "live_probe.py"), host, port, slot, *password]),
    ("live_check", [str(T / "live_check.py")]),
    ("check_detection", [str(T / "check_detection.py")]),
    ("host_gen/run", [str(T / "host_gen" / "run.py")]),
    ("host_gen/fuzz", [str(T / "host_gen" / "fuzz.py"), "60", "1"]),
    ("host_client/run", [str(T / "host_client" / "run.py"), host, port, slot]),
]
results = []
for name, args in steps:
    t = time.time()
    print(f"\n{'=' * 78}\n{name}\n{'=' * 78}", flush=True)
    r = subprocess.run([sys.executable, "-I", *args])
    results.append((name, r.returncode == 0, time.time() - t))

print(f"\n{'=' * 78}\nSUMMARY\n{'=' * 78}")
for name, ok, secs in results:
    print(f"  {'PASS' if ok else 'FAIL'}  {name:18} {secs:6.1f}s")
sys.exit(0 if all(ok for _, ok, _ in results) else 1)
