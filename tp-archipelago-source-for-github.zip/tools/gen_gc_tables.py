#!/usr/bin/env python3
"""Generates the GameCube-apworld adapter tables for the Dusklight Archipelago mod.

Reads (read-only):
  ref_tp_apworld/Locations.py, Items.py, ClientUtils.py     the server's world ("Twilight Princess")
  ref_official_rando_ap/generator/data/locations.yaml       Dusklight's location names
                                         items.yaml         Dusklight's item names / ids
                                         settings_list.yaml Dusklight's setting names / options
Writes:
  output/src/ap/gc_data.inc        C++ tables included by gc_tables.cpp
  output/docs/GC_MAPPING_REPORT.md human-readable review of every mapping decision

Run with:  python3 -I output/tools/gen_gc_tables.py
The script fails loudly (exit 1) if any mapping it emits would not resolve against the Dusklight
data, so a bad table can never reach the C++ build.
"""
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
REF_GC = ROOT / "ref_tp_apworld"
REF_DL = ROOT / "ref_official_rando_ap" / "generator" / "data"
OUT_INC = ROOT / "output" / "src" / "ap" / "gc_data.inc"
OUT_REPORT = ROOT / "output" / "docs" / "GC_MAPPING_REPORT.md"

ID_BASE = 2320000  # TPLocation.get_apid / TPItem.get_apid


def die(msg):
    print("gen_gc_tables: ERROR: " + msg, file=sys.stderr)
    sys.exit(1)


# ----------------------------------------------------------------------------------------------
# Dusklight data

def read_dl_locations():
    names = []
    for line in (REF_DL / "locations.yaml").read_text(encoding="utf-8").splitlines():
        m = re.match(r"^- Name:\s*(.+?)\s*$", line)
        if m:
            names.append(m.group(1).strip("\"'"))
    return names


def read_dl_items():
    """name -> id (or None when the entry has no Id)."""
    text = (REF_DL / "items.yaml").read_text(encoding="utf-8")
    items = {}
    for block in re.split(r"\n(?=- Name:)", text):
        block = block.strip()
        if not block.startswith("- Name:"):
            continue
        first = block.split("\n")[0]
        name = first.split(":", 1)[1].split("#", 1)[0].strip().strip("\"'")
        m = re.search(r"^\s*Id:\s*(\S+)", block, re.M)
        items[name] = int(m.group(1), 0) if m else None
    return items


def read_dl_settings():
    """setting name -> list of legal option labels (numeric ranges kept as 'a-b')."""
    text = (REF_DL / "settings_list.yaml").read_text(encoding="utf-8")
    settings = {}
    for block in re.split(r"\n(?=- Name:)", text):
        block = block.strip()
        if not block.startswith("- Name:"):
            continue
        name = block.split("\n")[0].split(":", 1)[1].strip()
        opts = []
        in_opts = False
        for line in block.split("\n")[1:]:
            if re.match(r"^\s{2}Options:\s*$", line):
                in_opts = True
                continue
            if in_opts:
                m = re.match(r'^\s{4}- ("?)(.+?)\1:\s', line)
                if m:
                    opts.append(m.group(2))
                elif re.match(r"^\s{2}\S", line):
                    in_opts = False
        settings[name] = opts
    return settings


# ----------------------------------------------------------------------------------------------
# GameCube apworld data

def read_gc_locations():
    src = (REF_GC / "Locations.py").read_text(encoding="utf-8")
    body = re.search(r"^LOCATION_TABLE\s*=\s*\{(.*?)^\}\s*$", src, re.S | re.M)
    if not body:
        die("LOCATION_TABLE not found in Locations.py")
    out = []
    for m in re.finditer(r'^    "([^"]+)": TPLocationData\(\s*code=(\w+)', body.group(1), re.M):
        name, code = m.group(1), m.group(2)
        out.append((name, None if code == "None" else int(code)))
    return out


def read_gc_items():
    src = (REF_GC / "Items.py").read_text(encoding="utf-8")
    body = re.search(r"ITEM_TABLE:\s*dict\[str, TPItemData\]\s*=\s*\{(.*?)^\}\s*$", src, re.S | re.M)
    if not body:
        die("ITEM_TABLE not found in Items.py")
    out = []
    for m in re.finditer(
            r'^\s*"([^"]+)":\s*TPItemData\(\s*"([^"]+)",\s*([^,]+),\s*(\w+),\s*(\w+),\s*(\w+)\s*\)',
            body.group(1), re.M):
        name, typ, cls, code, qty, iid = m.groups()
        out.append(dict(name=name, type=typ, cls=cls.strip(),
                        code=None if code == "None" else int(code),
                        game_id=None if iid == "None" else int(iid, 0)))
    return out


def read_gc_version():
    m = re.search(r'VERSION\s*=\s*"([^"]+)"', (REF_GC / "ClientUtils.py").read_text(encoding="utf-8"))
    if not m:
        die("VERSION not found in ClientUtils.py")
    return m.group(1)


# ----------------------------------------------------------------------------------------------
# Item name mapping: GameCube apworld item -> Dusklight item name.
# Names that differ between the two projects. Everything else resolves by exact (case-insensitive)
# name, then by punctuation-insensitive name, then by game id; ambiguity or a miss is an error.

ITEM_ALIASES = {
    # The GC world's sword progression is named after its last stage; Dusklight's first item is
    # the progressive sword (verifyProgressiveItem picks the next sword when it is given).
    "Progressive Master Sword": "Progressive Sword",
    "Progressive Hero's Bow": "Progressive Bow",
    "Links Purple Rupee": "Purple Rupee Links House",
    "Empty Bottle (Fishing Hole)": "Empty Bottle",
    "Milk (half) (Sera Bottle)": "Bottle with Half Milk",
    "Lantern Oil (Coro Bottle)": "Bottle with Lantern Oil",
    "Great Fairy Tears (Jovani)": "Bottle with Great Fairies Tears",
    "Gerudo Desert Bublin Camp Key": "Gerudo Desert Bulblin Camp Key",
    "Auru's Memo": "Aurus Memo",
    "Ashei's Sketch": "Asheis Sketch",
    "Bedroom Key": "Snowpeak Ruins Bedroom Key",
    "Ordon Goat Cheese": "Ordon Cheese",
    "Ice Trap": "Foolish Item",
    "Progressive Hidden Skill": "Progressive Hidden Skill",
    # ammo naming: "Bombs (5)" -> "Bombs 5" is handled by the punctuation rule below
}

# Items with no in-game counterpart (events the server uses for logic).
EVENT_ITEMS = {"Victory"}

# Real game items the Dusklight generator cannot place (their items.yaml entries are commented
# out). The seed is built with the nearest generator item; the exact game byte is what gets
# resolved at the pickup and what a received copy gives, so the player always gets the real item.
APPROXIMATE = {
    "Water Bombs (3)": "Water Bombs 5",
    "Bomblings (3)": "Bomblings 5",
}


def norm(s):
    return re.sub(r"[^a-z0-9]+", " ", s.lower()).strip()


def map_items(gc_items, dl_items):
    by_lower = {n.lower(): n for n in dl_items}
    by_norm = {}
    for n in dl_items:
        by_norm.setdefault(norm(n), []).append(n)
    by_id = {}
    for n, i in dl_items.items():
        if i is not None:
            by_id.setdefault(i, []).append(n)

    rows = []
    for it in gc_items:
        name = it["name"]
        how = None
        dl_name = None
        if name in EVENT_ITEMS:
            rows.append(dict(it, dl_name=None, dl_id=None, how="event (no game item)"))
            continue
        if name in APPROXIMATE:
            dl_name, how = APPROXIMATE[name], "approximate (generator has no such item; exact game id 0x%02X is given)" % it["game_id"]
            rows.append(dict(it, dl_name=dl_name, dl_id=it["game_id"], how=how))
            continue
        if name in ITEM_ALIASES and ITEM_ALIASES[name] in dl_items:
            dl_name, how = ITEM_ALIASES[name], "alias"
        elif name.lower() in by_lower:
            dl_name, how = by_lower[name.lower()], "name"
        elif len(by_norm.get(norm(name), [])) == 1:
            dl_name, how = by_norm[norm(name)][0], "name (punctuation-insensitive)"
        else:
            cand = by_id.get(it["game_id"], [])
            if len(cand) == 1:
                dl_name, how = cand[0], "game id"
        if dl_name is None:
            die(f"no Dusklight item for GC item {name!r} (game id {it['game_id']})")
        dl_id = dl_items[dl_name]
        if dl_id is None:
            die(f"Dusklight item {dl_name!r} has no Id (needed for GC item {name!r})")
        rows.append(dict(it, dl_name=dl_name, dl_id=dl_id, how=how))
    return rows


# ----------------------------------------------------------------------------------------------
# Settings mapping. One entry per slot_data["Settings"] key (see TPClient/__init__.get_settings_map).
# Value spellings are what AP's Toggle/Choice.get_option_name produce ("Yes"/"No", Title Case);
# matching at runtime is case- and punctuation-insensitive, and Toggle rows also accept
# true/false/on/off/1/0.

TOGGLE = [("yes", "On"), ("true", "On"), ("on", "On"), ("1", "On"),
          ("no", "Off"), ("false", "Off"), ("off", "Off"), ("0", "Off")]


def toggle(gc_key, dl_name):
    return [(gc_key, f, dl_name, t) for f, t in TOGGLE]


def passthrough(gc_key, dl_name, mapping=None):
    rows = []
    for f, t in (mapping or {}).items():
        rows.append((gc_key, f, dl_name, t))
    rows.append((gc_key, "*", dl_name, "*"))
    return rows


SETTING_ROWS = []
SETTING_ROWS += toggle("Golden Bugs Shuffled", "Golden Bugs")
SETTING_ROWS += toggle("Sky Chracters Shuffled", "Sky Characters")  # sic: the apworld's key
SETTING_ROWS += toggle("NPC Items Shuffled", "Gifts From NPCs")
SETTING_ROWS += toggle("Shop Items Shuffled", "Shop Items")
SETTING_ROWS += toggle("Hidden Skills Shuffled", "Hidden Skills")
SETTING_ROWS += [("Poes Shuffled", f, "Poe Souls", "All") for f in ("yes", "true", "on", "1")]
SETTING_ROWS += [("Poes Shuffled", f, "Poe Souls", "Vanilla") for f in ("no", "false", "off", "0")]
SETTING_ROWS += passthrough("Small Key Settings", "Small Keys", {"Startwith": "Keysy"})
SETTING_ROWS += passthrough("Big Key Settings", "Big Keys", {"Startwith": "Keysy"})
SETTING_ROWS += passthrough("Map and Compass Settings", "Maps and Compasses", {"Startwith": "Start With"})
SETTING_ROWS += toggle("Dungeon Rewards Progression", "Dungeon Rewards Can Be Anywhere")
SETTING_ROWS += [("Dungeon Rewards Progression", f, "Dungeon Rewards Can Be Anywhere", "On")
                 for f in ("anything", "any progressive")]
SETTING_ROWS += [("Dungeon Rewards Progression", "vanilla", "Dungeon Rewards Can Be Anywhere", "Off")]
SETTING_ROWS += passthrough("Palace of Twilight Requirements", "Palace of Twilight Requirements")
SETTING_ROWS += passthrough("Faron Woods Logic", "Faron Woods Logic")
SETTING_ROWS += toggle("Skip Prologue", "Skip Prologue")
SETTING_ROWS += toggle("Faron Twilight Cleared", "Faron Twilight Cleared")
SETTING_ROWS += toggle("Eldin Twilight Cleared", "Eldin Twilight Cleared")
SETTING_ROWS += toggle("Lanayru Twilight Cleared", "Lanayru Twilight Cleared")
SETTING_ROWS += toggle("Skip MDH", "Skip Midna's Desperate Hour")
SETTING_ROWS += toggle("Skip Minor Cutscenes", "Skip Minor Cutscenes")
SETTING_ROWS += toggle("Skip Major Cutscenes", "Skip Major Cutscenes")
SETTING_ROWS += toggle("Open Map", "Unlock Map Regions")
SETTING_ROWS += toggle("Open Door of Time", "Open Door of Time")
SETTING_ROWS += toggle("Increase Wallet", "Logic Increase Wallet Capacity")
SETTING_ROWS += toggle("Transform Anywhere", "Logic Transform Anywhere")
SETTING_ROWS += toggle("Bonks do Damage", "Bonks Do Damage")
SETTING_ROWS += passthrough("Trap Frequency", "Trap Item Frequency", {"No Traps": "None"})
SETTING_ROWS += passthrough("Damage Magnification", "Logic Damage Multiplier", {"Ohko": "OHKO"})
SETTING_ROWS += passthrough("Starting ToD", "Starting Time of Day")
SETTING_ROWS += toggle("Lakebed Entrance Requirements", "Lakebed Does Not Require Water Bombs")
SETTING_ROWS += toggle("Arbiters Grounds Entrance Requirements", "Arbiters Does Not Require Bulblin Camp")
SETTING_ROWS += toggle("Snowpeak Entrance Requirements", "Snowpeak Does Not Require Reekfish Scent")
SETTING_ROWS += toggle("City in the Sky Entrance Requirements", "City Does Not Require Filled Skybook")
SETTING_ROWS += passthrough("Goron Mines Entrance Requirements", "Goron Mines Entrance")
# "Castle Requirements": the apworld always assumes the maximum count of whatever it asks for.
for v, rows in {
    "Open": [("Hyrule Barrier Requirements", "Open")],
    "Vanilla": [("Hyrule Barrier Requirements", "Vanilla")],
    "Fused Shadows": [("Hyrule Barrier Requirements", "Fused Shadows"), ("Hyrule Barrier Fused Shadows", "3")],
    "Mirror Shards": [("Hyrule Barrier Requirements", "Mirror Shards"), ("Hyrule Barrier Mirror Shards", "4")],
    "All Dungeons": [("Hyrule Barrier Requirements", "Dungeons"), ("Hyrule Barrier Dungeons", "8")],
}.items():
    for dl_name, dl_val in rows:
        SETTING_ROWS.append(("Castle Requirements", v, dl_name, dl_val))
# "Temple of Time Entrance Requirements" drives two Dusklight settings.
for v, rows in {
    "Closed": [("Sacred Grove Does Not Require Skull Kid", "Off"), ("Temple of Time Sword Requirement", "Master Sword")],
    "Open Grove": [("Sacred Grove Does Not Require Skull Kid", "On"), ("Temple of Time Sword Requirement", "Master Sword")],
    "Open": [("Sacred Grove Does Not Require Skull Kid", "On"), ("Temple of Time Sword Requirement", "None")],
}.items():
    for dl_name, dl_val in rows:
        SETTING_ROWS.append(("Temple of Time Entrance Requirements", v, dl_name, dl_val))

# Keys the apworld sends that have no Dusklight counterpart. Logged, never an error.
IGNORED_SETTINGS = {
    "Heart Pieces Shuffled": "No Dusklight setting: the server's location list decides what is a check",
    "Overworld Shuffled": "No Dusklight setting: the server's location list decides what is a check",
    "Dungeons Shuffled": "No Dusklight setting: the server's location list decides what is a check",
    "Logic Settings": "Logic was decided by the server; the local seed skips logic verification",
    "Early Shadow Crystal": "Server-side fill option; the crystal arrives as a received item",
    "Fast Iron Boots": "GameCube patch option with no Dusklight equivalent",
    "Quick Transform": "GameCube patch option with no Dusklight equivalent",
    "Instant Message Text": "GameCube patch option with no Dusklight equivalent",
    "Increase Spinner Speed": "GameCube patch option with no Dusklight equivalent",
    "Modify Shop Models": "GameCube patch option with no Dusklight equivalent",
}

# Applied first; slot_data overrides. The GameCube apworld hard-codes these to "Yes" (they are
# commented out of its YAML options), and the start state of every seed depends on them.
DEFAULTS = {
    "Skip Prologue": "On",
    "Faron Twilight Cleared": "On",
    "Eldin Twilight Cleared": "On",
    "Lanayru Twilight Cleared": "On",
    "Skip Midna's Desperate Hour": "On",
}

# Always written: the local seed is only the in-game half of a multiworld.
FIXED = {
    "Logic Rules": "All Locations Reachable",
    "Unrequired Dungeons Are Barren": "Off",
    "Randomize Starting Spawn": "Off",
    "Randomize Dungeon Entrances": "Off",
    "Randomize Boss Entrances": "Off",
    "Randomize Grotto Entrances": "Off",
    "Randomize Cave Entrances": "Off",
    "Randomize Interior Entrances": "Off",
    "Randomize Overworld Entrances": "Off",
    "Decouple Double Door Entrances": "Off",
    "Decouple Entrances": "Off",
    "Number of Path Hints": "0",
    "Path Hints on Midna": "Off",
    "Path Hints on Hint Signs": "Off",
    "Number of Barren Hints": "0",
    "Barren Hints on Midna": "Off",
    "Barren Hints on Hint Signs": "Off",
    "Number of Item Hints": "0",
    "Item Hints on Midna": "Off",
    "Item Hints on Hint Signs": "Off",
    "Number of Location Hints": "0",
    "Location Hints on Midna": "Off",
    "Location Hints on Hint Signs": "Off",
    "Prioritize Remote Location Hints": "Off",
    "Agitha Hints": "Off",
    "Hidden Rupees": "Off",
    "Freestanding Rupees": "Off",
    "Ilia Memory Quest": "Vanilla",
    "Item Scarcity": "Vanilla",
    "Randomize Starting Spawn": "Off",
}


def validate_settings(dl_settings):
    def legal(name, val):
        opts = dl_settings.get(name)
        if opts is None:
            die(f"Dusklight has no setting {name!r}")
        for o in opts:
            if o == val:
                return True
            m = re.fullmatch(r"(\d+)-(\d+)", o)
            if m and re.fullmatch(r"\d+", val) and int(m.group(1)) <= int(val) <= int(m.group(2)):
                return True
        return False

    for gc_key, gc_val, dl_name, dl_val in SETTING_ROWS:
        if dl_name not in dl_settings:
            die(f"setting {dl_name!r} (from GC key {gc_key!r}) does not exist in settings_list.yaml")
        if dl_val != "*" and not legal(dl_name, dl_val):
            die(f"{dl_name!r} has no option {dl_val!r} (from GC {gc_key!r}={gc_val!r}); legal: {dl_settings[dl_name]}")
    for table_name, table in (("FIXED", FIXED), ("DEFAULTS", DEFAULTS)):
        for name, val in table.items():
            if not legal(name, val):
                die(f"{table_name}: {name!r} cannot be {val!r}; legal: {dl_settings.get(name)}")
    # Passthrough rows must be able to carry every value the GC world can send.
    gc_options = {
        "Small Key Settings": ["Vanilla", "Own Dungeon", "Any Dungeon", "Anywhere", "Startwith"],
        "Big Key Settings": ["Vanilla", "Own Dungeon", "Any Dungeon", "Anywhere", "Startwith"],
        "Map and Compass Settings": ["Vanilla", "Own Dungeon", "Any Dungeon", "Anywhere", "Startwith"],
        "Palace of Twilight Requirements": ["Open", "Fused Shadows", "Mirror Shards", "Vanilla"],
        "Faron Woods Logic": ["Open", "Closed"],
        "Trap Frequency": ["No Traps", "Few", "Many", "Mayhem", "Nightmare"],
        "Damage Magnification": ["Vanilla", "Double", "Triple", "Quadruple", "Ohko"],
        "Starting ToD": ["Morning", "Noon", "Evening", "Night"],
        "Goron Mines Entrance Requirements": ["Closed", "No Wrestling", "Open"],
    }
    rows_by_key = {}
    for r in SETTING_ROWS:
        rows_by_key.setdefault(r[0], []).append(r)
    for key, values in gc_options.items():
        for v in values:
            matched = [r for r in rows_by_key[key] if r[1] in (v, "*")]
            exact = [r for r in matched if r[1] == v]
            use = exact or matched
            if not use:
                die(f"GC {key}={v!r} has no row")
            for _, _, dl_name, dl_val in use:
                final = v if dl_val == "*" else dl_val
                if not legal(dl_name, final):
                    die(f"GC {key}={v!r} -> {dl_name!r}={final!r} is not a legal Dusklight option "
                        f"({dl_settings[dl_name]})")


def check_gc_settings_covered(gc_keys):
    covered = {r[0] for r in SETTING_ROWS} | set(IGNORED_SETTINGS)
    missing = sorted(set(gc_keys) - covered)
    if missing:
        die(f"slot_data Settings keys with no rule: {missing}")
    stale = sorted(covered - set(gc_keys))
    return stale


def read_gc_settings_keys():
    src = (REF_GC / "__init__.py").read_text(encoding="utf-8")
    body = src[src.index("def get_settings_map"):]
    body = body[:body.index("\n        }")]
    return re.findall(r'^\s+"([^"]+)":', body, re.M)


# ----------------------------------------------------------------------------------------------

def cstr(s):
    return '"' + s.replace("\\", "\\\\").replace('"', '\\"') + '"'


def main():
    dl_locs = read_dl_locations()
    dl_items = read_dl_items()
    dl_settings = read_dl_settings()
    gc_locs = read_gc_locations()
    gc_items = read_gc_items()
    version = read_gc_version()

    lc = {n.lower(): n for n in dl_locs}
    if len(lc) != len(dl_locs):
        die("Dusklight location names collide case-insensitively")
    loc_rows, events = [], []
    for name, code in gc_locs:
        if code is None:
            events.append(name)
            continue
        if name.lower() not in lc:
            die(f"GC location {name!r} has no Dusklight location")
        loc_rows.append((code, name, lc[name.lower()]))
    codes = [r[0] for r in loc_rows]
    if len(set(codes)) != len(codes):
        die("duplicate GC location codes")
    loc_rows.sort()

    item_rows = map_items(gc_items, dl_items)
    icodes = [r["code"] for r in item_rows if r["code"] is not None]
    if len(set(icodes)) != len(icodes):
        die("duplicate GC item codes")
    item_rows = sorted((r for r in item_rows if r["code"] is not None), key=lambda r: r["code"])

    validate_settings(dl_settings)
    stale = check_gc_settings_covered(read_gc_settings_keys())

    with open(OUT_INC, "w", encoding="utf-8", newline="\n") as f:
        f.write("// GENERATED by output/tools/gen_gc_tables.py from ref_tp_apworld and the Dusklight\n")
        f.write("// generator data. Do not edit by hand; rerun the tool.\n\n")
        f.write(f"inline constexpr const char* kSupportedWorldVersion = {cstr(version)};\n\n")
        f.write("inline constexpr Location kLocationTable[] = {\n")
        for code, gc_name, dl_name in loc_rows:
            f.write(f"    {{{code}, {cstr(dl_name)}}},\n")
        f.write("};\n\n")
        f.write("inline constexpr Item kItemTable[] = {\n")
        for r in item_rows:
            dl_id = 0xFF if r["dl_id"] is None else r["dl_id"]
            f.write(f"    {{{r['code']}, {dl_id}, {cstr(r['dl_name'] or '')}, {cstr(r['name'])}}},\n")
        f.write("};\n\n")
        f.write("inline constexpr SettingRow kSettingRows[] = {\n")
        for gc_key, gc_val, dl_name, dl_val in SETTING_ROWS:
            f.write(f"    {{{cstr(gc_key)}, {cstr(gc_val)}, {cstr(dl_name)}, {cstr(dl_val)}}},\n")
        f.write("};\n\n")
        f.write("inline constexpr const char* kIgnoredSettings[] = {\n")
        for k in IGNORED_SETTINGS:
            f.write(f"    {cstr(k)},\n")
        f.write("};\n\n")
        f.write("inline constexpr SettingPair kDefaultSettings[] = {\n")
        for k, v in DEFAULTS.items():
            f.write(f"    {{{cstr(k)}, {cstr(v)}}},\n")
        f.write("};\n\n")
        f.write("inline constexpr SettingPair kFixedSettings[] = {\n")
        for k, v in FIXED.items():
            f.write(f"    {{{cstr(k)}, {cstr(v)}}},\n")
        f.write("};\n")

    # ---- report
    with open(OUT_REPORT, "w", encoding="utf-8", newline="\n") as r:
        r.write("# GameCube apworld -> Dusklight mapping report\n\n")
        r.write("Generated by `tools/gen_gc_tables.py`; review after every apworld update.\n\n")
        r.write(f"- Supported apworld version: `{version}`\n")
        r.write(f"- Locations: {len(loc_rows)} server locations (id = {ID_BASE} + code), all resolved to a Dusklight "
                f"location name. {len(dl_locs) - len(loc_rows)} Dusklight locations are not server locations and "
                f"keep their vanilla item.\n")
        renamed = [(g, d) for _, g, d in loc_rows if g != d]
        r.write(f"- Location names that differ only by letter case: {len(renamed)}\n")
        r.write(f"- Server events / always-vanilla entries without an id (never sent): {', '.join(events)}\n\n")
        r.write("## Items\n\n| code | GC name | Dusklight name | game id | how |\n|---|---|---|---|---|\n")
        for it in item_rows:
            did = "-" if it["dl_id"] is None else f"0x{it['dl_id']:02X}"
            gid = "-" if it["game_id"] is None else f"0x{it['game_id']:02X}"
            flag = ""
            if it["dl_id"] is not None and it["game_id"] is not None and it["dl_id"] != it["game_id"]:
                flag = f" **(GC byte {gid} differs; the Dusklight id is used)**"
            r.write(f"| {it['code']} | {it['name']} | {it['dl_name'] or '-'} | {did} | {it['how']}{flag} |\n")
        r.write("\n## Settings\n\n| GC `Settings` key | GC value | Dusklight setting | value |\n|---|---|---|---|\n")
        for gc_key, gc_val, dl_name, dl_val in SETTING_ROWS:
            if gc_val in ("true", "false", "on", "off", "1", "0"):
                continue
            r.write(f"| {gc_key} | {gc_val} | {dl_name} | {dl_val} |\n")
        r.write("\n(Toggle rows accept yes/no/true/false/on/off/1/0.)\n\n### Ignored keys\n\n")
        for k, why in IGNORED_SETTINGS.items():
            r.write(f"- `{k}`: {why}\n")
        r.write("\n### Defaults (overridden by slot_data)\n\n")
        for k, v in DEFAULTS.items():
            r.write(f"- {k} = {v}\n")
        r.write("\n### Always set\n\n")
        for k, v in FIXED.items():
            r.write(f"- {k} = {v}\n")
        if stale:
            r.write(f"\n### Rules with no matching slot_data key in this apworld version\n\n{stale}\n")

    print(f"locations: {len(loc_rows)}  items: {len(item_rows)}  setting rows: {len(SETTING_ROWS)}")
    print(f"wrote {OUT_INC.relative_to(ROOT)} and {OUT_REPORT.relative_to(ROOT)}")


if __name__ == "__main__":
    main()
