// VERIFICATION STUB (not nlohmann/json): a small working JSON value with the API surface the mod uses.
#pragma once
#include <cstdint>
#include <initializer_list>
#include <map>
#include <string>
#include <type_traits>
#include <utility>
#include <vector>
#include <istream>
namespace nlohmann {
class json {
public:
    enum class value_t { null, object, array, string, boolean, integer, floating, discarded };
    struct error_handler_t { enum type { strict, replace, ignore }; };
    json() {}
    json(std::nullptr_t) {}
    json(bool b) : t(value_t::boolean), i(b) {}
    json(int v) : t(value_t::integer), i(v) {}
    json(long v) : t(value_t::integer), i(v) {}
    json(long long v) : t(value_t::integer), i(v) {}
    json(unsigned v) : t(value_t::integer), i(v) {}
    json(unsigned long v) : t(value_t::integer), i(static_cast<long long>(v)) {}
    json(double v) : t(value_t::floating), d(v) {}
    json(const char* v) : t(value_t::string), s(v) {}
    json(const std::string& v) : t(value_t::string), s(v) {}
    template <class T, class = std::enable_if_t<!std::is_same_v<T, json>>>
    json(const std::vector<T>& v) : t(value_t::array) { for (const auto& e : v) a.push_back(json(e)); }
    json(std::initializer_list<json> l) {
        bool isObj = l.size() > 0;
        for (const auto& e : l) if (!(e.t == value_t::array && e.a.size() == 2 && e.a[0].t == value_t::string)) { isObj = false; break; }
        if (isObj) { t = value_t::object; for (const auto& e : l) o[e.a[0].s] = e.a[1]; }
        else { t = value_t::array; a.assign(l.begin(), l.end()); }
    }
    static json object() { json j; j.t = value_t::object; return j; }
    static json array(std::initializer_list<json> l = {}) { json j; j.t = value_t::array; j.a.assign(l.begin(), l.end()); return j; }
    static json parse(const std::string&, std::nullptr_t = nullptr, bool = true) { return json(); }
    static json parse(std::string_view, std::nullptr_t = nullptr, bool = true) { return json(); }
    static json parse(std::istream&, std::nullptr_t = nullptr, bool = true) { return json(); }
    bool is_discarded() const { return t == value_t::discarded; }
    bool is_null() const { return t == value_t::null; }
    bool is_array() const { return t == value_t::array; }
    bool is_object() const { return t == value_t::object; }
    bool is_string() const { return t == value_t::string; }
    bool is_boolean() const { return t == value_t::boolean; }
    bool is_number() const { return t == value_t::integer || t == value_t::floating; }
    bool is_number_integer() const { return t == value_t::integer; }
    bool empty() const { return size() == 0; }
    size_t size() const { return t == value_t::array ? a.size() : t == value_t::object ? o.size() : 0; }
    bool contains(const std::string& k) const { return t == value_t::object && o.count(k) > 0; }
    json& operator[](const std::string& k) { t = value_t::object; return o[k]; }
    json& operator[](const char* k) { t = value_t::object; return o[k]; }
    const json& operator[](const std::string& k) const { static json nul; auto it = o.find(k); return it == o.end() ? nul : it->second; }
    const json& operator[](const char* k) const { return (*this)[std::string(k)]; }
    template <class T> T value(const std::string& k, const T& def) const { auto it = o.find(k); return it == o.end() ? def : it->second.template get<T>(); }
    std::string value(const std::string& k, const char* def) const { auto it = o.find(k); return it == o.end() ? std::string(def) : it->second.get<std::string>(); }
    template <class T> T get() const {
        if constexpr (std::is_same_v<T, json>) return *this;
        else if constexpr (std::is_same_v<T, std::string>) return s;
        else if constexpr (std::is_same_v<T, bool>) return i != 0;
        else if constexpr (std::is_floating_point_v<T>) return static_cast<T>(t == value_t::floating ? d : static_cast<double>(i));
        else return static_cast<T>(i);
    }
    void push_back(const json& v) { t = value_t::array; a.push_back(v); }
    using array_t = std::vector<json>;
    array_t::const_iterator begin() const { return a.begin(); }
    array_t::const_iterator end() const { return a.end(); }
    array_t::iterator begin() { return a.begin(); }
    array_t::iterator end() { return a.end(); }
    struct const_iterator { const json* p; bool operator!=(const const_iterator& r) const { return p != r.p; } };
    array_t::const_iterator find(const std::string&) const { return a.end(); }
    std::vector<std::pair<std::string, json>> items() const { return {o.begin(), o.end()}; }
    std::string dump(int = -1, char = ' ', bool = false, error_handler_t::type = error_handler_t::strict) const { return {}; }
private:
    value_t t = value_t::null;
    long long i = 0; double d = 0; std::string s; array_t a; std::map<std::string, json> o;
};
}  // namespace nlohmann
