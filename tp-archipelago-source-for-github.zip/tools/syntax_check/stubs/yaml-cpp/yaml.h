// VERIFICATION STUB (not the real yaml-cpp): just enough surface to type-check the mod's calls.
#pragma once
#include <iterator>
#include <list>
#include <set>
#include <map>
#include <vector>
#include <unordered_map>
#include <unordered_set>
#include <sstream>
#include <fstream>
#include <memory>
#include <optional>
#include <stdexcept>
#include <string>
#include <utility>
namespace YAML {
enum class NodeType { Undefined, Null, Scalar, Sequence, Map };
struct BadFile : std::runtime_error { explicit BadFile(const std::string& f) : std::runtime_error(f) {} };
class Node {
public:
    Node() {}
    explicit Node(NodeType) {}
    template <class T> explicit Node(const T&) {}
    NodeType Type() const { return NodeType::Undefined; }
    bool IsDefined() const { return false; }
    bool IsNull() const { return true; }
    bool IsScalar() const { return false; }
    bool IsSequence() const { return false; }
    bool IsMap() const { return false; }
    explicit operator bool() const { return false; }
    bool operator!() const { return true; }
    template <class T> T as() const { return T(); }
    template <class T, class S> T as(const S&) const { return T(); }
    template <class K> Node operator[](const K&) const { return Node(); }
    template <class T> Node& operator=(const T&) { return *this; }
    size_t size() const { return 0; }
    struct iterator_value;
    struct const_iterator {
        const_iterator& operator++() { return *this; }
        bool operator!=(const const_iterator&) const { return false; }
        bool operator==(const const_iterator&) const { return true; }
        const iterator_value& operator*() const;
        const iterator_value* operator->() const;
    };
    const_iterator begin() const { return {}; }
    const_iterator end() const { return {}; }
};
struct Node::iterator_value : Node, std::pair<Node, Node> {};
inline const Node::iterator_value& Node::const_iterator::operator*() const { static iterator_value v; return v; }
inline const Node::iterator_value* Node::const_iterator::operator->() const { static iterator_value v; return &v; }
inline Node Load(const std::string&) { return Node(); }
inline std::string Dump(const Node&) { return {}; }
}  // namespace YAML
