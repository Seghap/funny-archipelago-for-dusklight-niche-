// VERIFICATION STUB (not battery-embed).
#pragma once
#include <cstddef>
#include <string>
namespace b {
template <size_t N> struct fixed_string { char v[N]; constexpr fixed_string(const char (&s)[N]) { for (size_t i = 0; i < N; ++i) v[i] = s[i]; } };
template <fixed_string P> struct embedded { std::string str() const { return {}; } };
template <fixed_string P> embedded<P> embed() { return {}; }
}  // namespace b
