// VERIFICATION STUB
#pragma once
inline double frsqrte(double x) { return x; }
