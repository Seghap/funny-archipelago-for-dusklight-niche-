// VERIFICATION STUB for the card (memory card) API declarations Aurora provides.
#pragma once
#include <dolphin/types.h>
struct CARDStat { char fileName[32]; u32 length; u32 time; u8 gameName[4]; u8 company[2]; u8 bannerFormat; u32 iconAddr; u16 iconFormat; u16 iconSpeed; u32 commentAddr; u32 offsetBanner; u32 offsetBannerTlut; u32 offsetIcon[8]; u32 offsetIconTlut; u32 offsetData; };
extern "C++" {
s32 CARDGetStatus(s32 chan, s32 fileNo, CARDStat* stat);
s32 CARDSetStatus(s32 chan, s32 fileNo, CARDStat* stat);
s32 CARDGetSerialNo(s32 chan, u64* serialNo);
}
