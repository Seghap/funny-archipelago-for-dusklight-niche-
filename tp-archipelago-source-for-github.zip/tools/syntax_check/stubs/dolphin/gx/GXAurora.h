// VERIFICATION STUB
#pragma once
#include <dolphin/gx/GXStruct.h>
void GXDestroyTexObj(GXTexObj*);
void GXDestroyTlutObj(GXTlutObj*);
#define GXSETARRAY(attr, ptr, a, b, stride) GXSetArray(attr, ptr, stride)
