#!/bin/bash
# Type-checks the Archipelago mod's C++ against the REAL Dusklight game and SDK headers, without
# CMake and without the third-party libraries (yaml-cpp, nlohmann/json, mbedtls, miniz, battery-embed)
# or the Aurora platform submodule, which are replaced by small stand-ins in ./stubs.
#
# The stand-ins only make the headers parse. They are NOT those libraries: this proves the mod's calls
# into the game and the SDK are well-formed (names, signatures, members, types), not that the final
# link or run works. The real build is `cmake -B build && cmake --build build` (see README.md).
#
#   tools/syntax_check/check.sh                 # every file below (run from output/)
#   tools/syntax_check/check.sh src/ap/mode/items.cpp ...
#   DUSKLIGHT_DIR=/path/to/dusklight tools/syntax_check/check.sh
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"
OUT="$(cd "$HERE/../.." && pwd)"
D="${DUSKLIGHT_DIR:-$OUT/../dusklight}"
[ -d "$D/sdk/include" ] || { echo "Dusklight tree not found at $D (set DUSKLIGHT_DIR)"; exit 2; }
CXX="${CXX:-g++}"
cd "$OUT"

FILES=("$@")
if [ ${#FILES[@]} -eq 0 ]; then
  FILES=(src/session.cpp src/mod.cpp src/hooks.cpp src/ui/rando_config.cpp src/item.cpp src/messages.cpp
         src/ap/ap_mode.cpp src/ap/ap_client.cpp src/ap/ws_tcp.cpp src/ap/gc_settings.cpp src/ap/gc_tables.cpp src/ap/seed_inputs.cpp
         src/ap/mode/common.cpp src/ap/mode/slot.cpp src/ap/mode/items.cpp src/ap/mode/saves.cpp
         src/ap/mode/status.cpp src/ap/mode/death_link.cpp src/ap/mode/hooks.cpp)
fi

fail=0
for f in "${FILES[@]}"; do
  out=$($CXX -std=c++23 -fsyntax-only -fmax-errors=0 \
      -DTARGET_PC=1 -DWIDESCREEN_SUPPORT=1 -DAVOID_UB=1 -DVERSION=0 -DMTX_USE_PS=1 -DPARTIAL_DEBUG=1 \
      -DDUSK_MOD_FEATURE_GAME=1 -DDUSK_MOD_FEATURE_FMT=1 -DRANDO_DATA_PATH='"generator/data/"' \
      -DFULL_RANDOMIZER_VERSION='"check"' -DSOURCE_PATH_SIZE=0 -include global.h \
      -I "$HERE/stubs" -I "$D/include" -I "$D/assets/GZ2E01" -I "$D/libs/JSystem/include" \
      -I "$D/libs/dolphin/include" -I "$D/libs/dolphin/include/dolphin" -I "$D/sdk/include" \
      -I src -I . "$f" 2>&1)
  n=$(printf '%s\n' "$out" | grep -c "error")
  if [ "$n" -ne 0 ]; then
    fail=1; echo "FAIL ($n errors)  $f"; printf '%s\n' "$out" | grep "error" | head -5
  else
    echo "ok    $f"
  fi
done
exit $fail
