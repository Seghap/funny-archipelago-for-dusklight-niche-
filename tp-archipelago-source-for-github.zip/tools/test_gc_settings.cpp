// Host-side test of the GameCube-apworld -> Dusklight settings translation and the id tables.
//
//   g++ -std=c++23 -Wall -Wextra -I src/ap tools/test_gc_settings.cpp src/ap/gc_settings.cpp src/ap/gc_tables.cpp -o test_gc
//   (run from the output/ directory, then ./test_gc)
//
// The "defaults" below are what ref_tp_apworld/__init__.py get_settings_map() sends for an
// all-default YAML: Toggle options render as "Yes"/"No", Choice options as Title Case words.

#include "gc_settings.hpp"
#include "gc_tables.hpp"

#include <cstdio>
#include <map>
#include <string>

using ap::gc::StringPairs;

static int g_failures = 0;

#define CHECK(cond)                                                                                \
    do {                                                                                           \
        if (!(cond)) {                                                                             \
            std::printf("FAIL %s:%d: %s\n", __FILE__, __LINE__, #cond);                            \
            ++g_failures;                                                                          \
        }                                                                                          \
    } while (0)

static std::string get(const ap::gc::SettingsResult& r, const std::string& name) {
    for (const auto& [n, v] : r.settings) {
        if (n == name) {
            return v;
        }
    }
    return "<unset>";
}

static StringPairs defaults() {
    return {
        {"Castle Requirements", "Open"},
        {"Palace of Twilight Requirements", "Open"},
        {"Faron Woods Logic", "Open"},
        {"Small Key Settings", "Vanilla"},
        {"Big Key Settings", "Vanilla"},
        {"Map and Compass Settings", "Vanilla"},
        {"Skip Prologue", "Yes"},
        {"Faron Twilight Cleared", "Yes"},
        {"Eldin Twilight Cleared", "Yes"},
        {"Lanayru Twilight Cleared", "Yes"},
        {"Skip MDH", "Yes"},
        {"Skip Minor Cutscenes", "Yes"},
        {"Fast Iron Boots", "Yes"},
        {"Quick Transform", "Yes"},
        {"Transform Anywhere", "Yes"},
        {"Increase Wallet", "Yes"},
        {"Modify Shop Models", "No"},
        {"Goron Mines Entrance Requirements", "Open"},
        {"Lakebed Entrance Requirements", "Yes"},
        {"Arbiters Grounds Entrance Requirements", "Yes"},
        {"Snowpeak Entrance Requirements", "Yes"},
        {"Temple of Time Entrance Requirements", "Open"},
        {"City in the Sky Entrance Requirements", "Yes"},
        {"Instant Message Text", "Yes"},
        {"Open Map", "Yes"},
        {"Increase Spinner Speed", "Yes"},
        {"Open Door of Time", "Yes"},
        {"Damage Magnification", "Vanilla"},
        {"Bonks do Damage", "No"},
        {"Skip Major Cutscenes", "Yes"},
        {"Starting ToD", "Morning"},
        {"Logic Settings", "Glitchless"},
        {"Golden Bugs Shuffled", "Yes"},
        {"Sky Chracters Shuffled", "Yes"},
        {"NPC Items Shuffled", "Yes"},
        {"Shop Items Shuffled", "Yes"},
        {"Hidden Skills Shuffled", "Yes"},
        {"Poes Shuffled", "Yes"},
        {"Heart Pieces Shuffled", "Yes"},
        {"Overworld Shuffled", "Yes"},
        {"Dungeons Shuffled", "Yes"},
        {"Dungeon Rewards Progression", "Yes"},
        {"Trap Frequency", "No Traps"},
        {"Early Shadow Crystal", "No"},
    };
}

static void override_value(StringPairs& s, const std::string& key, const std::string& value) {
    for (auto& [k, v] : s) {
        if (k == key) {
            v = value;
            return;
        }
    }
    s.emplace_back(key, value);
}

int main() {
    // ---- defaults: no errors, every key understood
    {
        const auto r = ap::gc::translate_settings(defaults());
        CHECK(r.errors.empty());
        for (const auto& e : r.errors) std::printf("  error: %s\n", e.c_str());
        // only the documented ignored keys may warn
        for (const auto& w : r.warnings) {
            CHECK(w.find("unknown setting") == std::string::npos);
        }
        CHECK(get(r, "Skip Prologue") == "On");
        CHECK(get(r, "Faron Twilight Cleared") == "On");
        CHECK(get(r, "Eldin Twilight Cleared") == "On");
        CHECK(get(r, "Lanayru Twilight Cleared") == "On");
        CHECK(get(r, "Skip Midna's Desperate Hour") == "On");
        CHECK(get(r, "Hyrule Barrier Requirements") == "Open");
        CHECK(get(r, "Palace of Twilight Requirements") == "Open");
        CHECK(get(r, "Faron Woods Logic") == "Open");
        CHECK(get(r, "Small Keys") == "Vanilla");
        CHECK(get(r, "Maps and Compasses") == "Vanilla");
        CHECK(get(r, "Poe Souls") == "All");
        CHECK(get(r, "Golden Bugs") == "On");
        CHECK(get(r, "Sky Characters") == "On");
        CHECK(get(r, "Gifts From NPCs") == "On");
        CHECK(get(r, "Shop Items") == "On");
        CHECK(get(r, "Hidden Skills") == "On");
        CHECK(get(r, "Dungeon Rewards Can Be Anywhere") == "On");
        CHECK(get(r, "Trap Item Frequency") == "None");
        CHECK(get(r, "Logic Damage Multiplier") == "Vanilla");
        CHECK(get(r, "Bonks Do Damage") == "Off");
        CHECK(get(r, "Unlock Map Regions") == "On");
        CHECK(get(r, "Open Door of Time") == "On");
        CHECK(get(r, "Starting Time of Day") == "Morning");
        CHECK(get(r, "Goron Mines Entrance") == "Open");
        CHECK(get(r, "Sacred Grove Does Not Require Skull Kid") == "On");
        CHECK(get(r, "Temple of Time Sword Requirement") == "None");
        CHECK(get(r, "Lakebed Does Not Require Water Bombs") == "On");
        CHECK(get(r, "Logic Transform Anywhere") == "On");
        CHECK(get(r, "Logic Increase Wallet Capacity") == "On");
        // fixed by the mod
        CHECK(get(r, "Randomize Starting Spawn") == "Off");
        CHECK(get(r, "Number of Location Hints") == "0");
        CHECK(get(r, "Logic Rules") == "All Locations Reachable");
        // each setting once
        for (size_t i = 0; i < r.settings.size(); ++i)
            for (size_t j = i + 1; j < r.settings.size(); ++j)
                CHECK(r.settings[i].first != r.settings[j].first);
    }

    // ---- non-default values
    {
        auto s = defaults();
        override_value(s, "Small Key Settings", "Startwith");
        override_value(s, "Big Key Settings", "Own Dungeon");
        override_value(s, "Map and Compass Settings", "Startwith");
        override_value(s, "Castle Requirements", "All Dungeons");
        override_value(s, "Palace of Twilight Requirements", "Mirror Shards");
        override_value(s, "Damage Magnification", "Ohko");
        override_value(s, "Trap Frequency", "Nightmare");
        override_value(s, "Temple of Time Entrance Requirements", "Closed");
        override_value(s, "Poes Shuffled", "No");
        override_value(s, "Dungeon Rewards Progression", "No");
        override_value(s, "Starting ToD", "Night");
        override_value(s, "Goron Mines Entrance Requirements", "No Wrestling");
        override_value(s, "Faron Woods Logic", "Closed");
        const auto r = ap::gc::translate_settings(s);
        CHECK(r.errors.empty());
        CHECK(get(r, "Small Keys") == "Keysy");
        CHECK(get(r, "Big Keys") == "Own Dungeon");
        CHECK(get(r, "Maps and Compasses") == "Start With");
        CHECK(get(r, "Hyrule Barrier Requirements") == "Dungeons");
        CHECK(get(r, "Hyrule Barrier Dungeons") == "8");
        CHECK(get(r, "Palace of Twilight Requirements") == "Mirror Shards");
        CHECK(get(r, "Logic Damage Multiplier") == "OHKO");
        CHECK(get(r, "Trap Item Frequency") == "Nightmare");
        CHECK(get(r, "Sacred Grove Does Not Require Skull Kid") == "Off");
        CHECK(get(r, "Temple of Time Sword Requirement") == "Master Sword");
        CHECK(get(r, "Poe Souls") == "Vanilla");
        CHECK(get(r, "Dungeon Rewards Can Be Anywhere") == "Off");
        CHECK(get(r, "Starting Time of Day") == "Night");
        CHECK(get(r, "Goron Mines Entrance") == "No Wrestling");
        CHECK(get(r, "Faron Woods Logic") == "Closed");
    }
    {
        auto s = defaults();
        override_value(s, "Castle Requirements", "Fused Shadows");
        auto r = ap::gc::translate_settings(s);
        CHECK(get(r, "Hyrule Barrier Requirements") == "Fused Shadows");
        CHECK(get(r, "Hyrule Barrier Fused Shadows") == "3");
        override_value(s, "Castle Requirements", "Mirror Shards");
        r = ap::gc::translate_settings(s);
        CHECK(get(r, "Hyrule Barrier Mirror Shards") == "4");
        override_value(s, "Temple of Time Entrance Requirements", "Open Grove");
        r = ap::gc::translate_settings(s);
        CHECK(get(r, "Sacred Grove Does Not Require Skull Kid") == "On");
        CHECK(get(r, "Temple of Time Sword Requirement") == "Master Sword");
    }

    // ---- the server may someday send these as real options; slot_data wins over the mod's defaults
    {
        auto s = defaults();
        override_value(s, "Skip Prologue", "No");
        const auto r = ap::gc::translate_settings(s);
        CHECK(get(r, "Skip Prologue") == "Off");
    }

    // ---- robustness: spelling, unknown keys, unmappable values
    {
        StringPairs s = {{"Poes Shuffled", "true"}, {"Faron Woods Logic", "closed"},
            {"Small Key Settings", "own_dungeon"}, {"Brand New Option", "Whatever"},
            {"Skip Minor Cutscenes", "maybe"}};
        const auto r = ap::gc::translate_settings(s);
        CHECK(get(r, "Poe Souls") == "All");
        CHECK(get(r, "Faron Woods Logic") == "Closed");
        CHECK(get(r, "Small Keys") == "Own Dungeon");
        CHECK(r.errors.size() == 1);  // only "maybe"
        bool warnedUnknown = false;
        for (const auto& w : r.warnings) warnedUnknown |= w.find("Brand New Option") != std::string::npos;
        CHECK(warnedUnknown);
    }
    CHECK(ap::gc::is_on("Yes") && ap::gc::is_on("TRUE") && ap::gc::is_on(" on ") && !ap::gc::is_on("No"));

    // ---- id tables
    {
        const auto locs = ap::gc::locations();
        const auto items = ap::gc::items();
        CHECK(locs.size() == 475);
        CHECK(items.size() == 122);
        const auto* first = ap::gc::find_location(ap::gc::kIdBase + 0);
        CHECK(first != nullptr && std::string(first->dusklightName) == "Arbiters Grounds Big Key Chest");
        CHECK(ap::gc::location_id("Arbiters Grounds Big Key Chest") == ap::gc::kIdBase);
        CHECK(ap::gc::find_location(ap::gc::kIdBase - 1) == nullptr);
        CHECK(ap::gc::find_location(ap::gc::kIdBase + 999999) == nullptr);
        CHECK(ap::gc::location_id("Defeat Ganondorf") == -1);
        for (const auto& l : locs) {
            CHECK(ap::gc::location_id(l.dusklightName) == ap::gc::kIdBase + l.code);
            CHECK(ap::gc::find_location(ap::gc::kIdBase + l.code) == &l);
        }
        const auto* green = ap::gc::find_item(ap::gc::kIdBase + 0);
        CHECK(green != nullptr && std::string(green->gcName) == "Green Rupee" && green->giveByte == 0x01);
        // no real item may resolve to "nothing to give"
        for (const auto& it : items) {
            if (it.giveByte == 0xFF) {
                CHECK(std::string(it.gcName) == "Victory");
            }
        }
        CHECK(std::string(ap::gc::supported_world_version()) == "v0.3.0");
    }

    if (g_failures == 0) {
        std::printf("all gc settings/table tests passed\n");
        return 0;
    }
    std::printf("%d failure(s)\n", g_failures);
    return 1;
}
