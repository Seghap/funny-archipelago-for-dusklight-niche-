// Runs the mod's real GameCube-apworld adapter (gc_tables.cpp, gc_settings.cpp) on data captured
// from a live room by tools/live_probe.py, so what the server actually sent is what gets tested.
//
//   g++ -std=c++23 -Wall -Wextra -I src/ap tools/gc_adapter_cli.cpp src/ap/gc_settings.cpp \
//       src/ap/gc_tables.cpp -o gc_adapter_cli
//   ./gc_adapter_cli < tools/live/adapter_input.txt
//
// Input, one record per line, fields separated by TAB:
//   WORLD   <World Version>
//   SLOT    <our slot number>
//   SETTING <key> <value>
//   LOC     <archipelago location id>
//   PLACE   <location id> <item id> <receiving player>
// Output records (TAB separated): T (translated setting), W/E (warning/error), V (version check),
// P (placement: location, gc item name, plando name, give byte, own), U (unknown id).

#include "gc_settings.hpp"
#include "gc_tables.hpp"

#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

static std::vector<std::string> split(const std::string& line) {
    std::vector<std::string> out;
    std::string cur;
    for (const char c : line) {
        if (c == '\t') {
            out.push_back(cur);
            cur.clear();
        } else {
            cur += c;
        }
    }
    out.push_back(cur);
    return out;
}

int main() {
    ap::gc::StringPairs settings;
    std::string world;
    long mySlot = -1;
    std::vector<long long> locs;
    struct Place { long long loc, item; int player; };
    std::vector<Place> places;

    std::string line;
    while (std::getline(std::cin, line)) {
        const auto f = split(line);
        if (f[0] == "WORLD" && f.size() > 1) world = f[1];
        else if (f[0] == "SLOT" && f.size() > 1) mySlot = std::atol(f[1].c_str());
        else if (f[0] == "SETTING" && f.size() > 2) settings.emplace_back(f[1], f[2]);
        else if (f[0] == "LOC" && f.size() > 1) locs.push_back(std::atoll(f[1].c_str()));
        else if (f[0] == "PLACE" && f.size() > 3)
            places.push_back({std::atoll(f[1].c_str()), std::atoll(f[2].c_str()), std::atoi(f[3].c_str())});
    }

    std::printf("V\t%s\t%s\t%s\n", world.c_str(), ap::gc::supported_world_version(),
        world == ap::gc::supported_world_version() ? "match" : "MISMATCH");

    const auto result = ap::gc::translate_settings(settings);
    for (const auto& [k, v] : result.settings) std::printf("T\t%s\t%s\n", k.c_str(), v.c_str());
    for (const auto& w : result.warnings) std::printf("W\t%s\n", w.c_str());
    for (const auto& e : result.errors) std::printf("E\t%s\n", e.c_str());

    int unknown = 0;
    for (const long long id : locs) {
        const auto* l = ap::gc::find_location(id);
        if (l == nullptr) {
            ++unknown;
            std::printf("U\tlocation\t%lld\n", id);
        } else {
            std::printf("L\t%lld\t%s\n", id, l->dusklightName);
        }
    }
    for (const auto& p : places) {
        const auto* it = ap::gc::find_item(p.item);
        const auto* l = ap::gc::find_location(p.loc);
        const bool own = p.player == mySlot;
        if (it == nullptr) {
            std::printf("U\titem\t%lld\n", p.item);
            continue;
        }
        std::printf("P\t%s\t%s\t%s\t%d\t%d\n", l ? l->dusklightName : "?", it->gcName, it->plandoName, it->giveByte,
            own ? 1 : 0);
    }
    std::printf("S\t%zu locations\t%d unknown\t%zu placements\n", locs.size(), unknown, places.size());
    return 0;
}
