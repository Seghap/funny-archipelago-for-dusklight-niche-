// Game boxes in the mode: which game an item belongs to, the item draw and text box hooks. Drawing is ap_box, covers ap_covers.

#include "internal.hpp"

namespace ap::internal {
// Used only in this file; defined below.
static std::string game_for_location(const std::string& location);
static std::string game_for_actor(const void* actor);

// The game that owns the AP item at a location, or "" (our own items, or unknown).
static std::string game_for_location(const std::string& location) {
    const auto it = g_placements.find(location);
    return it != g_placements.end() && !it->second.own ? it->second.game : std::string{};
}


// The game that owns the AP item an actor shows, or "" when we can't tell.
static std::string game_for_actor(const void* actor) {
    std::string location;
    if (fopAcM_GetName(const_cast<void*>(actor)) == fpcNm_Demo_Item_e) {
        // Held up: the pickup resolved just before this actor appeared (see g_heldActor).
        if (g_heldActor != actor) {
            g_heldActor = actor;
            g_heldLocation = g_lastResolvedApLocation;
        }
        location = g_heldLocation;
    } else if (const auto loc = g_actorLocation.find(actor); loc != g_actorLocation.end()) {
        location = loc->second;
    }
    return game_for_location(location);
}

HookAction pre_item_draw_base(ModContext*, void* args, void* retval, void*) {
    auto* item = mods::arg<daItemBase_c*>(args, 0);
    if (item == nullptr || item->getDisplayItemNo() != kApItem || !cfg_on(g_cfgBoxes)) {
        return HOOK_CONTINUE;
    }
    const std::string game = game_for_actor(item);
    const covers::Cover* cover = game.empty() ? nullptr : covers::get(game);
    const bool held = fopAcM_GetName(item) == fpcNm_Demo_Item_e;
    if (cover == nullptr || !box::draw(item, *cover, held)) {
        return HOOK_CONTINUE;
    }
    *static_cast<int*>(retval) = 1;
    return HOOK_SKIP_ORIGINAL;
}

// The get-item text box: its icon (the Sol's rupee-shaped stand-in) becomes the cover. The
// box builds its pictures from the icon it loads, sized for that; swapping the picture's
// texture afterwards keeps the size and changes only the image.
void post_msg_item_exec(ModContext*, void* args, void*, void*) {
    auto* scrn = mods::arg<dMsgScrnItem_c*>(args, 0);
    if (scrn == nullptr || !cfg_on(g_cfgBoxes)) {
        return;
    }
    // The box works out its item from the message: ours is the Foolish Item's (0x13).
    constexpr int kDonorItem = kApItemDonorMessage - 0x65;
    if (scrn->mItemIndex == kDonorItem && g_apTextServed) {
        g_apTextServed = false;
        g_apTextBox = scrn;
    }
    // Ours only while it still shows our (borrowed) message: boxes are reallocated at the
    // same address, so a later box for anything else must not inherit the claim.
    const bool ours = scrn == g_apTextBox && scrn->mItemIndex == kDonorItem;
    if (scrn == g_apTextBox && !ours) {
        g_apTextBox = nullptr;
    }
    if (scrn->mItemIndex != kApItem && !ours) {
        return;
    }
    J2DPicture* pane = scrn->mpItemPane[0];
    const covers::Cover* cover = covers::get(game_for_location(g_heldLocation));
    if (pane == nullptr || cover == nullptr || cover->iconTimg.empty()) {
        return;
    }
    const auto* timg = reinterpret_cast<const ResTIMG*>(cover->iconTimg.data());
    if (const JUTTexture* tex = pane->getTexture(0); tex != nullptr && tex->getTexInfo() == timg) {
        return;  // already showing it
    }
    pane->changeTexture(timg, 0);
    // The box draws the icon at a size taken from the stand-in's shape (taller than wide); the
    // cover's icon is square, so draw it square, as big as the icon slot allows. It centres
    // itself in the slot.
    const float side = std::min(scrn->field_0x170, scrn->field_0x174);
    scrn->field_0x178 = side;
    scrn->field_0x17c = side;
    // The icon's colours were set for the stand-in (tinted); the cover shows as it is.
    pane->setBlackWhite(JUtility::TColor(0, 0, 0, 0), JUtility::TColor(255, 255, 255, 255));
    pane->setCornerColor(JUtility::TColor(255, 255, 255, 255));
}


// The Status tab's section: the switch, the key and what the covers are doing.
void add_box_settings(ModContext* ctx, UiElementHandle left) {
    svc_mng.ui->pane_add_section(ctx, left, "Other players' items");
    auto add = [&](UiControlKind kind, const char* label, ConfigVarHandle var, const char* help) {
        UiControlDesc d = UI_CONTROL_DESC_INIT;
        d.kind = kind;
        d.label = label;
        d.help_rml = help;
        d.binding = UI_BINDING_CONFIG_VAR;
        d.config_var = var;
        svc_mng.ui->pane_add_control(ctx, left, &d, nullptr);
    };
    add(UI_CONTROL_TOGGLE, "Show as game boxes", g_cfgBoxes,
        "Items that belong to other worlds show as the box of the game they're for, with its cover "
        "art, instead of a Sol. Covers come from SteamGridDB with your own API key and download once "
        "per game. Games without art stay Sols.");
    auto add_art = [&](const char* label, ConfigVarHandle var, const char* help) {
        UiControlDesc d = UI_CONTROL_DESC_INIT;
        d.kind = UI_CONTROL_SELECT;
        d.label = label;
        d.help_rml = help;
        d.binding = UI_BINDING_CONFIG_VAR;
        d.config_var = var;
        static const char* const options[] = {"Box cover", "Game icon"};
        d.options = options;
        d.option_count = std::size(options);
        svc_mng.ui->pane_add_control(ctx, left, &d, nullptr);
    };
    add_art("Art on the item", g_cfgArtWorld,
        "What the item shows on the ground and in Link's hands: the game's box cover, or its square icon "
        "(SteamGridDB icons; a game without one uses its cover).");
    add_art("Art in the text box", g_cfgArtText,
        "The picture beside \"You found ...\": the cover, or the game's icon. Mix them, for example the icon "
        "in Link's hands and the cover in the text box.");
    add(UI_CONTROL_STRING, "SteamGridDB API key", g_cfgSgdbKey,
        "Free: sign in at steamgriddb.com, then Preferences, API, and copy your key here. It's only "
        "sent to SteamGridDB. Leave it empty and items stay Sols.");
    g_coverStatusText = 0;
    svc_mng.ui->pane_add_text(ctx, left, covers::status().c_str(), &g_coverStatusText);
    UiControlDesc again = UI_CONTROL_DESC_INIT;
    again.kind = UI_CONTROL_BUTTON;
    again.label = "Download covers again";
    again.help_rml = "Forgets the saved covers (and which games had none) and downloads them again. "
                     "To use your own art for a game, put a PNG or JPG named after the game in "
                     "randomizer/archipelago/covers/custom.";
    again.on_pressed = [](ModContext*, void*) { covers::refetch(); };
    svc_mng.ui->pane_add_control(ctx, left, &again, nullptr);
}

// Covers for every game with an item in this world (theirs, or another Twilight Princess).
void want_covers() {
    std::vector<std::string> games;
    for (const auto& [loc, p] : g_placements) {
        if (!p.own && !p.game.empty() && std::find(games.begin(), games.end(), p.game) == games.end()) {
            games.push_back(p.game);
        }
    }
    covers::want(games);
}

}  // namespace ap::internal
