// The new-save connection window and the save lifecycle (new save, load, reset).

#include "internal.hpp"

namespace ap::internal {

// Used only in this file; defined below.
static void press_connect(ModContext*, void*);
static bool connect_disabled(ModContext*, void*);
static ModResult build_new_save_tab(ModContext*, UiWindowHandle, UiElementHandle left, UiElementHandle,
    void*, ModError*);
static ModResult update_new_save_tab(ModContext*, void*, ModError*);
static void new_save_window_closed(ModContext*, UiWindowHandle, void*);
static std::string connect_status();
static void reset_connection_state();


// ---------------------------------------------------------------------------------------
// The connection window shown when a new Archipelago file is created.
//
// It is the gate in front of name entry (GameModeDesc::on_new_save_select): the new file only
// goes on once the server has answered and the seed is built, because the seed is the file's
// whole starting state. Closing the window sends the player back to the file list.

static void reset_connection_state() {
    g_client.disconnect();
    g_haveSlot = false;
    g_serverItems.clear();
    g_placements.clear();
    g_scoutedIds.clear();
    g_checked.clear();
    g_toSend.clear();
    g_apItemText.clear();
    g_skippedPlando.clear();
    g_checkToLocations.clear();
    g_scan.clear();
    g_hints.clear();
    reset_tracker();
    g_recentItems.clear();
    g_recentChat.clear();
    g_outstanding = -1;
    g_needsRegen = false;
    g_giveUpReconnect = false;
}

static void press_connect(ModContext*, void*) {
    if (g_phase != Phase::NewSave) {
        return;
    }
    std::string host;
    int64_t port = g_inPort;
    if (!split_server(g_inHost, host, port)) {
        g_status = "Enter the server address, for example archipelago.gg (and its port below).";
        return;
    }
    if (g_inSlot.empty()) {
        g_status = "Enter your slot (player) name.";
        return;
    }
    g_inHost = host;  // a pasted "host:port" splits itself into the two fields
    g_inPort = port;
    mDoAud_seStartMenu(Z2SE_SY_MENU_NEXT);
    g_conn = {join_server(host, port), g_inSlot, g_inPassword};
    if (g_cfgHost != 0) {
        svc_mng.config->set_string(svc_mng.mod_ctx, g_cfgHost, host.c_str());
        svc_mng.config->set_int(svc_mng.mod_ctx, g_cfgPort, port);
        svc_mng.config->set_string(svc_mng.mod_ctx, g_cfgSlot, g_inSlot.c_str());
    }
    g_giveUpReconnect = false;
    g_status = "Connecting...";
    g_client.connect({g_conn.server, g_conn.slot, g_conn.password});
}

static bool connect_disabled(ModContext*, void*) {
    return g_phase != Phase::NewSave || g_client.state() == State::Connecting ||
           g_client.state() == State::Handshaking;
}

// What the window says, refreshed every frame.
static std::string connect_status() {
    std::string text = status_line();
    if (g_phase != Phase::NewSave || g_status != "Connecting...") {
        text += "\n" + g_status;  // a new line in the window (see rml_lines)
    }
    return text;
}

static ModResult build_new_save_tab(ModContext* ctx, UiWindowHandle, UiElementHandle left, UiElementHandle,
    void*, ModError*) {
    auto string_row = [&](const char* label, std::string* target, const char* help, int32_t maxLength) {
        UiControlDesc d = UI_CONTROL_DESC_INIT;
        d.kind = UI_CONTROL_STRING;
        d.label = label;
        d.help_rml = help;
        d.get = get_str;
        d.set = set_str;
        d.user_data = target;
        d.max_length = maxLength;
        d.string_set_mode = UI_STRING_SET_ON_CHANGE;
        svc_mng.ui->pane_add_control(ctx, left, &d, nullptr);
    };
    svc_mng.ui->pane_add_section(ctx, left, "Archipelago server");
    string_row("Host", &g_inHost,
        "The server address, for example archipelago.gg or localhost. Pasting a full address with its "
        "port (archipelago.gg:38281) also works.", 128);

    UiControlDesc port = UI_CONTROL_DESC_INIT;
    port.kind = UI_CONTROL_NUMBER;
    port.label = "Port";
    port.help_rml = "The room's port, shown on the room page (38281 by default).";
    port.min = 1;
    port.max = 65535;
    port.step = 1;
    port.get = [](ModContext*, void*, UiControlValue* out) { out->int_value = g_inPort; };
    port.set = [](ModContext*, void*, const UiControlValue* v) { g_inPort = v->int_value; };
    svc_mng.ui->pane_add_control(ctx, left, &port, nullptr);

    string_row("Slot name", &g_inSlot, "Your player name from your YAML.", 32);
    string_row("Password", &g_inPassword, "Leave empty if the room has no password. Shown as you type it.", 64);

    UiControlDesc b = UI_CONTROL_DESC_INIT;
    b.kind = UI_CONTROL_BUTTON;
    b.label = "Connect and start";
    b.help_rml = "Connects, asks the server what is at each of your locations, builds your seed from "
                 "the answer, and continues to name entry. Your settings come from the server; there is "
                 "nothing to configure here.";
    b.on_pressed = press_connect;
    b.is_disabled = connect_disabled;
    svc_mng.ui->pane_add_control(ctx, left, &b, nullptr);

    svc_mng.ui->pane_add_section(ctx, left, "Status");
    g_statusText = 0;
    svc_mng.ui->pane_add_rml(ctx, left, rml_lines(connect_status()).c_str(), &g_statusText);
    return MOD_OK;
}

static ModResult update_new_save_tab(ModContext* ctx, void*, ModError*) {
    if (g_statusText != 0) {
        static std::string shown;
        const std::string now = connect_status();
        if (shown != now) {
            shown = now;
            svc_mng.ui->elem_set_rml(ctx, g_statusText, rml_lines(now).c_str());
        }
    }
    return MOD_OK;
}

void abandon_new_save(const char* why) {
    ap_log(std::string("new save abandoned: ") + why);
    if (g_newSaveState != nullptr && *g_newSaveState == GAME_MODE_STATE_PENDING) {
        *g_newSaveState = GAME_MODE_STATE_RETURN;  // back to the file list
    }
    ++g_genSerial;  // anything still building is for nobody now
    g_genStatus = 0;
    g_client.disconnect();
    g_haveSlot = false;
    g_phase = Phase::Idle;
}

static void new_save_window_closed(ModContext*, UiWindowHandle, void*) {
    g_window = 0;
    g_statusText = 0;
    // The window also closes by itself once the seed is ready. By then the game has already taken
    // PROCEED and reset the state to PENDING for the next screen, so the state says nothing about
    // whether the player gave up: the phase does. Only a window closed while still connecting,
    // scouting or building is an abandoned new file.
    if (g_phase == Phase::NewSave || g_phase == Phase::Scouting || g_phase == Phase::Generating) {
        abandon_new_save("window closed");
    }
}

ModResult on_new_save_select(void*, GameModeNewSaveState* state, ModError* err) {
    g_newSaveState = state;
    reset_connection_state();
    g_phase = Phase::NewSave;
    g_status = "Connect to your Archipelago room. Your seed is built from the server's data.";
    g_inHost = config_string(g_cfgHost);
    if (g_inHost.empty()) {
        g_inHost = "archipelago.gg";
    }
    g_inPort = cfg_int(g_cfgPort, 38281);
    g_inSlot = config_string(g_cfgSlot);
    g_inPassword.clear();

    static UiTabDesc tab = UI_TAB_DESC_INIT;
    tab.title = "Archipelago";
    tab.build = build_new_save_tab;
    tab.update = update_new_save_tab;
    UiWindowDesc desc = UI_WINDOW_DESC_INIT;
    desc.tabs = &tab;
    desc.tab_count = 1;
    desc.on_closed = new_save_window_closed;
    const ModResult rt = svc_mng.ui->window_push(svc_mng.mod_ctx, &desc, &g_window);
    if (rt != MOD_OK) {
        return mods::set_error(err, rt, "Failed to open the Archipelago connection window");
    }
    return MOD_OK;
}


// ---------------------------------------------------------------------------------------
// Save lifecycle

ModResult on_new_save(void* ud, ModError* err) {
    // The seed built in the connection window becomes this file's seed: this is where the
    // start flags (prologue skipped, twilights cleared, Hero's Clothes, map regions, ...) are
    // applied, with the seed's stage edits and item resolver already active.
    const ModResult r = randomizer::session::onNewSave(ud, err);
    if (r != MOD_OK) {
        return r;
    }
    g_state = {};
    g_state.seed = g_slotSeed;
    g_state.slot = g_conn.slot;
    g_state.transformAnywhere = g_transformAnywhereSlot;
    write_state();
    write_conn();
    g_loadedHash = randomizer_GetContext().mHash;
    g_needsRegen = false;
    g_outstanding = -1;
    g_giveUpReconnect = false;
    g_lastLife = 0;
    g_lifeDropFrames = 0;
    g_phase = Phase::Playing;
    ap_log(fmt::format("new save created, hash {}, {} locations", g_loadedHash, g_locationIds.size()));
    after_seed_activated();
    return MOD_OK;
}

ModResult on_save_loaded(void* ud, ModError* err) {
    g_outstanding = -1;
    g_toSend.clear();
    g_giveUpReconnect = false;
    g_lastLife = 0;
    g_lifeDropFrames = 0;

    Conn conn;
    SaveState state;
    const bool haveConn = read_conn(conn);
    const bool haveState = read_state(state);

    std::string hash;
    {
        size_t size = 0;
        if (svc_mng.save->get_blob(svc_mng.mod_ctx, kSeedHashBlob, nullptr, &size) == MOD_OK && size != 0) {
            hash.resize(size);
            if (svc_mng.save->get_blob(svc_mng.mod_ctx, kSeedHashBlob, hash.data(), &size) == MOD_OK) {
                hash.resize(size);
            } else {
                hash.clear();
            }
        }
    }
    g_loadedHash = hash;

    // The seed files and the placement cache both live on this machine. If either is missing
    // (the save came from another computer) the seed is rebuilt from the server.
    bool cacheOk = false;
    if (haveState && !state.seed.empty() && !hash.empty()) {
        std::string cachedHash;
        cacheOk = load_placements(seed_base(state.seed, state.slot), cachedHash) && cachedHash == hash;
    }
    g_needsRegen = !seed_files_exist(hash) || !cacheOk;
    if (!g_needsRegen) {
        const ModResult r = randomizer::session::onSaveLoaded(ud, err);
        if (r != MOD_OK) {
            return r;
        }
        build_check_map();
        after_seed_activated();
    } else {
        randomizer::session::deactivateSeed();
        g_checkToLocations.clear();
        g_scan.clear();
    }

    const bool sameSession = g_client.state() == State::Connected && g_haveSlot && haveState &&
                             g_slotSeed == state.seed && g_client.info().slot == conn.slot;
    g_state = state;
    g_phase = Phase::Playing;
    ap_log(fmt::format("save loaded: seed '{}', {} server item(s) already delivered, {}{}", hash, state.received,
        haveConn && haveState ? "connection info present" : "NO connection info",
        g_needsRegen ? ", seed will be rebuilt from the server" : ""));
    if (!haveConn || !haveState) {
        toast("Archipelago", "This save has no Archipelago connection info.", "warning");
        return MOD_OK;
    }
    g_conn = conn;
    if (!sameSession) {
        g_serverItems.clear();
        g_haveSlot = false;
        g_client.connect({g_conn.server, g_conn.slot, g_conn.password});
    } else if (g_needsRegen) {
        begin_scouting();
    }
    return MOD_OK;
}

ModResult on_game_reset(void*, ModError*) {
    g_phase = Phase::Idle;
    g_outstanding = -1;
    g_toSend.clear();
    return MOD_OK;
}

}  // namespace ap::internal
