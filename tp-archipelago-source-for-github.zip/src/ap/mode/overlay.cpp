// The in-game overlay: what it shows, its settings and its tab. Drawing is ap_overlay.
//
// Ported from the community Archipelago mod's overlay (same drawing code, same settings). It is
// a small panel drawn at the end of the game's HUD pass, so it hides with the HUD. Its content
// here: connection, checks done (with a bar), the last items received or found, open hints that
// concern this slot, the last chat lines, and a reminder while death link is on.

#include "internal.hpp"

namespace ap::internal {

static uint32_t overlay_accent() {
    switch (g_client.state()) {
    case State::Connected: return kOvGreen;
    case State::Connecting:
    case State::Handshaking: return kOvYellow;
    default: return kOvRed;
    }
}

// How many of this slot's locations the server counts as checked.
static size_t checks_done() {
    size_t done = 0;
    for (const int64_t id : g_locationIds) {
        done += g_checked.count(id);
    }
    return done;
}

static std::vector<overlay::Line> overlay_lines() {
    using overlay::ascii_only;
    using overlay::Line;
    constexpr size_t kChars = 34;
    std::vector<Line> out;
    auto section = [&] {
        if (!out.empty()) {
            out.push_back(Line::divider());
        }
    };
    const auto now = std::chrono::steady_clock::now();
    const int64_t keep = cfg_int(g_ovKeep, 30);
    auto fresh = [&](const Recent& r) {
        return keep <= 0 || now - r.at < std::chrono::seconds(keep);
    };

    if (cfg_on(g_ovStatus)) {
        const char* state = g_client.state() == State::Connected ? "connected"
                            : g_client.state() == State::Connecting ||
                                      g_client.state() == State::Handshaking
                                ? "connecting"
                                : "offline";
        out.push_back(Line::text("Archipelago", kOvText, state, overlay_accent()));
    }
    if (cfg_on(g_ovChecks) && g_haveSlot && !g_locationIds.empty()) {
        const size_t done = checks_done();
        const size_t total = g_locationIds.size();
        section();
        out.push_back(Line::text("Checks", kOvText, fmt::format("{} / {}", done, total), kOvText));
        out.push_back(Line::bar(static_cast<float>(done) / static_cast<float>(total), kOvGreen));
        if (g_reachInputs != SIZE_MAX) {
            const auto n = region_counts(-1);
            out.push_back(Line::text("In logic now", kOvDim, std::to_string(n.inLogic),
                n.inLogic > 0 ? kOvGreen : kOvDim, true));
        }
    }
    if (cfg_on(g_ovItems)) {
        int64_t left = std::clamp<int64_t>(cfg_int(g_ovItemCount, 3), 1, 8);
        bool first = true;
        for (auto it = g_recentItems.rbegin(); it != g_recentItems.rend() && left > 0; ++it) {
            if (!fresh(*it)) {
                continue;
            }
            if (first) {
                section();
                first = false;
            }
            out.push_back(Line::text(ascii_only(it->item, kChars), kOvBlue, ascii_only(it->from, 16), kOvDim));
            --left;
        }
    }
    if (cfg_on(g_ovHints) && g_client.state() == State::Connected) {
        const int me = g_client.slot();
        // Anything that concerns us: our items wherever they are, and anyone's items in our world.
        std::vector<const Hint*> open;
        for (const auto& h : g_hints) {  // sorted, priority first
            if ((h.receivingPlayer == me || h.findingPlayer == me) && !h.found) {
                open.push_back(&h);
            }
        }
        if (!open.empty()) {
            section();
            out.push_back(Line::text("Hints", kOvText, fmt::format("{} open", open.size()), kOvYellow));
            const auto shown = static_cast<size_t>(std::clamp<int64_t>(cfg_int(g_ovHintCount, 3), 1, 8));
            for (size_t k = 0; k < open.size() && k < shown; ++k) {
                const Hint* h = open[k];
                // Right column: whose world our item is in, or whose item it is.
                const std::string who = h->receivingPlayer == me
                    ? (h->findingPlayer == me ? "your world" : ascii_only(player_label(h->findingPlayer), 16))
                    : "for " + ascii_only(player_label(h->receivingPlayer), 12);
                out.push_back(Line::text(ascii_only(g_client.itemName(h->item, h->receivingPlayer), kChars),
                    h->status == 30 ? kOvYellow : kOvText, who, kOvDim, true));
                out.push_back(Line::text(
                    ascii_only(g_client.locationName(h->location, h->findingPlayer), kChars + 6), kOvDim, {},
                    kOvDim, true));
            }
        }
    }
    if (cfg_on(g_ovChat)) {
        std::vector<const Recent*> lines;
        for (auto it = g_recentChat.rbegin(); it != g_recentChat.rend() && lines.size() < 3; ++it) {
            if (fresh(*it)) {
                lines.push_back(&*it);
            }
        }
        if (!lines.empty()) {
            section();
        }
        for (auto it = lines.rbegin(); it != lines.rend(); ++it) {  // oldest of them first
            out.push_back(Line::text(ascii_only((*it)->item, kChars + 6), kOvDim, {}, kOvDim, true));
        }
    }
    if (cfg_on(g_ovDeathLink) && death_link_on()) {
        section();
        out.push_back(Line::text("Death link", kOvRed, "on", kOvRed, true));
    }
    return out;
}

void post_meter2_draw(ModContext*, void*, void*, void*) {
    // Not dScnPly_c::isPause(): that's the hit-stop timer (set for a few frames when an attack
    // lands), and hiding the panel for it made it flicker. The panel only draws boxes and text,
    // so a frozen frame is fine; only the pause flag (menus) hides it.
    if (!cfg_on(g_ovEnabled) || !in_gameplay() || dComIfGp_isPauseFlag()) {
        return;
    }
    overlay::Layout layout;
    layout.corner = static_cast<overlay::Corner>(std::clamp<int64_t>(cfg_int(g_ovCorner, 3), 0, 5));
    layout.offsetX = static_cast<float>(cfg_int(g_ovX, 12));
    layout.offsetY = static_cast<float>(cfg_int(g_ovY, 0));
    layout.scale = static_cast<float>(cfg_int(g_ovScale, 100)) / 100.0f;
    layout.backgroundAlpha =
        static_cast<uint8_t>(std::clamp<int64_t>(cfg_int(g_ovOpacity, 60), 0, 100) * 255 / 100);
    layout.accent = overlay_accent();
    overlay::draw_panel(overlay_lines(), layout);
}

// Hold L and R and press D-Pad Left on the first controller to show or hide the overlay without
// opening the menu. D-Pad Left has no use in play (Up and Down open the item ring, Right the map),
// and it takes a deliberate L+R hold to get there.
void tick_overlay_shortcut() {
    const int64_t mode = cfg_int(g_ovShortcut, 1);
    if (mode == 0 || !in_gameplay() || dComIfGp_isPauseFlag()) {
        return;
    }
    constexpr u32 kPad = 0;
    const bool held = mDoCPd_c::getHoldL(kPad) != 0 && mDoCPd_c::getHoldR(kPad) != 0;
    const bool pressed = mDoCPd_c::getTrigLeft(kPad) != 0;
    if (held && pressed) {
        const bool now = !cfg_on(g_ovEnabled);
        svc_mng.config->set_bool(svc_mng.mod_ctx, g_ovEnabled, now);
        ap_log(std::string("overlay shortcut: ") + (now ? "on" : "off"));
    }
}

void register_overlay_vars() {
    auto reg_bool = [](const char* name, bool def, ConfigVarHandle& out) {
        ConfigVarDesc d = CONFIG_VAR_DESC_INIT;
        d.name = name;
        d.type = CONFIG_VAR_BOOL;
        d.default_bool = def;
        svc_mng.config->register_var(svc_mng.mod_ctx, &d, &out);
    };
    auto reg_int = [](const char* name, int64_t def, ConfigVarHandle& out) {
        ConfigVarDesc d = CONFIG_VAR_DESC_INIT;
        d.name = name;
        d.type = CONFIG_VAR_INT;
        d.default_int = def;
        svc_mng.config->register_var(svc_mng.mod_ctx, &d, &out);
    };
    reg_bool("overlay", true, g_ovEnabled);
    reg_int("overlayShortcut", 1, g_ovShortcut);
    reg_int("overlayCorner", 3, g_ovCorner);
    reg_int("overlayX", 12, g_ovX);
    reg_int("overlayY", 0, g_ovY);
    reg_int("overlayScale", 100, g_ovScale);
    reg_int("overlayBackground", 60, g_ovOpacity);
    reg_bool("overlayStatus", true, g_ovStatus);
    reg_bool("overlayChecks", true, g_ovChecks);
    reg_bool("overlayItems", true, g_ovItems);
    reg_bool("overlayHints", true, g_ovHints);
    reg_bool("overlayChat", true, g_ovChat);
    reg_bool("overlayDeathLink", true, g_ovDeathLink);
    reg_int("overlayItemCount", 3, g_ovItemCount);
    reg_int("overlayHintCount", 3, g_ovHintCount);
    reg_int("overlayKeepSeconds", 30, g_ovKeep);
}


// Overlay tab: every control is bound straight to its config var.
static void add_bound(ModContext* ctx, UiElementHandle pane, UiControlKind kind, const char* label,
    ConfigVarHandle var, const char* help, int64_t min, int64_t max, int64_t step, const char* suffix) {
    UiControlDesc d = UI_CONTROL_DESC_INIT;
    d.kind = kind;
    d.label = label;
    d.help_rml = help;
    d.binding = UI_BINDING_CONFIG_VAR;
    d.config_var = var;
    d.min = min;
    d.max = max;
    d.step = step;
    d.suffix = suffix;
    if (kind == UI_CONTROL_SELECT) {
        static const char* const corners[] = {"Top left", "Top right", "Middle left",
            "Middle right", "Bottom left", "Bottom right"};
        static const char* const shortcuts[] = {"Off", "L + R + D-Pad Left"};
        const bool isShortcut = var == g_ovShortcut;
        d.options = isShortcut ? shortcuts : corners;
        d.option_count = isShortcut ? std::size(shortcuts) : std::size(corners);
    }
    svc_mng.ui->pane_add_control(ctx, pane, &d, nullptr);
}

ModResult build_overlay_tab(ModContext* ctx, UiWindowHandle, UiElementHandle left, UiElementHandle,
    void*, ModError*) {
    add_bound(ctx, left, UI_CONTROL_TOGGLE, "Show overlay", g_ovEnabled,
        "A small panel of Archipelago info on screen while you play. It hides whenever the "
        "game's own HUD does.", 0, 0, 0, nullptr);
    add_bound(ctx, left, UI_CONTROL_SELECT, "Shortcut", g_ovShortcut,
        "Hold L and R on your controller and press D-Pad Left to show or hide the overlay without "
        "opening the menu.", 0, 0, 0, nullptr);
    svc_mng.ui->pane_add_section(ctx, left, "Placement");
    add_bound(ctx, left, UI_CONTROL_SELECT, "Position", g_ovCorner, nullptr, 0, 0, 0, nullptr);
    add_bound(ctx, left, UI_CONTROL_NUMBER, "Horizontal offset", g_ovX,
        "How far the panel sits from its side of the screen.", 0, 600, 5, nullptr);
    add_bound(ctx, left, UI_CONTROL_NUMBER, "Vertical offset", g_ovY,
        "How far it sits from the top or bottom. For the middle positions this moves it down, or "
        "up below zero.",
        -400, 400, 5, nullptr);
    add_bound(ctx, left, UI_CONTROL_NUMBER, "Size", g_ovScale, nullptr, 50, 200, 10, "%");
    add_bound(ctx, left, UI_CONTROL_NUMBER, "Background", g_ovOpacity, nullptr, 0, 100, 10, "%");
    svc_mng.ui->pane_add_section(ctx, left, "Show");
    add_bound(ctx, left, UI_CONTROL_TOGGLE, "Connection status", g_ovStatus, nullptr, 0, 0, 0, nullptr);
    add_bound(ctx, left, UI_CONTROL_TOGGLE, "Checks and logic", g_ovChecks,
        "Checks done out of all of this slot's locations, with a progress bar, and how many are in logic now.", 0, 0, 0, nullptr);
    add_bound(ctx, left, UI_CONTROL_TOGGLE, "Recent items", g_ovItems,
        "Items you just received or found, and who sent them.", 0, 0, 0, nullptr);
    add_bound(ctx, left, UI_CONTROL_NUMBER, "Recent items shown", g_ovItemCount, nullptr, 1, 8, 1, nullptr);
    add_bound(ctx, left, UI_CONTROL_TOGGLE, "Hints", g_ovHints,
        "Open hints that concern you: your items wherever they are, and anyone's items in your "
        "world. Priority hints come first.", 0, 0, 0, nullptr);
    add_bound(ctx, left, UI_CONTROL_NUMBER, "Hints shown", g_ovHintCount, nullptr, 1, 8, 1, nullptr);
    add_bound(ctx, left, UI_CONTROL_TOGGLE, "Chat", g_ovChat, "The last few chat messages.", 0, 0, 0, nullptr);
    add_bound(ctx, left, UI_CONTROL_TOGGLE, "Death link", g_ovDeathLink,
        "A reminder while death link is on.", 0, 0, 0, nullptr);
    add_bound(ctx, left, UI_CONTROL_NUMBER, "Fade items and chat after", g_ovKeep,
        "0 keeps them until newer ones push them out.", 0, 300, 5, " s");
    return MOD_OK;
}

}  // namespace ap::internal
