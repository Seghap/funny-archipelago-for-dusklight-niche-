// The tracker: logic built and searched on worker threads, and its tab.
//
// Ported from the community Archipelago mod's tracker. The logic is the randomizer generator's, run
// on the same settings and plando the seed was built from, so it answers "what can I reach with what
// I have?" the way the randomizer would, not exactly as the GameCube apworld's Python logic does:
// where they differ, the server's answer (what it lets you check) is the truth.

#include "internal.hpp"

namespace ap::internal {
namespace {


// kInLogicNow lists every check in logic under region headings; otherwise one region's checks,
// in logic first and done last.
constexpr int kInLogicNow = -2;
constexpr const char* kLegendRml =
    R"(<div class="ap-legend"><span class="ap-in"><span class="ap-dot"></span>in logic</span>)"
    R"(<span class="ap-glitch"><span class="ap-dot"></span>glitched only</span>)"
    R"(<span class="ap-out"><span class="ap-dot"></span>not yet</span>)"
    R"(<span class="ap-done"><span class="ap-dot"></span>done</span></div>)";
int g_trackerShownRegion = kInLogicNow;
std::pair<uint64_t, size_t> g_trackerShown{0, 0};

}  // namespace

// Used only in this file; defined below.
static CheckState check_state(const TrackerCheck& c);
static std::string tracker_summary();
static std::string region_label(int region);
static std::string check_row(const TrackerCheck& c, CheckState st);
static std::string region_rml(int region);
static float done_fraction();
static ModResult build_region_pane(ModContext* ctx, UiElementHandle pane, void* ud, ModError*);

void reset_tracker() {
    g_inLogic.clear();
    g_inGlitched.clear();
    g_reachInputs = SIZE_MAX;
    ++g_trackerVersion;
}

// The apworld's own logic (gc_logic.*), asked twice: Glitchless, and Glitched. A check that only the
// second reaches is shown in yellow. A search takes a few milliseconds, so it runs right here whenever
// the inputs (what the room has sent, what's been checked) change.
static void search_reach() {
    std::vector<std::string> received;  // the apworld's names for everything the server gave us
    for (const auto& it : g_serverItems) {
        const gc::Item* item = gc::find_item(it.item);
        if (item != nullptr) {
            received.emplace_back(item->gcName);
        }
    }
    const auto options = gc_logic::options_from_settings(g_slotSettings);
    auto ids = [](const std::unordered_set<int>& codes) {
        std::unordered_set<int64_t> out;
        for (const int code : codes) {
            out.insert(gc::kIdBase + code);
        }
        return out;
    };
    g_inLogic = ids(gc_logic::reachable(received, options, false));
    g_inGlitched = ids(gc_logic::reachable(received, options, true));
    size_t glitchedOnly = 0;
    for (const auto& c : g_trackerChecks) {
        glitchedOnly += g_inGlitched.contains(c.id) && !g_inLogic.contains(c.id);
    }
    size_t inLogic = 0;
    for (const auto& c : g_trackerChecks) {
        inLogic += g_inLogic.contains(c.id);
    }
    ap_log(fmt::format("tracker: {} of {} checks in logic ({} done), {} more with glitches", inLogic,
        g_trackerChecks.size(), g_checked.size(), glitchedOnly));
    // For the trail only (it is the one place to see exactly what the tracker decided)
    std::string inNames, glitchNames;
    for (const auto& c : g_trackerChecks) {
        if (g_inLogic.contains(c.id)) {
            inNames += c.name + "; ";
        } else if (g_inGlitched.contains(c.id)) {
            glitchNames += c.name + "; ";
        }
    }
    ap_log("tracker: in logic: " + inNames);
    ap_log("tracker: glitched only: " + glitchNames);
    ++g_trackerVersion;
}

void tick_tracker() {
    if (g_phase != Phase::Playing || !g_haveSlot || g_trackerChecks.empty()) {
        return;
    }
    // Items only ever arrive and checks only ever get done, so the two counts say when the
    // answer can have changed.
    const size_t inputs = g_serverItems.size() * 100003u + g_checked.size();
    if (inputs != g_reachInputs) {
        g_reachInputs = inputs;
        search_reach();
    }
}

static CheckState check_state(const TrackerCheck& c) {
    if (g_checked.contains(c.id)) {
        return CheckState::Done;
    }
    if (g_reachInputs == SIZE_MAX) {
        return CheckState::Unknown;
    }
    if (g_inLogic.contains(c.id)) {
        return CheckState::InLogic;
    }
    return g_inGlitched.contains(c.id) ? CheckState::Glitched : CheckState::NotYet;
}

RegionCounts region_counts(int region) {
    RegionCounts n;
    for (const auto& c : g_trackerChecks) {
        if (region >= 0 && c.region != region) {
            continue;
        }
        ++n.total;
        const auto st = check_state(c);
        n.done += st == CheckState::Done;
        n.inLogic += st == CheckState::InLogic;
        n.glitched += st == CheckState::Glitched;
    }
    return n;
}

static std::string tracker_summary() {
    if (!g_haveSlot) {
        return "Connect to your room to see your checks.";
    }
    const auto n = region_counts(-1);
    std::string s = fmt::format("{} of {} checks done", n.done, n.total);
    if (g_reachInputs != SIZE_MAX) {
        s += fmt::format(", {} in logic now", n.inLogic);
        if (n.glitched > 0) {
            s += fmt::format(" (+{} with glitches)", n.glitched);
        }
    }
    return s;
}

static std::string region_label(int region) {
    const auto n = region_counts(region);
    std::string label = fmt::format("{}   {}/{}", tracker_regions()[region].label, n.done, n.total);
    if (g_reachInputs != SIZE_MAX && n.inLogic > 0) {
        label += fmt::format("   ({} in logic)", n.inLogic);
    }
    if (g_reachInputs != SIZE_MAX && n.glitched > 0) {
        label += fmt::format("   (+{} glitched)", n.glitched);
    }
    return label;
}

static std::string check_row(const TrackerCheck& c, CheckState st) {
    const char* cls = st == CheckState::Done      ? "ap-done"
                      : st == CheckState::InLogic ? "ap-in"
                      : st == CheckState::Glitched ? "ap-glitch"
                      : st == CheckState::NotYet  ? "ap-out"
                                                  : "ap-unknown";
    return fmt::format(R"(<div class="ap-row {}"><span class="ap-dot"></span>{}</div>)", cls,
        rml_escape(c.name));
}

static std::string region_rml(int region) {
    if (!g_haveSlot) {
        return "";
    }
    std::string out;
    if (region == kInLogicNow) {
        if (g_reachInputs == SIZE_MAX) {
            return R"(<div class="ap-quiet">)" + rml_escape(tracker_summary()) + "</div>";
        }
        for (int r = 0; r < static_cast<int>(tracker_regions().size()); ++r) {
            std::string rows;
            size_t n = 0;
            for (const auto& c : g_trackerChecks) {
                if (c.region == r && check_state(c) == CheckState::InLogic) {
                    rows += check_row(c, CheckState::InLogic);
                    ++n;
                }
            }
            if (n > 0) {
                out += fmt::format(R"(<div class="ap-head">{} ({})</div>)",
                    rml_escape(tracker_regions()[r].label), n);
                out += rows;
            }
        }
        const bool anyInLogic = !out.empty();
        std::string glitchRows;
        for (int r = 0; r < static_cast<int>(tracker_regions().size()); ++r) {
            std::string rows;
            size_t n = 0;
            for (const auto& c : g_trackerChecks) {
                if (c.region == r && check_state(c) == CheckState::Glitched) {
                    rows += check_row(c, CheckState::Glitched);
                    ++n;
                }
            }
            if (n > 0) {
                glitchRows += fmt::format(R"(<div class="ap-head">{} ({})</div>)",
                    rml_escape(tracker_regions()[r].label), n);
                glitchRows += rows;
            }
        }
        if (!anyInLogic) {
            out = R"(<div class="ap-quiet">Nothing in logic right now.</div>)";
        }
        if (!glitchRows.empty()) {
            out += R"(<div class="ap-quiet" style="margin-top: 14dp;">In glitched logic only (the apworld counts these when Logic Settings is Glitched):</div>)" + glitchRows;
        }
        return out;
    }
    const auto& regions = tracker_regions();
    if (region < 0 || region >= static_cast<int>(regions.size())) {
        return "";
    }
    out += fmt::format(R"(<div class="ap-head">{}</div>)", rml_escape(region_label(region)));
    for (const auto want :
        {CheckState::InLogic, CheckState::Glitched, CheckState::Unknown, CheckState::NotYet, CheckState::Done}) {
        for (const auto& c : g_trackerChecks) {
            if (c.region == region && check_state(c) == want) {
                out += check_row(c, want);
            }
        }
    }
    return out;
}

static float done_fraction() {
    const auto n = region_counts(-1);
    return n.total == 0 ? 0.0f : static_cast<float>(n.done) / static_cast<float>(n.total);
}

static ModResult build_region_pane(ModContext* ctx, UiElementHandle pane, void* ud, ModError*) {
    g_trackerShownRegion = static_cast<int>(reinterpret_cast<intptr_t>(ud));
    g_trackerList = 0;
    return svc_mng.ui->pane_add_rml(
        ctx, pane, region_rml(g_trackerShownRegion).c_str(), &g_trackerList);
}

ModResult build_tracker_tab(ModContext* ctx, UiWindowHandle, UiElementHandle left,
    UiElementHandle right, void*, ModError*) {
    g_trackerSummary = g_trackerProgress = g_trackerList = 0;
    g_trackerGroups.clear();
    svc_mng.ui->pane_add_text(ctx, left, tracker_summary().c_str(), &g_trackerSummary);
    svc_mng.ui->pane_add_progress(ctx, left, done_fraction(), &g_trackerProgress);
    svc_mng.ui->pane_add_rml(ctx, left, kLegendRml, nullptr);

    UiGroupDesc now = UI_GROUP_DESC_INIT;
    now.label = "In logic now";
    now.build = build_region_pane;
    now.user_data = reinterpret_cast<void*>(static_cast<intptr_t>(kInLogicNow));
    svc_mng.ui->pane_add_group(ctx, left, right, &now, nullptr);

    svc_mng.ui->pane_add_section(ctx, left, "Regions");
    const auto& regions = tracker_regions();
    for (int r = 0; r < static_cast<int>(regions.size()); ++r) {
        if (region_counts(r).total == 0) {
            continue;
        }
        const std::string label = region_label(r);
        UiGroupDesc g = UI_GROUP_DESC_INIT;
        g.label = label.c_str();
        g.build = build_region_pane;
        g.user_data = reinterpret_cast<void*>(static_cast<intptr_t>(r));
        UiElementHandle elem = 0;
        svc_mng.ui->pane_add_group(ctx, left, right, &g, &elem);
        g_trackerGroups.emplace_back(elem, r);
    }

    // Open on what's in logic: the question mid-run is usually "what can I do now?".
    g_trackerShownRegion = kInLogicNow;
    svc_mng.ui->pane_add_rml(ctx, right, region_rml(kInLogicNow).c_str(), &g_trackerList);
    g_trackerShown = {g_trackerVersion, g_checked.size()};
    return MOD_OK;
}

ModResult update_tracker_tab(ModContext* ctx, void*, ModError*) {
    const std::pair<uint64_t, size_t> now{g_trackerVersion, g_checked.size()};
    if (now == g_trackerShown) {
        return MOD_OK;
    }
    g_trackerShown = now;
    if (g_trackerSummary != 0) {
        svc_mng.ui->elem_set_text(ctx, g_trackerSummary, tracker_summary().c_str());
    }
    if (g_trackerProgress != 0) {
        svc_mng.ui->elem_set_progress(ctx, g_trackerProgress, done_fraction());
    }
    for (const auto& [elem, region] : g_trackerGroups) {
        if (elem != 0) {
            svc_mng.ui->control_set_label(ctx, elem, region_label(region).c_str());
        }
    }
    if (g_trackerList != 0) {
        svc_mng.ui->elem_set_rml(ctx, g_trackerList, region_rml(g_trackerShownRegion).c_str());
    }
    return MOD_OK;
}

}  // namespace ap::internal
