// Shared helpers: the debug log, toasts, config vars, save blobs, status text, server address.

#include "internal.hpp"

namespace ap::internal {
namespace {

std::unordered_map<int, std::string> g_itemNames;
constexpr size_t kLogLines = 12;
constexpr size_t kRoomLogLines = 200;

}  // namespace


// ---------------------------------------------------------------------------------------
// Logging and messages

// Flushed debug trail next to the mod's data; the host log buffers too much to debug with.
void ap_log(const std::string& line) {
    mods::log::debug("archipelago: {}", line);
    if (!cfg_on(g_cfgDebugLog)) {
        return;
    }
    const char* dir = nullptr;
    if (svc_mng.host->data_dir(svc_mng.mod_ctx, &dir) != MOD_OK || dir == nullptr) {
        return;
    }
    const auto now = std::chrono::system_clock::to_time_t(std::chrono::system_clock::now());
    std::tm tm{};
#ifdef _WIN32
    localtime_s(&tm, &now);
#else
    localtime_r(&now, &tm);
#endif
    const std::string stamped =
        fmt::format("{:02}:{:02}:{:02} {}", tm.tm_hour, tm.tm_min, tm.tm_sec, line);
    if (std::FILE* f = std::fopen((std::filesystem::path(dir) / "ap_debug.log").string().c_str(), "a")) {
        std::fputs(stamped.c_str(), f);
        std::fputc('\n', f);
        std::fclose(f);
    }
}

const std::string& item_name(int id) {
    if (g_itemNames.empty()) {
        for (const auto& node : LOAD_EMBED_YAML(RANDO_DATA_PATH "items.yaml")) {
            if (node["Id"] && node["Name"]) {
                g_itemNames[node["Id"].as<int>()] = node["Name"].as<std::string>();
            }
        }
    }
    static const std::string unknown = "an item";
    const auto it = g_itemNames.find(id);
    return it != g_itemNames.end() ? it->second : unknown;
}

// Plain text with line breaks as RML: the UI collapses "\n" in text rows, so lines are joined
// with <br/>. Every line is made safe first (server text lands here: chat, names).
std::string rml_lines(const std::string& text) {
    std::string out;
    size_t start = 0;
    while (start <= text.size()) {
        const size_t end = text.find('\n', start);
        const std::string line = text.substr(start, end == std::string::npos ? std::string::npos : end - start);
        if (start != 0) {
            out += "<br/>";
        }
        out += rml_escape(message_safe(line, 400));
        if (end == std::string::npos) {
            break;
        }
        start = end + 1;
    }
    return out;
}

void toast(const std::string& title, const std::string& body, const char* type, uint32_t ms) {
    // Server chat and refusal messages land here, so bound what we are willing to render.
    const std::string t = rml_escape(message_safe(title, 80));
    const std::string b = rml_escape(message_safe(body, 400));
    UiToastDesc desc = UI_TOAST_DESC_INIT;
    desc.type = type;
    desc.title_rml = t.c_str();
    desc.body_rml = b.c_str();
    desc.duration_ms = ms;
    svc_mng.ui->push_toast(svc_mng.mod_ctx, &desc);
}

// A line for the status tab's recent-messages box (plain text, bounded).
void log_rml(std::string rml) {
    g_logRml.push_back(std::move(rml));
    while (g_logRml.size() > kRoomLogLines) {
        g_logRml.pop_front();
    }
    ++g_logVersion;
}

bool not_connected(ModContext*, void*) {
    return g_client.state() != State::Connected;
}

void add_log(const std::string& line) {
    g_log.push_back(message_safe(line, 240));
    while (g_log.size() > kLogLines) {
        g_log.pop_front();
    }
}


// ---------------------------------------------------------------------------------------
// Config

// A pasted key often brings a space or newline along.
std::string trim_key(std::string key) {
    std::erase_if(key, [](char c) { return c == ' ' || c == '\t' || c == '\r' || c == '\n'; });
    return key;
}

std::string config_string(ConfigVarHandle var) {
    if (var == 0) {
        return {};
    }
    size_t len = 0;
    if (svc_mng.config->get_string(svc_mng.mod_ctx, var, nullptr, 0, &len) != MOD_OK || len == 0) {
        return {};
    }
    std::string s(len, '\0');
    if (svc_mng.config->get_string(svc_mng.mod_ctx, var, s.data(), s.size() + 1, &len) != MOD_OK) {
        return {};
    }
    s.resize(std::strlen(s.c_str()));
    return s;
}

int64_t cfg_int(ConfigVarHandle h, int64_t fallback) {
    int64_t v = fallback;
    if (h != 0) {
        svc_mng.config->get_int(svc_mng.mod_ctx, h, &v);
    }
    return v;
}

bool cfg_on(ConfigVarHandle h) {
    bool v = false;
    if (h != 0) {
        svc_mng.config->get_bool(svc_mng.mod_ctx, h, &v);
    }
    return v;
}


// ---------------------------------------------------------------------------------------
// Save blobs: the connection this save was made with, and how far it has got.
// The password is stored in the save in plain text so that an existing save can reconnect by
// itself; the blob lives in the save file, next to the game's own data.

void write_conn() {
    const std::string s =
        json{{"server", g_conn.server}, {"slot", g_conn.slot}, {"password", g_conn.password}}.dump();
    svc_mng.save->set_blob(svc_mng.mod_ctx, kConnBlob, s.data(), s.size());
}

void write_state() {
    const std::string s = json{{"received", g_state.received}, {"goal", g_state.goal},
        {"seed", g_state.seed}, {"slot", g_state.slot}, {"death_link", g_state.deathLink},
        {"transform_anywhere", g_state.transformAnywhere}}
                              .dump();
    svc_mng.save->set_blob(svc_mng.mod_ctx, kStateBlob, s.data(), s.size());
}

static bool read_blob_json(const char* name, json& out) {
    size_t size = 0;
    if (svc_mng.save->get_blob(svc_mng.mod_ctx, name, nullptr, &size) != MOD_OK || size == 0) {
        return false;
    }
    std::string buf(size, '\0');
    if (svc_mng.save->get_blob(svc_mng.mod_ctx, name, buf.data(), &size) != MOD_OK) {
        return false;
    }
    buf.resize(size);
    out = json::parse(buf, nullptr, false);
    return !out.is_discarded() && out.is_object();
}

bool read_conn(Conn& out) {
    json j;
    if (!read_blob_json(kConnBlob, j)) {
        return false;
    }
    out = Conn{};
    out.server = j.value("server", out.server);
    out.slot = j.value("slot", "");
    out.password = j.value("password", "");
    return true;
}

bool read_state(SaveState& out) {
    json j;
    if (!read_blob_json(kStateBlob, j)) {
        return false;
    }
    out = SaveState{};
    out.received = j.value("received", 0);
    out.goal = j.value("goal", false);
    out.seed = j.value("seed", "");
    out.slot = j.value("slot", "");
    out.deathLink = j.value("death_link", -1);
    out.transformAnywhere = j.value("transform_anywhere", false);
    return true;
}


// ---------------------------------------------------------------------------------------
// Status

std::string status_line() {
    switch (g_client.state()) {
    case State::Connected:
        return "Connected to " + g_client.info().server + " as " + g_client.info().slot;
    case State::Connecting:
    case State::Handshaking:
        return "Connecting to " + g_client.info().server + "...";
    case State::Refused:
        return "Connection refused: " + g_client.lastError();
    default:
        return g_client.lastError().empty() ? "Disconnected" : "Disconnected: " + g_client.lastError();
    }
}

bool in_gameplay() {
    return g_phase == Phase::Playing && !g_needsRegen && randomizer_IsActive() &&
           !playerIsOnTitleScreen() && dComIfGp_getPlayer(0) != nullptr;
}

void get_str(ModContext*, void* ud, UiControlValue* out) {
    out->string_value = static_cast<std::string*>(ud)->c_str();
}

void set_str(ModContext*, void* ud, const UiControlValue* v) {
    *static_cast<std::string*>(ud) = v->string_value != nullptr ? v->string_value : "";
}


// ---------------------------------------------------------------------------------------
// Server address: the connect window has a host and a port, but people paste whole addresses.

static std::string trim(std::string s) {
    while (!s.empty() && std::isspace(static_cast<unsigned char>(s.back()))) {
        s.pop_back();
    }
    size_t i = 0;
    while (i < s.size() && std::isspace(static_cast<unsigned char>(s[i]))) {
        ++i;
    }
    return s.substr(i);
}

bool split_server(const std::string& text, std::string& host, int64_t& port) {
    std::string rest = trim(text);
    std::string scheme;
    for (const char* prefix : {"wss://", "ws://"}) {
        if (rest.starts_with(prefix)) {
            scheme = prefix;
            rest = rest.substr(scheme.size());
            break;
        }
    }
    if (const auto slash = rest.find('/'); slash != std::string::npos) {
        rest.resize(slash);
    }
    if (rest.empty()) {
        return false;
    }
    const auto colon = rest.rfind(':');
    const auto bracket = rest.rfind(']');
    if (colon != std::string::npos && (bracket == std::string::npos || bracket < colon)) {
        const std::string digits = rest.substr(colon + 1);
        if (digits.empty() || digits.size() > 5 ||
            !std::all_of(digits.begin(), digits.end(), [](char c) { return std::isdigit(static_cast<unsigned char>(c)); })) {
            return false;
        }
        const long value = std::strtol(digits.c_str(), nullptr, 10);
        if (value < 1 || value > 65535) {
            return false;
        }
        port = value;
        rest.resize(colon);
    }
    if (rest.empty()) {
        return false;
    }
    host = scheme + rest;
    return true;
}

std::string join_server(const std::string& host, int64_t port) {
    return host + ":" + std::to_string(port);
}

}  // namespace ap::internal
