// The Items tab: everything the room has sent this save, newest first, with who found it and where
// and whether it has reached Link yet; and, once the goal is reached, the room's release and collect
// commands as buttons (when the room allows them).

#include "internal.hpp"

namespace ap::internal {

void note_items_changed() {
    ++g_itemsVersion;
}

static const char* item_class(int flags) {
    return (flags & 1) ? "ap-prog" : (flags & 2) ? "ap-useful" : (flags & 4) ? "ap-trap" : "ap-item";
}

static std::string items_rml() {
    if (g_serverItems.empty()) {
        return R"(<div class="ap-msg ap-quiet">Nothing has been sent to you yet.</div>)";
    }
    std::string out;
    const int me = g_client.slot();
    int shown = 0;
    for (int i = static_cast<int>(g_serverItems.size()) - 1; i >= 0 && shown < 300; --i, ++shown) {
        const NetworkItem& it = g_serverItems[i];
        std::string row = fmt::format(R"(<div class="ap-msg"><span class="{}">{}</span>)", item_class(it.flags),
            rml_escape(message_safe(g_client.itemName(it.item, me), 80)));
        if (it.location >= 0 && it.player != me) {
            row += fmt::format(R"( from <span class="ap-player">{}</span>)", rml_escape(message_safe(player_label(it.player), 40)));
            row += fmt::format(R"( at <span class="ap-loc">{}</span>)",
                rml_escape(message_safe(g_client.locationName(it.location, it.player), 80)));
        } else if (it.location >= 0) {
            row += " from you";
        } else {
            row += R"(&nbsp;<span class="ap-quiet">(the server)</span>)";
        }
        const bool delivered = i < g_state.received;
        row += delivered ? R"(&nbsp;&nbsp;<span class="ap-quiet">in your game</span>)"
                     : R"(&nbsp;&nbsp;<span class="ap-ent">waiting for a safe moment</span>)";
        out += row + "</div>";
    }
    return out;
}

static std::string items_summary() {
    const int total = static_cast<int>(g_serverItems.size());
    const int waiting = std::max(0, total - g_state.received);
    std::string s = fmt::format("{} item{} received, {} waiting to reach Link.", total, total == 1 ? "" : "s", waiting);
    if (g_client.state() != State::Connected) {
        s += " (Offline: new items arrive when you reconnect.)";
    }
    return s;
}

// The server's rule: bit 1 any time, bit 2 once the goal is reached.
static bool allowed_now(const char* what) {
    const int perm = g_client.permission(what);
    return (perm & 1) != 0 || ((perm & 2) != 0 && g_state.goal);
}

static const char* why_not(const char* what) {
    const int perm = g_client.permission(what);
    if (g_client.state() != State::Connected) {
        return "Connect to your room first.";
    }
    if (perm == 0) {
        return "This room doesn't allow it.";
    }
    if (!allowed_now(what)) {
        return g_state.goal ? "This room doesn't allow it." : "This room allows it once your goal is complete.";
    }
    return nullptr;
}

static bool release_disabled(ModContext*, void*) { return why_not("release") != nullptr; }
static bool collect_disabled(ModContext*, void*) { return why_not("collect") != nullptr; }

static void press_collect(ModContext*, void*) {
    if (!collect_disabled(nullptr, nullptr)) {
        g_client.say("!collect");
    }
}

static void press_release(ModContext*, void*) {
    if (release_disabled(nullptr, nullptr)) {
        return;
    }
    // Releasing hands every item still in your world to the players it belongs to, and cannot be undone.
    static const UiDialogAction actions[] = {
        {sizeof(UiDialogAction), "Release", [](ModContext*, UiDialogHandle, void*) { g_client.say("!release"); }, nullptr,
            false, nullptr},
        {sizeof(UiDialogAction), "Cancel", [](ModContext*, UiDialogHandle, void*) {}, nullptr, false, nullptr},
    };
    UiDialogDesc d = UI_DIALOG_DESC_INIT;
    d.title = "Release the rest of your items?";
    d.body_rml = "Every item still waiting in your world is sent to the players it belongs to, and your remaining "
                 "locations count as checked. This can't be undone.";
    d.variant = UI_DIALOG_NORMAL;
    d.icon = "warning";
    d.actions = actions;
    d.action_count = std::size(actions);
    svc_mng.ui->dialog_push(svc_mng.mod_ctx, &d, nullptr);
}

ModResult build_items_tab(ModContext* ctx, UiWindowHandle, UiElementHandle left, UiElementHandle, void*,
    ModError*) {
    g_itemsSummary = g_itemsList = 0;
    svc_mng.ui->pane_add_text(ctx, left, items_summary().c_str(), &g_itemsSummary);

    svc_mng.ui->pane_add_section(ctx, left, "When you've finished");
    UiControlDesc collect = UI_CONTROL_DESC_INIT;
    collect.kind = UI_CONTROL_BUTTON;
    collect.label = "Collect (!collect)";
    collect.help_rml = "Asks the room to send you the items other worlds are holding for you. Rooms usually "
                       "allow it once your goal is complete.";
    collect.on_pressed = press_collect;
    collect.is_disabled = collect_disabled;
    svc_mng.ui->pane_add_control(ctx, left, &collect, nullptr);

    UiControlDesc release = UI_CONTROL_DESC_INIT;
    release.kind = UI_CONTROL_BUTTON;
    release.label = "Release (!release)";
    release.help_rml = "Sends every item still in your world to its owner and counts your remaining checks as "
                       "done. Rooms usually allow it once your goal is complete. Asks to confirm first.";
    release.on_pressed = press_release;
    release.is_disabled = release_disabled;
    svc_mng.ui->pane_add_control(ctx, left, &release, &g_itemsRelease);
    svc_mng.ui->pane_add_rml(ctx, left,
        R"(<div class="ap-quiet">The goal is reported when Ganondorf falls; if it wasn't noticed, use "Send goal complete" )"
        R"(on the Status tab.</div>)",
        nullptr);

    svc_mng.ui->pane_add_section(ctx, left, "Received");
    svc_mng.ui->pane_add_rml(ctx, left, items_rml().c_str(), &g_itemsList);
    g_itemsShown = {g_itemsVersion, g_state.goal};
    return MOD_OK;
}

ModResult update_items_tab(ModContext* ctx, void*, ModError*) {
    const std::pair<uint64_t, bool> now{g_itemsVersion + static_cast<uint64_t>(g_state.received) * 1000003u, g_state.goal};
    if (now == g_itemsShown) {
        return MOD_OK;
    }
    g_itemsShown = now;
    if (g_itemsSummary != 0) {
        svc_mng.ui->elem_set_text(ctx, g_itemsSummary, items_summary().c_str());
    }
    if (g_itemsList != 0) {
        svc_mng.ui->elem_set_rml(ctx, g_itemsList, items_rml().c_str());
    }
    return MOD_OK;
}

}  // namespace ap::internal
