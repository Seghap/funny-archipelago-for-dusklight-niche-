// The Archipelago window: the Status tab (connection, reconnect, death link, goal) and the window
// that holds the other tabs (Tracker, Hints, Messages, Overlay).

#include "internal.hpp"

namespace ap::internal {
// Used only in this file; defined below.
static void press_reconnect(ModContext*, void*);
static void press_disconnect(ModContext*, void*);
static std::string status_text();
static ModResult build_status_tab(ModContext*, UiWindowHandle, UiElementHandle left, UiElementHandle, void*, ModError*);
static ModResult update_status_tab(ModContext*, void*, ModError*);

static void press_reconnect(ModContext*, void*) {
    std::string host;
    int64_t port = g_editPort;
    if (split_server(g_editHost, host, port)) {
        const std::string server = join_server(host, port);
        if (server != g_conn.server) {
            g_conn.server = server;  // the room may have moved to a new port
            if (g_phase == Phase::Playing) {
                write_conn();
            }
        }
    }
    g_giveUpReconnect = false;
    if (!g_conn.slot.empty()) {
        g_client.connect({g_conn.server, g_conn.slot, g_conn.password});
    }
}

static void press_disconnect(ModContext*, void*) {
    g_client.disconnect();
    g_giveUpReconnect = true;  // the player chose this: no automatic retry
}

static std::string status_text() {
    std::string s = status_line();
    if (g_phase == Phase::Playing) {
        s += fmt::format("\nItems received: {} / {}", g_state.received, g_serverItems.size());
        if (const std::string waiting = delivery_status(); !waiting.empty()) {
            s += "\n" + waiting;
        }
        if (g_haveSlot) {
            size_t done = 0;
            for (const int64_t id : g_locationIds) {
                done += g_checked.contains(id) ? 1 : 0;
            }
            s += fmt::format("\nChecks sent: {} / {}", done, g_locationIds.size());
        }
        if (!g_worldVersion.empty()) {
            s += "\nApworld: " + message_safe(g_worldVersion, 24);
        }
        if (g_state.transformAnywhere) {
            s += "\nTransform anywhere: on (from your YAML)";
        }
        if (g_state.goal) {
            s += "\nGoal complete!";
        }
        if (g_needsRegen) {
            s += "\nWaiting to rebuild this save's seed from the server.";
        }
        if (g_giveUpReconnect && g_client.state() != State::Connected) {
            s += "\nNot retrying automatically. Press Reconnect when ready.";
        } else if (g_client.state() == State::Disconnected && !g_conn.slot.empty()) {
            // tick() retries after 600 frames (about ten seconds at 60 fps)
            s += fmt::format("\nReconnecting in {} s. Checks made meanwhile are kept and sent then.",
                std::max(1, (600 - g_reconnectFrames + 59) / 60));
        }
    }
    return s;
}

static ModResult build_status_tab(ModContext* ctx, UiWindowHandle, UiElementHandle left, UiElementHandle,
    void*, ModError*) {
    split_server(g_conn.server, g_editHost, g_editPort);
    if (g_editHost.empty()) {
        g_editHost = "archipelago.gg";
    }

    svc_mng.ui->pane_add_section(ctx, left, "Connection");
    g_statusWindowText = 0;
    svc_mng.ui->pane_add_rml(ctx, left, rml_lines(status_text()).c_str(), &g_statusWindowText);

    UiControlDesc host = UI_CONTROL_DESC_INIT;
    host.kind = UI_CONTROL_STRING;
    host.label = "Host";
    host.help_rml = "Change this if the room moved, then press Reconnect.";
    host.get = get_str;
    host.set = set_str;
    host.user_data = &g_editHost;
    host.max_length = 128;
    host.string_set_mode = UI_STRING_SET_ON_CHANGE;
    svc_mng.ui->pane_add_control(ctx, left, &host, nullptr);

    UiControlDesc port = UI_CONTROL_DESC_INIT;
    port.kind = UI_CONTROL_NUMBER;
    port.label = "Port";
    port.min = 1;
    port.max = 65535;
    port.step = 1;
    port.get = [](ModContext*, void*, UiControlValue* out) { out->int_value = g_editPort; };
    port.set = [](ModContext*, void*, const UiControlValue* v) { g_editPort = v->int_value; };
    svc_mng.ui->pane_add_control(ctx, left, &port, nullptr);

    UiControlDesc reconnect = UI_CONTROL_DESC_INIT;
    reconnect.kind = UI_CONTROL_BUTTON;
    reconnect.label = "Reconnect";
    reconnect.on_pressed = press_reconnect;
    svc_mng.ui->pane_add_control(ctx, left, &reconnect, nullptr);

    UiControlDesc disconnect = UI_CONTROL_DESC_INIT;
    disconnect.kind = UI_CONTROL_BUTTON;
    disconnect.label = "Disconnect";
    disconnect.on_pressed = press_disconnect;
    svc_mng.ui->pane_add_control(ctx, left, &disconnect, nullptr);

    UiControlDesc goal = UI_CONTROL_DESC_INIT;
    goal.kind = UI_CONTROL_BUTTON;
    goal.label = "Send goal complete";
    goal.help_rml = "Tells the server you finished the game, in case it wasn't detected.";
    goal.on_pressed = [](ModContext*, void*) { complete_goal("manual"); };
    goal.is_disabled = [](ModContext*, void*) {
        return g_state.goal || g_client.state() != State::Connected || g_phase != Phase::Playing;
    };
    svc_mng.ui->pane_add_control(ctx, left, &goal, nullptr);

    UiControlDesc dl = UI_CONTROL_DESC_INIT;
    dl.kind = UI_CONTROL_TOGGLE;
    dl.label = "Death link";
    dl.help_rml = "When anyone else with death link dies, so do you, and the other way round. "
                  "Starts from your YAML; changing it here sticks to this save.";
    dl.get = [](ModContext*, void*, UiControlValue* out) { out->bool_value = death_link_on(); };
    dl.set = [](ModContext*, void*, const UiControlValue* v) {
        g_state.deathLink = v->bool_value ? 1 : 0;
        write_state();
        apply_death_link_tags();
    };
    dl.is_disabled = [](ModContext*, void*) { return g_phase != Phase::Playing; };
    svc_mng.ui->pane_add_control(ctx, left, &dl, nullptr);

    add_box_settings(ctx, left);

    return MOD_OK;
}

static ModResult update_status_tab(ModContext* ctx, void*, ModError*) {
    if (g_coverStatusText != 0) {
        static std::string shownCovers;
        const std::string now = covers::status();
        if (now != shownCovers) {
            shownCovers = now;
            svc_mng.ui->elem_set_text(ctx, g_coverStatusText, now.c_str());
        }
    }
    if (g_statusWindowText != 0) {
        static std::string shown;
        const std::string now = status_text();
        if (now != shown) {
            shown = now;
            svc_mng.ui->elem_set_rml(ctx, g_statusWindowText, rml_lines(now).c_str());
        }
    }
    return MOD_OK;
}

void open_status_window(ModContext*, void*) {
    static UiTabDesc tabs[6] = {UI_TAB_DESC_INIT, UI_TAB_DESC_INIT, UI_TAB_DESC_INIT, UI_TAB_DESC_INIT,
        UI_TAB_DESC_INIT, UI_TAB_DESC_INIT};
    tabs[0].title = "Status";
    tabs[0].build = build_status_tab;
    tabs[0].update = update_status_tab;
    tabs[1].title = "Tracker";
    tabs[1].build = build_tracker_tab;
    tabs[1].update = update_tracker_tab;
    tabs[2].title = "Hints";
    tabs[2].build = build_hints_tab;
    tabs[2].update = update_hints_tab;
    tabs[3].title = "Messages";
    tabs[3].build = build_messages_tab;
    tabs[3].update = update_messages_tab;
    tabs[4].title = "Items";
    tabs[4].build = build_items_tab;
    tabs[4].update = update_items_tab;
    tabs[5].title = "Overlay";
    tabs[5].build = build_overlay_tab;
    UiWindowDesc desc = UI_WINDOW_DESC_INIT;
    desc.tabs = tabs;
    desc.tab_count = 6;
    desc.rcss = kWindowRcss;
    desc.on_closed = [](ModContext*, UiWindowHandle, void*) {
        g_statusWindow = 0;
        g_statusWindowText = 0;
        g_coverStatusText = 0;
        g_logElem = 0;
        g_hintsSummary = g_hintDetails = 0;
        g_hintsList = 0;
        g_itemsSummary = g_itemsList = g_itemsRelease = 0;
    };
    svc_mng.ui->window_push(svc_mng.mod_ctx, &desc, &g_statusWindow);
}

}  // namespace ap::internal
