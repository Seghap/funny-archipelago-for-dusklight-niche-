// Checks and items: server events, the item resolver and give observer, sending checks,
// delivering received items when it is safe, and the goal.

#include "internal.hpp"

namespace ap::internal {

// ---------------------------------------------------------------------------------------
// Server events (all handled here, on the game thread, from ap::update)

void on_connected(const json& packet) {
    std::string err;
    if (!load_slot_data(packet, err)) {
        g_status = err;
        add_log(err);
        toast("Archipelago", err, "warning", 9000);
        g_client.disconnect();
        if (g_phase == Phase::NewSave || g_phase == Phase::Scouting) {
            g_phase = Phase::NewSave;  // the window stays open so the player can fix it and retry
        } else {
            g_giveUpReconnect = true;
        }
        return;
    }
    apply_death_link_tags();

    // What the server already counts as checked. Anything we obtained while away is found again
    // by scan_locations (from the save's own flags) and sent.
    g_checked.clear();
    const json checked = packet.value("checked_locations", json::array());
    for (const auto& id : checked) {
        if (id.is_number_integer()) {
            g_checked.insert(id.get<int64_t>());
        }
    }
    ap_log(fmt::format("connected in phase {}: {} locations ({} checked), {} unknown to this mod",
        static_cast<int>(g_phase), g_locationIds.size(), g_checked.size(), g_unknownLocations));
    add_log(status_line());

    if (g_phase == Phase::NewSave) {
        begin_scouting();
        return;
    }
    if (g_phase == Phase::Playing) {
        if (!g_state.seed.empty() && g_state.seed != g_slotSeed) {
            toast("Archipelago", "This save belongs to a different multiworld. Disconnected.", "warning", 8000);
            g_client.disconnect();
            g_haveSlot = false;
            g_giveUpReconnect = true;
            return;
        }
        if (g_state.transformAnywhere != g_transformAnywhereSlot) {
            g_state.transformAnywhere = g_transformAnywhereSlot;
            write_state();
        }
        if (g_needsRegen) {
            toast("Archipelago", "Rebuilding this save's seed from the server...");
            begin_scouting();
            return;
        }
        if (g_scan.empty()) {
            build_check_map();
        }
        toast("Archipelago", status_line(), "success", 3000);
        if (g_state.goal) {
            g_client.sendGoal();
        }
    }
}

void on_items(int index, const std::vector<NetworkItem>& items) {
    if (index == 0) {
        g_serverItems.clear();
    }
    if (static_cast<size_t>(index) != g_serverItems.size()) {
        g_client.sendSync();  // gap: ask for the full list again
        return;
    }
    g_serverItems.insert(g_serverItems.end(), items.begin(), items.end());
    note_items_changed();
    ap_log(fmt::format("server sent {} item(s) from index {}; {} in total, {} already delivered to this file",
        items.size(), index, g_serverItems.size(), g_state.received));
}

static int hint_rank(const Hint& h) {
    if (h.found) {
        return 4;
    }
    switch (h.status) {
    case 30: return 0;  // priority
    case 0: return 1;   // unspecified
    case 10: return 2;  // no priority
    default: return 3;  // avoid
    }
}

void on_hints(const std::vector<Hint>& hints) {
    g_hints = hints;
    std::stable_sort(g_hints.begin(), g_hints.end(),
        [](const Hint& a, const Hint& b) { return hint_rank(a) < hint_rank(b); });
    ++g_hintsVersion;
}

void note_recent_item(const std::string& item, const std::string& from) {
    g_recentItems.push_back({item, from, std::chrono::steady_clock::now()});
    while (g_recentItems.size() > 8) {
        g_recentItems.pop_front();
    }
}

void on_checked(const std::vector<int64_t>& locations) {
    size_t added = 0;
    for (const int64_t id : locations) {
        added += g_checked.insert(id).second ? 1 : 0;
    }
    if (added != 0) {
        // Other players' finds, a release or a collect: the room counts more of our locations as done.
        ap_log(fmt::format("the room counts {} more location(s) as checked ({} of {} now)", added, g_checked.size(),
            g_locationIds.size()));
    }
}

void on_print(const std::string& text, const json& msg) {
    add_log(text);
    log_rml(print_rml(msg.value("data", json::array()), g_client));
    const std::string type = msg.value("type", "");
    const int me = g_client.slot();
    if (type == "ItemSend" || type == "ItemCheat") {
        const int receiver = json_num(msg, "receiving", -1);
        const int sender = msg.contains("item") ? json_num(msg["item"], "player", -1) : -1;
        if (receiver == me || sender == me) {
            if (receiver == me && sender == me) {
                return;  // our own item at our own location: the game already showed it
            }
            toast("Archipelago", text, nullptr, 4000);
        }
    } else if (type == "Hint") {
        const int receiver = json_num(msg, "receiving", -1);
        const int finder = msg.contains("item") ? json_num(msg["item"], "player", -1) : -1;
        if (!msg.value("found", false) && (receiver == me || finder == me)) {
            toast("Hint", text, nullptr, 6000);
        }
    } else if (type == "Goal" || type == "Release" || type == "Collect" || type == "Countdown" ||
               type == "CommandResult") {  // CommandResult: the answer to !release, !remaining, !hint ...
        toast("Archipelago", text, nullptr, 4000);
    } else if (type == "Chat" || type == "ServerChat") {
        toast("Archipelago", text, nullptr, 5000);
        g_recentChat.push_back({text, {}, std::chrono::steady_clock::now()});
        while (g_recentChat.size() > 8) {
            g_recentChat.pop_front();
        }
    }
}

void on_disconnected(const std::string& reason, bool refused) {
    add_log("Disconnected: " + reason);
    log_rml(R"(<span class="ap-quiet">)" + rml_escape(message_safe("Disconnected: " + reason, 300)) + "</span>");
    switch (g_phase) {
    case Phase::NewSave:
        g_status = "Could not connect: " + reason;
        break;
    case Phase::Scouting:
        // The answers will never come. (A drop while the seed is building changes nothing:
        // generation needs no network.)
        g_status = "Lost the connection while asking the server: " + reason;
        g_placements.clear();
        g_scoutedIds.clear();
        g_phase = g_needsRegen ? Phase::Playing : Phase::NewSave;
        break;
    case Phase::Playing:
        toast("Archipelago", "Disconnected: " + reason, "warning", 4000);
        if (refused) {
            g_giveUpReconnect = true;  // retrying the same way would fail the same way
        }
        break;
    default:
        break;
    }
}


// ---------------------------------------------------------------------------------------
// ItemService callbacks

// Runs after the randomizer's own resolver. For every check that is one of this slot's
// locations it has the last word, and the word is always an explicit item: our own item, or the
// placeholder for another world's. It never answers "not mine", which is what would leave the
// vanilla item (or a default rupee) in the chest.
bool resolve_check(ModContext*, const ItemCheckInfo* info, ItemCheckResolution* out, void*) {
    if (info == nullptr || info->name == nullptr || out == nullptr || g_placements.empty()) {
        return false;
    }
    const auto locs = locations_for_check(info->name);
    if (locs.empty()) {
        return false;  // not a location of this slot: the seed (vanilla) decides
    }
    const auto it = g_placements.find(locs.front());
    uint8_t item = kApItem;
    uint8_t display = kApItem;
    if (it != g_placements.end() && it->second.own) {
        item = static_cast<uint8_t>(verifyProgressiveItem(static_cast<u32>(it->second.giveByte)));
        display = item;
        if (item == dItemNo_Randomizer_FOOLISH_ITEM_e) {
            // Traps are disguised, exactly as the randomizer does for its own.
            display = randomizer_getRandomFoolishItemModelID(info->name);
        }
    } else {
        // Another world's item, or (which should not happen after scouting) one we know nothing
        // about: either way it is the placeholder, and the check is still reported.
        g_lastResolvedApLocation = locs.front();
        if (info->giver_actor != nullptr) {
            g_actorLocation[info->giver_actor] = locs.front();  // for its box (see pre_item_draw_base)
        }
        g_heldActor = nullptr;  // a new pickup: the next held item is this one
    }
    out->item = item;
    out->display_item = display;
    out->was_resolved = true;
    return true;
}

static void report_locations(const std::vector<std::string>& locs) {
    for (const auto& loc : locs) {
        const auto it = g_locationToId.find(loc);
        if (it == g_locationToId.end()) {
            ap_log(fmt::format("report_location '{}': not a location of this slot", loc));
            continue;
        }
        if (g_checked.insert(it->second).second) {
            g_toSend.push_back(it->second);
        }
    }
}

void observe_give(ModContext*, const ItemGiveInfo* info, void*) {
    if (info == nullptr) {
        return;
    }
    if (info->check_name != nullptr) {
        const auto locs = locations_for_check(info->check_name);
        ap_log(fmt::format("give item=0x{:02X} ({}) origin={} check='{}' -> {}", info->item, item_name(info->item),
            info->origin, info->check_name, locs.empty() ? std::string{"(not ours)"} : locs.front()));
        if (!locs.empty()) {
            const auto placed = g_placements.find(locs.front());
            if (placed != g_placements.end() && placed->second.own && info->item != kApItem &&
                info->item != static_cast<uint8_t>(placed->second.giveByte))
            {
                ap_log(fmt::format("  the server's item there is {} (0x{:02X}); given as {} (progressive item, or "
                                   "ammo before its weapon)",
                    item_name(placed->second.giveByte), static_cast<uint8_t>(placed->second.giveByte),
                    item_name(info->item)));
            }
            report_locations(locs);
            if (info->item != kApItem) {
                note_recent_item(item_name(info->item), {});  // found here, in our own world
            }
            if (info->item == kApItem) {
                g_lastResolvedApLocation = locs.front();
            }
            flush_checks();  // right away: the server should know before anything else happens
        }
        return;
    }
    if ((info->origin == ITEM_GIVE_ORIGIN_QUEUE || info->origin == ITEM_GIVE_ORIGIN_QUEUE_SILENT) &&
        g_outstanding >= 0)
    {
        g_outstanding = -1;
        ++g_state.received;
        write_state();
        ap_log(fmt::format("delivered item 0x{:02X} ({}); {} of {} received items are now in this file", info->item,
            item_name(info->item), g_state.received, g_serverItems.size()));
    }
}

// The get-item text for the placeholder: it borrows the Foolish Item's message and is replaced
// for each pickup with "You found X's Y".
bool ap_item_text(ModContext*, const MessageOverrideContext*, MessageTextData* out, void*) {
    if (g_armedFrames <= 0 || g_armedText.empty()) {
        return false;
    }
    // Sanitized again at the sink: whatever the source, the renderer only ever sees printable
    // text of a sane length.
    const std::string text = message_safe(g_armedText, 160);
    thread_local std::vector<uint8_t> buf;
    buf.assign(text.begin(), text.end());
    buf.push_back(0);
    out->text = buf.data();
    out->text_size = buf.size();
    // Consume it: the next placeholder re-arms with its own text, and a real Foolish Item
    // (which shares this message) must not inherit it.
    g_armedFrames = 0;
    g_apTextServed = true;
    return true;
}


// ---------------------------------------------------------------------------------------
// Goal

void complete_goal(const char* how) {
    if (g_state.goal) {
        return;
    }
    g_state.goal = true;
    write_state();
    g_client.sendGoal();
    ap_log(fmt::format("goal complete ({})", how));
    toast("Archipelago", "Goal complete!", "success", 6000);
}

void post_ganondorf_execute(ModContext*, void* args, void*, void*) {
    // The ending plays out inside the arena (no stage or scene change), so watch Ganondorf
    // himself: the finishing blow puts him in the end action with the ending camera running.
    constexpr s16 kActionEnd = 22;  // ACTION_END in d_a_b_gnd.cpp
    constexpr s16 kEndingCamera = 60;
    auto* gnd = mods::arg<b_gnd_class*>(args, 0);
    if (g_phase == Phase::Playing && gnd != nullptr && gnd->mActionMode == kActionEnd &&
        gnd->mDemoCamMode >= kEndingCamera) {
        complete_goal("Ganondorf defeated");
    }
}

HookAction pre_change_scene(ModContext*, void*, void*, void*) {
    const char* stage = dComIfGp_getStartStageName();
    // Leaving Dark Lord Ganondorf's arena only happens through the ending.
    if (g_phase == Phase::Playing && stage != nullptr && std::strcmp(stage, "D_MN09C") == 0) {
        complete_goal("left D_MN09C");
    }
    return HOOK_CONTINUE;
}


// ---------------------------------------------------------------------------------------
// Sending checks

// Reads the save for locations that were checked without the item service noticing (or while
// the mod was not running or the server was away) and queues them.
void scan_locations() {
    if (!g_haveSlot || g_scan.empty() || !in_gameplay()) {
        return;
    }
    for (int n = 0; n < 24; ++n) {
        const auto& loc = g_scan[g_scanPos];
        g_scanPos = (g_scanPos + 1) % g_scan.size();
        if (g_checked.contains(loc.id)) {
            continue;
        }
        if (loc.meta.IsMap() && isLocationMetadataObtained(loc.meta, loc.name)) {
            g_toSend.push_back(loc.id);
            g_checked.insert(loc.id);
        }
    }
}

void flush_checks() {
    if (!g_toSend.empty() && g_client.state() == State::Connected && g_haveSlot) {
        ap_log(fmt::format("sending {} location check(s)", g_toSend.size()));
        g_client.sendLocations(g_toSend);
        g_toSend.clear();
    }
}


// ---------------------------------------------------------------------------------------
// Receiving items

// Remembers when Link last lost life, so nothing is handed over in the middle of a hit.
void track_life() {
    if (!in_gameplay()) {
        g_lifeDropFrames = 0;
        return;
    }
    const int life = dComIfGs_getLife();
    if (life < g_lastLife) {
        g_lifeDropFrames = 45;
    } else if (g_lifeDropFrames > 0) {
        --g_lifeDropFrames;
    }
    g_lastLife = life;
}

// Why an item cannot be handed to Link right now, or nullptr when it can. The engine's own give
// queue also waits for a safe moment; this is the mod's second, stricter layer: not loading, not in
// a cutscene or conversation, alive, not hit, not falling, not mid-warp or transformation.
const char* delivery_blocker() {
    if (!in_gameplay()) {
        return "not in gameplay (title, loading the file, or the seed is being rebuilt)";
    }
    if (fopOvlpM_IsPeek()) {
        return "a scene is loading";
    }
    if (mDoRst::isReset()) {
        return "the game is resetting";
    }
    if (dComIfGp_isPauseFlag()) {
        return "the game is paused (a menu or window is open)";
    }
    if (dComIfGp_event_runCheck()) {
        return "a cutscene or conversation is running";
    }
    auto* link = daAlink_getAlinkActorClass();
    if (link == nullptr || link->checkEventRun()) {
        return "Link is busy with an event";
    }
    if (dComIfGs_getLife() <= 0 || g_lifeDropFrames > 0) {
        return "Link is dying or was just hit";
    }
    switch (link->mProcID) {
    case daAlink_c::PROC_DEAD:
    case daAlink_c::PROC_FOG_DEAD:
    case daAlink_c::PROC_TALK:
    case daAlink_c::PROC_GET_ITEM:
    case daAlink_c::PROC_LOOK_UP_TO_GET_ITEM:
    case daAlink_c::PROC_WARP:
    case daAlink_c::PROC_DUNGEON_WARP_READY:
    case daAlink_c::PROC_DUNGEON_WARP:
    case daAlink_c::PROC_DUNGEON_WARP_SCN_START:
    case daAlink_c::PROC_METAMORPHOSE:
    case daAlink_c::PROC_METAMORPHOSE_ONLY:
    // taking damage
    case daAlink_c::PROC_DAMAGE:
    case daAlink_c::PROC_LARGE_DAMAGE:
    case daAlink_c::PROC_LARGE_DAMAGE_UP:
    case daAlink_c::PROC_LARGE_DAMAGE_WALL:
    case daAlink_c::PROC_LAND_DAMAGE:
    case daAlink_c::PROC_HORSE_DAMAGE:
    case daAlink_c::PROC_SWIM_DAMAGE:
    case daAlink_c::PROC_POLY_DAMAGE:
    case daAlink_c::PROC_ELEC_DAMAGE:
    case daAlink_c::PROC_WOLF_DAMAGE:
    case daAlink_c::PROC_WOLF_LARGE_DAMAGE_UP:
    case daAlink_c::PROC_WOLF_LAND_DAMAGE:
    // falling
    case daAlink_c::PROC_FALL:
    case daAlink_c::PROC_WOLF_FALL:
    case daAlink_c::PROC_HANG_FALL_START:
    case daAlink_c::PROC_WOLF_HANG_FALL_START:
        return "Link is talking, getting an item, warping, transforming, hit or falling";
    default:
        break;
    }
    return nullptr;
}

// "" when nothing is waiting, else how many items are and why they are.
std::string delivery_status() {
    const int waiting = static_cast<int>(g_serverItems.size()) - g_state.received;
    if (waiting <= 0 || g_phase != Phase::Playing) {
        return {};
    }
    if (g_outstanding >= 0) {
        return fmt::format("{} item(s) waiting; one is being handed over", waiting);
    }
    const char* why = delivery_blocker();
    return why == nullptr ? fmt::format("{} item(s) about to be delivered", waiting)
                          : fmt::format("{} item(s) waiting: {}", waiting, why);
}

void deliver_items() {
    if (g_outstanding >= 0) {
        // The item is in the game's give queue, which hands over only while Link stands or walks.
        // Say so once if it takes long, with what Link is doing, so a stuck item is not silent.
        if (++g_outstandingFrames == 600) {
            auto* link = daAlink_getAlinkActorClass();
            const bool inScene = link != nullptr && link->mProcID == daAlink_c::PROC_GET_ITEM;
            ap_log(fmt::format("item 0x{:02X} has waited 10 s in the game's give queue; {}", g_outstanding,
                inScene ? "Link is in a get-item scene (press A to dismiss it; the next item follows)"
                        : fmt::format("Link's action is {} (it is handed over while he stands or walks)",
                              link != nullptr ? static_cast<int>(link->mProcID) : -1)));
        }
        return;
    }
    g_outstandingFrames = 0;
    if (g_state.received >= static_cast<int>(g_serverItems.size())) {
        return;
    }
    // Say in the trail when delivery starts or stops waiting, and what for.
    static const char* lastBlocker = nullptr;
    const char* const blocker = delivery_blocker();
    if (blocker != lastBlocker) {
        ap_log(blocker != nullptr
                   ? fmt::format("{} item(s) waiting; not delivering now: {}",
                         static_cast<int>(g_serverItems.size()) - g_state.received, blocker)
                   : std::string{"delivery can proceed"});
        lastBlocker = blocker;
    }
    if (blocker != nullptr) {
        return;
    }
    const auto& it = g_serverItems[g_state.received];
    const gc::Item* gi = gc::find_item(it.item);
    if (gi == nullptr || gi->giveByte == 0xFF) {
        // Not something this game can be given (an event, or an id this mod does not know).
        ap_log(fmt::format("skipping server item {}: not giveable", it.item));
        ++g_state.received;
        write_state();
        return;
    }
    const auto give = static_cast<uint8_t>(verifyProgressiveItem(static_cast<u32>(gi->giveByte)));
    const bool progression = (it.flags & 1) != 0;
    const bool trap = (it.flags & 4) != 0;
    const bool fromOther = it.player != g_client.slot() && it.location >= 0;
    // Progression items from other players play the whole get-item scene. So do traps: the
    // game's Foolish Item (the apworld's Ice Trap) is a joke that needs its scene and text, and a
    // silent toast would give it away as a plain "Ice Trap". Everything else is silent with a toast.
    const uint32_t flags = ((progression || trap) && fromOther) ? 0u : static_cast<uint32_t>(ITEM_GIVE_SILENT);
    if (svc_mng.item->give_item(svc_mng.mod_ctx, nullptr, give, flags) != MOD_OK) {
        return;  // try again next tick
    }
    g_outstanding = give;
    note_recent_item(item_name(give), fromOther ? g_client.playerName(it.player) : std::string{});
    ap_log(fmt::format("delivering #{}: {} from {} as game item 0x{:02X} ({}), {}", g_state.received,
        g_client.itemName(it.item, g_client.slot()), fromOther ? g_client.playerName(it.player) : "the server or ourselves",
        give, item_name(give), (flags & ITEM_GIVE_SILENT) ? "silent with a toast" : "with the get-item scene"));
    if (flags & ITEM_GIVE_SILENT) {
        const std::string from = fromOther ? g_client.playerName(it.player) : std::string{};
        toast("Received item", fmt::format("{}{}", g_client.itemName(it.item, g_client.slot()),
                                   from.empty() ? "" : " from " + from),
            nullptr, 3000);
    }
}

}  // namespace ap::internal
