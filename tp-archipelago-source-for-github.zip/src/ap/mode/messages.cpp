// The Messages tab: the room log, in the colors Archipelago clients use, and chat.
// (After the community Archipelago mod's tab, without its emoji picker.)

#include "internal.hpp"

namespace ap::internal {

static std::string log_rml_all() {
    if (g_logRml.empty()) {
        return R"(<div class="ap-msg ap-quiet">Nothing yet. Messages from the room show up here.</div>)";
    }
    std::string out;
    for (auto it = g_logRml.rbegin(); it != g_logRml.rend(); ++it) {  // newest first
        out += R"(<div class="ap-msg">)" + *it + "</div>";
    }
    return out;
}

// The field only edits the draft; Send sends it, so moving focus away never sends half a message.
static void send_chat(ModContext*, void*) {
    std::string text = message_safe(g_chatDraft, 400);
    std::erase(text, '\n');
    const auto first = text.find_first_not_of(' ');
    if (first != std::string::npos && g_client.state() == State::Connected) {
        g_client.say(text.substr(first));
        g_chatDraft.clear();
    }
}

ModResult build_messages_tab(ModContext* ctx, UiWindowHandle, UiElementHandle left, UiElementHandle,
    void*, ModError*) {
    svc_mng.ui->pane_add_section(ctx, left, "Chat");
    UiControlDesc say = UI_CONTROL_DESC_INIT;
    say.kind = UI_CONTROL_STRING;
    say.label = "Message";
    say.max_length = 400;
    say.get = get_str;
    say.set = set_str;
    say.user_data = &g_chatDraft;
    say.string_set_mode = UI_STRING_SET_ON_CHANGE;
    say.is_disabled = not_connected;
    svc_mng.ui->pane_add_control(ctx, left, &say, nullptr);

    UiControlDesc send = UI_CONTROL_DESC_INIT;
    send.kind = UI_CONTROL_BUTTON;
    send.label = "Send";
    send.on_pressed = send_chat;
    send.is_disabled = not_connected;
    svc_mng.ui->pane_add_control(ctx, left, &send, nullptr);
    svc_mng.ui->pane_add_rml(ctx, left,
        R"(<div class="ap-quiet">Chat with the room, or send a command such as !remaining or !help.</div>)",
        nullptr);

    svc_mng.ui->pane_add_section(ctx, left, "Room");
    g_logElem = 0;
    svc_mng.ui->pane_add_rml(ctx, left, log_rml_all().c_str(), &g_logElem);
    g_logShown = g_logVersion;
    return MOD_OK;
}

ModResult update_messages_tab(ModContext* ctx, void*, ModError*) {
    if (g_logElem != 0 && g_logShown != g_logVersion) {
        g_logShown = g_logVersion;
        svc_mng.ui->elem_set_rml(ctx, g_logElem, log_rml_all().c_str());
    }
    return MOD_OK;
}

}  // namespace ap::internal
