// Slot data into lookup tables, the scouted placements, and the seed built from them on a
// worker thread.
//
// The GameCube apworld does not send placements in slot_data: the server decides them, and the
// client asks ("LocationScouts") what is at each of its locations. The local seed is then built
// from that answer, so the game's own chests, shops, NPCs and text agree with the multiworld:
//   - a location holding one of our own items gets that item (by name),
//   - a location holding another world's item gets the "Archipelago Item" placeholder,
//   - every other location the generator would shuffle keeps its vanilla item.

#include "internal.hpp"

#include "../seed_inputs.hpp"

namespace ap::internal {
namespace {

// 2: seeds name other players' items in shop texts, so a cache from version 1 rebuilds its seed
constexpr int kPlacementCacheVersion = 2;
constexpr size_t kScoutChunk = 500;

std::string sanitize(std::string s) {
    for (auto& c : s) {
        if (!std::isalnum(static_cast<unsigned char>(c)) && c != '-' && c != '_') {
            c = '_';
        }
    }
    return s;
}

std::string to_text(const json& v) {
    if (v.is_string()) {
        return v.get<std::string>();
    }
    if (v.is_boolean()) {
        return v.get<bool>() ? "true" : "false";
    }
    if (v.is_number_integer()) {
        return std::to_string(v.get<int64_t>());
    }
    return {};
}

bool generate_seed(const SeedInput& in, std::string& outHash, std::string& outError,
    std::vector<std::string>& outSkipped) {
    namespace fs = std::filesystem;
    std::lock_guard lock{g_generatorMutex};
    try {
        const fs::path base = seed_base(in.seedName, in.slot);
        write_seed_inputs(in, base);

        randomizer::g_archipelagoMode = true;
        randomizer::g_archipelagoSkippedPlando.clear();
        randomizer::g_archipelagoItemLabels.clear();
        for (const auto& [location, label] : in.labels) {
            randomizer::g_archipelagoItemLabels[location] = label;
        }
        randomizer::Randomizer rando{base};
        auto err = rando.Generate();
        randomizer::g_archipelagoMode = false;
        randomizer::g_archipelagoItemLabels.clear();
        if (err.has_value()) {
            outError = *err;
            return false;
        }
        outSkipped = randomizer::g_archipelagoSkippedPlando;
        RandomizerContext ctx = WriteSeedData(rando.GetWorld());
        ctx.mHash = rando.GetConfig().GetHash();
        fs::create_directories(ctx.GetSeedDataPath().parent_path());
        if (auto werr = ctx.WriteToFile(); werr.has_value()) {
            outError = *werr;
            return false;
        }
        outHash = ctx.mHash;
        return true;
    } catch (const std::exception& e) {
        randomizer::g_archipelagoMode = false;
        randomizer::g_archipelagoItemLabels.clear();
        outError = e.what();
        return false;
    }
}

}  // namespace


// Where a seed's settings, plando and placement cache live.
std::filesystem::path seed_base(const std::string& seedName, const std::string& slot) {
    return randomizer::paths::GetRandomizerPath() / "archipelago" / sanitize(seedName + "-" + slot);
}

std::string placement_text(const Placement& p) {
    std::string who = message_safe(p.playerName.empty() ? "someone" : p.playerName, 40);
    std::string what = message_safe(p.itemName.empty() ? "an item" : p.itemName, 60);
    if (who.empty()) {
        who = "someone";
    }
    if (what.empty()) {
        what = "an item";
    }
    return fmt::format("You found {}'s\n{}!", who, what);
}


// ---------------------------------------------------------------------------------------
// Slot data

bool load_slot_data(const json& connected, std::string& err) {
    g_haveSlot = false;
    try {
        const json slotData = connected.value("slot_data", json::object());
        if (!slotData.is_object() || slotData.empty()) {
            err = "The server sent no slot data for this slot. Is it a Twilight Princess slot?";
            return false;
        }

        // The tables in this mod are keyed by the apworld's numbering, so a different release
        // could silently mean different items. Refuse it unless the player says otherwise.
        g_worldVersion = slotData.contains("World Version") && slotData["World Version"].is_string()
                             ? slotData["World Version"].get<std::string>()
                             : std::string{};
        if (g_worldVersion != gc::supported_world_version()) {
            ap_log(fmt::format("world version '{}' (this mod supports '{}')", g_worldVersion,
                gc::supported_world_version()));
            if (!cfg_on(g_cfgAllowUnknownVersion)) {
                err = fmt::format("This room was generated with Twilight Princess apworld '{}', but this "
                                  "mod is built for '{}'. Update the mod or the apworld so they match.",
                    g_worldVersion.empty() ? "unknown" : message_safe(g_worldVersion, 24),
                    gc::supported_world_version());
                return false;
            }
        }

        // Settings
        g_slotSettings.clear();
        if (slotData.contains("Settings") && slotData["Settings"].is_object()) {
            const json settings = slotData["Settings"];
            for (const auto& [key, value] : settings.items()) {
                const std::string text = to_text(value);
                if (!text.empty()) {
                    g_slotSettings.emplace_back(key, text);
                }
            }
        }
        const auto translated = gc::translate_settings(g_slotSettings);
        for (const auto& w : translated.warnings) {
            ap_log("settings: " + w);
        }
        if (!translated.errors.empty()) {
            err = "Could not translate this slot's settings: " + message_safe(translated.errors.front(), 160);
            return false;
        }
        g_transformAnywhereSlot = false;
        for (const auto& [key, value] : g_slotSettings) {
            if (key == "Transform Anywhere") {
                g_transformAnywhereSlot = gc::is_on(value);
            }
        }

        // Death link
        g_deathLinkSlot = false;
        if (slotData.contains("DeathLink")) {
            const json& dl = slotData["DeathLink"];
            g_deathLinkSlot = dl.is_boolean() ? dl.get<bool>() : (dl.is_number() && dl.get<int>() != 0);
        }

        // The locations this slot owns: whatever the server counts as ours, checked or not.
        g_locationIds.clear();
        g_idToLocation.clear();
        g_locationToId.clear();
        g_unknownLocations = 0;
        for (const char* key : {"checked_locations", "missing_locations"}) {
            const json list = connected.value(key, json::array());
            for (const auto& id : list) {
                if (!id.is_number_integer()) {
                    continue;
                }
                const int64_t apId = id.get<int64_t>();
                const gc::Location* loc = gc::find_location(apId);
                if (loc == nullptr) {
                    ++g_unknownLocations;
                    continue;
                }
                if (g_idToLocation.emplace(apId, loc->dusklightName).second) {
                    g_locationIds.push_back(apId);
                    g_locationToId[loc->dusklightName] = apId;
                }
            }
        }
        std::sort(g_locationIds.begin(), g_locationIds.end());
        if (g_unknownLocations > 0) {
            ap_log(fmt::format("{} location ids from the server are not known to this mod", g_unknownLocations));
        }
        if (g_locationIds.empty()) {
            err = "This slot has no Twilight Princess locations this mod knows about.";
            return false;
        }
    } catch (const std::exception& e) {
        err = std::string("Could not read the slot data: ") + e.what();
        return false;
    }
    g_slotSeed = g_client.seedName();
    g_haveSlot = true;
    return true;
}

// The randomizer tracker's own groups (src/ui/rando_config.cpp), plus "Other".
const std::vector<TrackerRegion>& tracker_regions() {
    static const std::vector<TrackerRegion> regions = {
        {"Ordon", {"Ordona Province"}, false},
        {"Faron", {"Faron Province", "Faron Woods", "Hyrule Field - Faron Province", "Sacred Grove"}, false},
        {"Eldin", {"Eldin Province", "Hyrule Field - Eldin", "Hyrule Field - Eldin Province",
                      "Eldin Lantern Cave", "Eldin Stockcave", "Death Mountain", "Kakariko Village",
                      "Kakariko Graveyard"},
            false},
        {"Lanayru", {"Lanayru Province", "Hyrule Field - Lanayru", "Hyrule Field - Lanayru Province",
                        "Castle Town", "Fishing Hole", "Lake Hylia", "Lake Lantern Cave", "Upper Zoras River",
                        "Zoras Domain"},
            false},
        {"Gerudo Desert", {"Gerudo Desert", "Bulblin Camp", "Mirror Chamber", "Cave Of Ordeals"}, false},
        {"Snowpeak", {"Snowpeak Province", "Snowpeak"}, false},
        {"Forest Temple", {"Forest Temple"}, true},
        {"Goron Mines", {"Goron Mines"}, true},
        {"Lakebed Temple", {"Lakebed Temple"}, true},
        {"Arbiter's Grounds", {"Arbiters Grounds"}, true},
        {"Snowpeak Ruins", {"Snowpeak Ruins"}, true},
        {"Temple of Time", {"Temple of Time"}, true},
        {"City in the Sky", {"City in the Sky"}, true},
        {"Palace of Twilight", {"Palace of Twilight"}, true},
        {"Hyrule Castle", {"Hyrule Castle"}, true},
        {"Other", {}, false},
    };
    return regions;
}

// Dungeons first, so a dungeon's checks never land in the province around it.
static int region_of(const YAML::Node& categories) {
    const auto& regions = tracker_regions();
    auto has = [&](const std::string& c) {
        for (const auto& n : categories) {
            if (n.as<std::string>() == c) {
                return true;
            }
        }
        return false;
    };
    for (const bool dungeons : {true, false}) {
        for (size_t i = 0; i < regions.size(); ++i) {
            if (regions[i].dungeon == dungeons && std::ranges::any_of(regions[i].categories, has)) {
                return static_cast<int>(i);
            }
        }
    }
    return static_cast<int>(regions.size()) - 1;
}

// Engine check names (what the item service reports for a pickup) -> the locations they mean,
// and the list of locations whose state can be read from the save. Only this slot's locations.
void build_check_map() {
    g_checkToLocations.clear();
    g_scan.clear();
    g_scanPos = 0;
    g_trackerChecks.clear();
    const auto locations = LOAD_EMBED_YAML(RANDO_DATA_PATH "locations.yaml");
    auto add = [](const std::string& check, const std::string& loc) {
        g_checkToLocations[check].push_back(loc);
    };
    auto stage = [](const YAML::Node& n) -> std::string {
        const int s = n["Stage"].as<int>();
        return (s >= 0 && s < static_cast<int>(std::size(allStages))) ? allStages[s] : "";
    };
    for (const auto& node : locations) {
        const std::string name = node["Name"].as<std::string>();
        const auto idIt = g_locationToId.find(name);
        if (idIt == g_locationToId.end()) {
            continue;  // not a location of this slot
        }
        const YAML::Node meta = node["Metadata"];
        g_scan.push_back({name, idIt->second, meta});
        g_trackerChecks.push_back({name, idIt->second, region_of(node["Categories"])});
        if (!meta.IsMap()) {
            continue;
        }
        for (const auto& c : meta["Chest"]) {
            add(fmt::format("chest:{}:{}", stage(c), c["Tbox Id"].as<int>()), name);
        }
        for (const auto& c : meta["Poe"]) {
            add(fmt::format("poe:{}:{}", stage(c), c["Flag"].as<int>()), name);
        }
        for (const auto& c : meta["Freestanding Item"]) {
            const int flag = c["Flag"].as<int>();
            add(fmt::format("freestanding:{}:{}", stage(c), flag), name);
            if (flag == 0x9F) {
                add(fmt::format("boss:{}", stage(c)), name);
            }
        }
        for (const auto& c : meta["Sky Character"]) {
            add(fmt::format("sky:{}:{}", stage(c), c["Room"].as<int>()), name);
        }
        for (const auto& c : meta["Golden Wolf"]) {
            add(fmt::format("golden_wolf:{}", c["Flag"].as<int>()), name);
        }
        for (const auto& c : meta["Bug Reward"]) {
            add(fmt::format("bug:{}", c["Item Id"].as<int>()), name);
        }
        for (const auto& c : meta["Shop"]) {
            add(fmt::format("shop:{}:{}:{}", stage(c), c["Room"].as<int>(), c["Item"].as<int>()), name);
        }
        for (const auto& c : meta["Name Lookup"]) {
            add(nameLookupOverride(c.as<std::string>()), name);
        }
    }
}

std::vector<std::string> locations_for_check(const char* check) {
    if (check == nullptr) {
        return {};
    }
    if (const auto it = g_checkToLocations.find(check); it != g_checkToLocations.end()) {
        return it->second;
    }
    // Ook drops the Gale Boomerang as a freestanding item in his own stage
    const std::string ook = fmt::format("freestanding:{}:", allStages[Ook]);
    if (std::strncmp(check, ook.c_str(), ook.size()) == 0 &&
        g_locationToId.contains("Forest Temple Gale Boomerang")) {
        return {"Forest Temple Gale Boomerang"};
    }
    return {};
}


// ---------------------------------------------------------------------------------------
// Scouting: what does the server say is at each of our locations?

void begin_scouting() {
    g_phase = Phase::Scouting;
    g_placements.clear();
    g_scoutedIds.clear();
    g_scoutExpected = g_locationIds.size();
    g_status = fmt::format("Connected. Asking the server what is at your {} locations...", g_scoutExpected);
    for (size_t i = 0; i < g_locationIds.size(); i += kScoutChunk) {
        const size_t end = std::min(i + kScoutChunk, g_locationIds.size());
        g_client.sendScouts(std::vector<int64_t>(g_locationIds.begin() + i, g_locationIds.begin() + end));
    }
}

static void fail_scouting(const std::string& why) {
    ap_log("scouting failed: " + why);
    g_status = why;
    toast("Archipelago", why, "warning", 8000);
    g_client.disconnect();
    g_placements.clear();
    g_scoutedIds.clear();
    g_phase = g_needsRegen ? Phase::Playing : Phase::NewSave;
}

void on_location_info(const std::vector<NetworkItem>& items) {
    if (g_phase != Phase::Scouting) {
        return;  // an old answer
    }
    for (const auto& it : items) {
        const auto name = g_idToLocation.find(it.location);
        if (name == g_idToLocation.end()) {
            continue;
        }
        Placement p;
        p.id = it.location;
        p.location = name->second;
        p.item = it.item;
        p.player = it.player;
        p.flags = it.flags;
        p.own = it.player == g_client.slot();
        if (p.own) {
            const gc::Item* gi = gc::find_item(it.item);
            if (gi == nullptr || gi->giveByte == 0xFF || gi->plandoName[0] == '\0') {
                // An item of ours that this mod cannot give would be lost for good.
                fail_scouting(fmt::format("The server put an item this mod does not know (id {}) at '{}'. "
                                          "The mod and the apworld are out of step.",
                    it.item, name->second));
                return;
            }
            p.giveByte = gi->giveByte;
            p.plando = gi->plandoName;
        }
        p.itemName = g_client.itemName(it.item, it.player);
        p.playerName = g_client.playerName(it.player);
        p.game = g_client.gameOfSlot(it.player);
        g_placements[p.location] = std::move(p);
        g_scoutedIds.insert(it.location);
    }
    if (g_scoutedIds.size() < g_scoutExpected) {
        g_status = fmt::format("Asking the server what is at your locations ({}/{})...", g_scoutedIds.size(),
            g_scoutExpected);
        return;
    }
    // Everything is accounted for: build the seed.
    g_apItemText.clear();
    for (const auto& [loc, p] : g_placements) {
        if (!p.own) {
            g_apItemText[loc] = placement_text(p);
        }
    }
    build_check_map();
    g_phase = Phase::Generating;
    start_generation();
}


// ---------------------------------------------------------------------------------------
// Seed generation (worker thread)

void start_generation() {
    SeedInput in;
    in.seedName = g_slotSeed;
    in.slot = g_client.info().slot;
    in.settings = gc::translate_settings(g_slotSettings).settings;
    for (const auto& [loc, p] : g_placements) {
        in.plando.emplace_back(loc, p.own ? p.plando : std::string{kPlaceholderPlandoItem});
    }
    std::sort(in.plando.begin(), in.plando.end());  // a stable file for a stable hash
    for (const auto& [loc, p] : g_placements) {
        if (!p.own) {
            // plain ASCII and short: it goes on a shop shelf, in the game's font
            in.labels.emplace_back(loc, overlay::ascii_only(
                (p.playerName.empty() ? std::string{"Someone"} : p.playerName) + "'s " +
                    (p.itemName.empty() ? std::string{"item"} : p.itemName), 30));
        }
    }
    g_genBase = seed_base(in.seedName, in.slot).string();
    g_status = fmt::format("Building your seed from {} locations. This takes a few seconds...",
        in.plando.size());
    const int serial = ++g_genSerial;
    g_genStatus = 1;
    std::thread([in = std::move(in), serial] {
        std::string hash, error;
        std::vector<std::string> skipped;
        const bool ok = generate_seed(in, hash, error, skipped);
        std::lock_guard lock{g_genMutex};
        if (serial != g_genSerial.load()) {
            return;  // a newer run replaced this one (the player backed out and tried again)
        }
        g_genHash = hash;
        g_genError = error;
        g_genSkipped = std::move(skipped);
        g_genStatus = ok ? 2 : 3;
    }).detach();
}

bool seed_files_exist(const std::string& hash) {
    std::error_code ec;
    return !hash.empty() &&
           std::filesystem::exists(randomizer::paths::GetRandomizerSeedsPath() / hash / "seed.dat", ec);
}

// The worker only reports through g_genStatus/g_gen*; what happens next happens here.
void tick_generation() {
    if (g_genStatus.load() < 2) {
        return;
    }
    int st = 0;
    std::string hash, error;
    std::vector<std::string> skipped;
    {
        std::lock_guard lock{g_genMutex};
        st = g_genStatus.load();
        g_genStatus = 0;
        hash = g_genHash;
        error = g_genError;
        skipped = g_genSkipped;
    }
    if (g_phase != Phase::Generating) {
        return;  // the window was closed (or the save changed) while the seed was building
    }
    if (st == 3) {
        mods::log::error("archipelago: seed generation failed: {}", error);
        ap_log("generation failed: " + error);
        g_status = "Seed generation failed: " + message_safe(error, 200);
        toast("Archipelago", g_status, "warning", 10000);
        g_client.disconnect();
        g_phase = g_needsRegen ? Phase::Playing : Phase::NewSave;
        return;
    }
    g_skippedPlando = std::move(skipped);
    ap_log(fmt::format("seed built: {} ({} locations are vanilla in it and patched at runtime)", hash, g_skippedPlando.size()));
    for (const auto& name : g_skippedPlando) {
        ap_log("vanilla in the local seed, patched at runtime: " + name);
    }
    if (!save_placements(g_genBase, hash)) {
        mods::log::warn("archipelago: could not save the placement cache; this save will need the "
                        "server to reload");
    }

    if (g_needsRegen) {
        // A loaded save on a machine without its seed files: activate the rebuilt seed now.
        if (hash != g_loadedHash) {
            ap_log(fmt::format("the rebuilt seed '{}' doesn't match this save's '{}'", hash, g_loadedHash));
            toast("Archipelago", "The rebuilt seed doesn't match this save.", "warning", 10000);
        } else {
            randomizer::session::deactivateSeed();
            randomizer::session::activateSeed(hash.c_str());
            loadAncientDocumentNum();
            g_needsRegen = false;
            after_seed_activated();
        }
        g_phase = Phase::Playing;
        return;
    }

    randomizer::session::g_pending_seed_hash = hash;
    g_status = "Seed ready!";
    g_phase = Phase::AwaitNewSave;
    if (g_newSaveState != nullptr) {
        *g_newSaveState = GAME_MODE_STATE_PROCEED;  // continue to name entry
        g_newSaveState = nullptr;  // the host owns it from here (valid only until the selection completes)
    }
    mDoAud_seStartMenu(Z2SE_SY_NEW_FILE);
    if (g_window != 0) {
        const auto w = g_window;
        g_window = 0;
        svc_mng.ui->window_close(svc_mng.mod_ctx, w);
    }
}


// ---------------------------------------------------------------------------------------
// The placement cache: lets a save reload (and keep checking and describing its locations)
// without the server, and without scouting again.

bool save_placements(const std::filesystem::path& base, const std::string& hash) {
    try {
        json out;
        out["version"] = kPlacementCacheVersion;
        out["hash"] = hash;
        out["world_version"] = g_worldVersion;
        out["skipped"] = g_skippedPlando;
        json list = json::array();
        for (const auto& [loc, p] : g_placements) {
            list.push_back({{"id", p.id}, {"location", p.location}, {"item", p.item}, {"player", p.player},
                {"flags", p.flags}, {"own", p.own}, {"give", p.giveByte}, {"plando", p.plando},
                {"item_name", p.itemName}, {"player_name", p.playerName}, {"game", p.game}});
        }
        out["placements"] = std::move(list);
        std::filesystem::create_directories(base);
        std::ofstream file(base / "ap_placements.json", std::ios::binary | std::ios::trunc);
        file << out.dump(-1, ' ', false, json::error_handler_t::replace);
        return static_cast<bool>(file);
    } catch (const std::exception& e) {
        mods::log::error("archipelago: saving placements failed: {}", e.what());
        return false;
    }
}

bool load_placements(const std::filesystem::path& base, std::string& hash) {
    try {
        std::ifstream file(base / "ap_placements.json", std::ios::binary);
        if (!file) {
            return false;
        }
        const json in = json::parse(file, nullptr, false);
        if (in.is_discarded() || !in.is_object() || in.value("version", 0) != kPlacementCacheVersion) {
            return false;
        }
        hash = in.value("hash", "");
        g_placements.clear();
        g_idToLocation.clear();
        g_locationToId.clear();
        g_locationIds.clear();
        g_apItemText.clear();
        g_skippedPlando.clear();
        for (const auto& s : in.value("skipped", json::array())) {
            if (s.is_string()) {
                g_skippedPlando.push_back(s.get<std::string>());
            }
        }
        for (const auto& e : in.value("placements", json::array())) {
            Placement p;
            p.id = json_num(e, "id", int64_t{0});
            p.location = e.value("location", "");
            p.item = json_num(e, "item", int64_t{0});
            p.player = json_num(e, "player", 0);
            p.flags = json_num(e, "flags", 0);
            p.own = e.value("own", false);
            p.giveByte = json_num(e, "give", 0xFF);
            p.plando = e.value("plando", "");
            p.itemName = e.value("item_name", "");
            p.playerName = e.value("player_name", "");
            p.game = e.value("game", "");
            if (p.location.empty() || p.id == 0) {
                continue;
            }
            g_idToLocation[p.id] = p.location;
            g_locationToId[p.location] = p.id;
            g_locationIds.push_back(p.id);
            if (!p.own) {
                g_apItemText[p.location] = placement_text(p);
            }
            g_placements[p.location] = std::move(p);
        }
        std::sort(g_locationIds.begin(), g_locationIds.end());
        return !g_placements.empty() && !hash.empty();
    } catch (const std::exception& e) {
        mods::log::error("archipelago: reading the placement cache failed: {}", e.what());
        return false;
    }
}


// ---------------------------------------------------------------------------------------

void after_seed_activated() {
    // Our resolver must run after the randomizer's (registered on seed activation), so it has
    // the last word; message overrides likewise stack on top of its text.
    if (g_resolver != 0) {
        svc_mng.item->clear_check_resolver(svc_mng.mod_ctx, g_resolver);
        g_resolver = 0;
    }
    svc_mng.item->set_check_resolver(svc_mng.mod_ctx, nullptr, resolve_check, nullptr, &g_resolver);
    g_textOverrides.clear();
    for (auto lang : {MESSAGE_LANGUAGE_ENGLISH, MESSAGE_LANGUAGE_GERMAN, MESSAGE_LANGUAGE_FRENCH,
             MESSAGE_LANGUAGE_SPANISH, MESSAGE_LANGUAGE_ITALIAN, MESSAGE_LANGUAGE_JAPANESE})
    {
        g_textOverrides.push_back(
            mods::flow::override_message_fn(0, kApItemDonorMessage, lang, ap_item_text));
    }
}

}  // namespace ap::internal
