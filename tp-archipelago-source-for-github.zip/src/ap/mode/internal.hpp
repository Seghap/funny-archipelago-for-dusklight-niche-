#pragma once

// Internal to the Archipelago game mode (src/ap/ap_mode.cpp and src/ap/mode/*.cpp): the mode's
// shared state, and the functions its files call across each other. Nothing outside the mode
// includes this; its public face is ap_mode.hpp.

#include "../ap_mode.hpp"

#include "../ap_client.hpp"
#include "../ap_overlay.hpp"
#include "../gc_logic.hpp"
#include "../ap_box.hpp"
#include "../ap_covers.hpp"
#include "../gc_settings.hpp"
#include "../gc_tables.hpp"
#include "../inbox.hpp"
#include "../text_safe.hpp"

#include "../../../generator/randomizer.hpp"
#include "../../../generator/utility/yaml.hpp"
#include "../../item_ids.h"
#include "../../paths.hpp"
#include "../../randomizer_context.hpp"
#include "../../session.hpp"
#include "../../stages.h"
#include "../../tools.h"
#include "../../verify_item_functions.h"

#include "d/actor/d_a_alink.h"
#include "d/actor/d_a_b_gnd.h"
#include "d/actor/d_a_demo_item.h"
#include "d/actor/d_a_itembase.h"
#include "d/actor/d_a_obj_item.h"
#include "d/d_com_inf_game.h"
#include "d/d_kankyo.h"
#include "d/d_meter2_draw.h"
#include "d/d_msg_flow.h"
#include "d/d_msg_scrn_item.h"
#include "JSystem/J2DGraph/J2DPicture.h"
#include "d/d_stage.h"
#include "f_op/f_op_overlap_mng.h"
#include "m_Do/m_Do_Reset.h"
#include "m_Do/m_Do_audio.h"

#include <mods/items.h>
#include <mods/svc/flow.hpp>
#include <mods/svc/hook.hpp>
#include <mods/svc/log.hpp>

#include <yaml-cpp/yaml.h>
#include <fmt/format.h>

#include <algorithm>
#include <atomic>
#include <cctype>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <filesystem>
#include <fstream>
#include <mutex>
#include <optional>
#include <string>
#include <thread>
#include <unordered_map>
#include <unordered_set>
#include <variant>
#include <vector>

// Defined in randomizer_context.cpp: turns a generated world into the data the game plays from.
RandomizerContext WriteSeedData(randomizer::logic::world::World* world);

namespace ap::internal {

using randomizer::session::svc_mng;

inline constexpr const char* kGameModeId = "tp_archipelago";
inline constexpr const char* kConnBlob = "ap_conn";    // server, slot, password of this save
inline constexpr const char* kStateBlob = "ap_state";  // items received, goal, seed of this save
inline constexpr const char* kSeedHashBlob = "seed_hash";  // written by the randomizer session
// The placeholder for any item that belongs to another world (the Sol model).
inline constexpr uint8_t kApItem = dItemNo_Randomizer_NOENTRY_220_e;
// The Foolish Item's get-item message, borrowed for the placeholder and replaced per pickup.
inline constexpr uint16_t kApItemDonorMessage = 120;
inline constexpr const char* kPlaceholderPlandoItem = "Archipelago Item";

// ---------------------------------------------------------------------------------------
// State

struct Conn {
    std::string server = "archipelago.gg:38281";
    std::string slot;
    std::string password;
};

struct SaveState {
    int received = 0;  // server items delivered into this save
    bool goal = false;
    std::string seed;  // the multiworld this save belongs to (RoomInfo seed_name)
    std::string slot;
    int deathLink = -1;              // -1 follow the YAML, 0 off, 1 on (toggled in the status tab)
    bool transformAnywhere = false;  // the slot's Transform Anywhere, kept for offline play
};

enum class Phase {
    Idle,          // title / no Archipelago save loaded
    NewSave,       // connect window open, not yet connected
    Scouting,      // connected; asking the server what is at each of our locations
    Generating,    // seed generation thread running
    AwaitNewSave,  // generated; waiting for the host to create the save
    Playing,       // an Archipelago save is loaded
};

// What the server says is at one of our locations, and what we derived from it.
struct Placement {
    int64_t id = 0;        // Archipelago location id
    std::string location;  // Dusklight location name
    int64_t item = 0;      // Archipelago item id
    int player = 0;        // slot that receives the item
    int flags = 0;         // 1 progression, 2 useful, 4 trap
    bool own = false;      // an item of our own world: given in game by the check itself
    int giveByte = 0xFF;   // own: the game item number
    std::string plando;    // own: the generator item placed in the local seed
    std::string itemName;
    std::string playerName;
    std::string game;
};

inline Client g_client;
inline Phase g_phase = Phase::Idle;
inline Conn g_conn;
inline SaveState g_state;
inline std::string g_status = "Enter your Archipelago connection, then press Connect.";

// Slot data of the current connection
inline bool g_haveSlot = false;
inline std::string g_slotSeed;                     // RoomInfo seed_name
inline std::string g_worldVersion;                 // slot_data "World Version"
inline gc::StringPairs g_slotSettings;             // slot_data "Settings", as text
inline bool g_deathLinkSlot = false;               // slot_data "DeathLink": the YAML's choice
inline bool g_transformAnywhereSlot = false;       // Settings "Transform Anywhere"
inline std::vector<int64_t> g_locationIds;         // every server location of this slot (sorted)
inline std::unordered_map<int64_t, std::string> g_idToLocation;
inline std::unordered_map<std::string, int64_t> g_locationToId;
inline int g_unknownLocations = 0;                 // ids the server listed that this mod has no entry for

// Placements (from LocationScouts, or the saved cache)
inline std::unordered_map<std::string, Placement> g_placements;  // by Dusklight location name
inline std::unordered_set<int64_t> g_scoutedIds;
inline size_t g_scoutExpected = 0;
inline std::vector<std::string> g_skippedPlando;   // owned by the server, vanilla in the local seed
// check name (engine) -> locations it stands for
inline std::unordered_map<std::string, std::vector<std::string>> g_checkToLocations;
struct ScanLoc {
    std::string name;
    int64_t id;
    YAML::Node meta;
};
inline std::vector<ScanLoc> g_scan;
inline size_t g_scanPos = 0;

// Checks
inline std::unordered_set<int64_t> g_checked;  // known to the server (sent or reported back)
inline std::vector<int64_t> g_toSend;

// Items
inline std::vector<NetworkItem> g_serverItems;
inline int g_outstanding = -1;  // a give is queued with the engine and not yet confirmed
inline int g_lifeDropFrames = 0;
inline int g_lastLife = 0;

// Seed generation (worker thread)
inline std::atomic<int> g_genStatus{0};  // 0 idle, 1 running, 2 ok, 3 failed
inline std::atomic<int> g_genSerial{0};  // the run whose result counts; older runs are ignored
inline std::mutex g_genMutex;
inline std::string g_genHash;
inline std::string g_genError;
inline std::vector<std::string> g_genSkipped;
inline std::string g_genBase;       // directory of this seed's files
inline bool g_needsRegen = false;   // loaded save whose seed files are missing on this machine
inline std::string g_loadedHash;

// New-save window
inline GameModeNewSaveState* g_newSaveState = nullptr;
inline UiWindowHandle g_window = 0;
inline UiElementHandle g_statusText = 0;
inline std::string g_inHost, g_inSlot, g_inPassword;
inline int64_t g_inPort = 38281;

// Foreign-item text and jingle
inline std::unordered_map<std::string, std::string> g_apItemText;  // location -> get-item text
inline std::string g_armedText;
// Game boxes: which pickup's text box is ours, and the item actors (and the one Link holds up) that
// resolved to another player's item, by location, so their draw can show the box of that game.
inline bool g_apTextServed = false;
inline const void* g_apTextBox = nullptr;
inline std::unordered_map<const void*, std::string> g_actorLocation;
inline const void* g_heldActor = nullptr;
inline std::string g_heldLocation;
inline ConfigVarHandle g_cfgBoxes = 0;      // other worlds' items as game boxes
inline ConfigVarHandle g_ovShortcut = 0;     // 0 off, 1 L+R+D-Pad Left
inline ConfigVarHandle g_cfgSgdbKey = 0;    // the player's SteamGridDB API key
inline ConfigVarHandle g_cfgArtWorld = 0;   // 0 cover, 1 icon: the item in the world and in Link's hands
inline ConfigVarHandle g_cfgArtText = 0;    // 0 cover, 1 icon: the get-item text box
inline UiElementHandle g_coverStatusText = 0;
inline int g_armedFrames = 0;
inline std::string g_lastResolvedApLocation;
inline std::vector<mods::flow::MessageOverride> g_textOverrides;
inline ItemCheckHandle g_resolver = 0;
inline ItemGiveHandle g_observer = 0;

// Death link
inline bool g_deathSent = false;        // this death is handled; cleared once Link is alive again
inline double g_lastDeathTime = 0.0;    // time on the death we sent, to recognise its echo
inline int g_killFrames = 0;            // > 0: a death now is the one we were sent, not a new one
inline std::optional<std::string> g_pendingDeath;

// Menu tab and status window
inline UiMenuTabHandle g_menuTab = 0;
inline UiWindowHandle g_statusWindow = 0;
inline UiElementHandle g_statusWindowText = 0;
inline UiElementHandle g_logText = 0;
inline std::string g_editHost;
inline int64_t g_editPort = 38281;
inline std::deque<std::string> g_log;  // recent server messages, newest last
inline int g_reconnectFrames = 0;
// Set when retrying the same way would only fail again (refused, wrong multiworld, bad slot data);
// cleared by pressing Reconnect or loading a save.
inline bool g_giveUpReconnect = false;
inline int g_outstandingFrames = 0;  // frames the current item has been in the game's give queue

// Tracker: which of this slot's checks are in logic, by the apworld's own rules (gc_logic.*), plain and
// glitched. The game thread searches whenever what the room has sent or what's been checked changes.
struct TrackerCheck {
    std::string name;
    int64_t id = 0;
    int region = 0;  // index into tracker_regions()
};
struct TrackerRegion {
    const char* label;
    std::vector<std::string> categories;
    bool dungeon;
};
// Glitched: not in logic, but in the apworld's glitched logic.
enum class CheckState { Done, InLogic, Glitched, NotYet, Unknown };
struct RegionCounts {
    size_t total = 0, done = 0, inLogic = 0, glitched = 0;
};
inline std::vector<TrackerCheck> g_trackerChecks;  // this slot's checks, in locations.yaml order
inline std::unordered_set<int64_t> g_inLogic, g_inGlitched;  // Archipelago ids reachable, done or not; the second with glitches allowed
inline size_t g_reachInputs = SIZE_MAX;            // the inputs g_inLogic was searched for (SIZE_MAX: not yet)
inline uint64_t g_trackerVersion = 1;              // bumped whenever what the tracker shows changes
// The randomizer generator keeps global state: seed generation takes turns (see slot.cpp).
inline std::mutex g_generatorMutex;
inline UiElementHandle g_trackerSummary = 0, g_trackerProgress = 0, g_trackerList = 0;
inline std::vector<std::pair<UiElementHandle, int>> g_trackerGroups;  // group control, region

// The window's styles: tracker rows, and Archipelago's usual colors for the message log.
inline constexpr const char* kWindowRcss = R"(
.ap-row { display: block; padding: 3dp 0dp; }
.ap-dot { display: inline-block; width: 10dp; height: 10dp; border-radius: 5dp; margin-right: 10dp; }
.ap-in { color: #ffffff; }
.ap-in .ap-dot { background-color: #6fd08c; }
.ap-out { color: #a6a6a6; }
.ap-out .ap-dot { border: 2dp #a6a6a6; }
.ap-glitch { color: #ffe14d; }
.ap-glitch .ap-dot { background-color: #ffe14d; }
.ap-unknown { color: #d0d0d0; }
.ap-unknown .ap-dot { border: 2dp #d0d0d0; }
.ap-done { color: #6c6c6c; text-decoration: line-through; }
.ap-done .ap-dot { background-color: #6c6c6c; }
.ap-head { display: block; margin-top: 10dp; margin-bottom: 2dp; font-weight: bold; color: #9fc3ff; }
.ap-legend > span { margin-right: 18dp; }
.ap-quiet { color: #a6a6a6; }
.ap-msg { display: block; padding: 3dp 0dp; }
.ap-me { color: #ee00ee; }
.ap-player { color: #fafad2; }
.ap-prog { color: #af99ef; }
.ap-useful { color: #6d8be8; }
.ap-trap { color: #fa8072; }
.ap-item { color: #00eeee; }
.ap-loc { color: #00ff7f; }
.ap-ent { color: #6495ed; }
)";

// Hints (open ones concerning this slot show in the overlay) and what the overlay lists
inline std::vector<Hint> g_hints;  // sorted: priority first, found last
struct Recent {
    std::string item;  // the item, or the whole chat line
    std::string from;  // who sent the item (empty for chat and for items found here)
    std::chrono::steady_clock::time_point at;
};
inline std::deque<std::string> g_logRml;  // the Messages tab's room log, as RML (newest last)
inline uint64_t g_logVersion = 1;
inline UiElementHandle g_logElem = 0;
inline uint64_t g_logShown = 0;
inline uint64_t g_hintsVersion = 1;       // bumped whenever the hint list changes
inline uint64_t g_selectedHint = 0;
inline std::vector<std::string> g_hintLabels;
inline std::string g_hintItemDraft, g_hintLocationDraft;
inline UiElementHandle g_hintsSummary = 0, g_hintDetails = 0;
inline UiListHandle g_hintsList = 0;
inline std::tuple<uint64_t, uint64_t, int> g_hintsShown{0, 0, -1};
inline std::string g_chatDraft;
inline uint64_t g_itemsVersion = 1;   // bumped when the list of received items or what was delivered changes
inline UiElementHandle g_itemsSummary = 0, g_itemsList = 0, g_itemsRelease = 0;
inline std::pair<uint64_t, bool> g_itemsShown{0, false};
inline std::deque<Recent> g_recentItems;
inline std::deque<Recent> g_recentChat;

// Overlay settings (config vars, so they persist and bind straight to the Overlay tab)
inline ConfigVarHandle g_ovEnabled = 0, g_ovCorner = 0, g_ovX = 0, g_ovY = 0, g_ovScale = 0,
                       g_ovOpacity = 0, g_ovStatus = 0, g_ovChecks = 0, g_ovItems = 0, g_ovHints = 0,
                       g_ovChat = 0, g_ovDeathLink = 0, g_ovItemCount = 0, g_ovHintCount = 0, g_ovKeep = 0;
inline constexpr uint32_t kOvText = 0xF2EEE2FF, kOvDim = 0xA9A493FF, kOvGreen = 0x6FD08CFF,
                          kOvYellow = 0xE8C867FF, kOvRed = 0xE8837AFF, kOvBlue = 0x9DB8FFFF;

// Config
inline ConfigVarHandle g_cfgHost = 0;
inline ConfigVarHandle g_cfgPort = 0;
inline ConfigVarHandle g_cfgSlot = 0;
inline ConfigVarHandle g_cfgModelScale = 0;
inline ConfigVarHandle g_cfgDebugLog = 0;
inline ConfigVarHandle g_cfgAllowUnknownVersion = 0;

// ---------------------------------------------------------------------------------------
// Functions shared between the mode's files, by file

// mode/common.cpp
void ap_log(const std::string& line);
const std::string& item_name(int id);
std::string rml_lines(const std::string& text);
void log_rml(std::string rml);   // one line of the Messages tab; already escaped
bool not_connected(ModContext*, void*);
std::string player_label(int slot);
void toast(const std::string& title, const std::string& body, const char* type = nullptr, uint32_t ms = 0);
void add_log(const std::string& line);
std::string config_string(ConfigVarHandle var);
int64_t cfg_int(ConfigVarHandle h, int64_t fallback);
bool cfg_on(ConfigVarHandle h);
void write_conn();
void write_state();
bool read_conn(Conn& out);
bool read_state(SaveState& out);
std::string status_line();
bool in_gameplay();
void get_str(ModContext*, void* ud, UiControlValue* out);
void set_str(ModContext*, void* ud, const UiControlValue* v);
// "host", "host:port", "ws://host:port" -> host and port; false if it is not an address.
bool split_server(const std::string& text, std::string& host, int64_t& port);
std::string join_server(const std::string& host, int64_t port);

// mode/slot.cpp
bool load_slot_data(const json& connected, std::string& err);
void build_check_map();
std::vector<std::string> locations_for_check(const char* check);
void begin_scouting();
void on_location_info(const std::vector<NetworkItem>& items);
std::filesystem::path seed_base(const std::string& seedName, const std::string& slot);
void start_generation();
bool seed_files_exist(const std::string& hash);
void tick_generation();
bool save_placements(const std::filesystem::path& base, const std::string& hash);
bool load_placements(const std::filesystem::path& base, std::string& hash);
void after_seed_activated();
std::string placement_text(const Placement& p);

// mode/items.cpp
void on_connected(const json& packet);
void on_items(int index, const std::vector<NetworkItem>& items);
void on_print(const std::string& text, const json& msg);
void on_disconnected(const std::string& reason, bool refused);
void on_checked(const std::vector<int64_t>& locations);
void on_hints(const std::vector<Hint>& hints);
void note_recent_item(const std::string& item, const std::string& from);
const char* delivery_blocker();
std::string delivery_status();
bool resolve_check(ModContext*, const ItemCheckInfo* info, ItemCheckResolution* out, void*);
void observe_give(ModContext*, const ItemGiveInfo* info, void*);
bool ap_item_text(ModContext*, const MessageOverrideContext*, MessageTextData* out, void*);
void complete_goal(const char* how);
void post_ganondorf_execute(ModContext*, void* args, void*, void*);
HookAction pre_change_scene(ModContext*, void*, void*, void*);
void scan_locations();
void flush_checks();
void deliver_items();
void track_life();

// mode/hooks.cpp
void post_ditem_set_mtx(ModContext*, void* args, void*, void*);
void post_item_set_base_mtx(ModContext*, void* args, void*, void*);
void post_midna_search_npc(ModContext*, void*, void* retval, void*);
void post_msg_query042(ModContext*, void*, void* retval, void*);

// mode/death_link.cpp
bool death_link_on();
void apply_death_link_tags();
void post_link_dead_init(ModContext*, void* args, void*, void*);
void post_link_fog_dead_init(ModContext*, void* args, void*, void*);
void on_bounced(const json& packet);
void tick_death_link();

// mode/saves.cpp
ModResult on_new_save_select(void* ud, GameModeNewSaveState* state, ModError* err);
ModResult on_new_save(void* ud, ModError* err);
ModResult on_save_loaded(void* ud, ModError* err);
ModResult on_game_reset(void*, ModError*);
void abandon_new_save(const char* why);

// mode/tracker.cpp
void reset_tracker();
void tick_tracker();
RegionCounts region_counts(int region);
ModResult build_tracker_tab(ModContext* ctx, UiWindowHandle, UiElementHandle left, UiElementHandle right, void*, ModError*);
ModResult update_tracker_tab(ModContext* ctx, void*, ModError*);
const std::vector<TrackerRegion>& tracker_regions();

// mode/received.cpp
ModResult build_items_tab(ModContext* ctx, UiWindowHandle, UiElementHandle left, UiElementHandle right, void*, ModError*);
ModResult update_items_tab(ModContext* ctx, void*, ModError*);
void note_items_changed();

// mode/hints.cpp, mode/messages.cpp
ModResult build_hints_tab(ModContext* ctx, UiWindowHandle, UiElementHandle left, UiElementHandle right, void*, ModError*);
ModResult update_hints_tab(ModContext* ctx, void*, ModError*);
ModResult build_messages_tab(ModContext* ctx, UiWindowHandle, UiElementHandle left, UiElementHandle right, void*, ModError*);
ModResult update_messages_tab(ModContext* ctx, void*, ModError*);

// mode/boxes.cpp
HookAction pre_item_draw_base(ModContext*, void* args, void* retval, void*);
void post_msg_item_exec(ModContext*, void* args, void*, void*);
void want_covers();
std::string trim_key(std::string key);
void add_box_settings(ModContext* ctx, UiElementHandle left);

// mode/overlay.cpp
void post_meter2_draw(ModContext*, void*, void*, void*);
void tick_overlay_shortcut();
void register_overlay_vars();
ModResult build_overlay_tab(ModContext* ctx, UiWindowHandle, UiElementHandle left, UiElementHandle,
    void*, ModError*);

// mode/status.cpp
void open_status_window(ModContext*, void*);

}  // namespace ap::internal
