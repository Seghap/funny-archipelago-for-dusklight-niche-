#pragma once

// Archipelago game mode: connects to an Archipelago server from inside the game, asks it what is
// at each of the slot's locations, builds the matching seed with the randomizer's own generator,
// then delivers received items and reports checks while the randomizer runtime plays the seed.

#include "mods/svc/game_mode.h"

namespace ap {

// The mode's registration. The session fills in on_activated / on_deactivated / on_tick.
GameModeDesc game_mode_desc();

// Game-mode lifecycle
ModResult activate();
void deactivate();
// Every game tick while the mode is active (not while the game is paused behind a window).
void tick();
// Every host frame, even while the game is paused behind a UI window: network and seed build.
void update();

// Called by the randomizer's procCoGetItem hook: lets the placeholder item use custom text.
void on_get_item_demo(void* link);

// How important the other world's item being picked up is, from its Archipelago
// classification, so its get-item jingle can match (see hookPreSetGetSubBgm).
enum class ItemImportance { Progression, Useful, Filler, Trap };
ItemImportance ap_item_importance();

}  // namespace ap
