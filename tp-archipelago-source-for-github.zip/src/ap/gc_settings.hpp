#pragma once

// Translation of the GameCube apworld's slot_data["Settings"] into Dusklight randomizer settings,
// so nothing has to be configured by hand in game. Pure C++ (no engine or JSON headers) so it
// can be tested on the host: see tools/test_gc_settings.cpp.

#include <string>
#include <utility>
#include <vector>

namespace ap::gc {

using StringPairs = std::vector<std::pair<std::string, std::string>>;

struct SettingsResult {
    // Dusklight setting name -> option, in a stable order, each name once.
    StringPairs settings;
    // Things worth logging that do not stop the seed (unknown or ignored keys).
    std::vector<std::string> warnings;
    // Things that make the seed unplayable as the server intended (a value we cannot map).
    std::vector<std::string> errors;
};

// `slotSettings` is slot_data["Settings"] with every value rendered as text. Order of precedence:
// fixed settings, defaults, then whatever the server sent.
SettingsResult translate_settings(const StringPairs& slotSettings);

// "Yes"/"On"/"true"/"1" (any case) -> true. Used for the few settings the mod itself acts on.
bool is_on(const std::string& value);

// Lower case, underscores and runs of spaces folded: the form values are compared in.
std::string normalize_value(const std::string& value);

}  // namespace ap::gc
