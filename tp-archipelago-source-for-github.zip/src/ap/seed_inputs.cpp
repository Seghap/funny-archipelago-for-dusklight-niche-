#include "seed_inputs.hpp"

#include <yaml-cpp/yaml.h>

#include <fstream>

namespace ap {

std::string seed_string(const SeedInput& in) {
    return "AP-" + in.seedName + "-" + in.slot;
}

void write_seed_inputs(const SeedInput& in, const std::filesystem::path& base) {
    namespace fs = std::filesystem;
    fs::create_directories(base);

    YAML::Node settings;
    settings["Seed"] = seed_string(in);
    settings["Plandomizer"] = true;
    settings["Generate Spoiler Log"] = false;
    settings["Starting Inventory"] = YAML::Node(YAML::NodeType::Map);
    settings["Excluded Locations"] = YAML::Node(YAML::NodeType::Sequence);
    settings["Mixed Entrance Pools"] = YAML::Node(YAML::NodeType::Sequence);
    for (const auto& [name, value] : in.settings) {
        settings[name] = value;
    }
    std::ofstream(base / "settings.yaml") << YAML::Dump(settings);

    YAML::Node plando;
    YAML::Node locs(YAML::NodeType::Map);
    for (const auto& [location, item] : in.plando) {
        locs[location] = item;
    }
    plando["World 1"]["Locations"] = locs;
    const fs::path plandoPath = base / "plando.yaml";
    std::ofstream(plandoPath) << YAML::Dump(plando);

    YAML::Node prefs;
    prefs["Plandomizer Path"] = plandoPath.generic_string();
    std::ofstream(base / "preferences.yaml") << YAML::Dump(prefs);
}

}  // namespace ap
