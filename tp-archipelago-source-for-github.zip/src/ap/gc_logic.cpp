#include "gc_logic.hpp"

#include <algorithm>
#include <cstring>
#include <iterator>
#include <string_view>
#include <unordered_map>

namespace ap::gc_logic {
namespace {

struct State {
    const int* counts;
    const unsigned char* reached;
    const int* opts;
    bool has(int item, int n = 1) const { return counts[item] >= n; }
    bool reach(int region) const { return reached[region] != 0; }
    int opt(int i) const { return opts[i]; }
};

struct OptionDef {
    const char* attr;
    const char* key;
    int dflt;
    std::vector<std::pair<const char*, int>> names;
};
using Rule = bool (*)(const State&);
struct Exit {
    const char* name;
    int from, to;
    Rule rule, glitched;
};
struct Location {
    const char* name;
    int code, region;
    Rule rule, glitched;
};
struct Event {
    const char* location;
    int item;
};

// The macros the generator leaves to hand-written code (tools/gen_gc_logic.py HAND_WRITTEN): they loop,
// or exit early, in the apworld's Python (Logic/Macros.py).
#include "gc_logic.inc"

static bool any_reach(const State& s, const int* rooms, size_t n) {
    for (size_t i = 0; i < n; ++i) {
        if (s.reach(rooms[i])) {
            return true;
        }
    }
    return false;
}
#define ANY_REACH(list) any_reach(s, list, sizeof(list) / sizeof(list[0]))

static bool m_can_change_time(const State& s) {
    return s.has(kShadowCrystal) || ANY_REACH(kTimeFlowRooms);
}
[[maybe_unused]] static bool m_can_warp(const State& s) {
    return s.has(kShadowCrystal) && ANY_REACH(kWarpRooms);
}
[[maybe_unused]] static bool m_has_bug(const State& s) {
    return std::any_of(std::begin(kGoldenBugs), std::end(kGoldenBugs), [&](int b) { return s.has(b); });
}
[[maybe_unused]] static bool m_has_bugs(const State& s, int count) {
    return std::count_if(std::begin(kGoldenBugs), std::end(kGoldenBugs), [&](int b) { return s.has(b); }) >= count;
}
// Logic/Macros.py has_bottles: the bottle items only count once the Lantern does (the lantern oil
// bottle can't be emptied before it), and two of them make "bottles".
static int item_index(const char* name);
static bool m_has_bottles(const State& s) {
    static const int lantern = item_index("Lantern");
    static const int bottles[] = {item_index("Empty Bottle (Fishing Hole)"), item_index("Milk (half) (Sera Bottle)"),
        item_index("Great Fairy Tears (Jovani)"), item_index("Lantern Oil (Coro Bottle)")};
    if (!s.has(lantern)) {
        return false;
    }
    int n = 0;
    for (int b : bottles) {
        n += s.has(b);
    }
    return n > 1;
}
// The map macros: open map, or any room that unlocks that province's map. (The apworld's Python calls
// can_reach_region without the player there, which only matters with Open Map off; this is what it
// means.) Snowpeak's is also open when its entrance is skipped.
[[maybe_unused]] static bool m_can_unlock_ordona_map(const State& s) {
    return s.opt(kOpenMap) || ANY_REACH(kOrdonaMapRooms);
}
[[maybe_unused]] static bool m_can_unlock_faron_map(const State& s) {
    return s.opt(kOpenMap) || ANY_REACH(kFaronMapRooms);
}
[[maybe_unused]] static bool m_can_unlock_eldin_map(const State& s) {
    return s.opt(kOpenMap) || ANY_REACH(kEldinMapRooms);
}
[[maybe_unused]] static bool m_can_unlock_lanayru_map(const State& s) {
    return s.opt(kOpenMap) || ANY_REACH(kLanayruMapRooms);
}
[[maybe_unused]] static bool m_can_unlock_snowpeak_map(const State& s) {
    return s.opt(kOpenMap) || s.opt(kSkipSnowpeak) || ANY_REACH(kSnowpeakMapRooms);
}
[[maybe_unused]] static bool m_can_unlock_gerudo_map(const State& s) {
    return s.opt(kOpenMap) || ANY_REACH(kGerudoMapRooms);
}
// `assert False, "This is no longer used"` in the apworld; nothing calls it.
[[maybe_unused]] static bool m_can_complete_faron_twilight(const State&) {
    return false;
}

static int item_index(const char* name) {
    static const std::unordered_map<std::string_view, int> map = [] {
        std::unordered_map<std::string_view, int> m;
        for (size_t i = 0; i < std::size(kItemNames); ++i) {
            m.emplace(kItemNames[i], static_cast<int>(i));
        }
        return m;
    }();
    const auto it = map.find(name);
    return it == map.end() ? -1 : it->second;
}

struct Result {
    std::vector<unsigned char> reached;
    std::vector<char> located;  // per kLocations entry
};

Result sweep(const std::vector<std::string>& items, const Options& options, bool glitched) {
    std::vector<int> counts(std::size(kItemNames), 0);
    for (const auto& name : items) {
        const int i = item_index(name.c_str());
        if (i >= 0) {
            ++counts[i];
        }
    }
    std::vector<int> opts = options.value;
    opts[kLogicRules] = glitched ? 1 : 0;

    Result r;
    r.reached.assign(std::size(kRegionNames), 0);
    r.located.assign(std::size(kLocations), 0);
    r.reached[kMenuRegion] = 1;

    static const std::unordered_map<std::string_view, size_t> locationByName = [] {
        std::unordered_map<std::string_view, size_t> m;
        for (size_t i = 0; i < std::size(kLocations); ++i) {
            m.emplace(kLocations[i].name, i);
        }
        return m;
    }();
    std::vector<char> eventDone(std::size(kEvents), 0);

    bool changed = true;
    while (changed) {
        changed = false;
        State s{counts.data(), r.reached.data(), opts.data()};
        // Menu -> start, and (Open Map) -> each portal region with the Shadow Crystal (TPWorld.create_regions)
        if (!r.reached[kStartRegion]) {
            r.reached[kStartRegion] = 1;
            changed = true;
        }
        if (opts[kOpenMap] && s.has(kShadowCrystal)) {
            for (int region : kPortalRegions) {
                if (!r.reached[region]) {
                    r.reached[region] = 1;
                    changed = true;
                }
            }
        }
        for (const auto& e : kExits) {
            if (r.reached[e.from] && !r.reached[e.to] && ((glitched && e.glitched) ? e.glitched : e.rule)(s)) {
                r.reached[e.to] = 1;
                changed = true;
            }
        }
        for (size_t i = 0; i < std::size(kLocations); ++i) {
            const auto& l = kLocations[i];
            if (!r.located[i] && r.reached[l.region] && ((glitched && l.glitched) ? l.glitched : l.rule)(s)) {
                r.located[i] = 1;
                changed = true;
            }
        }
        for (size_t i = 0; i < std::size(kEvents); ++i) {
            if (!eventDone[i] && r.located[locationByName.at(kEvents[i].location)]) {
                eventDone[i] = 1;
                ++counts[kEvents[i].item];
                changed = true;
            }
        }
    }
    return r;
}

}  // namespace

Options options_from_settings(const std::vector<std::pair<std::string, std::string>>& settings) {
    Options o;
    for (const auto& def : kOptions) {
        int v = def.dflt;
        for (const auto& [key, text] : settings) {
            if (key == def.key) {
                for (const auto& [name, value] : def.names) {
                    if (text == name) {
                        v = value;
                    }
                }
            }
        }
        o.value.push_back(v);
    }
    return o;
}

std::unordered_set<int> reachable(const std::vector<std::string>& items, const Options& options, bool glitched) {
    const Result r = sweep(items, options, glitched);
    std::unordered_set<int> out;
    for (size_t i = 0; i < std::size(kLocations); ++i) {
        if (r.located[i] && kLocations[i].code >= 0) {
            out.insert(kLocations[i].code);
        }
    }
    return out;
}

std::unordered_set<std::string> reachable_names(
    const std::vector<std::string>& items, const Options& options, bool glitched) {
    const Result r = sweep(items, options, glitched);
    std::unordered_set<std::string> out;
    for (size_t i = 0; i < std::size(kLocations); ++i) {
        if (r.located[i]) {
            out.insert(kLocations[i].name);
        }
    }
    return out;
}

int logic_rules_index() {
    return kLogicRules;
}

}  // namespace ap::gc_logic
