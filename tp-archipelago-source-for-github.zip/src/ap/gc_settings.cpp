#include "gc_settings.hpp"

#include "gc_tables.hpp"

#include <algorithm>
#include <cctype>
#include <cstring>

namespace ap::gc {

std::string normalize_value(const std::string& value) {
    std::string out;
    bool lastSpace = true;  // also trims leading space
    for (const char raw : value) {
        char c = raw == '_' ? ' ' : raw;
        if (std::isspace(static_cast<unsigned char>(c))) {
            if (!lastSpace) {
                out += ' ';
            }
            lastSpace = true;
            continue;
        }
        out += static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
        lastSpace = false;
    }
    if (!out.empty() && out.back() == ' ') {
        out.pop_back();
    }
    return out;
}

bool is_on(const std::string& value) {
    const std::string v = normalize_value(value);
    return v == "yes" || v == "on" || v == "true" || v == "1";
}

namespace {

void set_setting(StringPairs& out, const std::string& name, const std::string& value) {
    for (auto& [n, v] : out) {
        if (n == name) {
            v = value;
            return;
        }
    }
    out.emplace_back(name, value);
}

bool is_ignored(const std::string& key) {
    for (const char* ignored : ignored_settings()) {
        if (key == ignored) {
            return true;
        }
    }
    return false;
}

// "own_dungeon" / "Own  Dungeon" -> "Own Dungeon": the spelling Dusklight's options use.
std::string passthrough_spelling(const std::string& value) {
    std::string out;
    bool wordStart = true;
    for (const char raw : value) {
        const char c = raw == '_' ? ' ' : raw;
        if (c == ' ' && (out.empty() || out.back() == ' ')) {
            continue;
        }
        if (std::isalpha(static_cast<unsigned char>(c))) {
            out += wordStart ? static_cast<char>(std::toupper(static_cast<unsigned char>(c)))
                             : static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
            wordStart = false;
        } else {
            out += c;
            wordStart = c == ' ';
        }
    }
    while (!out.empty() && out.back() == ' ') {
        out.pop_back();
    }
    return out;
}

}  // namespace

SettingsResult translate_settings(const StringPairs& slotSettings) {
    SettingsResult result;
    for (const auto& fixed : fixed_settings()) {
        set_setting(result.settings, fixed.name, fixed.value);
    }
    for (const auto& def : default_settings()) {
        set_setting(result.settings, def.name, def.value);
    }

    const auto rows = setting_rows();
    for (const auto& [key, rawValue] : slotSettings) {
        const std::string value = normalize_value(rawValue);

        bool anyRow = false;
        bool exact = false;
        for (const auto& row : rows) {
            if (key != row.gcKey) {
                continue;
            }
            anyRow = true;
            if (std::strcmp(row.gcValue, "*") != 0 && normalize_value(row.gcValue) == value) {
                exact = true;
            }
        }
        if (!anyRow) {
            if (is_ignored(key)) {
                result.warnings.push_back("setting '" + key + "' has no Dusklight equivalent; ignored");
            } else {
                result.warnings.push_back("unknown setting '" + key + "' = '" + rawValue + "'; ignored");
            }
            continue;
        }

        bool applied = false;
        for (const auto& row : rows) {
            if (key != row.gcKey) {
                continue;
            }
            const bool wildcard = std::strcmp(row.gcValue, "*") == 0;
            if (exact ? (wildcard || normalize_value(row.gcValue) != value) : !wildcard) {
                continue;
            }
            const std::string dlValue =
                std::strcmp(row.dlValue, "*") == 0 ? passthrough_spelling(rawValue) : row.dlValue;
            set_setting(result.settings, row.dlName, dlValue);
            applied = true;
        }
        if (!applied) {
            result.errors.push_back("setting '" + key + "' has a value this mod cannot map: '" + rawValue + "'");
        }
    }
    return result;
}

}  // namespace ap::gc
