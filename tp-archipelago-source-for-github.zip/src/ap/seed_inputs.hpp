#pragma once

// The three files the randomizer's generator reads to build a seed (settings.yaml, plando.yaml,
// preferences.yaml), written from what the Archipelago connection learned.
//
// Free of engine headers (only the standard library and yaml-cpp), so the same code that runs in
// the mod is what tools/host_gen exercises against a live room's real placements.

#include "gc_settings.hpp"

#include <filesystem>
#include <string>
#include <utility>
#include <vector>

namespace ap {

struct SeedInput {
    std::string seedName;  // the room's seed name (RoomInfo)
    std::string slot;      // our slot name
    gc::StringPairs settings;  // Dusklight setting -> option, from gc::translate_settings
    // Dusklight location name -> generator item, one entry per location the server owns.
    std::vector<std::pair<std::string, std::string>> plando;
    // Dusklight location name -> the words that name another world's item there ("Alice's Hookshot"),
    // for the shop shelves and the other texts that name the item at a location.
    std::vector<std::pair<std::string, std::string>> labels;
};

// The text the generator is seeded with: stable for a given room and slot, so rebuilding a
// save's seed later gives the same hash.
std::string seed_string(const SeedInput& in);

// Creates `base` and writes settings.yaml, plando.yaml and preferences.yaml into it.
void write_seed_inputs(const SeedInput& in, const std::filesystem::path& base);

}  // namespace ap
