#include "gc_tables.hpp"

#include <algorithm>
#include <string>
#include <unordered_map>

namespace ap::gc {

#include "gc_data.inc"

const char* supported_world_version() {
    return kSupportedWorldVersion;
}

std::span<const Location> locations() {
    return kLocationTable;
}

std::span<const Item> items() {
    return kItemTable;
}

std::span<const SettingRow> setting_rows() {
    return kSettingRows;
}

std::span<const char* const> ignored_settings() {
    return kIgnoredSettings;
}

std::span<const SettingPair> default_settings() {
    return kDefaultSettings;
}

std::span<const SettingPair> fixed_settings() {
    return kFixedSettings;
}

namespace {

// Both tables are emitted sorted by code, which the generator checks is unique.
template <typename T>
const T* find_by_code(std::span<const T> table, int64_t apId) {
    const int64_t code = apId - kIdBase;
    if (code < 0 || code > INT32_MAX) {
        return nullptr;
    }
    const auto it = std::lower_bound(table.begin(), table.end(), static_cast<int>(code),
        [](const T& entry, int value) { return entry.code < value; });
    return it != table.end() && it->code == static_cast<int>(code) ? &*it : nullptr;
}

}  // namespace

const Location* find_location(int64_t apId) {
    return find_by_code(locations(), apId);
}

const Item* find_item(int64_t apId) {
    return find_by_code(items(), apId);
}

int64_t location_id(std::string_view dusklightName) {
    static const std::unordered_map<std::string, int64_t> byName = [] {
        std::unordered_map<std::string, int64_t> out;
        for (const auto& loc : locations()) {
            out.emplace(loc.dusklightName, kIdBase + loc.code);
        }
        return out;
    }();
    const auto it = byName.find(std::string{dusklightName});
    return it != byName.end() ? it->second : -1;
}

}  // namespace ap::gc
