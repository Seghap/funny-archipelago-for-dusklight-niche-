#pragma once

// A queue anything may push to and the game thread drains.
//
// Server packets, seed-build results and socket events are all produced somewhere other than
// the place the game state may be touched. Everything that arrives goes through one of these
// and is acted on from the game thread's update/tick, never from the producer's own context.
// (In this mod the socket is polled on the game thread, so today there is one thread; the queue
// is what keeps that true if a transport ever delivers from another.)

#include <cstddef>
#include <deque>
#include <mutex>
#include <optional>
#include <utility>

namespace ap {

template <typename T>
class Inbox {
public:
    void push(T value) {
        std::lock_guard lock{mMutex};
        mItems.push_back(std::move(value));
    }

    std::optional<T> pop() {
        std::lock_guard lock{mMutex};
        if (mItems.empty()) {
            return std::nullopt;
        }
        T value = std::move(mItems.front());
        mItems.pop_front();
        return value;
    }

    // Everything queued so far, in order, leaving the inbox empty.
    std::deque<T> drain() {
        std::lock_guard lock{mMutex};
        std::deque<T> out;
        out.swap(mItems);
        return out;
    }

    void clear() {
        std::lock_guard lock{mMutex};
        mItems.clear();
    }

    size_t size() const {
        std::lock_guard lock{mMutex};
        return mItems.size();
    }

private:
    mutable std::mutex mMutex;
    std::deque<T> mItems;
};

}  // namespace ap
