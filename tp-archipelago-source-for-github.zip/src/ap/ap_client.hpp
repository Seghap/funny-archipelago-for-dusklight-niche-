#pragma once

// Archipelago network protocol client over the mod's own WebSocket client (see ws_tcp.hpp).
//
// Transport and parsing happen in poll(), which is called once per host frame. What the server
// said is not acted on there: it is queued as an Event in a mutex-guarded Inbox, and the mod
// takes the events with next_event() from the game thread.

#include "inbox.hpp"
#include "ws_tcp.hpp"

#include <nlohmann/json.hpp>

#include <cstdint>
#include <string>
#include <unordered_map>
#include <variant>
#include <vector>

namespace ap {

using json = nlohmann::json;

// A number field from a server packet, or `fallback` when it's missing, null or not a number.
// Only for fields where a default is harmless; anything identity-bearing is checked strictly.
template <typename T>
T json_num(const json& j, const char* key, T fallback) {
    if (!j.is_object()) {
        return fallback;
    }
    const auto it = j.find(key);
    return it != j.end() && it->is_number() ? it->template get<T>() : fallback;
}

struct NetworkItem {
    int64_t item = 0;
    int64_t location = 0;
    int player = 0;
    int flags = 0;  // 1 progression, 2 useful, 4 trap
};

// One hint, as the server keeps it (NetUtils.Hint).
struct Hint {
    int receivingPlayer = 0;
    int findingPlayer = 0;
    int64_t location = 0;
    int64_t item = 0;
    bool found = false;
    std::string entrance;
    int itemFlags = 0;
    int status = 0;  // HintStatus: 0 unspecified, 10 no priority, 20 avoid, 30 priority, 40 found
};

struct ConnectInfo {
    std::string server;  // "host:port", optionally with ws:// or wss://
    std::string slot;
    std::string password;
};

enum class State {
    Disconnected,
    Connecting,    // socket opening
    Handshaking,   // waiting for RoomInfo / Connected
    Connected,
    Refused,
};

// ---- events
struct ConnectedEvent {
    json packet;  // the whole Connected packet, including slot_data
};
struct ItemsEvent {
    int index = 0;
    std::vector<NetworkItem> items;
};
struct LocationInfoEvent {
    std::vector<NetworkItem> items;  // answer to sendScouts
};
struct CheckedEvent {
    std::vector<int64_t> locations;  // RoomUpdate: locations the server now counts as checked
};
struct PrintEvent {
    std::string text;
    json message;  // the PrintJSON packet
};
struct BouncedEvent {
    json packet;
};
struct HintsEvent {
    std::vector<Hint> hints;  // the whole list, from the server's data storage
};
struct DisconnectedEvent {
    std::string reason;
    bool refused = false;  // the server turned us away; retrying the same way is pointless
};
using Event = std::variant<ConnectedEvent, ItemsEvent, LocationInfoEvent, CheckedEvent, PrintEvent,
    BouncedEvent, HintsEvent, DisconnectedEvent>;

class Client {
public:
    void connect(const ConnectInfo& info);
    void disconnect();

    // Reads the socket and queues what arrived. Every host frame.
    void poll();
    // The next queued event, in arrival order.
    bool next_event(Event& out);

    void sendLocations(const std::vector<int64_t>& locations);
    void sendScouts(const std::vector<int64_t>& locations);
    void sendGoal();
    void sendSync();
    void sendBounce(const json& bounce);
    // Tags go out with Connect, so a reconnect keeps them; changing them while connected
    // sends ConnectUpdate. "DeathLink" here is what puts us on the death link channel.
    void setTags(const std::vector<std::string>& tags);
    void say(const std::string& text);
    // Sets what a hint on one of our items shows to the player who has to find it
    // (HintStatus: 10 no priority, 20 avoid, 30 priority).
    void updateHint(int findingPlayer, int64_t location, int status);

    // Hint points we have and what a hint costs (the room's percentage of our locations).
    // What the room allows, from RoomInfo's permissions (the server's bits: 1 any time, 2 once the
    // goal is reached, 4 done by the server itself at the goal). 0 means disabled.
    int permission(const std::string& what) const;
    int hintPoints() const { return mHintPoints; }
    int hintCost() const;
    State state() const { return mState; }
    const std::string& lastError() const { return mLastError; }
    const ConnectInfo& info() const { return mInfo; }
    int slot() const { return mSlot; }
    int team() const { return mTeam; }
    const std::string& seedName() const { return mSeedName; }
    const std::string& playerName(int slot) const;
    // The game a slot plays, from the Connected packet's slot_info ("" if unknown).
    std::string gameOfSlot(int slot) const;
    // Names from the data package, by the game of the slot that owns the id.
    std::string itemName(int64_t id, int ownerSlot) const;
    std::string locationName(int64_t id, int ownerSlot) const;

private:
    void open(const std::string& url);
    void on_open();
    void on_message(std::string_view text);
    void on_closed(std::string reason);
    void handle(const json& packet);
    void send(const json& packets);

    ConnectInfo mInfo{};
    State mState = State::Disconnected;
    std::string mLastError;
    std::vector<std::string> mUrls;
    size_t mUrlIndex = 0;
    TcpWebSocket mSocket;
    std::vector<std::string> mTags;
    int mSlot = -1;
    int mTeam = 0;
    std::string mSeedName;
    std::vector<std::string> mPlayerNames;
    // From GetDataPackage / slot_info: names for display only, per game and per slot.
    std::unordered_map<std::string, std::unordered_map<int64_t, std::string>> mItemNames;
    std::unordered_map<std::string, std::unordered_map<int64_t, std::string>> mLocationNames;
    std::unordered_map<int, std::string> mSlotGames;
    int mHintPoints = 0;
    std::unordered_map<std::string, int> mPermissions;
    int mHintCostPercent = 0;
    size_t mSlotLocations = 0;
    Inbox<Event> mEvents;
};

// The server's hint list (data storage "_read_hints_<team>_<slot>") as hints.
std::vector<Hint> parse_hints(const json& list);

// PrintJSON's "data" parts as RML with the colors the Archipelago clients use (player, item by
// classification, location, entrance); every part is made safe first.
std::string print_rml(const json& data, const Client& client);

// PrintJSON's "data" parts as plain text, with player/item/location ids resolved to names.
std::string flatten_print(const json& data, const Client& client);

}  // namespace ap
