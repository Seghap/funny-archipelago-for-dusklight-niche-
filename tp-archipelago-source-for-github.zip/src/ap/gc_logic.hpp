#pragma once

// The GameCube Twilight Princess apworld's own logic, run by the tracker: the same region graph, rules and
// options, glitchless and glitched, as the apworld's Python (ref_tp_apworld/Logic). The rules are
// generated from that Python by tools/gen_gc_logic.py (into gc_logic.inc) so they cannot drift unnoticed;
// tools/ap_truth checks this evaluator against the real apworld running in Archipelago's own core.
//
// No mod services in here: tools/host_gen drives it offline.

#include <cstdint>
#include <string>
#include <string_view>
#include <unordered_set>
#include <utility>
#include <vector>

namespace ap::gc_logic {

// The values of the options the rules read, from slot_data["Settings"] (the apworld's own spelling).
// Options the slot doesn't list keep the apworld's default.
struct Options {
    std::vector<int> value;
};
Options options_from_settings(const std::vector<std::pair<std::string, std::string>>& settings);

// What a rule set reaches.
//   items:    the apworld's item names (gcName) of everything received, once per copy (start inventory
//             included)
//   glitched: use the apworld's glitched rules (what `Logic Settings: Glitched` turns on)
// Returns the locations the logic says are reachable, as apworld location codes (Archipelago id minus
// gc::kIdBase). Event locations (bosses, quest chain) are collected as soon as they're reachable, the
// way the apworld's logic assumes you will; every other location's item arrives only through `items`.
std::unordered_set<int> reachable(const std::vector<std::string>& items, const Options& options, bool glitched);

// Same, by location name: for tests.
std::unordered_set<std::string> reachable_names(
    const std::vector<std::string>& items, const Options& options, bool glitched);

// The option the generated rules read for logic: 1 = glitched.
int logic_rules_index();

}  // namespace ap::gc_logic
