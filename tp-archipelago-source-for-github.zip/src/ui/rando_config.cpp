#include "rando_config.hpp"

#include <mods/svc/log.hpp>
#include <mods/svc/file.hpp>
#include <mods/svc/ui.hpp>

#include "../session.hpp"
#include "../paths.hpp"
#include "../randomizer_context.hpp"
#include "../../generator/utility/string.hpp"
#include "../../generator/utility/text.hpp"
#include "../../generator/utility/yaml.hpp"

#include "rando_seed_generation.hpp"
#include "config_store.hpp"
#include "tracker.hpp"

#include <algorithm>
#include <map>
#include <mutex>
#include <ranges>
#include <thread>
#include <unordered_set>

#include "d/d_file_select.h"

namespace randomizer::ui {

const std::vector<std::pair<std::string, std::string>>& GetStartingInventoryLayoutOrder() {
    static const std::vector<std::pair<std::string, std::string>> layoutOrder = {
        // { display name , logic item name }
        {"Shadow Crystal", "Shadow Crystal"},
        {"Horse Call", "Horse Call"},
        {"Fishing Rod", "Progressive Fishing Rod"},
        {"Slingshot", "Slingshot"},
        {"Lantern", "Lantern"},
        {"Gale Boomerang", "Gale Boomerang"},
        {"Iron Boots", "Iron Boots"},
        {"Bow", "Progressive Bow"},
        {"Hawkeye", "Hawkeye"},
        {"Bomb Bags", "Bomb Bag"},
        {"Giant Bomb Bags", "Giant Bomb Bag"},
        {"Clawshot", "Progressive Clawshot"},
        {"Spinner", "Spinner"},
        {"Ball and Chain", "Ball and Chain"},
        {"Dominion Rod", "Progressive Dominion Rod"},
        {"Empty Bottle", "Empty Bottle"},
        {"Auru's Memo", "Aurus Memo"},
        {"Ashei's Sketch", "Asheis Sketch"},
        {"Sky Book", "Progressive Sky Book"},
        {"Sword", "Progressive Sword"},
        {"Ordon Shield", "Ordon Shield"},
        {"Hylian Shield", "Hylian Shield"},
        {"Zora Armor", "Zora Armor"},
        {"Magic Armor", "Magic Armor"},
        {"Wallet", "Progressive Wallet"},
        {"Hidden Skills", "Progressive Hidden Skill"},
        {"Poe Souls", "Poe Soul"},
        {"Fused Shadows", "Progressive Fused Shadow"},
        {"Mirror Shards", "Progressive Mirror Shard"},
        {"Faron Woods Coro Key", "Faron Woods Coro Key"},
        {"Gate Keys", "Gate Keys"},
        {"Gerudo Desert Bulblin Camp Key", "Gerudo Desert Bulblin Camp Key"},
        {"Forest Temple Small Keys", "Forest Temple Small Key"},
        {"Goron Mines Small Keys", "Goron Mines Small Key"},
        {"Lakebed Temple Small Keys", "Lakebed Temple Small Key"},
        {"Arbiter's Grounds Small Keys", "Arbiters Grounds Small Key"},
        {"Snowpeak Ruins Small Keys", "Snowpeak Ruins Small Key"},
        {"Ordon Pumpkin", "Ordon Pumpkin"},
        {"Ordon Cheese", "Ordon Cheese"},
        {"Temple of Time Small Keys", "Temple of Time Small Key"},
        {"City in the Sky Small Keys", "City in the Sky Small Key"},
        {"Palace of Twilight Small Keys", "Palace of Twilight Small Key"},
        {"Hyrule Castle Small Keys", "Hyrule Castle Small Key"},
        {"Forest Temple Big Key", "Forest Temple Big Key"},
        {"Goron Mines Key Shards", "Goron Mines Key Shard"},
        {"Lakebed Temple Big Key", "Lakebed Temple Big Key"},
        {"Arbiter's Grounds Big Key", "Arbiters Grounds Big Key"},
        {"Snowpeak Ruins Bedroom Key", "Snowpeak Ruins Bedroom Key"},
        {"Temple of Time Big Key", "Temple of Time Big Key"},
        {"City in the Sky Big Key", "City in the Sky Big Key"},
        {"Palace of Twilight Big Key", "Palace of Twilight Big Key"},
        {"Hyrule Castle Big Key", "Hyrule Castle Big Key"},
        {"Gerudo Desert Portal", "Gerudo Desert Portal"},
        {"Mirror Chamber Portal", "Mirror Chamber Portal"},
        {"Snowpeak Portal", "Snowpeak Portal"},
        {"Sacred Grove Portal", "Sacred Grove Portal"},
        {"Bridge of Eldin Portal", "Bridge of Eldin Portal"},
        {"Upper Zora's River Portal", "Upper Zoras River Portal"}
    };
    return layoutOrder;
}

UiMenuTabHandle g_menu_tab{};

FileSelectGateWindowCtx g_file_select_window_ctx{};

std::vector<std::string> get_compatible_seed_hashes() {
    const std::filesystem::path seedDir = paths::GetRandomizerSeedsPath();
    std::filesystem::create_directories(seedDir);

    static std::map<std::filesystem::path, std::filesystem::file_time_type> verifiedSeeds{};
    std::vector<std::string> seedHashes;

    // Mutex so that we can pre-load verified seeds on a different thread when the randomizer
    // is selected.
    static std::mutex compatibleSeedHashesMutex{};
    std::lock_guard lock{compatibleSeedHashesMutex};

    for (const auto& entry : std::filesystem::directory_iterator(seedDir)) {
        if (!entry.is_directory()) {
            continue;
        }

        try {
            auto it = verifiedSeeds.find(entry.path());
            auto writeTime = std::filesystem::last_write_time(entry.path() / "seed.dat");

            // If the seed hasn't changed since the last time we verified it, add it immediately
            if (it != verifiedSeeds.end() && it->second == writeTime) {
                seedHashes.push_back(entry.path().filename().string());
            } else {
                // If we haven't verified the seed, do that now
                const YAML::Node seedData = LoadYAML(entry.path() / "seed.dat");
                if (seedData["formatVersion"] &&
                    seedData["formatVersion"].as<u32>() == RandomizerContext::FORMAT_VERSION)
                {
                    verifiedSeeds[entry.path()] = std::filesystem::last_write_time(entry.path() / "seed.dat");
                    seedHashes.push_back(entry.path().filename().string());
                }
            }
        } catch (const std::exception&) {
            // Incomplete or malformed seeds cannot be activated and should not be offered.
        }
    }

    // Clear verified seeds which were deleted
    std::erase_if(verifiedSeeds, [](const auto& item) {
        return !std::filesystem::exists(item.first);
    });

    std::ranges::sort(seedHashes);
    return seedHashes;
}

namespace {
std::vector<std::string> get_presets() {
    const std::filesystem::path presetsDir = paths::GetRandomizerPresetsPath();
    std::filesystem::create_directories(presetsDir);

    std::vector<std::string> presets;
    for (const auto& entry : std::filesystem::directory_iterator(presetsDir)) {
        try {
            presets.push_back(entry.path().filename().string());
        } catch (const std::exception&) {

        }
    }

    std::ranges::sort(presets);
    return presets;
}

// Control Helpers
ModResult add_button(UiElementHandle pane, const char* label, const char* help_rml,
    UiPressedFn on_pressed, UiPredicateFn is_disabled = nullptr, void* userdata = nullptr, UiElementHandle* out_handle = nullptr)
{
    UiControlDesc desc = UI_CONTROL_DESC_INIT;
    desc.kind = UI_CONTROL_BUTTON;
    desc.label = label;
    desc.help_rml = help_rml;
    desc.on_pressed = on_pressed;
    desc.is_disabled = is_disabled;
    desc.user_data = userdata;
    return session::svc_mng.ui->pane_add_control(session::svc_mng.mod_ctx, pane, &desc, out_handle);
}

ModResult add_icon_button(UiElementHandle pane, const char* icon, const char* label, const char* help_rml,
    UiPressedFn on_pressed, UiPredicateFn is_disabled = nullptr, void* userdata = nullptr, UiElementHandle* out_handle = nullptr)
{
    UiControlDesc desc = UI_CONTROL_DESC_INIT;
    desc.kind = UI_CONTROL_ICON_BUTTON;
    desc.icon = icon;
    desc.label = label;
    desc.help_rml = help_rml;
    desc.on_pressed = on_pressed;
    desc.is_disabled = is_disabled;
    desc.user_data = userdata;
    return session::svc_mng.ui->pane_add_control(session::svc_mng.mod_ctx, pane, &desc, out_handle);
}

void add_section(UiElementHandle pane, const char* label) {
    session::svc_mng.ui->pane_add_section(session::svc_mng.mod_ctx, pane, label);
}

ModResult add_row(UiElementHandle pane, UiElementHandle* rowHandle, const UiRowAlign align, const bool wrap = false) {
    UiRowDesc row = UI_ROW_DESC_INIT;
    row.align = align;
    row.wrap = wrap;
    return session::svc_mng.ui->pane_add_row(session::svc_mng.mod_ctx, pane, &row, rowHandle);
}

void add_string_input(UiElementHandle pane, const char* label, const char* help_rml,
    int32_t max_length, UiControlGetFn getFn, UiControlSetFn setFn, UiElementHandle* out_handle = nullptr)
{
    UiControlDesc desc = UI_CONTROL_DESC_INIT;
    desc.kind = UI_CONTROL_STRING;
    desc.label = label;
    desc.help_rml = help_rml;
    desc.binding = UI_BINDING_CALLBACKS;
    desc.get = getFn;
    desc.set = setFn;
    desc.max_length = max_length;
    session::svc_mng.ui->pane_add_control(session::svc_mng.mod_ctx, pane, &desc, out_handle);
}

void add_select(UiElementHandle pane, const char* label, const char* help_rml, const char** options,
    size_t option_count, UiControlGetFn getFn, UiControlSetFn setFn, UiElementHandle* out_handle = nullptr)
{
    UiControlDesc desc = UI_CONTROL_DESC_INIT;
    desc.kind = UI_CONTROL_SELECT;
    desc.label = label;
    desc.help_rml = help_rml;
    desc.binding = UI_BINDING_CALLBACKS;
    desc.get = getFn;
    desc.set = setFn;
    desc.options = options;
    desc.option_count = option_count;
    session::svc_mng.ui->pane_add_control(session::svc_mng.mod_ctx, pane, &desc, out_handle);
}

void add_number_input(UiElementHandle pane, const char* label, const char* help_rml, int64_t min,
    int64_t max, int64_t step, UiControlGetFn getFn, UiControlSetFn setFn,
    UiElementHandle* out_handle = nullptr)
{
    UiControlDesc desc = UI_CONTROL_DESC_INIT;
    desc.kind = UI_CONTROL_NUMBER;
    desc.label = label;
    desc.help_rml = help_rml;
    desc.binding = UI_BINDING_CALLBACKS;
    desc.get = getFn;
    desc.set = setFn;
    desc.min = min;
    desc.max = max;
    desc.step = step;
    session::svc_mng.ui->pane_add_control(session::svc_mng.mod_ctx, pane, &desc, out_handle);
}

void add_select_setting(UiElementHandle pane, const char* key, UiPredicateFn isDisabledFn = nullptr, UiElementHandle* out_handle = nullptr)
{
    auto setting = FindSetting(key);
    auto info = setting->GetInfo();

    std::vector<const char*> optionsList;
    std::string help_rml = "";
    for (size_t i = 0; i < info->GetOptions().size(); ++i) {
        optionsList.push_back(info->GetOptions()[i].c_str());
        help_rml += fmt::format("<br/><span style=\"color: #C2A42D;\">{}</span>: {}", info->GetOptions()[i], info->GetDescriptions()[i]);
    }

    auto getFn = [](ModContext*, void* user_data, UiControlValue* out_value) {
        auto setting = FindSetting(static_cast<const char*>(user_data));
        const auto& options = setting->GetInfo()->GetOptions();

        for (size_t i = 0; i < options.size(); ++i) {
            if (options[i] == setting->GetCurrentOption()) {
                out_value->int_value = i;
                return;
            }
        }

        // default
        out_value->int_value = 0;
    };

    auto setFn = [](ModContext*, void* user_data, const UiControlValue* value) {
        auto setting = FindSetting(static_cast<const char*>(user_data));
        const auto& options = setting->GetInfo()->GetOptions();

        if (value->int_value >= 0 && value->int_value < options.size()) {
            setting->SetCurrentOption(options[value->int_value]);
            CheckAndSetForcedOptions();
            SaveRandomizerConfig();
        }
    };

    UiControlDesc desc = UI_CONTROL_DESC_INIT;
    desc.kind = UI_CONTROL_SELECT;
    desc.label = key;
    desc.help_rml = help_rml.c_str();
    desc.binding = UI_BINDING_CALLBACKS;
    desc.get = getFn;
    desc.set = setFn;
    desc.is_disabled = isDisabledFn;
    desc.user_data = (void*)key;
    desc.options = optionsList.data();
    desc.option_count = optionsList.size();
    session::svc_mng.ui->pane_add_control(session::svc_mng.mod_ctx, pane, &desc, out_handle);
}

void add_select_number_setting(UiElementHandle pane, const char* key, UiElementHandle* out_handle = nullptr)
{
    auto setting = FindSetting(key);
    auto info = setting->GetInfo();

    std::vector<const char*> optionsList;
    for (size_t i = 0; i < info->GetOptions().size(); ++i) {
        optionsList.push_back(info->GetOptions()[i].c_str());
    }

    auto getFn = [](ModContext*, void* user_data, UiControlValue* out_value) {
        auto setting = FindSetting(static_cast<const char*>(user_data));
        const auto& options = setting->GetInfo()->GetOptions();

        for (size_t i = 0; i < options.size(); ++i) {
            if (options[i] == setting->GetCurrentOption()) {
                out_value->int_value = i;
                return;
            }
        }

        // default
        out_value->int_value = 0;
    };

    auto setFn = [](ModContext*, void* user_data, const UiControlValue* value) {
        auto setting = FindSetting(static_cast<const char*>(user_data));
        const auto& options = setting->GetInfo()->GetOptions();

        if (value->int_value >= 0 && value->int_value < options.size()) {
            setting->SetCurrentOption(options[value->int_value]);
            SaveRandomizerConfig();
        }
    };

    UiControlDesc desc = UI_CONTROL_DESC_INIT;
    desc.kind = UI_CONTROL_SELECT;
    desc.label = key;
    desc.help_rml = "";
    desc.binding = UI_BINDING_CALLBACKS;
    desc.get = getFn;
    desc.set = setFn;
    desc.user_data = (void*)key;
    desc.options = optionsList.data();
    desc.option_count = optionsList.size();
    session::svc_mng.ui->pane_add_control(session::svc_mng.mod_ctx, pane, &desc, out_handle);
}

void add_number_setting(UiElementHandle pane, const char* label, const char* key,
    UiPredicateFn isDisabledFn, UiElementHandle* out_handle = nullptr)
{
    std::string fullOptionalKey = key;

    // check if setting exists
    auto randoSettings = seedgen::settings::GetAllSettingsInfo();
    if (!randoSettings->contains(fullOptionalKey)) {
        return;
    }
    auto curSetting = FindSetting(fullOptionalKey);
    const auto& options = curSetting->GetInfo()->GetOptions();
    int64_t min = std::stoi(options.front());
    int64_t max = std::stoi(options.back());

    auto getFn = [](ModContext*, void* user_data, UiControlValue* out_value) {
        std::string fullOptionalKey = static_cast<const char*>(user_data);

        // check if setting exists
        auto randoSettings = seedgen::settings::GetAllSettingsInfo();
        if (!randoSettings->contains(fullOptionalKey)) {
            return;
        }

        auto setting = FindSetting(fullOptionalKey);
        out_value->int_value = setting->GetCurrentOptionAsNumber();
    };

    auto setFn = [](ModContext*, void* user_data, const UiControlValue* value) {
        std::string fullOptionalKey = static_cast<const char*>(user_data);

        // check if setting exists
        auto randoSettings = seedgen::settings::GetAllSettingsInfo();
        if (!randoSettings->contains(fullOptionalKey)) {
            return;
        }

        auto setting = FindSetting(fullOptionalKey);
        setting->SetCurrentOption(std::to_string(value->int_value));
    };

    UiControlDesc desc = UI_CONTROL_DESC_INIT;
    desc.kind = UI_CONTROL_NUMBER;
    desc.label = label;
    desc.help_rml = "";
    desc.binding = UI_BINDING_CALLBACKS;
    desc.get = getFn;
    desc.set = setFn;
    desc.is_disabled = isDisabledFn;
    desc.user_data = (void*)key;
    desc.min = min;
    desc.max = max;
    desc.step = 1;
    session::svc_mng.ui->pane_add_control(session::svc_mng.mod_ctx, pane, &desc, out_handle);
}

void add_group(UiElementHandle leftPane, UiElementHandle rightPane, const char* label,
    UiGroupBuildFn buildFn, UiElementHandle* out_handle = nullptr)
{
    UiGroupDesc group = UI_GROUP_DESC_INIT;
    group.label = label;
    group.build = buildFn;
    session::svc_mng.ui->pane_add_group(mod_ctx, leftPane, rightPane, &group, out_handle);
}

// Presets
void SaveNewRandomizerPreset(const std::string& presetName, bool overwriteExisting);

void onOverwriteDialogYes(ModContext* ctx, UiDialogHandle dialog, void* user_data) {
    auto presetName = static_cast<const char*>(user_data);
    session::svc_mng.ui->dialog_close(mod_ctx, dialog);
    SaveNewRandomizerPreset(presetName, true);
};

void onOverwriteDialogNo(ModContext* ctx, UiDialogHandle dialog, void* user_data) {
    session::svc_mng.ui->dialog_close(mod_ctx, dialog);
};

void SaveNewRandomizerPreset(const std::string& presetName, bool overwriteExisting /*= false*/) {
    const std::filesystem::path presetsDir = paths::GetRandomizerPresetsPath();
    if (!exists(presetsDir))
        std::filesystem::create_directories(presetsDir);

    auto presetFilepath = paths::GetRandomizerPresetsPath() / (presetName + ".yaml");

    // If the preset exists, ask the user if they want to overwrite it. If so, call this function
    // again but force overwrite the existing preset
    if (std::filesystem::exists(presetFilepath) && !overwriteExisting) {
        UiDialogAction actions[] = {
            {sizeof(UiDialogAction), "No", onOverwriteDialogNo, nullptr, false, nullptr},
            {sizeof(UiDialogAction), "Yes", onOverwriteDialogYes, nullptr, false, nullptr},
        };

        actions[1].user_data = (void*)presetName.data();

        const std::string body_rml = "A preset with the name " + presetName + " already exists. Do you wish to overwrite it?";
        UiDialogDesc desc = UI_DIALOG_DESC_INIT;
        desc.icon = "information";
        desc.title = "Overwrite Existing Preset";
        desc.body_rml = body_rml.c_str();
        desc.actions = actions;
        desc.action_count = 2;
        session::svc_mng.ui->dialog_push(mod_ctx, &desc, nullptr);
        return;
    }

    // If there was an error trying to save, let the user know
    try {
        GetRandomizerConfig().WriteSettingsToFile(presetFilepath);
    } catch (std::exception& e) {
        std::string body_rml = fmt::format("Error: {}", e.what());
        UiToastDesc desc = UI_TOAST_DESC_INIT;
        desc.title_rml = "Error Saving Preset";
        desc.body_rml = body_rml.c_str();
        desc.duration_ms = 6000;
        session::svc_mng.ui->push_toast(session::svc_mng.mod_ctx, &desc);
        mods::log::error("Error saving preset: {}", e.what());
        return;
    }

    std::string body_rml = fmt::format("Saved preset {}", presetName);
    UiToastDesc desc = UI_TOAST_DESC_INIT;
    desc.title_rml = "";
    desc.body_rml = body_rml.c_str();
    desc.duration_ms = 3000;
    session::svc_mng.ui->push_toast(session::svc_mng.mod_ctx, &desc);
}

void ApplyExistingRandomizerPreset(const std::filesystem::path& presetFilePath) {
    // Don't overwrite the seed with the one from the preset
    auto seed = GetRandomizerConfig().GetSeed();
    try {
        GetRandomizerConfig().LoadFromFile(presetFilePath, paths::GetRandomizerPreferencesPath(), false, true);
        GetRandomizerConfig().SetSeed(seed);
    } catch (std::exception& e) {
        std::string body_rml = fmt::format("Error: {}", e.what());
        UiToastDesc desc = UI_TOAST_DESC_INIT;
        desc.title_rml = "Error Loading Preset";
        desc.body_rml = body_rml.c_str();
        desc.duration_ms = 6000;
        desc.type = "error";
        session::svc_mng.ui->push_toast(session::svc_mng.mod_ctx, &desc);
        mods::log::error("Error loading preset: {}", e.what());
        return;
    }

    std::string body_rml = fmt::format("Loaded preset {}", presetFilePath.stem().generic_string());
    UiToastDesc desc = UI_TOAST_DESC_INIT;
    desc.title_rml = "";
    desc.body_rml = body_rml.c_str();
    desc.duration_ms = 3000;
    session::svc_mng.ui->push_toast(session::svc_mng.mod_ctx, &desc);
}

UiDialogHandle g_presetSaveDialog{};
UiDialogHandle g_presetLoadDialog{};
std::string g_presetInputText{};

void onPresetDialogSave(ModContext* ctx, UiDialogHandle dialog, void* user_data) {
    if (!g_presetInputText.empty()) {
        SaveNewRandomizerPreset(g_presetInputText, false);
    }

    g_presetSaveDialog = 0;
    session::svc_mng.ui->dialog_close(mod_ctx, dialog);
};

void onPresetDialogCancel(ModContext* ctx, UiDialogHandle dialog, void* user_data) {
    session::svc_mng.ui->dialog_close(mod_ctx, dialog);
};

void buildPresetSaveDialog(ModContext* ctx, void* user_data) {
    UiDialogAction actions[] = {
        {sizeof(UiDialogAction), "Save", onPresetDialogSave, nullptr, false, nullptr},
        {sizeof(UiDialogAction), "Cancel", onPresetDialogCancel, nullptr, false, nullptr},
    };

    auto buildPaneFn = [](ModContext* ctx, UiElementHandle pane, void* user_data, ModError* out_error) {
        UiControlDesc input = UI_CONTROL_DESC_INIT;
        input.kind = UI_CONTROL_STRING;
        input.label = "";
        input.get = [](ModContext*, void*, UiControlValue* value) {
            value->string_value = g_presetInputText.c_str();
        };
        input.set = [](ModContext*, void*, const UiControlValue* value) {
            g_presetInputText = value->string_value != nullptr ? value->string_value : "";
        };
        return session::svc_mng.ui->pane_add_control(mod_ctx, pane, &input, nullptr);
    };

    UiDialogDesc desc = UI_DIALOG_DESC_INIT;
    desc.icon = "information";
    desc.title = "Preset Name";
    desc.body_rml = "";
    desc.actions = actions;
    desc.action_count = std::size(actions);
    desc.build = buildPaneFn;
    session::svc_mng.ui->dialog_push(mod_ctx, &desc, &g_presetSaveDialog);
}

void onPresetDialogLoadCancel(ModContext* ctx, UiDialogHandle dialog, void* user_data) {
    session::svc_mng.ui->dialog_close(ctx, dialog);
}

void onPresetLoad(ModContext* ctx, void* user_data) {
    auto preset = static_cast<const char*>(user_data);
    ApplyExistingRandomizerPreset(paths::GetRandomizerPresetsPath() / preset);
    session::svc_mng.ui->dialog_close(ctx, g_presetLoadDialog);
}

std::vector<std::string> presetList{};
void buildPresetLoadDialog(ModContext* ctx, void* user_data) {
    UiDialogAction actions[] = {
        {sizeof(UiDialogAction), "Cancel", onPresetDialogLoadCancel, nullptr, false, nullptr},
    };

    auto buildPaneFn = [](ModContext* ctx, UiElementHandle pane, void* user_data, ModError* out_error) {
        presetList = get_presets();

        for (const auto& preset : presetList) {
            ModResult rt = add_button(pane,
                preset.c_str(),
                "",
                onPresetLoad,
                nullptr,
                (void*)preset.c_str());
            if (rt != MOD_OK) {
                return rt;
            }
        }

        return MOD_OK;
    };

    UiDialogDesc desc = UI_DIALOG_DESC_INIT;
    desc.icon = "information";
    desc.title = "Load Preset";
    desc.body_rml = "";
    desc.actions = actions;
    desc.action_count = std::size(actions);
    desc.build = buildPaneFn;
    session::svc_mng.ui->dialog_push(mod_ctx, &desc, &g_presetLoadDialog);
}

std::vector<std::string> g_seedHashes = {};

// Seed Management Tab
UiDialogHandle g_seedDialog{};
void onSeedDialogCancel(ModContext* ctx, UiDialogHandle dialog, void* user_data) {
    session::svc_mng.ui->dialog_close(ctx, dialog);
}

struct DialogSeed {
    std::string hash;
    bool isUsed;
};

void onSeedDelete(ModContext* ctx, DialogSeed const& user_data) {
    if (randomizer_GetContext().mHash == user_data.hash) {
        randomizer_GetContext() = RandomizerContext{};
    }
    std::filesystem::remove_all(paths::GetRandomizerSeedsPath() / user_data.hash);
    session::svc_mng.ui->dialog_close(ctx, g_seedDialog);
}

bool isSeedDeleteDisabled(DialogSeed const& seed) {
    return seed.isUsed;
}

std::vector<DialogSeed> g_dialogSeedHashes = {};

typedef bool (*UiSeedDialogPredicateFunc)(DialogSeed const& seed);
typedef void (*UiSeedDialogPressedFunc)(ModContext* ctx, DialogSeed const& seed);

template<UiSeedDialogPredicateFunc predicate>
bool dialogIsDisabledWrapper(ModContext*, void* user_data) {
    if (predicate == nullptr) {
        return false;
    }

    return predicate(*static_cast<DialogSeed*>(user_data));
}

template<UiSeedDialogPressedFunc func>
void dialogPressedWrapper(ModContext* ctx, void* user_data) {
    func(ctx, *static_cast<DialogSeed*>(user_data));
}

template<UiSeedDialogPressedFunc on_pressed, UiSeedDialogPredicateFunc is_disabled>
ModResult buildSeedDialogPane(ModContext* ctx, UiElementHandle pane, void* user_data, ModError* out_error) {
    auto hashes = get_compatible_seed_hashes();
    g_dialogSeedHashes.clear();
    for (auto& hash : hashes) {
        g_dialogSeedHashes.push_back({std::move(hash), false});
    }

    // Get hashes of seeds which are actively being used
    std::array<std::string, 3> fileHashes{"", "", ""};
    for (size_t fileNum = 0; fileNum < 3; ++fileNum) {
        char hash[64];
        size_t size = sizeof(hash) - 1;
        ModResult rt = session::svc_mng.save->peek_blob(ctx, fileNum, "seed_hash", hash, &size);
        if (rt == MOD_OK && size > 0) {
            fileHashes[fileNum] = std::string(hash, size);
        }
    }

    for (auto& entry : g_dialogSeedHashes) {
        // Append the file a seed is being used on to the hash in this dialog
        auto adjustedHash = entry.hash;
        for (size_t fileNum = 0; fileNum < 3; ++fileNum) {
            auto& fileHash = fileHashes[fileNum];
            if (entry.hash == fileHash) {
                adjustedHash += " (File " + std::to_string(fileNum + 1) + ')';
                entry.isUsed = true;
            }
        }

        ModResult rt = add_button(pane,
            adjustedHash.c_str(),
            "",
            dialogPressedWrapper<on_pressed>,
            dialogIsDisabledWrapper<is_disabled>,
            &entry);
        if (rt != MOD_OK) {
            return rt;
        }
    }

    return MOD_OK;
}

void buildSeedDeleteDialog(ModContext* ctx, void* user_data) {
    UiDialogAction actions[] = {
        {sizeof(UiDialogAction), "Cancel", onSeedDialogCancel, nullptr, false, nullptr},
    };

    UiDialogDesc desc = UI_DIALOG_DESC_INIT;
    desc.icon = "information";
    desc.title = "Delete Seed";
    desc.body_rml = "";
    desc.actions = actions;
    desc.action_count = std::size(actions);
    desc.build = buildSeedDialogPane<onSeedDelete, isSeedDeleteDisabled>;
    session::svc_mng.ui->dialog_push(mod_ctx, &desc, &g_seedDialog);
}

void buildSeedStringPermalinkPastedDialog(ModContext* ctx, void* user_data) {
    UiDialogAction actions[] = {
        {sizeof(UiDialogAction), "OK",
            [](ModContext* ctx, UiDialogHandle dialog, void* user_data) {
                session::svc_mng.ui->dialog_close(ctx, dialog);
            },nullptr, false, nullptr},
    };

    UiDialogDesc desc = UI_DIALOG_DESC_INIT;
    desc.title = "Possible Permalink Detected";
    desc.body_rml = "It looks like you may have tried inputting a permalink into the seed string field. To apply a permalink, click the \"Paste Permalink\" button below.";
    desc.actions = actions;
    desc.action_count = std::size(actions);
    desc.build = nullptr;
    session::svc_mng.ui->dialog_push(mod_ctx, &desc, nullptr);
}

void onSeedExportSpoiler(ModContext* ctx, DialogSeed const& seed) {
    auto spoilerPath = paths::GetRandomizerSeedsPath() / seed.hash / (seed.hash + " Spoiler Log.txt");

    mods::file::export_file(spoilerPath.generic_string(), seed.hash + " Spoiler Log.txt", [&](mods::file::PickResult result) {
        UiToastDesc desc = UI_TOAST_DESC_INIT;
        desc.title_rml = "Randomizer";
        if (result.status == MOD_OK) {
            desc.body_rml = "Successfully Exported Spoiler Log";
            desc.duration_ms = 3000;
        } else {
            desc.body_rml = "Failed to Export Spoiler Log. See mod log for details.";
            desc.duration_ms = 5000;
            mods::log::error("Could not export spoiler log for seed {}. Reason: {}", seed.hash, result.error);
        }

        session::svc_mng.ui->push_toast(session::svc_mng.mod_ctx, &desc);
    });

    session::svc_mng.ui->dialog_close(ctx, g_seedDialog);
}

void onSeedExportAllData(ModContext* ctx, DialogSeed const& seed) {
    auto seedPath = paths::GetRandomizerSeedsPath() / seed.hash;

    mods::file::PickOptions options{};
    mods::file::pick_folder(options, [=](mods::file::PickResult result) {
        if (result.status == MOD_OK && !result.locations.empty()) {
            std::filesystem::path exportPath = result.locations.front();

            // Create the export folder. if it has any previous contents, delete those.
            auto exportFolder = exportPath / seed.hash;
            std::filesystem::create_directories(exportFolder);
            for (const auto& entry : std::filesystem::directory_iterator(seedPath)) {
                if (entry.is_directory()) {
                    continue;
                }

                // Remove previous files if they exist at the destination
                if (std::filesystem::exists(exportFolder / entry.path().filename().generic_string())) {
                    std::filesystem::remove(exportFolder / entry.path().filename().generic_string());
                }

                auto buffer = mods::file::read_all(entry.path().generic_string());
                std::string location{};
                auto createChildResult = mods::file::create_child(exportFolder.generic_string(), entry.path().filename().generic_string(), location);
                if (createChildResult == MOD_OK) {
                    mods::file::write_all(location, buffer.bytes());
                } else {
                    UiToastDesc desc = UI_TOAST_DESC_INIT;
                    desc.title_rml = "Randomizer";
                    desc.body_rml = "Failed to export seed data. See mod log for details.";
                    desc.duration_ms = 5000;
                    session::svc_mng.ui->push_toast(session::svc_mng.mod_ctx, &desc);
                    session::svc_mng.ui->dialog_close(ctx, g_seedDialog);
                    mods::log::error("Could not export file {} for seed {}. Reason: {}",
                        entry.path().filename().generic_string(), seed.hash, static_cast<int>(createChildResult));
                    return;
                }
            }

            UiToastDesc desc = UI_TOAST_DESC_INIT;
            desc.title_rml = "Randomizer";
            desc.body_rml = "Successfully Exported Seed Data";
            desc.duration_ms = 3000;
            session::svc_mng.ui->push_toast(session::svc_mng.mod_ctx, &desc);

        } else {
            UiToastDesc desc = UI_TOAST_DESC_INIT;
            desc.title_rml = "Randomizer";
            desc.body_rml = "Failed to export seed data. Bad export path.";
            desc.duration_ms = 5000;
            session::svc_mng.ui->push_toast(session::svc_mng.mod_ctx, &desc);
        }
    });

    session::svc_mng.ui->dialog_close(ctx, g_seedDialog);
}

void buildSeedExportSpoilerDialog(ModContext* ctx, void* user_data) {
    UiDialogAction actions[] = {
        {sizeof(UiDialogAction), "Cancel", onSeedDialogCancel, nullptr, false, nullptr},
    };

    UiDialogDesc desc = UI_DIALOG_DESC_INIT;
    desc.icon = "information";
    desc.title = "Export Spoiler Log";
    desc.body_rml = "";
    desc.actions = actions;
    desc.action_count = std::size(actions);
    desc.build = buildSeedDialogPane<onSeedExportSpoiler, nullptr>;
    session::svc_mng.ui->dialog_push(mod_ctx, &desc, &g_seedDialog);
}

void buildSeedExportAllDataDialog(ModContext* ctx, void* user_data) {
    UiDialogAction actions[] = {
        {sizeof(UiDialogAction), "Cancel", onSeedDialogCancel, nullptr, false, nullptr},
    };

    UiDialogDesc desc = UI_DIALOG_DESC_INIT;
    desc.icon = "information";
    desc.title = "Export Seed Data";
    desc.body_rml = "";
    desc.actions = actions;
    desc.action_count = std::size(actions);
    desc.build = buildSeedDialogPane<onSeedExportAllData, nullptr>;
    session::svc_mng.ui->dialog_push(mod_ctx, &desc, &g_seedDialog);
}

ModResult buildSeedManagementTab(ModContext* ctx, UiWindowHandle, UiElementHandle leftPane,
    UiElementHandle rightPane, void*, ModError*)
{
    add_button(leftPane,
        "Generate Seed",
        "Generate a Randomizer seed using the current configuration options, and the supplied seed string.",
        [](ModContext*, void*) {
            if (TryCreateRandomSeed()) {
                mods::log::info("Created new Seed for generator.");
            }
            GenerateRandomizerSeed();
        });

    UiElementHandle seedRow{};
    add_row(leftPane, &seedRow, UI_ROW_ALIGN_SPACE_BETWEEN);

    UiElementHandle seedStringElement{};
    add_string_input(seedRow,
        "Seed String",
        "Current value used by the randomizer for seeding generation. If blank, a random seed value will be chosen for seed generation.",
        31,
        [](ModContext*, void*, UiControlValue* out_value) {
            static char buffer[32];
            strncpy(buffer,GetRandomizerConfig().GetSeed().c_str(),31);
            out_value->string_value = buffer;
        },
        [](ModContext* ctx, void* user_data, const UiControlValue* value) {
            // If it seems like the user attempted to paste a permalink into the seed string field,
            // don't apply it to the seed string
            if (seedgen::config::LooksLikePermalink(value->string_value)) {
                buildSeedStringPermalinkPastedDialog(ctx, user_data);
                return;
            }

            GetRandomizerConfig().SetSeed(value->string_value);
            SaveRandomizerConfig();
        },
        &seedStringElement);
    svc_ui->elem_set_class(ctx, seedStringElement, "fill-horizontal", true);

    add_icon_button(seedRow,
        "shuffle",
        "Random Seed String",
        "Use a new random seed string for seed generation.",
        [](ModContext*, void*) {
            NewRandomSeed();
    });

    add_section(leftPane, "Permalink");
    UiElementHandle permalinkRow{};
    add_row(leftPane, &permalinkRow, UI_ROW_ALIGN_CENTER);
    {
        std::string help_rml = "Click this button to copy your current settings permalink to share with others.<br/>";
        help_rml += fmt::format(
            "<br/>Current Permalink:<br/><span style=\"word-break: break-all;\">{}</span>",
            GetRandomizerConfig().GetPermalink());
        UiElementHandle copyPermalinkElement{};
        add_button(permalinkRow,
            "Copy Permalink",
            help_rml.c_str(),
            [](ModContext*, void*) {
                mods::ui::set_clipboard_text(GetRandomizerConfig().GetPermalink().data());

                UiToastDesc desc = UI_TOAST_DESC_INIT;
                desc.title_rml = "Randomizer";
                desc.body_rml = "Permalink Copied";
                desc.duration_ms = 3000;
                session::svc_mng.ui->push_toast(session::svc_mng.mod_ctx, &desc);
            },
            nullptr,
            nullptr,
            &copyPermalinkElement);
        svc_ui->elem_set_class(ctx, copyPermalinkElement, "fill-horizontal", true);
    }

    UiElementHandle pastePermalinkElement{};
    add_button(permalinkRow,
        "Paste Permalink",
        "Click this button to paste in a permalink from your clipboard. This will overwrite your current settings.",
        [](ModContext*, void*) {
            std::string text;
            ModResult rt = mods::ui::get_clipboard_text(text);
            if (rt != MOD_OK) {
                return;
            }

            auto result = GetRandomizerConfig().LoadFromPermalink(text);
            if (result.has_value()) {
                mods::log::error("Failed to load permalink: {}", result.value());
                UiToastDesc desc = UI_TOAST_DESC_INIT;
                desc.title_rml = "Randomizer";
                desc.body_rml = "Could not apply permalink. See the mod log for details.";
                desc.duration_ms = 6000;
                session::svc_mng.ui->push_toast(session::svc_mng.mod_ctx, &desc);
                return;
            }

            SaveRandomizerConfig();

            UiToastDesc desc = UI_TOAST_DESC_INIT;
            desc.title_rml = "Randomizer";
            desc.body_rml = "Applied Permalink";
            desc.duration_ms = 3000;
            session::svc_mng.ui->push_toast(session::svc_mng.mod_ctx, &desc);
        },
        nullptr,
        nullptr,
        &pastePermalinkElement);
    svc_ui->elem_set_class(ctx, pastePermalinkElement, "fill-horizontal", true);

    add_section(leftPane, "Presets");
    UiElementHandle presetsRow{};
    add_row(leftPane, &presetsRow, UI_ROW_ALIGN_CENTER);

    UiElementHandle savePresetElement{};
    add_button(presetsRow,
        "Save Preset",
        "Save the current settings as a preset you can load later.",
        buildPresetSaveDialog,
        nullptr,
        nullptr,
        &savePresetElement);
    svc_ui->elem_set_class(ctx, savePresetElement, "fill-horizontal", true);

    UiElementHandle loadPresetElement{};
    add_button(presetsRow,
        "Load Preset",
        "Choose a previously saved preset to load from.",
        buildPresetLoadDialog,
        nullptr,
        nullptr,
        &loadPresetElement);
    svc_ui->elem_set_class(ctx, loadPresetElement, "fill-horizontal", true);

    add_section(leftPane, "Delete Seeds");
    add_button(leftPane,
        "Delete Seed",
        "Delete a selected seed.",
        buildSeedDeleteDialog);

    add_section(leftPane, "Seed Data");
    add_button(leftPane,
        "Export Spoiler Log",
        "Export the spoiler log of a specific seed.",
        buildSeedExportSpoilerDialog);
    add_button(leftPane,
        "Export Seed Data",
        "Export all data of a specific seed.",
        buildSeedExportAllDataDialog);

    return MOD_OK;
}

ModResult updateSeedManagementTab(ModContext* ctx, void*, ModError*) {
    return MOD_OK;
}

// Seed Options Tab
ModResult buildSeedOptionsTab(ModContext* ctx, UiWindowHandle, UiElementHandle leftPane,
    UiElementHandle rightPane, void*, ModError*)
{
    add_button(leftPane,
        "Reset Settings to Default",
        "Reset all settings to their default values. This will also clear starting items and excluded locations.",
        [](ModContext*, void*) {
            GetRandomizerConfig().ResetSettingsToDefault();
            SaveRandomizerConfig();
        });

    add_section(leftPane, "Logic Settings");
    add_select_setting(leftPane, "Logic Rules");

    add_section(leftPane, "Access Options");
    add_select_setting(leftPane, "Hyrule Barrier Requirements");

    // pretty ugly way of doing this, but it works for now
    add_number_setting(leftPane,
        "Required Fused Shadows",
        "Hyrule Barrier Fused Shadows",
        [](ModContext*, void*) {
            auto setting = FindSetting("Hyrule Barrier Requirements");
            if (setting->GetCurrentOption() != "Fused Shadows") {
                return true;
            }

            return false;
        });
    add_number_setting(leftPane,
        "Required Mirror Shards",
        "Hyrule Barrier Mirror Shards",
        [](ModContext*, void*) {
            auto setting = FindSetting("Hyrule Barrier Requirements");
            if (setting->GetCurrentOption() != "Mirror Shards") {
                return true;
            }

            return false;
        });
    add_number_setting(leftPane,
        "Required Dungeons",
        "Hyrule Barrier Dungeons",
        [](ModContext*, void*) {
            auto setting = FindSetting("Hyrule Barrier Requirements");
            if (setting->GetCurrentOption() != "Dungeons") {
                return true;
            }

            return false;
        });
    add_number_setting(leftPane,
        "Required Poe Souls",
        "Hyrule Barrier Poe Souls",
        [](ModContext*, void*) {
            auto setting = FindSetting("Hyrule Barrier Requirements");
            if (setting->GetCurrentOption() != "Poe Souls") {
                return true;
            }

            return false;
        });
    add_number_setting(leftPane,
        "Required Hearts",
        "Hyrule Barrier Hearts",
        [](ModContext*, void*) {
            auto setting = FindSetting("Hyrule Barrier Requirements");
            if (setting->GetCurrentOption() != "Hearts") {
                return true;
            }

            return false;
        });

    add_select_setting(leftPane, "Palace of Twilight Requirements");
    add_select_setting(leftPane, "Faron Woods Logic");
    add_select_setting(leftPane, "Mirror Chamber Access");

    add_section(leftPane, "Shuffles");
    add_select_setting(leftPane, "Golden Bugs");
    add_select_setting(leftPane, "Sky Characters");
    add_select_setting(leftPane, "Gifts From NPCs");
    add_select_setting(leftPane, "Shop Items");
    add_select_setting(leftPane, "Hidden Skills");
    add_select_setting(leftPane, "Hidden Rupees");
    add_select_setting(leftPane, "Freestanding Rupees");
    add_select_setting(leftPane, "Poe Souls");
    add_select_setting(leftPane, "Ilia Memory Quest");
    add_select_setting(leftPane, "Item Scarcity");
    add_select_setting(leftPane, "Trap Item Frequency");

    add_section(leftPane, "Dungeon Items");
    add_select_setting(leftPane, "Small Keys");
    add_select_setting(leftPane, "Big Keys");
    add_select_setting(leftPane, "Maps and Compasses");

    add_select_setting(leftPane, "Hyrule Castle Big Key Requirements");
    // pretty ugly way of doing this, but it works for now
    add_number_setting(leftPane,
        "Required Fused Shadows",
        "Hyrule Castle Big Key Fused Shadows",
        [](ModContext*, void*) {
            auto setting = FindSetting("Hyrule Castle Big Key Requirements");
            if (setting->GetCurrentOption() != "Fused Shadows") {
                return true;
            }

            return false;
        });
    add_number_setting(leftPane,
        "Required Mirror Shards",
        "Hyrule Castle Big Key Mirror Shards",
        [](ModContext*, void*) {
            auto setting = FindSetting("Hyrule Castle Big Key Requirements");
            if (setting->GetCurrentOption() != "Mirror Shards") {
                return true;
            }

            return false;
        });
    add_number_setting(leftPane,
        "Required Dungeons",
        "Hyrule Castle Big Key Dungeons",
        [](ModContext*, void*) {
            auto setting = FindSetting("Hyrule Castle Big Key Requirements");
            if (setting->GetCurrentOption() != "Dungeons") {
                return true;
            }

            return false;
        });
    add_number_setting(leftPane,
        "Required Poe Souls",
        "Hyrule Castle Big Key Poe Souls",
        [](ModContext*, void*) {
            auto setting = FindSetting("Hyrule Castle Big Key Requirements");
            if (setting->GetCurrentOption() != "Poe Souls") {
                return true;
            }

            return false;
        });
    add_number_setting(leftPane,
        "Required Hearts",
        "Hyrule Castle Big Key Hearts",
        [](ModContext*, void*) {
            auto setting = FindSetting("Hyrule Castle Big Key Requirements");
            if (setting->GetCurrentOption() != "Hearts") {
                return true;
            }

            return false;
        });

    add_select_setting(leftPane, "Dungeon Rewards Can Be Anywhere");
    add_select_setting(leftPane, "Small Keys on Bosses");
    add_select_setting(leftPane, "Unrequired Dungeons Are Barren");

    add_section(leftPane, "Timesavers");
    add_select_setting(
        leftPane,
        "Skip Prologue",
        [](ModContext*, void*) {
            bool randomizedStartingSpawn = *FindSetting("Randomize Starting Spawn") != "Off";
            bool randomizedDungeonEntrances = *FindSetting("Randomize Dungeon Entrances") != "Off";
            bool randomizedBossEntrances = *FindSetting("Randomize Boss Entrances") != "Off";
            bool randomizedGrottoEntrances = *FindSetting("Randomize Grotto Entrances") != "Off";
            bool randomizedCaveEntrances = *FindSetting("Randomize Cave Entrances") != "Off";
            bool randomizedInteriorEntrances = *FindSetting("Randomize Interior Entrances") != "Off";
            bool randomizedOverworldEntrances = *FindSetting("Randomize Overworld Entrances") != "Off";
            bool wolfStart = *FindSetting("Starting Form") == "Wolf";

            // Prologue is not compatible with wolf start or any ER
            return wolfStart || randomizedStartingSpawn || randomizedDungeonEntrances || randomizedBossEntrances ||
                    randomizedGrottoEntrances || randomizedCaveEntrances || randomizedInteriorEntrances || randomizedOverworldEntrances;
        });
    add_select_setting(
        leftPane,
        "Faron Twilight Cleared",
        [](ModContext*, void*) {
            bool randomizedCaveEntrances = *FindSetting("Randomize Cave Entrances") != "Off";
            bool randomizedOverworldEntrances = *FindSetting("Randomize Overworld Entrances") != "Off";

            // Faron Twilight is not compatible with Cave or Overworld ER
            return randomizedCaveEntrances || randomizedOverworldEntrances;
        });
    add_select_setting(
        leftPane,
        "Eldin Twilight Cleared",
        [](ModContext*, void*) {
            bool randomizedOverworldEntrances = *FindSetting("Randomize Overworld Entrances") != "Off";

            // Eldin Twilight is not compatible with Overworld ER
            return randomizedOverworldEntrances;
        });
    add_select_setting(
        leftPane,
        "Lanayru Twilight Cleared",
        [](ModContext*, void*) {
            bool randomizedOverworldEntrances = *FindSetting("Randomize Overworld Entrances") != "Off";

            // Lanayru Twilight is not compatible with Overworld ER
            return randomizedOverworldEntrances;
        });
    add_select_setting(
        leftPane,
        "Skip Midna's Desperate Hour",
        [](ModContext*, void*) {
            bool randomizedStartingSpawn = *FindSetting("Randomize Starting Spawn") != "Off";
            bool randomizedDungeonEntrances = *FindSetting("Randomize Dungeon Entrances") != "Off";
            bool randomizedBossEntrances = *FindSetting("Randomize Boss Entrances") != "Off";
            bool randomizedGrottoEntrances = *FindSetting("Randomize Grotto Entrances") != "Off";
            bool randomizedCaveEntrances = *FindSetting("Randomize Cave Entrances") != "Off";
            bool randomizedInteriorEntrances = *FindSetting("Randomize Interior Entrances") != "Off";
            bool randomizedOverworldEntrances = *FindSetting("Randomize Overworld Entrances") != "Off";

            // MDH is not compatible with any ER
            return randomizedStartingSpawn || randomizedDungeonEntrances || randomizedBossEntrances ||
                    randomizedGrottoEntrances || randomizedCaveEntrances || randomizedInteriorEntrances || randomizedOverworldEntrances;
        });
    add_select_setting(leftPane, "Skip Minor Cutscenes");
    add_select_setting(leftPane, "Skip Major Cutscenes");
    add_select_setting(leftPane, "Unlock Map Regions");
    add_select_setting(leftPane, "Open Door of Time");
    add_select_setting(leftPane, "Active Goron Mines Magnets");
    add_select_setting(leftPane, "Lower Hyrule Castle Chandelier");
    add_select_setting(leftPane, "Skip Bridge Donation");

    add_section(leftPane, "Entrance Randomizer Settings");
    add_select_setting(leftPane, "Randomize Starting Spawn");
    add_select_setting(leftPane, "Randomize Dungeon Entrances");
    add_select_setting(leftPane, "Randomize Boss Entrances");
    add_select_setting(leftPane, "Randomize Grotto Entrances");
    add_select_setting(leftPane, "Randomize Cave Entrances");
    add_select_setting(leftPane, "Randomize Interior Entrances");
    add_select_setting(leftPane, "Randomize Overworld Entrances");
    add_select_setting(leftPane, "Decouple Double Door Entrances");
    add_select_setting(leftPane, "Decouple Entrances");

    add_section(leftPane, "Additional Settings");
    add_select_setting(leftPane, "Starting Time of Day");
    add_select_setting(leftPane, "Logic Transform Anywhere");
    add_select_setting(leftPane, "Logic Increase Wallet Capacity");
    add_select_setting(leftPane, "Logic Damage Multiplier");

    add_section(leftPane, "Dungeon Entrance Settings");
    add_select_setting(leftPane, "Lakebed Does Not Require Water Bombs");
    add_select_setting(leftPane, "Arbiters Does Not Require Bulblin Camp");
    add_select_setting(leftPane, "Snowpeak Does Not Require Reekfish Scent");
    add_select_setting(leftPane, "Sacred Grove Does Not Require Skull Kid");
    add_select_setting(leftPane, "City Does Not Require Filled Skybook");
    add_select_setting(leftPane, "Goron Mines Entrance");
    add_select_setting(leftPane, "Temple of Time Sword Requirement");

    add_section(leftPane, "Tricks");
    add_select_setting(leftPane, "Back Slice as Sword");
    add_select_setting(leftPane, "Ball and Chain Webs");

    return MOD_OK;
}

// Hints Tab
ModResult buildHintsTab(ModContext* ctx, UiWindowHandle, UiElementHandle leftPane,
    UiElementHandle rightPane, void*, ModError*)
{
    add_section(leftPane, "Path Hints");
    add_select_number_setting(leftPane, "Number of Path Hints");
    add_select_setting(leftPane, "Path Hints on Midna");
    add_select_setting(leftPane, "Path Hints on Hint Signs");

    add_section(leftPane, "Barren Hints");
    add_select_number_setting(leftPane, "Number of Barren Hints");
    add_select_setting(leftPane, "Barren Hints on Midna");
    add_select_setting(leftPane, "Barren Hints on Hint Signs");

    add_section(leftPane, "Item Hints");
    add_select_number_setting(leftPane, "Number of Item Hints");
    add_select_setting(leftPane, "Item Hints on Midna");
    add_select_setting(leftPane, "Item Hints on Hint Signs");

    add_section(leftPane, "Location Hints");
    add_select_number_setting(leftPane, "Number of Location Hints");
    add_select_setting(leftPane, "Location Hints on Midna");
    add_select_setting(leftPane, "Location Hints on Hint Signs");
    add_select_setting(leftPane, "Prioritize Remote Location Hints");

    add_section(leftPane, "Miscellaneous Hints");
    add_select_setting(leftPane, "Agitha Hints");

    return MOD_OK;
}

// Starting Inventory Tab
UiElementHandle startingInventoryRmlElem = 0;

template <int Max = 1>
void on_pressed_starting_inventory_item(ModContext*, void* userdata) {
    const char* itemName = static_cast<const char*>(userdata);
    auto& inventory = GetRandomizerConfig().GetSettings().GetModifiableStartingInventory();
    int newCount = inventory[itemName] + 1;
    if (newCount > Max) {
        inventory.erase(itemName);
    } else {
        inventory.at(itemName) = newCount;
    }
    SaveRandomizerConfig();

    mDoAud_seStartMenu(Z2SE_SY_NAME_CURSOR);
}

template <int Max = 1>
void add_starting_inventory_item(UiElementHandle leftPane, const char* displayName, const char* itemName = "") {
    if (std::strcmp(itemName, "") == 0) {
        itemName = displayName;
    }

    UiControlDesc desc = UI_CONTROL_DESC_INIT;
    desc.kind = UI_CONTROL_BUTTON;
    desc.label = displayName;
    desc.help_rml = "";
    desc.binding = UI_BINDING_CALLBACKS;
    desc.on_pressed = on_pressed_starting_inventory_item<Max>;
    desc.user_data = (void*)itemName;
    session::svc_mng.ui->pane_add_control(session::svc_mng.mod_ctx, leftPane, &desc, nullptr);
};

ModResult buildStartingInventoryTab(ModContext* ctx, UiWindowHandle, UiElementHandle leftPane,
    UiElementHandle rightPane, void*, ModError*)
{
    add_button(leftPane,
        "Clear Selected Starting Items",
        "",
        [](ModContext*, void*) {
            auto& inventory = GetRandomizerConfig().GetSettings().GetModifiableStartingInventory();
            inventory.clear();
            SaveRandomizerConfig();
        });

    add_section(leftPane, "Main Items");
    add_starting_inventory_item(leftPane, "Shadow Crystal");
    add_starting_inventory_item(leftPane, "Horse Call");
    add_starting_inventory_item<2>(leftPane, "Fishing Rod", "Progressive Fishing Rod");
    add_starting_inventory_item(leftPane, "Slingshot");
    add_starting_inventory_item(leftPane, "Lantern");
    add_starting_inventory_item(leftPane, "Gale Boomerang");
    add_starting_inventory_item(leftPane, "Iron Boots");
    add_starting_inventory_item<3>(leftPane, "Bow", "Progressive Bow");
    add_starting_inventory_item(leftPane, "Hawkeye");
    add_starting_inventory_item<3>(leftPane, "Bomb Bags", "Bomb Bag");
    add_starting_inventory_item(leftPane, "Giant Bomb Bags", "Giant Bomb Bag");
    add_starting_inventory_item<2>(leftPane, "Clawshot", "Progressive Clawshot");
    add_starting_inventory_item(leftPane, "Spinner");
    add_starting_inventory_item(leftPane, "Ball and Chain");
    add_starting_inventory_item<2>(leftPane, "Dominion Rod", "Progressive Dominion Rod");
    add_starting_inventory_item(leftPane, "Empty Bottle");
    add_starting_inventory_item(leftPane, "Auru's Memo", "Aurus Memo");
    add_starting_inventory_item(leftPane, "Ashei's Sketch", "Asheis Sketch");
    add_starting_inventory_item<7>(leftPane, "Sky Book", "Progressive Sky Book");

    add_section(leftPane, "Gear Screen");
    add_starting_inventory_item<4>(leftPane, "Sword", "Progressive Sword");
    add_starting_inventory_item(leftPane, "Ordon Shield");
    add_starting_inventory_item(leftPane, "Hylian Shield");
    add_starting_inventory_item(leftPane, "Zora Armor");
    add_starting_inventory_item(leftPane, "Magic Armor");
    add_starting_inventory_item<2>(leftPane, "Wallet", "Progressive Wallet");
    add_starting_inventory_item<7>(leftPane, "Hidden Skills", "Progressive Hidden Skill");
    add_starting_inventory_item<60>(leftPane, "Poe Souls", "Poe Soul");
    add_starting_inventory_item<3>(leftPane, "Fused Shadows", "Progressive Fused Shadow");
    add_starting_inventory_item<4>(leftPane, "Mirror Shards", "Progressive Mirror Shard");

    add_section(leftPane, "Overworld Keys");
    add_starting_inventory_item(leftPane, "Faron Woods Coro Key");
    add_starting_inventory_item(leftPane, "Gate Keys");
    add_starting_inventory_item(leftPane, "Gerudo Desert Bulblin Camp Key");

    add_section(leftPane, "Dungeon Items");
    add_starting_inventory_item<4>(leftPane, "Forest Temple Small Keys", "Forest Temple Small Key");
    add_starting_inventory_item<3>(leftPane, "Goron Mines Small Keys", "Goron Mines Small Key");
    add_starting_inventory_item<3>(leftPane, "Lakebed Temple Small Keys", "Lakebed Temple Small Key");
    add_starting_inventory_item<5>(leftPane, "Arbiter's Grounds Small Keys", "Arbiters Grounds Small Key");
    add_starting_inventory_item<4>(leftPane, "Snowpeak Ruins Small Keys", "Snowpeak Ruins Small Key");
    add_starting_inventory_item(leftPane, "Ordon Pumpkin");
    add_starting_inventory_item(leftPane, "Ordon Cheese");
    add_starting_inventory_item<4>(leftPane, "Temple of Time Small Keys", "Temple of Time Small Key");
    add_starting_inventory_item<1>(leftPane, "City in the Sky Small Keys", "City in the Sky Small Key");
    add_starting_inventory_item<7>(leftPane, "Palace of Twilight Small Keys", "Palace of Twilight Small Key");
    add_starting_inventory_item<3>(leftPane, "Hyrule Castle Small Keys", "Hyrule Castle Small Key");

    add_starting_inventory_item(leftPane, "Forest Temple Big Key");
    add_starting_inventory_item<3>(leftPane, "Goron Mines Key Shards", "Goron Mines Key Shard");
    add_starting_inventory_item(leftPane, "Lakebed Temple Big Key");
    add_starting_inventory_item(leftPane, "Arbiter's Grounds Big Key", "Arbiters Grounds Big Key");
    add_starting_inventory_item(leftPane, "Snowpeak Ruins Bedroom Key");
    add_starting_inventory_item(leftPane, "Temple of Time Big Key");
    add_starting_inventory_item(leftPane, "City in the Sky Big Key");
    add_starting_inventory_item(leftPane, "Palace of Twilight Big Key");
    add_starting_inventory_item(leftPane, "Hyrule Castle Big Key");

    add_section(leftPane, "Warp Portals");
    add_starting_inventory_item(leftPane, "Gerudo Desert Portal");
    add_starting_inventory_item(leftPane, "Mirror Chamber Portal");
    add_starting_inventory_item(leftPane, "Snowpeak Portal");
    add_starting_inventory_item(leftPane, "Sacred Grove Portal");
    add_starting_inventory_item(leftPane, "Bridge of Eldin Portal");
    add_starting_inventory_item(leftPane, "Upper Zora's River Portal", "Upper Zoras River Portal");

    add_section(rightPane, "Selected Starting Items");
    session::svc_mng.ui->pane_add_rml(session::svc_mng.mod_ctx, rightPane, "", &startingInventoryRmlElem);

    return MOD_OK;
}

ModResult updateStartingInventoryTab(ModContext* ctx, void*, ModError*) {
    const auto& inventory = GetRandomizerConfig().GetSettings().GetStartingInventory();
    const auto& layoutOrder = GetStartingInventoryLayoutOrder();

    std::string rightPaneRml = "";
    for (const auto& [itemText, itemName] : layoutOrder) {
        if (!inventory.contains(itemName)) {
            continue;
        }

        int count = inventory.at(itemName);
        if (count <= 0) {
            continue;
        }

        // If we have a prettier name for the item, prioritize that
        std::string prettyItemName = fmt::format("{} x{}", itemName, count);
        if (randomizer::textObjectExists(prettyItemName)) {
            rightPaneRml += fmt::format("• {}<br/>", randomizer::getTextStr(prettyItemName));
        }
        // Display the count before the itemname for these items
        else if (itemName.find("Small Key") != std::string::npos ||
            itemName.find("Shard") != std::string::npos ||
            itemName.find("Fused Shadow") != std::string::npos ||
            itemName.find("Hidden Skill") != std::string::npos ||
            itemName == "Poe Soul" ||
            itemName == "Bomb Bag")
        {
            rightPaneRml += fmt::format("• {} {}<br/>", count, itemText);
        } else {
            rightPaneRml += fmt::format("• {}<br/>", itemName);
        }
    }

    session::svc_mng.ui->elem_set_rml(session::svc_mng.mod_ctx, startingInventoryRmlElem, rightPaneRml.c_str());
    return MOD_OK;
}

// Excluded Locations Tab
UiElementHandle exlocHeaderElem = 0;
UiElementHandle exlocSubHeaderElem = 0;
UiElementHandle exlocRightPaneElem = 0;
UiElementHandle exlocClearBtnElem = 0;
UiListHandle exlocList = 0;
std::string exlocFilter{};

struct ExcludedTabLocData {
    std::string name{};
    std::string lowercaseName{};
    std::unordered_set<std::string> categories{};
};

const std::vector<ExcludedTabLocData>& excluded_location_catalog(const bool reload = false) {
    static std::vector<ExcludedTabLocData> locationsForExcludedTab;

    if(reload) {
        locationsForExcludedTab.clear();
    }

    // If we haven't loaded the locations to display for the excluded locations tab, load them up
    if (locationsForExcludedTab.empty()) {
        auto locationDataTree = LOAD_EMBED_YAML(RANDO_DATA_PATH "locations.yaml");
        for (const auto& locationNode : locationDataTree) {
            ExcludedTabLocData excludedTabLocData{};
            auto& name = excludedTabLocData.name;
            auto& lowercaseName = excludedTabLocData.lowercaseName;
            name = locationNode["Name"].as<std::string>();
            lowercaseName = name;
            std::transform(lowercaseName.begin(), lowercaseName.end(), lowercaseName.begin(),
                [](unsigned char c) { return std::tolower(c); });

            for (const auto& category : locationNode["Categories"]) {
                excludedTabLocData.categories.insert(category.as<std::string>());
            }

            if (locationNode["Metadata"].IsMap()) {
                for (const auto& data : locationNode["Metadata"]) {
                    excludedTabLocData.categories.insert(data.first.as<std::string>());
                }
            }

            // Don't include warp portals
            if (excludedTabLocData.categories.contains("Warp Portal")) {
                continue;
            }

            // Certain locations we don't include for now
            if (utility::str::Contains(excludedTabLocData.name, "Renados Letter", "Telma Invoice",
                    "Wooden Statue", "Ilia Charm", "Defeat Ganondorf", "Twilit Insect",
                    "Twilit Bloat", "Hint"))
            {
                continue;
            }

            locationsForExcludedTab.push_back(std::move(excludedTabLocData));
        }

        std::ranges::sort(
            locationsForExcludedTab, [](const auto& a, const auto& b) { return a.name < b.name; });
    }

    return locationsForExcludedTab;
}

std::vector<UiListItem> excluded_location_items() {
    // Get settings values
    auto& randoSettings = GetRandomizerConfig().GetSettings().GetMap();
    bool goldenBugs = randoSettings.at("Golden Bugs") == "On";
    bool skyCharacters = randoSettings.at("Sky Characters") == "On";
    bool npcs = randoSettings.at("Gifts From NPCs") == "On";
    bool shops = randoSettings.at("Shop Items") == "On";
    bool goldenWolves = randoSettings.at("Hidden Skills") == "On";
    bool hiddenRupees = randoSettings.at("Hidden Rupees") == "On";
    bool freestandingRupees = randoSettings.at("Freestanding Rupees") == "On";
    bool overworldPoes = randoSettings.at("Poe Souls").IsAnyOf("Overworld", "All");
    bool dungeonPoes = randoSettings.at("Poe Souls").IsAnyOf("Dungeon", "All");

    // Create lowercase filter
    std::string lowercaseFilter = exlocFilter;
    std::transform(lowercaseFilter.begin(), lowercaseFilter.end(), lowercaseFilter.begin(),
        [](unsigned char c) { return std::tolower(c); });

    std::vector<UiListItem> items;
    const auto& catalog = excluded_location_catalog();
    items.reserve(catalog.size());
    for (size_t i = 0; i < catalog.size(); ++i) {
        const auto& locData = catalog[i];
        // Skip categories that aren't shuffled
        const auto& cats = locData.categories;
        if ((!goldenBugs && cats.contains("Golden Bug")) ||
            (!skyCharacters && cats.contains("Sky Character")) || (!npcs && cats.contains("Npc")) ||
            (!shops && cats.contains("Shop")) || (!goldenWolves && cats.contains("Golden Wolf")) ||
            (!hiddenRupees && cats.contains("Rupee - Hidden")) ||
            (!freestandingRupees && cats.contains("Rupee - Freestanding")) ||
            (!overworldPoes && cats.contains("Poe") && cats.contains("Overworld")) ||
            (!dungeonPoes && cats.contains("Poe") && cats.contains("Dungeon")))
        {
            continue;
        }

        // Don't add this location if it doesn't match the current filter
        if (locData.lowercaseName.find(lowercaseFilter) == std::string::npos) {
            continue;
        }

        UiListItem item = UI_LIST_ITEM_INIT;
        item.key = i;
        item.label = locData.name.c_str();
        items.push_back(item);
    }

    return items;
}

void refresh_excluded_location_items() {
    if (exlocList == 0) {
        return;
    }
    const auto items = excluded_location_items();
    session::svc_mng.ui->list_set_items(
        session::svc_mng.mod_ctx, exlocList, items.data(), items.size());
}

ModResult buildExcludedLocationsTab(ModContext* ctx, UiWindowHandle, UiElementHandle leftPane,
    UiElementHandle rightPane, void*, ModError*) {
    using namespace session;
    auto mod_ctx = svc_mng.mod_ctx;
    exlocList = 0;

    svc_mng.ui->elem_set_class(mod_ctx, leftPane, "excluded-locations-pane-left", true);
    svc_mng.ui->elem_set_class(mod_ctx, rightPane, "excluded-locations-pane-right", true);

    add_button(
        leftPane, "Clear All", "",
        [](ModContext*, void*) {
            GetRandomizerConfig().GetSettings().GetModifiableExcludedLocations().clear();
            SaveRandomizerConfig();
        },
        nullptr, &exlocClearBtnElem);
    svc_mng.ui->elem_set_class(mod_ctx, exlocClearBtnElem, "clear-all-button", true);

    UiControlDesc filter = UI_CONTROL_DESC_INIT;
    filter.kind = UI_CONTROL_STRING;
    filter.label = "Filter";
    filter.binding = UI_BINDING_CALLBACKS;
    filter.get = [](ModContext*, void*, UiControlValue* outValue) {
        outValue->string_value = exlocFilter.c_str();
    };
    filter.set = [](ModContext*, void*, const UiControlValue* value) {
        exlocFilter = value->string_value;
        refresh_excluded_location_items();
    };
    filter.max_length = 256;
    filter.string_set_mode = UI_STRING_SET_ON_CHANGE;
    svc_mng.ui->pane_add_control(mod_ctx, leftPane, &filter, nullptr);

    const auto items = excluded_location_items();
    UiListDesc list = UI_LIST_DESC_INIT;
    list.items = items.data();
    list.item_count = items.size();
    list.on_pressed = [](ModContext*, UiListHandle, uint64_t key, void*) {
        const auto& catalog = excluded_location_catalog();
        if (key >= catalog.size()) {
            return;
        }
        const auto& locationName = catalog[key].name;
        auto& excludedLocations =
            GetRandomizerConfig().GetSettings().GetModifiableExcludedLocations();
        if (excludedLocations.contains(locationName)) {
            excludedLocations.erase(locationName);
        } else {
            excludedLocations.insert(locationName);
        }
        SaveRandomizerConfig();
    };
    list.is_selected = [](ModContext*, UiListHandle, uint64_t key, void*) {
        const auto& catalog = excluded_location_catalog();
        return key < catalog.size() &&
               GetRandomizerConfig().GetSettings().GetExcludedLocations().contains(
                   catalog[key].name);
    };
    const ModResult listResult = svc_mng.ui->pane_add_list(mod_ctx, leftPane, &list, &exlocList);
    if (listResult != MOD_OK) {
        return listResult;
    }
    svc_mng.ui->elem_set_class(mod_ctx, exlocList, "excluded-locations-list", true);

    svc_mng.ui->pane_add_text(mod_ctx, rightPane, "Current Excluded Locations", &exlocHeaderElem);
    svc_mng.ui->elem_set_class(mod_ctx, exlocHeaderElem, "excluded-locations-header", true);

    svc_mng.ui->pane_add_text(
        mod_ctx, rightPane, "Re-select a location to remove it", &exlocSubHeaderElem);
    svc_mng.ui->elem_set_class(mod_ctx, exlocSubHeaderElem, "excluded-locations-subheader", true);

    svc_mng.ui->pane_add_rml(mod_ctx, rightPane, "", &exlocRightPaneElem);
    svc_mng.ui->elem_set_class(
        mod_ctx, exlocRightPaneElem, "excluded-locations-inner-pane-right", true);
    return MOD_OK;
}

ModResult updateExcludedLocationsTab(ModContext* ctx, void*, ModError*) {
    using namespace session;
    std::string rml = "";

    for (const auto& location : GetRandomizerConfig().GetSettings().GetExcludedLocations()) {
        rml += fmt::format("<span>• {}</span><br/>", location);
    }

    svc_mng.ui->elem_set_rml(svc_mng.mod_ctx, exlocRightPaneElem, rml.c_str());
    return MOD_OK;
}

// Tracker Tab
ModResult add_location_list(UiElementHandle pane, const std::vector<std::string>& regions, UiListHandle* outList = nullptr) {
    const auto& items = g_tracker.getLocationListItems(regions);
    UiListDesc list = UI_LIST_DESC_INIT;
    list.items = items.data();
    list.item_count = items.size();
    list.on_pressed = [](ModContext*, UiListHandle, uint64_t, void*) {};
    list.is_disabled = [](ModContext*, UiListHandle, uint64_t key, void*) {
        return g_tracker.isLocationObtained(key);
    };
    return session::svc_mng.ui->pane_add_list(mod_ctx, pane, &list, outList);
};

ModResult buildTrackerTab(ModContext* ctx, UiWindowHandle, UiElementHandle leftPane,
    UiElementHandle rightPane, void*, ModError*) {
    g_tracker.generateLocationInfo();
    add_section(leftPane, "Locations");

    add_group(leftPane, rightPane,
        "Ordon",
        [](ModContext*, UiElementHandle pane, void*, ModError*) {
            return add_location_list(pane, {"Ordona Province"});
        });

    add_group(leftPane, rightPane,
        "Faron",
        [](ModContext*, UiElementHandle pane, void*, ModError*) {
            return add_location_list(pane,
                {
                "Faron Province",
                "Faron Woods",
                "Hyrule Field - Faron Province",
                "Sacred Grove",
                });
        });

    add_group(leftPane, rightPane,
        "Eldin",
        [](ModContext*, UiElementHandle pane, void*, ModError*) {
            return add_location_list(pane,
                {
                "Eldin Province",
                "Hyrule Field - Eldin",
                "Hyrule Field - Eldin Province",
                "Eldin Lantern Cave",
                "Eldin Stockcave",
                "Death Mountain",
                "Kakariko Village",
                "Kakariko Graveyard",
                });
        });

    add_group(leftPane, rightPane,
        "Lanayru",
        [](ModContext*, UiElementHandle pane, void*, ModError*) {
            return add_location_list(pane,
                {
                "Lanayru Province",
                "Hyrule Field - Lanayru",
                "Hyrule Field - Lanayru Province",
                "Castle Town",
                "Fishing Hole",
                "Lake Hylia",
                "Lake Lantern Cave",
                "Upper Zoras River",
                "Zoras Domain",
                });
        });

    add_group(leftPane, rightPane,
        "Gerudo Desert",
        [](ModContext*, UiElementHandle pane, void*, ModError*) {
            return add_location_list(pane,
                {
                "Gerudo Desert",
                "Bulblin Camp",
                "Mirror Chamber",
                "Cave Of Ordeals",
                });
        });

    add_group(leftPane, rightPane,
        "Snowpeak",
        [](ModContext*, UiElementHandle pane, void*, ModError*) {
            return add_location_list(pane,
                {
                "Snowpeak Province",
                "Snowpeak",
                });
        });

    add_group(leftPane, rightPane,
        "Forest Temple",
        [](ModContext*, UiElementHandle pane, void*, ModError*) {
            return add_location_list(pane, {"Forest Temple"});
        });

    add_group(leftPane, rightPane,
        "Goron Mines",
        [](ModContext*, UiElementHandle pane, void*, ModError*) {
            return add_location_list(pane, {"Goron Mines"});
        });

    add_group(leftPane, rightPane,
        "Lakebed Temple",
        [](ModContext*, UiElementHandle pane, void*, ModError*) {
            return add_location_list(pane, {"Lakebed Temple"});
        });

    add_group(leftPane, rightPane,
        "Arbiter's Grounds",
        [](ModContext*, UiElementHandle pane, void*, ModError*) {
            return add_location_list(pane, {"Arbiters Grounds"});
        });

    add_group(leftPane, rightPane,
        "Snowpeak Ruins",
        [](ModContext*, UiElementHandle pane, void*, ModError*) {
            return add_location_list(pane, {"Snowpeak Ruins"});
        });

    add_group(leftPane, rightPane,
        "Temple of Time",
        [](ModContext*, UiElementHandle pane, void*, ModError*) {
            return add_location_list(pane, {"Temple of Time"});
        });

    add_group(leftPane, rightPane,
        "City in the Sky",
        [](ModContext*, UiElementHandle pane, void*, ModError*) {
            return add_location_list(pane, {"City in the Sky"});
        });

    add_group(leftPane, rightPane,
        "Palace of Twilight",
        [](ModContext*, UiElementHandle pane, void*, ModError*) {
            return add_location_list(pane, {"Palace of Twilight"});
        });

    add_group(leftPane, rightPane,
        "Hyrule Castle",
        [](ModContext*, UiElementHandle pane, void*, ModError*) {
            return add_location_list(pane, {"Hyrule Castle"});
        });

    return MOD_OK;
}

ModResult updateTrackerTab(ModContext* ctx, void*, ModError*) {
    return MOD_OK;
}

// Menu Tab
void OnMenuTabSelected(ModContext* ctx, void*) {
    UiTabDesc tabs[6]{};

    tabs[0].struct_size = sizeof(UiTabDesc);
    tabs[0].title = "Seed Management";
    tabs[0].build = buildSeedManagementTab;
    tabs[0].update = updateSeedManagementTab;

    tabs[1].struct_size = sizeof(UiTabDesc);
    tabs[1].title = "Seed Options";
    tabs[1].build = buildSeedOptionsTab;

    tabs[2].struct_size = sizeof(UiTabDesc);
    tabs[2].title = "Hints";
    tabs[2].build = buildHintsTab;

    tabs[3].struct_size = sizeof(UiTabDesc);
    tabs[3].title = "Starting Inventory";
    tabs[3].build = buildStartingInventoryTab;
    tabs[3].update = updateStartingInventoryTab;

    tabs[4].struct_size = sizeof(UiTabDesc);
    tabs[4].title = "Excluded Locations";
    tabs[4].build = buildExcludedLocationsTab;
    tabs[4].update = updateExcludedLocationsTab;

    if (session::g_seedActivated) {
        tabs[5].struct_size = sizeof(UiTabDesc);
        tabs[5].title = "Tracker";
        tabs[5].build = buildTrackerTab;
        tabs[5].update = updateTrackerTab;
    }

    UiWindowDesc desc = UI_WINDOW_DESC_INIT;
    desc.tabs = tabs;
    desc.tab_count = session::g_seedActivated ? 6 : 5;  // don't show tracker if seed isn't loaded
    UiWindowHandle window{};
    session::svc_mng.ui->window_push(ctx, &desc, &window);
}

// Play Tab
ModResult buildPlayTab(ModContext* ctx, UiWindowHandle, UiElementHandle leftPane,
    UiElementHandle rightPane, void*, ModError*)
{
    g_seedHashes = {"None"};
    for (const auto& hash : get_compatible_seed_hashes()) {
        g_seedHashes.push_back(hash);
    }

    std::string help_rml = "";
    if (g_seedHashes.size() <= 1) {
        help_rml = "No seeds generated! You can generate a seed from the Seed Management Tab.";
    } else {
        help_rml = "Choose which seed you want to play.";
    }

    if (!session::g_pending_seed_hash.empty() &&
        !std::ranges::contains(g_seedHashes, session::g_pending_seed_hash)) {
        session::g_pending_seed_hash.clear();
    }

    std::vector<const char*> availableSeeds;
    for (const auto& hash : g_seedHashes) {
        availableSeeds.push_back(hash.c_str());
    }

    add_select(leftPane,
        "Selected Seed",
        help_rml.c_str(),
        availableSeeds.data(),
        availableSeeds.size(),
        [](ModContext*, void*, UiControlValue* out_value) {
            const auto selected = std::ranges::find(g_seedHashes, session::g_pending_seed_hash);
            if (selected == g_seedHashes.end()) {
                out_value->int_value = 0;
                return;
            }

            out_value->int_value = static_cast<int32_t>(std::distance(g_seedHashes.begin(), selected));
        },
        [](ModContext*, void*, const UiControlValue* value) {
            if (value->int_value < 0 || static_cast<size_t>(value->int_value) >= g_seedHashes.size()) {
                session::g_pending_seed_hash.clear();
                return;
            }

            session::g_pending_seed_hash = g_seedHashes[value->int_value];
        });

    {
        UiControlDesc desc = UI_CONTROL_DESC_INIT;
        desc.kind = UI_CONTROL_BUTTON;
        desc.label = "Start Randomizer";
        desc.help_rml = "";
        desc.on_pressed = [](ModContext*, void* userdata) {
            // set flag to move to name screen after window close
            *g_dialogSelectModeState = GAME_MODE_STATE_PROCEED;
            session::svc_mng.ui->window_close(session::svc_mng.mod_ctx, *static_cast<UiWindowHandle*>(userdata));
            mDoAud_seStartMenu(Z2SE_SY_NEW_FILE);
        };
        desc.user_data = &g_file_select_window_ctx.window_handle;
        desc.is_disabled = [](ModContext*, void*) {
            return session::g_pending_seed_hash.empty() || session::g_pending_seed_hash == "None";
        };
        session::svc_mng.ui->pane_add_control(session::svc_mng.mod_ctx, leftPane, &desc, nullptr);
    }

    return MOD_OK;
}
}

// Function to call for pre-loading excluded location catalog when selecting randomizer game mode
void load_excluded_locations() {
    // Mutex so that we can pre-load excluded locations on a different thread when the randomizer
    // is selected.
    static std::mutex excludedLocationsMutex{};
    std::lock_guard lock{excludedLocationsMutex};

    excluded_location_catalog(true);
}

ModResult buildMenuTab() {
    UiMenuTabDesc desc = UI_MENU_TAB_DESC_INIT;
    desc.label = "Randomizer";
    desc.on_selected = OnMenuTabSelected;

    return session::svc_mng.ui->register_menu_tab(session::svc_mng.mod_ctx, &desc, &g_menu_tab);
}

ModResult removeMenuTab() {
    return session::svc_mng.ui->unregister_menu_tab(session::svc_mng.mod_ctx, g_menu_tab);
}

ModResult buildFileSelectGateMenu() {
    UiTabDesc tabs[6]{};

    tabs[0].struct_size = sizeof(UiTabDesc);
    tabs[0].title = "Play";
    tabs[0].build = buildPlayTab;

    tabs[1].struct_size = sizeof(UiTabDesc);
    tabs[1].title = "Seed Management";
    tabs[1].build = buildSeedManagementTab;
    tabs[1].update = updateSeedManagementTab;

    tabs[2].struct_size = sizeof(UiTabDesc);
    tabs[2].title = "Seed Options";
    tabs[2].build = buildSeedOptionsTab;

    tabs[3].struct_size = sizeof(UiTabDesc);
    tabs[3].title = "Hints";
    tabs[3].build = buildHintsTab;

    tabs[4].struct_size = sizeof(UiTabDesc);
    tabs[4].title = "Starting Inventory";
    tabs[4].build = buildStartingInventoryTab;
    tabs[4].update = updateStartingInventoryTab;

    tabs[5].struct_size = sizeof(UiTabDesc);
    tabs[5].title = "Excluded Locations";
    tabs[5].build = buildExcludedLocationsTab;
    tabs[5].update = updateExcludedLocationsTab;

    UiWindowDesc desc = UI_WINDOW_DESC_INIT;
    desc.tabs = tabs;
    desc.tab_count = 6;
    desc.on_closed = [](ModContext*, UiWindowHandle, void* userdata) {
        if (*g_dialogSelectModeState == GAME_MODE_STATE_PENDING) {
            *g_dialogSelectModeState = GAME_MODE_STATE_RETURN;
        }
    };

    return session::svc_mng.ui->window_push(session::svc_mng.mod_ctx, &desc, &g_file_select_window_ctx.window_handle);
}

} // namespace dusk::ui
