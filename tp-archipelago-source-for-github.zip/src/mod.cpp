#include "mods/service.hpp"
#include "mods/svc/log.h"
#include "mods/svc/http.h"
#include "mods/svc/net.h"

#include "ap/ap_mode.hpp"
#include "item.hpp"
#include "session.hpp"

DEFINE_MOD();
IMPORT_SERVICE(HostService, svc_host);
IMPORT_SERVICE(LogService, svc_log);
IMPORT_SERVICE(HookService, svc_hook);
IMPORT_SERVICE(UiService, svc_ui);
IMPORT_SERVICE(ResourceService, svc_res);
IMPORT_SERVICE(ConfigService, svc_config);
IMPORT_SERVICE(SaveService, svc_save);
IMPORT_SERVICE(StageService, svc_stage);
IMPORT_SERVICE(ItemService, svc_item);
IMPORT_SERVICE(FlowService, svc_flow);
IMPORT_SERVICE(MessageService, svc_message);
IMPORT_SERVICE(GameModeService, svc_game_mode);
IMPORT_SERVICE(TextureService, svc_texture);
IMPORT_SERVICE(FileService, svc_file);
IMPORT_SERVICE(NetService, svc_net);
IMPORT_SERVICE(HttpService, svc_http);

extern "C" {

MOD_EXPORT ModResult mod_initialize(ModError* error) {
     ModResult result = randomizer::session::initialize({
        mod_ctx,
        svc_host,
        svc_log,
        svc_hook,
        svc_ui,
        svc_res,
        svc_config,
        svc_save,
        svc_stage,
        svc_item,
        svc_flow,
        svc_message,
        svc_game_mode,
        svc_texture,
        svc_file,
    });
    if (result != MOD_OK) {
        return mods::set_error(error, result, "failed to initialize session");
    }

    svc_log->info(mod_ctx, "randomizer " FULL_RANDOMIZER_VERSION " initialized");
    return MOD_OK;
}

MOD_EXPORT ModResult mod_update(ModError*) {
    // Every host frame, even while the game itself is paused behind a UI window: the network
    // has to keep moving for the connect window to ever finish. Everything that touches the
    // game runs from the game mode's tick instead (ap::tick).
    ap::update();
    return MOD_OK;
}

MOD_EXPORT ModResult mod_shutdown(ModError*) {
    randomizer::session::shutdown();
    svc_log->info(mod_ctx, "randomizer unloaded");
    return MOD_OK;
}
}
