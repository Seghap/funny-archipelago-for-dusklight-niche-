#pragma once

#include "dolphin/types.h"
#include "../generator/logic/item_pool.hpp"
#include "../generator/utility/yaml.hpp"
#include "SSystem/SComponent/c_xyz.h"
#include "SSystem/SComponent/c_sxyz.h"

#include <string>

namespace randomizer::logic::location {
class Location;
}
namespace randomizer::logic::world {
class World;
}

bool playerIsInRoomStage(s32 room, const char* stage);
void checkTransformFromWolf();
u8 setNextWarashibeItem();
void offWarashibeItem(u8 item);
int initCreatePlayerItem(u32 item, u32 flag, const cXyz* pos, int roomNo, const csXyz* angle, const cXyz* scale);
/*
 * Returns the ID of the passed in stage name. If no stage name is passed in, the id of the current
 * stage is returned
 */
int getStageID(const char* stage = NULL);
bool playerIsOnTitleScreen();
u16 getItemMessageID(u8 itemId);
int numCompletedDungeons();
int numFusedShadows();
int numMirrorShards();
int getTempleKeysFound(int saveId);

std::string nameLookupOverride(const std::string& locationName);

/*
 * Reads the current player inventory and returns an ItemPool that can be used for logic searches
 *
 */
randomizer::logic::item_pool::ItemPool getSaveItemPool(randomizer::logic::world::World* world);

/*
 * Finds locations relevant flag in save (using its metadata) and checks if it's been set.
 */
bool isLocationObtained(randomizer::logic::location::Location* location);
bool isLocationMetadataObtained(const YAML::Node& locationMeta, const std::string& locationName);

/*
 * Pulls location item data from rando context using locations metadata.
 */
int getLocationItem(randomizer::logic::location::Location* location);

// Used to get a stage's Area ID used for save flags
int getStageSaveId(int id);
int getStageSaveId(const char* stage);

void onRegionFlag(int i_stageNo, int i_no);
void setRegionBit(u8 i_region);
void setAllLetterGet();
void setAllLetterRead();
void setAncientDocumentNum(u8 num);
u8 getAncientDocumentNum();
u8 getAreaKeyNum(int);

void saveAncientDocumentNum();
void loadAncientDocumentNum();

bool tracker_isEventBit(u16 flag);
bool tracker_isStageSwitch(int stage, int flag);
bool tracker_isStageItem(int stage, int flag);

const char* getYesNoText(bool flag);
int getCurrentLanguage();
