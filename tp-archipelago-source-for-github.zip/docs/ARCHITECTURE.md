# Architecture

How the mod works, where its code lives, and the rules that must keep holding. Read this before
changing the adapter, the seed build or anything that hooks the game.

## The idea

The server runs the GameCube **Twilight Princess** apworld. It decides what is at every location
and knows nothing about Dusklight. The in-game half is the Twilit Realm randomizer, which plays a
*seed*: stage edits, text, start flags, and a table saying what each check holds. This mod makes
the two agree: it asks the server what is at each of the slot's locations, then builds a local
seed in which every location holds exactly that, and plays it like any randomizer seed while
reporting checks and delivering items.

Three facts shape the design, all read from the references:

1. **The apworld sends no placements.** Its `slot_data` is `World Version`, `DeathLink` and
   `Settings` (final option values, after the world's own `generate_early` adjustments). What is
   at each location is only known by asking (`LocationScouts`).
2. **Locations join by name.** The apworld's locations are identified by numbers
   (`2320000 + code`) and by save-memory byte/bit for Dolphin; Dusklight identifies checks by
   `(stage, chest/flag)` metadata in `locations.yaml`. They share location *names*: all 475
   apworld locations match a Dusklight name once letter case is ignored (28 differ only by
   "The"/"the"). `tools/gen_gc_tables.py` builds that table and fails if any name is missing.
3. **The engine already routes every pickup through one place.** The item service names each
   check (`chest:<stage>:<box>`, `poe:...`, `shop:...`, named gifts), lets a resolver replace the
   item, and tells observers when it has been given. No game addresses are needed for checks.

## A session

```
new file ─► on_new_save_select ─► connect window (UiService), game ticks paused
              │ Connect
              ▼
         Client::connect ─► RoomInfo ─► Connect(game "Twilight Princess", items_handling 0b101) + GetDataPackage
              ▼
         Connected ─► load_slot_data: version check, Settings -> Dusklight settings, DeathLink,
              │        locations = checked_locations ∪ missing_locations
              ▼
         LocationScouts(all) ─► LocationInfo ─► Placement per location (own item / other world's)
              ▼
         worker thread: settings.yaml + plando.yaml ─► randomizer generator (Archipelago mode) ─► seed.dat
              ▼
         *g_newSaveState = PROCEED ─► name entry ─► on_new_save
              ▼
         session::onNewSave = activateSeed(hash) then setupRandomizerFile()      (start flags, clothes, ...)
         + our resolver registered after the seed's, state blobs written ─► Playing
```

Loading a save: the seed hash, the connection and the progress counters come from save blobs; the
seed files and the placement cache (`ap_placements.json`) from disk. Both present: the seed is
activated at once and the connection is made in the background. Either missing (the save came from
another machine): the mod scouts and regenerates, and refuses a rebuilt seed whose hash differs.

### Why the seed is built *before* the file exists

The seed is the file's whole starting state. `setupRandomizerFile()` applies the seed's start
event flags, region flags, map bits, starting inventory, twilight state and Hero's Clothes. The
layer chosen for each room by `hookPreGetLayerNo` reads those flags (Ordon Village room 1 is the
Day-1 morning layer until `ORDON_DAY_1_FINISHED`; Jaggle's house needs `FINISHED_SEWERS` or
Faron twilight cleared). The official work-in-progress branch ran `setupRandomizerFile()` with
the seed activation commented out, i.e. on an empty context. Here the order is fixed:
`activateSeed` first, `setupRandomizerFile` second, and `tools/check_start_state.py` verifies the
flags under the apworld's settings.

## The seed build

`src/ap/mode/slot.cpp` (worker thread) and `src/ap/seed_inputs.cpp` (writes the generator's three
input files; engine-free, so the host test in `tools/host_gen` runs the identical code). The
generator is given:

- **settings**: fixed settings (no entrance randomization, no hints, ...), then defaults (Skip
  Prologue, twilights, MDH: the apworld hard-codes these to "Yes"), then the translated slot
  settings (`gc_settings.cpp`, rows generated from `gen_gc_tables.py`).
- **a plando** with one entry per server location: your own item by its generator name, anything
  else as `Archipelago Item` (item `0xDC`, the Sol model).

and runs with `randomizer::g_archipelagoMode` set. In that mode (generator hunks in
`docs/PATCHES.md`): plando entries for locations the generator already treats as vanilla under
the current settings are skipped and recorded (the resolver patches them at runtime); every
other location the generator would shuffle but the server does not own keeps its **vanilla**
item (a dungeon with Dungeons Shuffled off, heart pieces with Heart Pieces Shuffled off, ...);
bottles stay as placed; local logic verification and filling are skipped, because other worlds'
items are opaque to the local world and the server already verified the multiworld.

## Checks

- **Detection**: `observe_give` receives every give with its check name; `locations_for_check`
  maps the name to location names (built from `locations.yaml` metadata, restricted to this slot's
  locations) and `report_locations` queues the ids and **flushes immediately**. A scan of the
  save's own flags (`scan_locations`, 24 per tick) catches anything that bypassed the item
  service, and sends what was obtained while offline once reconnected.
- **Content** (`resolve_check`): runs after the seed's resolver and has the last word for every
  location the server owns. It answers `true` with an explicit item: your own (resolved through
  `verifyProgressiveItem`, traps disguised as the randomizer does) or the placeholder. It never
  answers `false`, which is what lets the game fall back to its default item (a Green Rupee).
  Locations the server does not own are left to the seed (vanilla).
- **Other players' items**: the placeholder's get-item text is replaced per pickup
  (`ap_item_text`, `on_get_item_demo`), the model is scaled down (`mode/hooks.cpp`), and the jingle
  follows the item's classification (`hooks.cpp` hunk).

## Receiving items

`items_handling = 0b101`: other worlds' items and starting inventory; the server never echoes
your own items, which are given by the checks that hold them. `ReceivedItems` fill
`g_serverItems`; `deliver_items` gives the next one (index persisted in the save so nothing is
repeated or skipped) through `ItemService::give_item`, one at a time, confirmed by the give
observer before the next. The service's own queue "waits until gameplay is in a safe state"; the
mod adds a second, stricter gate (`safe_to_deliver`):

`in_gameplay()`, no scene change (`fopOvlpM_IsPeek`), no reset (`mDoRst::isReset`), not paused,
no event running (`dComIfGp_event_runCheck`, `daAlink_c::checkEventRun`), life above 0 and not
lost within the last 45 ticks, and Link's `mProcID` not one of dead, talking, getting an item,
warping, transforming, any of the damage procs, or falling.

## Threading

Everything that touches the game runs on the game thread. The socket is polled there too
(`mod_update` → `ap::update`, which runs every host frame even while a UI window pauses game
ticks, so the connect window can finish). Server packets are parsed in `Client::poll` and queued
as events in a mutex-guarded `Inbox`; `ap::update` drains them and acts. The seed build is the one
worker thread; it reports through an atomic, a mutex-guarded result and a serial number, so a
result from a run the player abandoned is ignored. `ap::tick` (the game mode's tick) does the
game-state work: item delivery, scanning, death link.

## Death link, goal, Transform Anywhere

Death link uses the `DeathLink` tag and `Bounce` packets; deaths are detected after
`daAlink_c::procCoDeadInit`/`procCoFogDeadInit` (a bottled-fairy save is not a death) and a
received death sets life to 0 once no event runs. Goal: `StatusUpdate` 30 when Ganondorf's
ending action begins (`daB_GND_Execute` hook) or the arena is left, plus a manual button.
Transform Anywhere (the apworld's default) is reproduced for the save with two small hooks,
because the host's own cheat is not reachable from a mod.

## Overlay and hints

`ap_overlay.*` (the community mod's drawing code, unchanged) lays out lines and draws them with
`J2DFillBox` and the game's message font from a post-hook on `dMeter2Draw_c::draw`, so the panel is
part of the HUD pass and hides with it. It hides only on `dComIfGp_isPauseFlag()`: `dScnPly_c::isPause()`
is the hit-stop timer and made it flicker. `mode/overlay.cpp` decides what goes in it and owns its
config variables and its tab. Its data: the client state, `g_checked` against `g_locationIds`,
`g_recentItems` (items delivered from the server and own-world items found in game),
`g_recentChat` (chat lines from `PrintJSON`) and `g_hints`. Hints come from the server's data storage:
after `Connected` the client sends `Get` and `SetNotify` for `_read_hints_<team>_<slot>` and turns
every `Retrieved`/`SetReply` into a `HintsEvent` carrying the whole list.

## Rules that must keep holding

- **The tables follow the apworld.** `gc_data.inc` is generated; after any apworld update rerun
  `tools/gen_gc_tables.py`, read `docs/GC_MAPPING_REPORT.md`, and bump the supported version.
- **Never answer `false` for a server location** in `resolve_check`.
- **`activateSeed` before `setupRandomizerFile`.**
- **Hook by exact symbol when the target is virtual or file-local**, and install optional hooks
  separately so a future Dusklight that renames one costs a feature, not the mode.
- **The server is untrusted input.** Server text passes through `message_safe` before the game's
  message renderer or a toast; ids are range-checked and resolved through tables, never used as
  indexes; the seed name is reduced to `[A-Za-z0-9_-]` before it becomes a path.
- **Never iterate `.items()` of a temporary** (dangles before C++23 range-for lifetime rules on
  older GCC): name the value first.
