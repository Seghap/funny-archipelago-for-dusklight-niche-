# Testing

Two kinds of test. The first needs no game: the mod's own source runs against a **live Archipelago
room**, with small stand-ins (below) for what only the game provides. The second runs the **real,
installed Dusklight** with the built `.dusk` (see "In the game"). What neither shows is listed at the
end; read that part.

One command runs the live suite (read-only: it never sends a location check, a status update or chat):

```sh
python3 -I tools/run_live_tests.py HOST PORT "SLOT NAME" [PASSWORD]
```

Needs g++, OpenSSL and zlib development files, and PyYAML. It writes `tools/live/capture.json`, which
holds the room's full placements for your slot (a spoiler for your own world; delete it if you share
the tree).

## The steps

| Step | What runs | What it proves |
|---|---|---|
| `live_probe.py` | A stdlib WebSocket client doing exactly the mod's handshake (bare `permessage-deflate`, `items_handling` 0b101, `GetDataPackage` in the same frame) | The room accepts the mod's handshake; the real `slot_data`, data package and `LocationScouts` answer are captured |
| `live_check.py` | The mod's real `gc_tables.cpp` + `gc_settings.cpp` (via `gc_adapter_cli.cpp`) and `ws_deflate.cpp`, on the capture | Version matches; every setting translates to a real Dusklight setting and option; all 475 location ids and every placed item id are known, and **the mod's names for them equal the server's own data package**; every placed item can be given and has a generator item; the server's compressed frames inflate byte-for-byte through the mod's negotiation and persistent inflater |
| `check_detection.py` | The mod's check-name map and flag scanner, emulated over the real `locations.yaml` and the SDK's check names | Every one of the room's 475 locations can be noticed when collected (by the engine's check name, by the save's flags, or both) |
| `host_gen/run.py` | **The real randomizer generator**, with the Archipelago-mode patches, built for the host, run on the room's real settings and placements | A seed generates (2 s); no item location is empty; every plandoed location holds exactly what the server put there; every other location is vanilla; the start event flags, evaluated by the generator's own condition code on the finished world, include every layer-critical flag |
| `host_gen/fuzz.py` | The same generator on many realistic variants: random options within the apworld's own constraints, vanilla items in switched-off categories, 0-90% of the locations held by "another world" | The Archipelago-mode patches hold across key/map/poe/bug/shop/heart/overworld/dungeon settings and castle/palace/ToT/trap/damage options (300+ variants run during development, all pass) |
| `host_client/run.py` | **The mod's real network client** (`ap_client.cpp`, `ws_tcp.cpp`, `ws_deflate.cpp`) against the live server | Connect over wss with compression in 0.2 s; slot data, players and slot_info parsed; 475 scouted placements with names; the hint list arrives from data storage and hints parse from the server's JSON; DeathLink tag change and Sync leave the connection up; reconnect on the same client; a wrong slot name is refused cleanly and flagged "do not retry"; an unreachable address reports failure instead of hanging |

Other checks, run separately: `tools/gen_gc_tables.py` (tables vs. apworld and Dusklight data),
`tools/test_gc_settings.cpp` (adapter unit tests), `tools/check_start_state.py` (start flags with a
negative control), `tools/make_grounding_ledger.py` (every external symbol exists),
`tools/syntax_check/check.sh` (type-checks 19 game-facing files against the real game and SDK headers).

## Stand-ins, and why they are honest

| Real | Stand-in | Where |
|---|---|---|
| Dusklight's net, log services | POSIX sockets / printf | `tools/host_client/net_shim.cpp` |
| mbedTLS (`tls.cpp`) | OpenSSL memory BIOs, same contract, certificate and host name verified | `tools/host_client/tls_openssl_shim.cpp` |
| nlohmann/json | a small working parser and writer | `tools/host_client/shims/nlohmann/json.hpp` |
| miniz | the system zlib behind the same calls | `tools/shims/miniz.h` |
| yaml-cpp | a libyaml-backed subset with yaml-cpp's reference semantics | `tools/host_gen/shims/` |
| battery-embed, base64pp | read files at run time; plain base64 | `tools/host_gen/shims/` |

The mod's own logic is what runs. The stand-ins can hide a bug in the *real* library glue
(`tls.cpp` against mbedTLS, `ws_deflate.cpp` against miniz, yaml-cpp's exact behaviour); those
files are Noah's, copied unchanged, except the generator's use of yaml-cpp, which is the
randomizer's own long-standing code.

## In the game

Build the bundle with CMake (`.toolchain/` holds a CMake/Ninja installed into a virtualenv here, so
nothing is installed globally; any CMake 3.25+ works), then run the tests against the installed game:

```sh
cmake -B .build -DDUSKLIGHT_DIR=<checkout of the installed Dusklight's tag>    # or omit it to fetch v2.0.3
cmake --build .build --parallel                                               # .build/mods/tp_archipelago.dusk
python3 -I tools/game_test/smoke.py                                           # unattended, no input, ~40 s
python3 -I tools/test_cover_art.py                                            # host test of the box-art image code
python3 -I tools/game_test/run_all.py                                         # every scenario below, ~2.5 hours
python3 -I tools/game_test/session.py --host HOST --port PORT --slot "SLOT"   # a person plays, see below
```

All of them start the installed game with `--user-dir`, `--mods` and `--log-dir` pointing into
`.gametest/`, so the player's own config, saves and mods are neither read for mod settings nor
written; only graphics/disc settings are copied from the player's config. The disc is *not* passed on
the command line: that skips the prelaunch menu, which is the only place a game mode gets activated
(`m_Do_main.cpp`, `prelaunch.cpp`). Window screenshots (`.gametest/shots/`) use the game's own X11
window (the game runs through XWayland: `SDL_VIDEODRIVER=x11`) and nothing else on the desktop.

### Scenarios: the real game, a fake room, a virtual gamepad

| Script | What it does and asserts |
|---|---|
| `smoke.py` (no input) | The bundle is found; 4/4 mods activate; the game mode activates in the prelaunch menu under the id the host derives (`<id>_<mod id>`, lower-cased) and shows next to Play; shutdown deactivates the mode and unloads the mod once each; no ERROR from the loader or the mod |
| `scenario_items.py` | New file (title, empty quest log, connect window, seed build, name entry, first scene) against the fake room: the mod sent Connect, GetDataPackage, LocationScouts, Get/SetNotify, ConnectUpdate; the connection stays up through name entry. Then: an item sent while Link is idle is delivered; an item sent with the status window open is delivered; "Send goal complete" reaches the room; a dropped connection is re-made by the mod and nothing is delivered twice; a death link from another player is received. Screenshots: the status window, the overlay with chat, a hint and recent items, Link dying |
| `scenario_reload.py` | Two items delivered, the game saved from the Collection screen, the game closed and started again, the file loaded: the mod finds its seed and connection, reconnects, reads the room's list back, delivers nothing twice, delivers a third item sent afterwards; the item wheel still has the first two |
| `scenario_ordon.py` | The game's own Warp window takes Link to each of the nine Ordon maps (the houses are stage `R_SP01`, including Jaggle & Pergie's): the game keeps running, its log has no error, and the screenshots show the NPCs, the chest in Link's House and the overlay in each |
| `scenario_checks.py` | Link walks to the Wooden Sword Chest and opens it: nothing was reported before; the room gets `LocationChecks` with that chest's id while the text box is still up; the game hands over the item the room placed there, never the default Green Rupee |
| `scenario_foreign.py` | The room says the same chest holds *Alice's Hookshot* (a game the mod has no items for): the seed builds, the chest is reported, Link holds the Sol and the text reads "You found Alice's Hookshot!", the item given is the `Archipelago Item` placeholder (0xDC) |
| `scenario_transform.py` | The slot's Transform Anywhere off, then on, with Dusklight's own "Can Transform Anywhere" cheat off in the profile: with Fado standing next to Link, Midna's menu offers "Transform into wolf"; off, she refuses ("If you transform here, it would scare someone!") and the mod overrides nothing; on, Link becomes the wolf and the trail says the mod let it through |
| `scenario_regions.py` | The Warp window takes Link to 28 maps across every region and dungeon (Faron, Eldin, Lanayru, the desert, Snowpeak, all nine dungeons, the Palace, Hyrule Castle, the Cave of Ordeals); each must load, the game keep running and the screen not be black; the log has no error. `--all` does every map in the table; `--from "Region"` resumes. Link has Dusklight's infinite-hearts cheat on, so nothing kills him between warps |
| `scenario_goal.py` | A room whose release, collect and remaining permissions are "goal" and which holds two items for the slot: "Send goal complete" sends the goal (StatusUpdate 30) once; `!collect` then delivers both held items to Link; `!release` is noticed by the mod (all 475 locations counted as checked); after a dropped connection and after a save, close and load the mod says again that the goal is done |
| `scenario_checktypes.py` | A check made by *playing*: Sera's Sundries, third shelf item (the Slingshot's slot). Nothing is reported while only looking at the wares; paying reports `Sera Shop Slingshot` (id 2320462) and the game hands over the room's Silver Rupee under the check name `shop:R_SP01:1:75`; the 30 rupees are taken |
| `scenario_every_check.py` | **Every one of the 474 locations that has an engine check name**, replayed through the real game (see below) |
| `scenario_glitched.py` | The tracker's glitched tier in game, on the live room's settings: 21 checks in logic and 13 more (Flight By Fowl, the Castle Town ladybugs, ...) in glitched logic only, listed in the trail and yellow in the Tracker tab; receiving the Shadow Crystal moves all 13 into plain logic and nothing out |
| `scenario_tracker.py` | The tracker in game: with only the start state, 21 of 475 checks are in logic; items sent by the room (Lantern, Iron Boots, Gale Boomerang, Clawshot, Bow, Master Sword) never take a check out of logic and together open a lot more |
| `scenario_tabs.py` | The Archipelago window's tabs: chat and the room's announcements in the Messages tab; a hint from the room in the Hints tab (hint points and cost from the server), its priority set from the tab and received by the room (`UpdateHint`); the Tracker tab by region; the overlay shows the open hint |
| `scenario_jingles.py` | Another player's item opened four times as progression, useful, filler and trap: the mod chooses the matching jingle each time (the choice is in the trail; the sound itself can only be heard) |
| `scenario_variants.py` | Five other sets of YAML options (dungeon items off or anywhere, categories off so 202 locations become vanilla in the local seed, castle/palace/ToT/Goron requirements, night start with OHKO and glitched logic, keys on bosses): each translates, builds a seed, creates the file, builds the tracker's logic (16 to 26 checks in logic at the start, depending on the variant) and plays on without an error |
| `scenario_deathlink.py` | Link's own death (warped into Hyrule Field with no cheats) is sent once as a `DeathLink` bounce from the slot |
| `scenario_boxes.py` | Game boxes, three combinations of the two art settings (item: cover or icon; text box: cover or icon): with a SteamGridDB key (from the environment, `TP_AP_SGDB_KEY`, never written to the tree) the mod downloads exactly the art asked for (cover and/or icon of *Ocarina of Time*, once, cached), and opening the chest shows Link holding the box with the chosen art and the text box's picture with the other. Without a key it asserts that nothing is downloaded and the item stays a Sol |
| `scenario_items_tab.py` | The Items tab: items from another player listed with sender and whether they reached Link; before the goal, Collect and Release send nothing; after "Send goal complete", Collect asks the room (`!collect`) and the held items arrive; Release asks to confirm first, then sends `!release` and the room counts every location as checked |
| `scenario_shortcut.py` | The overlay's controller shortcut: L + R (the pad's two triggers) + D-Pad Left hides and shows the overlay; D-Pad Left alone, L + Left, L + R and L + R + Right do nothing |
| `scenario_regen.py` | A saved file whose placement cache is marked as an older version: on load the mod rebuilds the seed from the server with the same hash, the save still matches it, and an item sent afterwards is delivered |
| `session.py` | A person presses the buttons against a real room; the script follows the mod's trail and gives a verdict. `--resume` reuses the previous session's profile so its file can be loaded |

The pieces (`tools/game_test/`):

- `fake_ap_server.py`: a local room that replays a read-only capture of the real room
  (`tools/live/capture.json`, from `tools/live_probe.py`). It speaks `ws://` with permessage-deflate (the
  real room's window of 2^11 and context takeover), passes the mod's own client test
  (`tools/host_client/run.py localhost 38999 "HELP ME"`), logs every packet the mod sends, and on command
  sends an item, chat, a hint, a death link, or drops the connection. `--foreign` puts another
  player's item at a location. `capture.json` is the room's full placement list for the slot (a spoiler
  for your own world); delete it if you share the tree.
- `vpad.py`, `padd.py`: a virtual Xbox 360 pad on `/dev/uinput` and the daemon that presses what it is
  told. Needs write access to `/dev/uinput` and, where an approval layer sits in front of the shell, the
  machine owner's approval of starting the daemon and sending presses.
- Server commands: the mod's chat box sends `Say`; the room's answers to `!release`, `!collect`, `!remaining`
  arrive as `PrintJSON` of type `CommandResult` (now shown as toasts) and the effects as `ReceivedItems` and
  `RoomUpdate`. The fake room implements the real server's permission bits (1 any time, 2 once the goal
  is reached, 4 automatically at the goal). `tools/host_client/run.py localhost PORT "HELP ME"` also
  checks, against the fake room only, that `!release` is refused before the goal and accepted after it.
- `ctl.py`: start/stop the game on a profile, screenshot, read the mod's flushed trail
  (`ap_debug.log`; the game's own log is only written at exit).
- `flows.py`: `Rig` ties them together (new file, load file, save in game, warp to an Ordon map).

What driving the game taught (facts a later test will need):

- Dusklight only feeds a port from a controller assigned to it: automatic assignment is switched off
  in aurora (`input.cpp`, `#if 0`), so a fresh profile has *no* gameplay input even though the menus
  (RmlUi) answer every connected pad. Port 1 must be set once in Settings -> Input -> Configure
  Inputs; `tools/game_test/fixtures/` holds the files that screen writes for the virtual pad, and
  `env.prepare` installs them into new profiles. A real controller on the machine takes Port 1 first.
- `--load-save N` skips the prelaunch menu, and with it the game-mode carousel, so the mode never
  activates and the game loads (or creates) a *vanilla* file. It is no shortcut for a mode's files.
- The pad's Back button is Dusklight's menu key (F1). The menu remembers its last window and focus:
  the Warp window opens on Hyrule Field the first time and keeps its selection afterwards; it changes
  the stage as soon as Warp is pressed, behind the open window. Warp's rows differ per map (Room is
  greyed for one-room maps), so tests press Down until the focus stops on the last row.
- The delivered-item count is stored in the save next to the inventory (mod blobs are written with the
  game's save): a file that was never saved in game loses both together and is legitimately given the
  items again. Tests save from Start -> Collection -> Save.
- The game's give queue hands an item over only while Link stands or walks, so "delivering" to
  "delivered item" in the trail can be a few seconds (8 s right after a new file's first scene).

Screenshots from the scripted runs are in `docs/evidence/in_game/` (Ordon maps, a chest check, a foreign
item, the overlay with chat and a hint, save and reload, the status window, a death link).

### The additions of the last round

- **Shops name other players' items.** A shop slot holding another player's item reads "Alice's Hookshot: 30
  Rupees" on the shelf, in the prompt and in the purchase talk (the same for the other texts the generator writes
  for an item at a location: the Fishing Hole bottle sign, Barnes's special offer, ...), and its model is the
  Sol at a shelf's size (it was as big as the screen). The generator takes a per-location label for this
  (`g_archipelagoItemLabels`, in `docs/PATCHES.md`). The labels live in the seed, so the placement cache's
  version went up to 2: an existing file rebuilds its seed on its next load (`scenario_regen.py` tests exactly
  that path, which no earlier test had walked).
- **Items tab and goal-time release/collect.** See above; the buttons follow the room's own permission bits
  (any time / after the goal) and Release asks first because it cannot be undone.
- **Overlay shortcut: L + R + D-Pad Left.** D-Pad *Down* is not free: it opens the item ring (Up too; Right opens
  the map), found by trying the shortcut on Down first. The virtual pad's analog triggers are the game's L and R
  (RB is Z). The pad's release of a three-button chord is sometimes noticed by the game seconds late, so the
  test sends a chord again if it toggled nothing; a real controller releases when the player does.
- **The CI workflow** (`.github/workflows/build.yml`) is described in the README; it has not been run.
- **A get-item scene waits for A.** A progression item from another player plays the whole scene and the next
  item waits behind it until the player dismisses it. The trail's 10-second note now says so
  ("Link is in a get-item scene (press A ...)").

### What the game runs found

- **Shutdown ran twice.** The host deactivates the game mode and then calls `mod_shutdown`; both ran
  the full teardown, so the second unregistered the logo texture again and the host logged
  `texture unregister failed: unknown handle 1`. `session::shutdown()` now tears down only what is
  installed.
- **The mode's name was cut off.** The carousel next to Play shows about 24 characters, so
  "Archipelago (Twilight Princess)" read "ARCHIPELAGO (TWILIGHT PRINCE". The mode is now called
  "Archipelago".
- **The connect window dropped the connection when the seed was ready.** The game reads PROCEED and
  resets its state to PENDING the same frame; when the mod's own window then closed, the mod took
  PENDING to mean the player had cancelled, dropped the connection and left a stale RETURN that would
  have bounced a second New File. The window-closed handler now goes by the mod's phase and the state
  pointer is released once PROCEED is set. (Found from a real player's trail and the room's join/leave
  log; `scenario_items.py` asserts a single Connect.)
- **The status window, the connect window's status and the message list ran lines together.** Text rows
  collapse "\n"; they are now RML with `<br/>`, every line made safe first.
- **The overlay works** (it had only been built): it draws in every Ordon map, in the item screens' and
  menus' absence, and keeps drawing while Link dies.
- **Test mistakes that looked like bugs:** the mode id (`<id>_<mod id>`), the delivered count living in
  the save, the Warp window's remembered focus.

### Real-room sessions (someone at the controls, live room `multiworld.gg:49607`)

Run with `session.py` (first two) and by hand; trail and screenshots in `docs/evidence/first_session/`.

| What | Evidence |
|---|---|
| Connect, scout, seed build, name entry, first scene, new file | Trail `connected in phase 1: 475 locations (0 checked), 0 unknown to this mod`, `new save created, hash Fyer Stalfos Fado, 475 locations`; Link in Ordon in Hero's Clothes |
| A check, end to end (twice) | `give item=0x02 (Blue Rupee) ... check='uli_cradle_reward' -> Uli Cradle Delivery`, and the Wooden Sword Chest (Piece of Heart); the room's own log: "HELP ME sent Seeds (50) to HELP ME (Uli Cradle Delivery)", "... sent Piece of Heart to HELP ME (Wooden Sword Chest)" |
| Not our locations stay quiet | `freestanding:` pickups logged `-> (not ours)`, not reported (the apworld has no such locations) |
| Status window in game | Host/port, Reconnect, Disconnect, Send goal complete, Death link, chat box, recent messages |

**Why a Blue Rupee for "Seeds (50)":** not a bug. The randomizer's `verifyProgressiveItem` turns ammo
(seeds, arrows, bombs) into a Blue Rupee while you do not own the weapon, and the slingshot is not
there at the start; the check still counts as Seeds (50) for the room. The trail says so
(`the server's item there is Seeds (50) (0x12); given as Blue Rupee`).

**A Slingshot sent from the room's console that the player reported never arriving** could not be
reproduced: the same item sent at the start of a file, mid-play with Link idle, and mid-play with the
status window open is delivered in every case here, the file that was created afterwards had it, and
the counter and the room's list agree. What the real session lacked was a trail for deliveries, so the
mod now logs `server sent`, `delivering #`, `delivered item`, `N item(s) waiting; not delivering now:
<reason>` and, if the game's own give queue has not handed an item over after 10 s, what Link is doing;
the Status tab shows the same. If it happens again the trail will say why.

## The tracker, hints, messages, jingles, traps

**Tracker.** The mod runs the GameCube apworld's own logic: the same regions, entrances, location rules
and options as its Python (`Logic/Macros.py`, `RegionRules.py`, `Rules.py`), which `tools/gen_gc_logic.py`
turns into C++ (`src/ap/gc_logic.inc`; `--check` fails if it is out of date, and the script stops on any
construct it does not understand rather than dropping a rule). It is asked twice, Glitchless and Glitched;
a check only the second reaches is shown yellow ("glitched only"), the rest of what the first reaches
green. The received items come from the server; the apworld's event locations (bosses, the Renado's
Letter/Invoice/Statue/Charm chain, Ganondorf) count once reachable, exactly as in its logic. The options the
rules read come from `slot_data["Settings"]`. If the slot itself is set to Glitched, the server counts the
yellow checks as in logic; the tab still shows them yellow.

*Proof it is the apworld's logic.* `tools/ap_truth/truth.py` runs the real apworld in Archipelago's real
core (0.6.7 source from `Downloads/Archipelago-0.6.7.zip`, unpacked into `.toolchain/ap_core`, with its own
Python 3.12 venv `.toolchain/ap_venv`; the core's version guard is stubbed, nothing in it is changed) for six
option variants, Glitchless and Glitched, on 80 random item sets each, and writes what the Python says is
reachable. `tools/host_gen/logic_test.cpp` requires the C++ to give exactly the same locations: 480 cases
x 2 modes, 0 differences (`g++ -std=c++23 -I src tools/host_gen/logic_test.cpp src/ap/gc_logic.cpp`, then
run it on `.gametest/ap_truth/*.txt`). Two places where the apworld's Python is broken are not
reproduced as crashes: `can_unlock_*_map` calls `can_reach_region` without the player (only reached with
Open Map off) and `can_complete_eldin_twilight_glitched` reads an accessor that is commented out (nothing
calls it); the C++ means what they obviously mean.

**Hints and Messages tabs.** After the community mod's: your hints with their status, asking for a hint
by item or location (`!hint`, `!hint_location`), setting a priority on a hint for your own item, the hint
points and cost the server reports, and the room's log in the colours Archipelago clients use. Left out:
the emoji picker and font (a separate asset set).

**Traps.** The apworld's Ice Trap is the game's Foolish Item. When another player sends you one it now
plays the whole get-item scene ("a cold wind blows..."), like a progression item, instead of arriving as a
silent toast that gives the joke away.

**Reconnect.** The Status tab counts down to the next automatic reconnect, and says that checks made
meanwhile are kept.

**Game box art.** Another player's item shows as the box of their game, with the cover from SteamGridDB, which
needs the player's own free API key (the Status tab's "Other players' items": a switch, the key, what the
covers are doing, and "Download covers again"). Each game's cover downloads once to
`randomizer/archipelago/covers` and is shared by every room; a PNG or JPG named after a game in
`covers/custom` is used instead; without a key, or for a game SteamGridDB doesn't know, the item stays a Sol.
Ported from the community mod (`ap_box`, `ap_covers`, `cover_art`, and its `stb_image.h`); unlike it, there is
no first-run dialog. Two settings choose the art, each **Box cover** or **Game icon** (SteamGridDB's square icons): "Art on the
item" (on the ground and in Link's hands) and "Art in the text box" (the picture beside "You found ..."), so
any mix works, for example the icon in Link's hands and the cover in the text box. A game with no art of the
kind asked for uses the other kind; only the kinds asked for are downloaded; an icon's transparent corners show
a dark backdrop on the world box but stay transparent in the text box. `tools/test_cover_art.py` tests the icon
picking (a square PNG, else the largest `.ico` preview) and the image processing on the host. Verified in game
with a real key in all three combinations tried (cover/cover, icon/icon, icon in hand and cover in the text box). One build lesson: a mod's shared library may link with
undefined symbols (it did, for the HTTP service, until it was imported) and only fails when the game loads
it; `nm -D .build/tp_archipelago.so | grep ' U ap'` lists what is missing, and every scenario starts by loading it.

The "update check" is the existing apworld-version check at connect (a newer apworld than the mod supports is
refused unless `allowUnknownWorldVersion` is on).

**The development room** (`multiworld.gg:49607`) was down for a while and is back (same seed, now with four
checks made by someone else's play: Uli, the Wooden Sword Chest and two Hyrule Castle chests). The host-side
live suite (`tools/run_live_tests.py`) passes against it again; no check or message has been sent to it by any
automated test (the game tests use the local fake room).

**The ending.** The credits can be started with the Warp window (Dark Lord Ganondorf Arena, spawn point 23),
but they run well over ten minutes, and playing them did *not* report the goal within ten: the mod's second
trigger is the game leaving the arena stage through a stage change, and the credits' return to the title may
not go through one. So of the three goal triggers only the button is shown to work; Ganondorf's end action
(`ACTION_END` with the ending camera) is the one meant for play and is untested in game; the stage-exit one
is doubtful. If the goal is not reported when you beat the game, use the status window's "Send goal complete".

## Every location, through the real game

`scenario_every_check.py` replays the check of every location (487 check names for 474 locations: a
chest, Poe, shop, Sky Character, golden wolf, Agitha bug reward, freestanding item, boss and each named
event or NPC reward) through the game's own item service. A separate test tool, `tools/game_test/replay_mod`
(its own `.dusk`, built with `cmake --build .build --target tp_ap_replay_package`, never part of the
mod), asks the service to give the item of each named check, as the game does when a chest opens or an
NPC gives a reward; the game then does what it always does. In the real engine, for every location, this
shows the part this mod owns: **check name -> location -> item -> report to the room.**

For each location it asserts: the room received `LocationChecks` for exactly that location; the game
handed over the item the room placed there (an item of the slot's own, with the randomizer's ammo and
progressive-item rules applied, explained in the trail line after the give) or the placeholder `0xDC` where the
room holds another player's item (every sixth location does); no other location was reported; the game
survived all 487 gives. Result: 474 of 474, with 79 placeholders. (It also shows that the
check-name table the mod builds at connect agrees, location for location, with the one `tools/check_detection.py`
derives independently from the randomizer's data.)

**What it does not show:** that the *game* raises that check name when a player does the thing.
That is the game's code, not this mod's, and its names are the SDK's (`mods/items.h`). The kinds of
check a person or script has actually *done* in the game: chest (Wooden Sword Chest, twice, one with
another player's item), shop (Sera's Slingshot slot), NPC reward (Uli's cradle). Not played, only
replayed: Poe, golden wolf, Sky Character (needs an owl statue pushed off its platform), Agitha's
bugs, freestanding pickups outside the Ordon houses, dungeon rewards and bosses, fishing, the other
named NPC rewards. A try at Agitha's castle was given up: it is a ring around a tree whose doors
I could not find a way through by walking blind.

The one location with no engine check name (Forest Temple's Gale Boomerang, an item-flag location) is
reported only by the save-flag scan, which runs in the background, so that single check can reach
the room a few seconds after the player gets the item rather than at once.

## Transform Anywhere, regions, the goal

**Transform Anywhere** (`mode/hooks.cpp`) was written from the host's source and had never run. In game,
with the host's own cheat off and Fado next to Link: setting off, Midna refuses; setting on, Link
transforms and the trail logs `transform anywhere: someone could see Link; allowed anyway`. Both
hooks' target functions exist and install; the Castle Town branch of the flow query (the other hook)
is covered by the same build but not walked through in Castle Town.

**Regions.** All 28 maps of the curated sweep load under the Archipelago seed: Hyrule Field, Faron
(South and North woods, Sacred Grove, the cave, Coro's house), Eldin (Kakariko, Death Mountain, the
graveyard, Renado's, Malo Mart), Lanayru (Castle Town, Zora's River and Domain, Lake Hylia, Telma's),
the desert, Snowpeak, all nine dungeons, the Palace of Twilight, Hyrule Castle and the Cave of Ordeals.
The twilights of this room's settings are cleared in the screenshots: Faron, Kakariko and Zora's Domain
are in daylight. Two things the sweep taught: the first run's screenshots were mostly the Game Over screen: Link had
been killed in Hyrule Field (Bulblins, on Epona) and the "not black" check was satisfied by the Game
Over text, so it proved nothing; the sweep now turns on Dusklight's infinite-hearts cheat, and the
screenshots (not the brightness check) are what was looked at. And the warp table's own note that
Bulblin Camp's first room "can't load far enough" is true: it is a black screen (not a mod fault;
excluded).

**The goal and `!release`.** The mod reports the goal three ways: Ganondorf's end action
(`daB_GND_Execute` with `ACTION_END` and the ending camera), leaving his arena `D_MN09C` through a
stage exit, and the status window's "Send goal complete" button. The last is what `scenario_goal.py`
drives, and what a player would use if the first two ever missed. What it proves: the goal reaches the
room exactly once, again after every reconnect and from a reloaded file; `!collect` and `!release`, which
the real room allows after the goal (the capture says release is allowed at any time, collect after the
goal), arrive in the mod as items to deliver and as checked locations; their `CommandResult` answers
are shown. **Not proven: the first two triggers.** Ganondorf's fight is spawned by the story's
events, and warping into his arena (it loads, the game runs) does not spawn him, so his last blow was
not played; the hook's constants were checked against `d_a_b_gnd.cpp` (`ACTION_END` is 22, the
ending camera mode is set to 60 at the killing blow) and against the community mod's same hook. Play
to the end once with `debugLog` on and look for `goal complete (Ganondorf defeated)` in the trail;
if it only says `(manual)`, the button was needed.

**Checks outside Ordon:** none was collected by playing; the replay above covers every location's name, the
static `tools/check_detection.py` shows each can be noticed, and the game's loading of the regions is
shown above.

## Still not shown

Other players actually in a room; Poe, golden wolf, Sky Character, Agitha and boss checks made by hand; the final blow on Ganondorf; the
Day-2 layer after the goat chores; Castle Town's Midna-menu branch.

## What testing found

- **Seed generation failed for everyone.** The generator requires every item to have text in each
  language file; the new `Archipelago Item` had none, so `Generate()` threw
  *"Item 'Archipelago Item' does not have associated text data in language files"* before any seed
  existed. Only `items.yaml` had been ported from the reference mod. The six language files now
  carry the entry (`docs/PATCHES.md`). This was invisible to type-checking and to every other test;
  it only showed once the real generator ran.

## What this cannot show

What is left is what no scripted scenario reaches: the items above, the real room's behaviour with
other players in it (foreign items arrive through the same path as the fake room's), and starting-state
options other than this room's (the generator is fuzzed on them, the game has only loaded these).
