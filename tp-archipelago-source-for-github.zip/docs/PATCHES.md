# Changes to the vendored randomizer

`src/` (outside `src/ap/`), `generator/` and `res/` are the official randomizer
(`ref_official_rando_ap`, v1.0.6 plus its work-in-progress Archipelago branch) copied unchanged
except for the changes below. Everything else is new code in `src/ap/` and `tools/`.

## Removed (the official work in progress)

- `src/archipelago.cpp/.hpp`, `src/archi/ap_settings_convert.*`: unfinished, and wrong in ways that
  break connecting: it reads `slot_data["SeedID"]` (the apworld does not send one; the JSON
  access throws), maps `Skip MDH` to a setting spelled `Skip Midna's Desparate Hour` (so
  `std::map::at` throws), ignores `ReceivedItems` and `LocationInfo`, sends through Dusklight's
  WebSocket service (which drops everything after a connection's first message), and its
  `onNewArchiSave` never activates a seed. Replaced by `src/ap/`.
- `buildArchipelagoTab` / `buildArchipelagoGateMenu` in `src/ui/rando_config.cpp/.hpp`.

## Generator (Archipelago mode)

| File | Change |
|---|---|
| `generator/randomizer.hpp` | `inline bool g_archipelagoMode` and `g_archipelagoSkippedPlando` |
| `generator/logic/world.cpp` `PlacePlandomizerItems` | In Archipelago mode: a plando entry on a location the generator already holds vanilla is recorded and skipped instead of throwing; after the plando, every empty item location keeps its original item; the leftover pool is cleared; logic verification of the plando is skipped |
| `generator/logic/world.cpp` `FinalizeBottleContents` | In Archipelago mode the random bottle re-roll is skipped (it would change bottles the multiworld placed) |
| `generator/logic/fill.cpp` | Final `VerifyLogic` skipped in Archipelago mode (other worlds' items are opaque) |
| `generator/logic/entrance_shuffle.cpp` `ValidateWorld` | Skipped in Archipelago mode (entrance randomization is always off here; kept for parity with the reference mod) |
| `generator/data/items.yaml` | New item `Archipelago Item`, id `0xDC`, junk (only ever plandomized) |
| `generator/data/text/languages/*.yaml` (all six) | Text for `Archipelago Item` (standard, pretty, cryptic). **Required**: the generator throws for any item without text in every language. Found by running the real generator (docs/TESTING.md) |

The `randomizer.hpp`, `fill.cpp`, `entrance_shuffle.cpp`, `items.yaml` and language-file rows follow
noahsmaximum's Dusklight Archipelago mod; the vanilla-fill and skip-and-record behaviour in
`PlacePlandomizerItems` and the bottle hunk are new, because that mod's apworld sends a placement
for every location and this one does not.

## Game side

| File | Change |
|---|---|
| `src/item.cpp` | Item `0xDC`: model `Obj_ballS` (the Sol) in both item data tables, instead of a dummy rupee |
| `src/hooks.cpp` | `#include "ap/ap_mode.hpp"`; the get-item jingle follows the Archipelago classification for `0xDC`; `ap::on_get_item_demo` called at the top of `hookPreProcCoGetItem` |
| `src/session.cpp/.hpp` | Archipelago-only mod: one game mode (`ap::game_mode_desc()` plus the session's activate/deactivate/tick); `onNewSave` / `onSaveLoaded` exported (the official `onNewRandoSave` / `onRandoSaveLoaded` logic, unchanged); `activateSeed` and the check-name parsers exported; the randomizer's own file-select UI and `ui::initialize` no longer used; `ap::activate/deactivate/tick` wired in |
| `src/mod.cpp` | Imports `NetService` instead of `WebSocketService`; `mod_update` calls `ap::update()` so the network keeps moving while a UI window pauses the game |

## Not changed, deliberately

`src/ui/*` (the randomizer's own menus) still compile but are not reachable: no menu tab and no
file-select gate are registered. The standalone generator and its tests (`generator/generator_only.cpp`,
`generator/test/`) are present but not built.


## Tracker

None. The tracker used to need three small additions to the generator; it now runs the apworld's own rules
(`src/ap/gc_logic.*`, generated from the apworld's Python by `tools/gen_gc_logic.py`) and those additions
are gone again.

## Names for other players' items (added with the shop labels)

- `randomizer.hpp`: `g_archipelagoItemLabels`, location name -> the words that name another world's item there
  ("Alice's Hookshot"), set by the mod before `Generate()` in Archipelago mode and cleared after.
- `logic/hints.cpp`, `doItemTextReplacement`: where the item at a location is the "Archipelago Item"
  placeholder and the map has a label for the location, the label replaces the placeholder's name in the shop,
  sign and offer texts built there. Locations without a label keep "Archipelago Item".
