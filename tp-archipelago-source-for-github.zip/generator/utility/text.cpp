#include "text.hpp"

#include "shiftjis_table.hpp"
#include "string.hpp"
#include "yaml.hpp"

#include <mods/svc/flow.hpp>

#include <fmt/format.h>

#include <mutex>
#include <ranges>
#include <unordered_map>

#ifndef RANDOMIZER_ONLY
#include "JSystem/JUtility/JUTFont.h"
#include "m_Do/m_Do_ext.h"
#endif

namespace randomizer {
namespace {

std::string text_color_code(uint32_t rgba) {
    const auto message =
        mods::flow::MessageBuilder{}.text_color(rgba).build(MESSAGE_LANGUAGE_ENGLISH);
    const auto& bytes = message.text();
    return {reinterpret_cast<const char*>(bytes.data()), bytes.size() - 1};
}

const auto kDarkGreenMessageCode = text_color_code(0x4BBE4BFF);
const auto kBlueMessageCode = text_color_code(0x4B96D7FF);
const auto kSilverMessageCode = text_color_code(0xBFBFBFFF);

}  // namespace

    Text::Text(const std::string& str) {
        for (auto& entry : mEntries) {
            entry.str = str;
        }
    }

    void Text::Replace(const std::string& oldText, const Text& replacementText, uint32_t count/* = max*/) {
        for (size_t i = 0; i < mEntries.size(); ++i) {
            auto& curString = mEntries[i].str;
            curString = utility::str::Replace(curString, oldText, replacementText.mEntries[i].str, count);
        }
    }

    void Text::Replace(const std::string& oldText, const std::string& replacementText, uint32_t count/* = max*/) {
        for (auto& text : mEntries) {
            text.str = utility::str::Replace(text.str, oldText, replacementText, count);
        }
    }

    void Text::Replace(const Text& oldText, const std::string& replacementText, uint32_t count /* = max*/) {
        for (size_t i = 0; i < mEntries.size(); ++i) {
            auto& curString = mEntries[i].str;
            auto& oldString = oldText.mEntries[i].str;
            curString = utility::str::Replace(curString, oldString, replacementText, count);
        }
    }

    void Text::PopBack() {
        for (auto& entry : mEntries) {
            if (!entry.str.empty()) {
                entry.str.pop_back();
            }
        }
    }

    void Text::Clear() {
        for (auto& entry : mEntries) {
            entry.str.clear();
        }
    }

    void Text::Capitalize() {
        try {
            // Determine the platform-specific locale string
#if defined(_WIN32) || defined(_WIN64)
            const char* localeName = "English_United States.1252";
#else
            const char* localeName = "en_US.iso88591";
#endif

            static const std::locale latin1Locale(localeName);

            for (size_t lang = 0; lang < mEntries.size(); ++lang) {
                auto& entry = mEntries[lang];
                if (!entry.str.empty() && lang != JAPANESE) {
                    auto firstCharIndex = findFirstNonMessageCodeIndex(entry.str);
                    entry.str[firstCharIndex] = std::toupper(entry.str[firstCharIndex], latin1Locale);
                }
            }
        } catch (const std::runtime_error&) {
            // Fallback incase the system completely lacks the requested locale definition
            for (size_t lang = 0; lang < mEntries.size(); ++lang) {
                auto& entry = mEntries[lang];
                if (!entry.str.empty() && lang != JAPANESE) {
                    auto firstCharIndex = findFirstNonMessageCodeIndex(entry.str);
                    entry.str[firstCharIndex] = static_cast<char>(std::toupper(static_cast<unsigned char>(entry.str[firstCharIndex])));
                }
            }
        }
    }

    void Text::BreakLines(float maxLineWidth /*= MAX_LINE_WIDTH_ITEM_TEXTBOX*/) {
        for (size_t lang = 0; lang < mEntries.size(); ++lang) {
            auto& entry = mEntries[lang];
            breakLines(entry.str, maxLineWidth, lang);
        }
    }

    void Text::PadToNextBox() {
        BreakLines();
        for (size_t lang = 0; lang < mEntries.size(); ++lang) {
            auto& entry = mEntries[lang];
            auto linesPerBox = mLinesPerBox;
            if (lang == JAPANESE) {
                linesPerBox = mLinesPerBoxJP;
            }
            size_t numNewLines = std::ranges::count_if(entry.str, [](char c){return c == '\n';});
            while (numNewLines == 0 || entry.str.back() != '\n' || numNewLines % linesPerBox != 0) {
                entry.str += '\n';
                ++numNewLines;
            }
        }
    }

    bool Text::Empty() const {
        for (auto& entry : mEntries) {
            if (!entry.str.empty()) {
                return false;
            }
        }
        return true;
    }

    bool Text::IsTooLong() const {
        for (auto& entry : mEntries) {
            auto numNewLines = std::ranges::count_if(entry.str, [](char c){return c == '\n';});
            if (numNewLines > mNewLinesPerMessage) {
                return true;
            }
        }

        return false;
    }

    // Will split this text object into multiple objects short enough to fit into individual
    // text ids
    std::vector<Text> Text::SplitToFitTextLimits() {
        if (this->IsTooLong()) {
            // Figure out how many new text objects we need to fit all the text
            size_t numTextObjects{1};
            for (auto& entry : mEntries) {
                double numNewLines = std::ranges::count_if(entry.str, [](char c){return c == '\n';});
                auto curTextSplitAmount = static_cast<size_t>(std::ceil(numNewLines / mNewLinesPerMessage));
                numTextObjects = std::max(curTextSplitAmount, numTextObjects);
            }

            // Populate the Text vector with copies of this object to copy over the fields
            auto splitText = std::vector(numTextObjects, *this);
            // Clear the text
            for (auto& text : splitText) {
                text.Clear();
            }

            // Split each string into the appropriate number of objects
            for (size_t textIdx = 0; textIdx < mEntries.size(); ++textIdx) {
                auto& textEntry = mEntries[textIdx];
                auto linesPerBox = mLinesPerBox;
                if (textIdx == JAPANESE) {
                    linesPerBox = mLinesPerBoxJP;
                }
                // Calculate how many newlines we're allowing in this string per message
                // Different languages may have different amounts of newlines
                double numNewLines = std::ranges::count_if(textEntry.str, [](char c){return c == '\n';});
                auto newLinesPerMessage  = static_cast<size_t>(std::ceil(numNewLines / numTextObjects));
                // Keep the number of lines as a multiple of how many lines are in a box so we don't split in the middle of a textbox
                while (newLinesPerMessage % linesPerBox != 0) {
                    ++newLinesPerMessage;
                }

                size_t splitIdx = 0;
                do {
                    size_t pos = 0;
                    if (newLinesPerMessage == 0) {
                        pos = std::string::npos;
                    }
                    for (int i = 0; i < newLinesPerMessage; ++i) {
                        pos = textEntry.str.find('\n', pos);
                        if (pos == std::string::npos) {
                            break;
                        }
                        ++pos;
                    }

                    // Get the current split of the string
                    auto curSplit = textEntry.str.substr(0, pos);
                    // Pop off the last newline since it's unnecessary
                    if (!curSplit.empty() && curSplit.back() == '\n') {
                        curSplit.pop_back();
                    }
                    splitText.at(splitIdx).mEntries[textIdx].str = curSplit;
                    ++splitIdx;
                    if (pos == std::string::npos) {
                        textEntry.str.clear();
                    } else {
                        textEntry.str = textEntry.str.substr(pos);
                    }
                } while (!textEntry.str.empty());
            }

            // Recopy the front element to this object
            *this = splitText[0];

            // Reassign the vector everything except the first element
            splitText.assign(splitText.begin() + 1, splitText.end());

            // Add the split message prefix to every box
            if (!mSplitMessagePrefix.empty()) {
                for (auto& textObj : splitText) {
                    for (auto& entry : textObj.mEntries) {
                        entry.str = mSplitMessagePrefix + entry.str;
                        applyMessageCodes(entry.str);
                    }
                }
            }
            return splitText;
        }

        return {};
    }

    Text& Text::operator+=(const Text& rhs) {
        for (size_t i = 0; i < mEntries.size(); ++i) {
            mEntries[i].str += rhs.mEntries[i].str;
        }
        return *this;
    }

    Text& Text::operator+=(const std::string& rhs) {
        for (auto& entry : mEntries) {
            entry.str += rhs;
        }
        return *this;
    }

    Text operator+(Text lhs, const Text& rhs) {
        lhs += rhs;
        return lhs;
    }

    Text operator+(Text lhs, const std::string& rhs) {
        for (auto& entry : lhs.mEntries) {
            entry.str += rhs;
        }
        return lhs;
    }

    Text operator+(const std::string& lhs, const Text& rhs) {
        return Text(lhs) + rhs;
    }

    Text::Type stringToType(const std::string& str) {
        std::unordered_map<std::string, Text::Type> strToType = {
            {"Standard", Text::Type::STANDARD},
            {"Pretty", Text::Type::PRETTY},
            {"Cryptic", Text::Type::CRYPTIC},
        };

        if (strToType.contains(str))
        {
            return strToType.at(str);
        }

        throw std::runtime_error("Text type \"" + str + "\" is not recognized.");
    }

    Text::Language stringToLanguage(const std::string& str) {
        std::unordered_map<std::string, Text::Language> strToLanguage = {
            {"english",  Text::ENGLISH},
            {"spanish",  Text::SPANISH},
            {"french",   Text::FRENCH},
            {"german",   Text::GERMAN},
            {"italian",  Text::ITALIAN},
            {"dutch",    Text::DUTCH},
            {"japanese", Text::JAPANESE}
        };

        if (strToLanguage.contains(str))
        {
            return strToLanguage.at(str);
        }

        throw std::runtime_error("Language \"" + str + "\" is not recognized.");
    }


    std::string languageToString(Text::Language language) {
        switch (language) {
            case Text::ENGLISH:
                return "english";
            case Text::SPANISH:
                return "spanish";
            case Text::FRENCH:
                return "french";
            case Text::GERMAN:
                return "german";
            case Text::ITALIAN:
                return "italian";
            case Text::DUTCH:
                return "dutch";
            case Text::JAPANESE:
                return "japanese";
            default:
                return "unknown language enum";
        }
    }

    Text::Gender stringToGender(const std::string& str)
    {
        std::unordered_map<std::string, Text::Gender> strToGender = {
            {"Masculine", Text::Gender::MASCULINE},
            {"Feminine", Text::Gender::FEMININE}
        };

        if (strToGender.contains(str))
        {
            return strToGender.at(str);
        }

        return Text::Gender::NEUTRAL;
    }

    Text::Plurality stringToPlurality(const std::string& str)
    {
        if (str == "Plural") return Text::Plurality::PLURAL;
        return Text::Plurality::SINGULAR;
    }

    std::string UTF8ToCP1252(const std::string& utf8Str) {
        std::string cp1252Str;
        cp1252Str.reserve(utf8Str.length());

        size_t readPos = 0;
        size_t len = utf8Str.length();

        while (readPos < len) {
            unsigned char c = utf8Str[readPos];

            if (c < 0x80) {
                // Standard ASCII (0x00 - 0x7F)
                cp1252Str.push_back(c);
                ++readPos;
            }
            else if ((c & 0xE0) == 0xC0 && (readPos + 1 < len)) {
                // 2-byte UTF-8 sequence (0xC2 - 0xDF)
                unsigned char nextByte = utf8Str[readPos + 1];

                // Reconstruct code point for U+0080 to U+07FF
                uint32_t codePoint = ((c & 0x1F) << 6) | (nextByte & 0x3F);

                static std::unordered_map<uint32_t, char> twoByteMap = {
                    {0x0152, 0x8C}, // Œ
                    {0x0153, 0x9C}, // œ
                    {0x0160, 0x8A}, // Š
                    {0x0161, 0x9A}, // š
                    {0x0178, 0x9F}, // Ÿ
                    {0x017D, 0x8E}, // Ž
                    {0x017E, 0x9E}, // ž
                };

                if (twoByteMap.contains(codePoint)) {
                    cp1252Str.push_back(twoByteMap.at(codePoint));
                } else if (codePoint <= 0xFF) {
                    cp1252Str.push_back(static_cast<char>(codePoint));
                } else {
                    throw std::runtime_error(fmt::format("Invalid character U+{:04X} when converting to CP1252 in \"{}\"", codePoint, utf8Str));
                }

                readPos += 2;
            }
            else if ((c & 0xF0) == 0xE0 && (readPos + 2 < len)) {
                // 3-byte UTF-8 sequence
                unsigned char b2 = utf8Str[readPos + 1];
                unsigned char b3 = utf8Str[readPos + 2];

                uint32_t codePoint = ((c & 0x0F) << 12) | ((b2 & 0x3F) << 6) | (b3 & 0x3F);

                static std::unordered_map<uint32_t, char> threeByteMap = {
                    {0x20AC, 0x80}, // €
                    {0x201A, 0x82}, // ‚
                    {0x0192, 0x83}, // ƒ
                    {0x201E, 0x84}, // „
                    {0x2026, 0x85}, // …
                    {0x2020, 0x86}, // †
                    {0x2021, 0x87}, // ‡
                    {0x02C6, 0x88}, // ˆ
                    {0x2030, 0x89}, // ‰
                    {0x2039, 0x8B}, // ‹
                    {0x2018, 0x91}, // ‘
                    {0x2019, 0x92}, // ’
                    {0x201C, 0x93}, // “
                    {0x201D, 0x94}, // ”
                    {0x2022, 0x95}, // •
                    {0x2013, 0x96}, // –
                    {0x2014, 0x97}, // —
                    {0x02DC, 0x98}, // ˜
                    {0x2122, 0x99}, // ™
                    {0x203A, 0x9B}, // ›
                };

                if (threeByteMap.contains(codePoint)) {
                    cp1252Str.push_back(threeByteMap.at(codePoint));
                } else {
                    throw std::runtime_error(fmt::format("Invalid character U+{:04X} when converting to CP1252 in \"{}\"", codePoint, utf8Str));
                }
                readPos += 3;
            }
            else {
                // Unsupported sequence, out of CP1252 range, or malformed UTF-8
                throw std::runtime_error(fmt::format("Invalid bytes when converting to CP1252 with \"{}\"", utf8Str));
            }
        }

        return cp1252Str;
    }

    std::string UTF8ToShiftJIS(const std::string& utf8Str) {
        std::string sjisStr;
        sjisStr.reserve(utf8Str.length());

        size_t read_pos = 0;
        size_t len = utf8Str.length();

        while (read_pos < len) {
            uint32_t codepoint = 0;
            unsigned char c = utf8Str[read_pos];

            // Decode UTF-8 sequence to Unicode codepoint
            if (c < 0x80) {
                codepoint = c;
                read_pos += 1;
            } else if ((c & 0xE0) == 0xC0 && (read_pos + 1 < len)) {
                codepoint = ((c & 0x1F) << 6) | (utf8Str[read_pos + 1] & 0x3F);
                read_pos += 2;
            } else if ((c & 0xF0) == 0xE0 && (read_pos + 2 < len)) {
                codepoint = ((c & 0x0F) << 12) |
                            ((utf8Str[read_pos + 1] & 0x3F) << 6) |
                            (utf8Str[read_pos + 2] & 0x3F);
                read_pos += 3;
            } else if ((c & 0xF8) == 0xF0 && (read_pos + 3 < len)) {
                codepoint = ((c & 0x07) << 18) |
                            ((utf8Str[read_pos + 1] & 0x3F) << 12) |
                            ((utf8Str[read_pos + 2] & 0x3F) << 6) |
                            (utf8Str[read_pos + 3] & 0x3F);
                read_pos += 4;
            } else {
                throw std::runtime_error(fmt::format("Invalid UTF-8 byte sequence in \"{}\"", utf8Str));
            }

            // Convert Codepoint to Shift-JIS
            if (codepoint < 0x80) {
                // Standard ASCII maps directly (Note: 0x5C is '\' in ASCII, '¥' in JIS X 0201)
                sjisStr.push_back(static_cast<char>(codepoint));
            } else if (codepoint >= 0xFF61 && codepoint <= 0xFF9F) {
                // Half-width Katakana (U+FF61 - U+FF9F -> 0xA1 - 0xDF)
                sjisStr.push_back(static_cast<char>(codepoint - 0xFF61 + 0xA1));
            } else {
                // Full-width Kana / Kanji lookup
                auto it = unicodeToShiftJISMap.find(codepoint);
                if (it == unicodeToShiftJISMap.end()) {
                    throw std::runtime_error(fmt::format("Codepoint U+{:04X} cannot be represented in Shift-JIS", codepoint));
                }

                uint16_t sjisVal = it->second;
                sjisStr.push_back(static_cast<char>((sjisVal >> 8) & 0xFF)); // Lead byte
                sjisStr.push_back(static_cast<char>(sjisVal & 0xFF));        // Trail byte
            }
        }

        return sjisStr;
    }

    static void LoadTextData(TextDatabase& tb) {
        struct LanguageEntry {
            std::string language;
            std::string languageData;
        };
        auto files = std::to_array<LanguageEntry>({
            {"english",  GET_EMBED_DATA(RANDO_DATA_PATH "text/languages/english.yaml")},
            {"spanish",  GET_EMBED_DATA(RANDO_DATA_PATH "text/languages/spanish.yaml")},
            {"french",   GET_EMBED_DATA(RANDO_DATA_PATH "text/languages/french.yaml")},
            {"german",   GET_EMBED_DATA(RANDO_DATA_PATH "text/languages/german.yaml")},
            {"italian",  GET_EMBED_DATA(RANDO_DATA_PATH "text/languages/italian.yaml")},
            {"japanese", GET_EMBED_DATA(RANDO_DATA_PATH "text/languages/japanese.yaml")},
        });

        // Helper function for inserting the text
        auto insertTextIntoDB = [&tb](Text::Type type, const YAML::Node& typeData, Text::Language language, const std::string& name) {
            const auto& text = typeData["Text"].as<std::string>();
            auto& entry = tb[name][type].mEntries[language];
            if (language != Text::JAPANESE) {
                entry.str = UTF8ToCP1252(text);
            } else {
                entry.str = UTF8ToShiftJIS(text);
            }
            if (typeData["Gender"]) {
                entry.gender = stringToGender(typeData["Gender"].as<std::string>());
            }
            if (typeData["Plurality"]) {
                entry.plurality = stringToPlurality(typeData["Plurality"].as<std::string>());
            }
        };

        for (const auto& file : files) {
            auto language = stringToLanguage(file.language);
            auto textData = LOAD_EMBED_DATA(file.languageData);

            // Get names of all fields to verify for template overrides
            std::set<std::string> allKeys{};
            for (const auto& textNode : textData) {
                allKeys.insert(textNode.first.as<std::string>());
            }

            for (const auto& textNode : textData) {
                const auto& name = textNode.first.as<std::string>();
                for (const auto& typeNode : textNode.second) {
                    const auto& typeStr = typeNode.first.as<std::string>();
                    if (typeStr == "Template Overrides") {
                        continue;
                    }
                    auto type = stringToType(typeStr);
                    auto typeData = typeNode.second;
                    insertTextIntoDB(type, typeData, language, name);
                }

                if (textNode.second["Template Overrides"]) {
                    for (const auto& overrideNode : textNode.second["Template Overrides"]) {
                        YAMLVerifyFields(overrideNode, "Keys");
                        std::list<std::string> keys{};
                        for (const auto& keyNode : overrideNode["Keys"]) {
                            const auto& key = keyNode.as<std::string>();
                            if (!allKeys.contains(key)) {
                                throw std::runtime_error(name + " Template Override key \"" + key + "\" does not exist. Please check the spelling.");
                            }
                            keys.push_back(name + key);
                        }
                        for (const auto& typeNode : overrideNode) {
                            const auto& typeStr = typeNode.first.as<std::string>();
                            if (typeStr == "Keys") {
                                continue;
                            }
                            auto type = stringToType(typeStr);
                            auto typeData = typeNode.second;
                            for (const auto& key : keys) {
                                insertTextIntoDB(type, typeData, language, key);
                            }
                        }
                    }
                }
            }
        }
    }

    const TextDatabase& getTextDatabase() {
        static TextDatabase tb{};

        // Use a mutex here so that we can load up the text database on a separate thread if desired
        static std::mutex textDbMutex;
        std::lock_guard lock{textDbMutex};

        // If database is empty, load it up
        if (tb.empty()) {
            LoadTextData(tb);
        }

        return tb;
    }

    bool textObjectExists(const std::string& name) {
        return getTextDatabase().contains(name);
    }

    const Text& getTextObject(const std::string& name, Text::Type type /*= Text::STANDARD*/)
    {
        const auto& tb = getTextDatabase();
        if (!tb.contains(name)) {
            throw std::runtime_error("Text name \"" + name + "\" is not recognized.");
        }
        return tb.at(name).at(type);
    }

    Text getTextObjectForTemplate(const std::string& name, Text::Type type, const std::string& textTemplate) {
        auto text = getTextObject(name, type);
        auto nameTemplate = name + textTemplate;
        if (!textObjectExists(nameTemplate) || textTemplate.empty()) {
            return text;
        }

        const auto& templateText = getTextObject(nameTemplate, type);
        for (size_t i = 0; i < text.mEntries.size(); i++) {
            // If an override is found, copy over its entry
            if (!templateText.mEntries[i].str.empty()) {
                text.mEntries[i] = templateText.mEntries[i];
            }
        }

        return text;
    }

    const std::string& getTextStr(const std::string& name,
                        Text::Type type /*= Text::STANDARD*/,
                        Text::Language language /*= Text::ENGLISH*/)
    {
        const auto& tb = getTextDatabase();
        if (!tb.contains(name)) {
            throw std::runtime_error("Text name \"" + name + "\" is not recognized.");
        }

        if (!tb.at(name).at(type).mEntries.at(language).str.empty()) {
            return tb.at(name).at(type).mEntries.at(language).str;
        }

        // Return english if the other language's string is empty
        return tb.at(name).at(type).mEntries.at(language).str;
    }

    Text addColor(const Text& t, Text::Color color, int count /* = max*/) {
        const static std::unordered_map<Text::Color, std::string> colorStrings = {
            {Text::WHITE, "<white>"},
            {Text::RED, "<red>"},
            {Text::GREEN, "<green>"},
            {Text::LIGHT_BLUE, "<light blue>"},
            {Text::YELLOW, "<yellow>"},
            {Text::PURPLE, "<purple>"},
            {Text::ORANGE, "<orange>"},
            {Text::DARK_GREEN, "<dark green>"},
            {Text::BLUE, "<blue>"},
            {Text::SILVER, "<silver>"},
        };

        if (color == Text::Color::RAW) {
            return t;
        }

        if (!colorStrings.contains(color)) {
            throw std::runtime_error("Color enum value \"" + std::to_string(color) + "\" is not recognized.");
        }

        Text text = t;
        for (auto& entry : text.mEntries) {
            // If we don't have brackets indicating color, then surround the entire text
            if (entry.str.find('{') == std::string::npos && entry.str.find('}') == std::string::npos) {
                entry.str = colorStrings.at(color) + entry.str + colorStrings.at(Text::WHITE);
            } else {
                entry.str = utility::str::Replace(entry.str, "{", colorStrings.at(color), count);
                entry.str = utility::str::Replace(entry.str, "}", colorStrings.at(Text::WHITE), count);
            }
        }

        return text;
    }

    using namespace std::string_view_literals;
    static const std::unordered_map<std::string_view, std::string_view> messageCodes = {
        {"<player name>",    "\x1A\x05\x00\x00\x00"sv},
        {"<fast>",           "\x1A\x05\x00\x00\x01"sv},
        {"<slow>",           "\x1A\x05\x00\x00\x02"sv},
        {"<begin choice>",   "\x1A\x05\x00\x00\x20"sv},
        {"<char kyo>",       "\x1A\x05\x04\x00\x0A"sv}, // Special JP character
        {"<male>",           "\x1A\x05\x06\x00\x02"sv},
        {"<female>",         "\x1A\x05\x06\x00\x03"sv},
        {"<2 way choice 1>", "\x1A\x06\x00\x00\x08\x01"sv},
        {"<2 way choice 2>", "\x1A\x06\x00\x00\x08\x02"sv},
        {"<3 way choice 1>", "\x1A\x06\x00\x00\x09\x01"sv},
        {"<3 way choice 2>", "\x1A\x06\x00\x00\x09\x02"sv},
        {"<3 way choice 3>", "\x1A\x06\x00\x00\x09\x03"sv},
        {"<white>",          "\x1A\x06\xFF\x00\x00\x00"sv},
        {"<red>",            "\x1A\x06\xFF\x00\x00\x01"sv},
        {"<green>",          "\x1A\x06\xFF\x00\x00\x02"sv},
        {"<light blue>",     "\x1A\x06\xFF\x00\x00\x03"sv},
        {"<yellow>",         "\x1A\x06\xFF\x00\x00\x04"sv},
        {"<purple>",         "\x1A\x06\xFF\x00\x00\x06"sv},
        {"<orange>",         "\x1A\x06\xFF\x00\x00\x08"sv},
        {"<dark green>",     kDarkGreenMessageCode},
        {"<blue>",           kBlueMessageCode},
        {"<silver>",         kSilverMessageCode},
        // TODO: Custom font sizes
        {"<font size 48>",   "\x1A\x07\xFF\x00\x01\x00\x48"sv},
    };

    void breakLines(std::string& str, float maxStrLength, int lang) {
        // Randomizer Only shouldn't rely on needing access to the iso
    #ifndef RANDOMIZER_ONLY
        // Get game's font
        auto gameFont = mDoExt_getMesgFont();
    #endif

        float curLineWidth = 0.f;
        size_t i = 0;
        size_t lastBreakOpportunity = 0;

        // Check if a byte is a Shift-JIS lead byte
        auto isSJISLeadByte = [&](uint8_t c) {
            return ((c >= 0x81 && c <= 0x9F) || (c >= 0xE0 && c <= 0xFC)) && lang == Text::JAPANESE;
        };

        // Check if a Shift-JIS 2-byte character is a prohibited line-start character
        auto isProhibitedLineStart = [](uint16_t sjisChar) {
            switch (sjisChar) {
                case 0x8141: // 、 (Comma)
                case 0x8142: // 。 (Period)
                case 0x8143: // ,
                case 0x8144: // .
                case 0x8168: // 」 (Closing Quote)
                case 0x816A: // 』
                case 0x816C: // ） (Closing Paren)
                case 0x816E: // ］
                case 0x8170: // ｝
                case 0x815B: // ー (Katakana Prolonged Sound Mark)
                case 0x8145: // ・ (Middle Dot)
                case 0x8148: // ?
                case 0x8149: // !
                    return true;
                default:
                    return false;
            }
        };

        while (i < str.length()) {
            // Skip over control codes since they don't get displayed
            std::string code{};
            for (const auto& messageCode : messageCodes | std::views::keys) {
                if (str.substr(i, messageCode.length()) == messageCode) {
                    code = messageCode;
                    break;
                }
            }

            if (!code.empty()) {
                // Assume worst case for player name width.
                if (code == "<player name>") {
                    curLineWidth += 8.f;
                }
                i += code.length();
                continue;
            }

            uint8_t c1 = static_cast<uint8_t>(str[i]);

            // If we encounter an already inserted newline, reset the counter
            if (c1 == '\n') {
                curLineWidth = 0.f;
                ++i;
                lastBreakOpportunity = i;
                continue;
            }

            uint16_t sjisChar = c1;
            size_t charLen = 1;

            if (isSJISLeadByte(c1) && (i + 1 < str.length())) {
                uint8_t c2 = static_cast<uint8_t>(str[i + 1]);
                sjisChar = (static_cast<uint16_t>(c1) << 8) | c2;
                charLen = 2;
            }

            // Keep track of the previous space to replace with
            // a line break when we reach the maximum width. For Japanese,
            // we can insert a newline anywhere we don't have a prohibited
            // line start character
            if (c1 == ' ') {
                lastBreakOpportunity = i;
            } else if (charLen == 2 && !isProhibitedLineStart(sjisChar)) {
                // In Japanese, every character boundary is a potential line break (unless prohibited by punctuation)
                lastBreakOpportunity = i;
            }

    #ifndef RANDOMIZER_ONLY
            float width = static_cast<float>(gameFont->getWidth(sjisChar));
            curLineWidth += width / static_cast<float>(gameFont->getCellWidth());
    #else
            // Assume worst case with no iso access
            curLineWidth += (charLen == 2) ? 2.f : 1.f;
    #endif

            // If we exceed the maximum line width, replace the
            // previous space with a newline and start counting
            // from the newline again
            if (curLineWidth > maxStrLength && lastBreakOpportunity > 0) {
                if (str[lastBreakOpportunity] == ' ') {
                    str[lastBreakOpportunity] = '\n';
                    i = lastBreakOpportunity + 1;
                } else {
                    // Insert a newline directly between Japanese characters
                    str.insert(lastBreakOpportunity, "\n");
                    i = lastBreakOpportunity + 1;
                }
                curLineWidth = 0.f;
                lastBreakOpportunity = 0;
                continue;
            }

            i += charLen;
        }

    #ifndef RANDOMIZER_ONLY
        mDoExt_removeMesgFont();
    #endif
    }

    void applyMessageCodes(std::string& str) {
        for (const auto& [code, replacement] : messageCodes) {
            size_t pos = 0;
            while ((pos = str.find(code, pos)) != std::string::npos) {
                str.replace(pos, code.length(), replacement);
                pos += replacement.length();
            }
        }
    }

    Text makeTextListing(std::vector<Text> texts) {
        if (texts.empty()) {
            return Text{};
        }
        if (texts.size() == 1) {
            return texts.front();
        }

        // TODO: Other language listing rules
        std::string english{};
        std::string french{};
        std::string german{};
        std::string italian{};
        std::string spanish{};
        std::string japanese{};
        for (int i = 0; i < texts.size(); ++i) {
            auto& text = texts[i];

            // English rules. Move other languages out of english when we have their rules
            if (i == 0) {
                english += text.mEntries[Text::ENGLISH].str;
                french += text.mEntries[Text::FRENCH].str;
                german += text.mEntries[Text::GERMAN].str;
                italian += text.mEntries[Text::ITALIAN].str;
                spanish += text.mEntries[Text::SPANISH].str;
                japanese += text.mEntries[Text::JAPANESE].str;
            } else if (i == texts.size() - 1 && texts.size() == 2) {
                english += " and " + text.mEntries[Text::ENGLISH].str;
                french += " and " + text.mEntries[Text::FRENCH].str;
                german += " and " + text.mEntries[Text::GERMAN].str;
                italian += " and " + text.mEntries[Text::ITALIAN].str;
                spanish += " and " + text.mEntries[Text::SPANISH].str;
                japanese += " and " + text.mEntries[Text::JAPANESE].str;
            } else if (i == texts.size() - 1) {
                english += ", and " + text.mEntries[Text::ENGLISH].str;
                french += ", and " + text.mEntries[Text::FRENCH].str;
                german += ", and " + text.mEntries[Text::GERMAN].str;
                italian += ", and " + text.mEntries[Text::ITALIAN].str;
                spanish += ", and " + text.mEntries[Text::SPANISH].str;
                japanese += ", and " + text.mEntries[Text::JAPANESE].str;
            } else {
                english += ", " + text.mEntries[Text::ENGLISH].str;
                french += ", " + text.mEntries[Text::FRENCH].str;
                german += ", " + text.mEntries[Text::GERMAN].str;
                italian += ", " + text.mEntries[Text::ITALIAN].str;
                spanish += ", " + text.mEntries[Text::SPANISH].str;
                japanese += ", " + text.mEntries[Text::JAPANESE].str;
            }
        }

        Text listingText{};
        listingText.mEntries[Text::ENGLISH].str = english;
        listingText.mEntries[Text::FRENCH].str = french;
        listingText.mEntries[Text::GERMAN].str = german;
        listingText.mEntries[Text::ITALIAN].str = italian;
        listingText.mEntries[Text::SPANISH].str = spanish;
        listingText.mEntries[Text::JAPANESE].str = japanese;
        return listingText;
    }

    int findFirstNonMessageCodeIndex(const std::string& str) {
        bool messageCode{};
        int index = 0;
        do {
            messageCode = false;
            for (const auto& code : messageCodes | std::views::keys) {
                if (str.substr(index).starts_with(code)) {
                    index += static_cast<int>(code.size());
                    messageCode = true;
                    break;
                }
            }
        } while (messageCode);

        return index;
    }
}; // namespace Text
