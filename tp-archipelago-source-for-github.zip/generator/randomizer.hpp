#pragma once

#include "logic/world.hpp"

#include <optional>
#include <string>
#include <unordered_map>
#include <vector>

namespace randomizer
{
    // Set while generating the local half of an Archipelago seed. The multiworld has already
    // decided every item and verified logic, so in this mode:
    //  - every location the multiworld owns is plandomized (own items by name, other worlds'
    //    items as the "Archipelago Item" placeholder),
    //  - every location the generator would shuffle but the multiworld does not own keeps its
    //    vanilla item,
    //  - local logic verification and filling are skipped, since other worlds' items are opaque
    //    here (see World::PlacePlandomizerItems, fill::FillWorlds, entrance shuffle validation).
    // Only touched by the thread that generates; set it before Generate() and clear it after.
    inline bool g_archipelagoMode = false;

    // Filled by World::PlacePlandomizerItems in Archipelago mode: plando entries that were
    // skipped because the generator already considers that location vanilla under the current
    // settings (for example a shop slot with Shop Items off). The mod patches those at runtime.
    inline std::vector<std::string> g_archipelagoSkippedPlando{};

    // Set before Generate() in Archipelago mode: for a location holding another world's item, the
    // words that name it ("Alice's Hookshot") in the texts that name the item at that location (the
    // shop shelves and the like). Locations not in the map keep the placeholder's own name.
    inline std::unordered_map<std::string, std::string> g_archipelagoItemLabels{};

    class Randomizer
    {
    public:
        Randomizer() = delete;
        Randomizer(const std::filesystem::path& baseOutputPath) : _baseOutputPath(baseOutputPath) {}

        /**
         *  @brief Generates a complete randomizer seed
         *
         *  @return a std::optional<std::string> containing a message if there was an error.
         */
        std::optional<std::string> Generate();
        void GenerateWorlds();
        void GenerateTrackerWorld();

        auto& GetConfig() { return this->_config; }
        auto& GetWorlds() { return this->_worlds; }
        /**
         * @param worldId
         * @return The world with the specified Id. If no Id is specified, the first world will
         * be returned. If a world with the Id does not exist, a nullptr will be returned.
         */
        logic::world::World* GetWorld(int worldId = 1);

        int GetNewEventID() { return ++(this->_eventIdCounter); }
        int GetNewAreaID() { return ++(this->_areaIdCounter); }
        int GetNewLocAccID() { return ++(this->_locAccIdCounter); }

        auto& GetPlaythroughSpheres() { return this->_playthroughSpheres; }
        auto& GetEntranceSpheres() { return this->_entranceSpheres; }

        std::filesystem::path GetSeedOutputPath();
        std::filesystem::path GetBaseOutputPath() const { return this->_baseOutputPath; };
        void SetBaseOutputPath(const std::filesystem::path& path) { this->_baseOutputPath = path; };

        std::filesystem::path GetConfigPath() const { return this->GetBaseOutputPath() / "settings.yaml"; }
        std::filesystem::path GetPrefPath() const { return this->GetBaseOutputPath() / "preferences.yaml"; }
    private:
        seedgen::config::Config _config{};
        logic::world::WorldPool _worlds{};

        int _eventIdCounter{};
        int _areaIdCounter{};
        int _locAccIdCounter{};

        // Playthrough data
        std::list<std::list<logic::location::Location*>> _playthroughSpheres{};
        std::list<std::list<logic::entrance::Entrance*>> _entranceSpheres{};

        std::filesystem::path _baseOutputPath{};
    };
} // namespace randomizer
